"""Tests for emoji notifications functionality."""

import pytest
from datetime import date
from app.database import reset_db
from app.event_service import create_event, delete_event
from app.models import EventCreate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_event_creation_notification_content(new_db):
    """Test that event creation logic works correctly (business logic test)."""
    event_data = EventCreate(title="Test Event", date=date.today(), description="Test description")

    created_event = create_event(event_data)

    # Verify the event was created successfully
    assert created_event.id is not None
    assert created_event.title == "Test Event"

    # In the UI, this would trigger: 🎉 Event "Test Event" created successfully!
    expected_notification = f'🎉 Event "{created_event.title}" created successfully!'
    assert "🎉" in expected_notification
    assert created_event.title in expected_notification


def test_event_deletion_notification_content(new_db):
    """Test that event deletion logic works correctly (business logic test)."""
    # Create event first
    event_data = EventCreate(title="Event to Delete", date=date.today())
    created_event = create_event(event_data)

    # Delete the event
    assert created_event.id is not None
    result = delete_event(created_event.id)

    # Verify deletion was successful
    assert result is True

    # In the UI, this would trigger: 🗑️ Event "Event to Delete" deleted successfully
    expected_notification = f'🗑️ Event "{created_event.title}" deleted successfully'
    assert "🗑️" in expected_notification
    assert created_event.title in expected_notification


def test_warning_notification_content():
    """Test warning notification content for empty title."""
    # This would be triggered when title is empty
    expected_notification = "⚠️ Please enter an event title"
    assert "⚠️" in expected_notification
    assert "Please enter an event title" in expected_notification


def test_date_validation_notification_content():
    """Test warning notification content for invalid date."""
    # This would be triggered when date is invalid
    expected_notification = "⚠️ Please select a valid date"
    assert "⚠️" in expected_notification
    assert "Please select a valid date" in expected_notification


def test_error_notification_content():
    """Test error notification content format."""
    error_message = "Database connection failed"
    expected_notification = f"❌ Error creating event: {error_message}"
    assert "❌" in expected_notification
    assert error_message in expected_notification


def test_failed_deletion_notification_content():
    """Test error notification for failed deletion."""
    expected_notification = "⚠️ Failed to delete event"
    assert "⚠️" in expected_notification
    assert "Failed to delete event" in expected_notification


def test_emoji_notifications_have_proper_emojis():
    """Test that all notification messages contain appropriate emojis."""
    notifications = {
        "success_create": "🎉",
        "success_delete": "🗑️",
        "warning_title": "⚠️",
        "warning_date": "⚠️",
        "error_create": "❌",
        "error_delete": "⚠️",
    }

    # Verify all expected emojis are different where appropriate
    assert notifications["success_create"] != notifications["success_delete"]
    assert notifications["success_create"] == "🎉"  # Party emoji for success
    assert notifications["success_delete"] == "🗑️"  # Trash emoji for delete
    assert notifications["warning_title"] == "⚠️"  # Warning emoji
    assert notifications["error_create"] == "❌"  # X emoji for errors
