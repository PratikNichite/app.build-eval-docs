import pytest
from datetime import date, timedelta
from app.event_service import create_event, get_all_events, get_event_by_id, delete_event, update_event
from app.models import EventCreate, EventUpdate
from app.database import reset_db


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_create_event(new_db):
    """Test creating a new event."""
    event_data = EventCreate(title="Test Event", date=date.today(), description="This is a test event")

    created_event = create_event(event_data)

    assert created_event.id is not None
    assert created_event.title == "Test Event"
    assert created_event.date == date.today()
    assert created_event.description == "This is a test event"
    assert created_event.created_at is not None


def test_create_event_without_description(new_db):
    """Test creating an event without description."""
    event_data = EventCreate(title="No Description Event", date=date.today())

    created_event = create_event(event_data)

    assert created_event.id is not None
    assert created_event.title == "No Description Event"
    assert created_event.description == ""


def test_get_all_events_empty(new_db):
    """Test getting all events when database is empty."""
    events = get_all_events()
    assert events == []


def test_get_all_events_with_data(new_db):
    """Test getting all events with data in database."""
    # Create test events
    today = date.today()
    tomorrow = today + timedelta(days=1)
    yesterday = today - timedelta(days=1)

    create_event(EventCreate(title="Event 1", date=today, description="First"))
    create_event(EventCreate(title="Event 2", date=tomorrow, description="Second"))
    create_event(EventCreate(title="Event 3", date=yesterday, description="Third"))

    events = get_all_events()

    assert len(events) == 3
    # Should be ordered by date descending
    assert events[0].date == tomorrow  # Most recent first
    assert events[1].date == today
    assert events[2].date == yesterday


def test_get_event_by_id_exists(new_db):
    """Test getting an event by ID when it exists."""
    event_data = EventCreate(title="Test Event", date=date.today(), description="Test description")
    created_event = create_event(event_data)

    event_id = created_event.id
    assert event_id is not None

    retrieved_event = get_event_by_id(event_id)

    assert retrieved_event is not None
    assert retrieved_event.id == created_event.id
    assert retrieved_event.title == "Test Event"


def test_get_event_by_id_not_exists(new_db):
    """Test getting an event by ID when it doesn't exist."""
    retrieved_event = get_event_by_id(999)
    assert retrieved_event is None


def test_delete_event_exists(new_db):
    """Test deleting an event that exists."""
    event_data = EventCreate(title="To Delete", date=date.today(), description="Will be deleted")
    created_event = create_event(event_data)

    # Verify event exists
    event_id = created_event.id
    assert event_id is not None
    assert get_event_by_id(event_id) is not None

    # Delete event
    result = delete_event(event_id)
    assert result is True

    # Verify event is gone
    assert get_event_by_id(event_id) is None


def test_delete_event_not_exists(new_db):
    """Test deleting an event that doesn't exist."""
    result = delete_event(999)
    assert result is False


def test_update_event_exists(new_db):
    """Test updating an existing event."""
    # Create initial event
    event_data = EventCreate(title="Original Title", date=date.today(), description="Original description")
    created_event = create_event(event_data)

    # Update event
    assert created_event.id is not None
    update_data = EventUpdate(title="Updated Title", description="Updated description")
    updated_event = update_event(created_event.id, update_data)

    assert updated_event is not None
    assert updated_event.id == created_event.id
    assert updated_event.title == "Updated Title"
    assert updated_event.description == "Updated description"
    assert updated_event.date == date.today()  # Unchanged


def test_update_event_partial(new_db):
    """Test partial update of an event."""
    # Create initial event
    event_data = EventCreate(title="Original Title", date=date.today(), description="Original description")
    created_event = create_event(event_data)

    # Update only title
    assert created_event.id is not None
    update_data = EventUpdate(title="New Title Only")
    updated_event = update_event(created_event.id, update_data)

    assert updated_event is not None
    assert updated_event.title == "New Title Only"
    assert updated_event.description == "Original description"  # Unchanged
    assert updated_event.date == date.today()  # Unchanged


def test_update_event_not_exists(new_db):
    """Test updating an event that doesn't exist."""
    update_data = EventUpdate(title="Won't work")
    result = update_event(999, update_data)
    assert result is None


def test_event_date_validation(new_db):
    """Test that events can handle various date values."""
    # Test past date
    past_date = date.today() - timedelta(days=365)
    past_event = create_event(EventCreate(title="Past Event", date=past_date))
    assert past_event.date == past_date

    # Test future date
    future_date = date.today() + timedelta(days=365)
    future_event = create_event(EventCreate(title="Future Event", date=future_date))
    assert future_event.date == future_date


def test_event_title_edge_cases(new_db):
    """Test event creation with various title formats."""
    # Empty string should still work (model validation will handle constraints)
    test_cases = [
        "Short",
        "A" * 200,  # Max length
        "Event with special chars: !@#$%^&*()",
        "Event\nwith\nnewlines",
    ]

    for title in test_cases:
        event_data = EventCreate(title=title, date=date.today())
        created_event = create_event(event_data)
        assert created_event.title == title


def test_multiple_events_same_date(new_db):
    """Test creating multiple events on the same date."""
    same_date = date.today()

    create_event(EventCreate(title="Event 1", date=same_date))
    create_event(EventCreate(title="Event 2", date=same_date))
    create_event(EventCreate(title="Event 3", date=same_date))

    events = get_all_events()
    assert len(events) == 3

    # All should have the same date
    for event in events:
        assert event.date == same_date

    # But different IDs and titles
    titles = [event.title for event in events]
    assert "Event 1" in titles
    assert "Event 2" in titles
    assert "Event 3" in titles
