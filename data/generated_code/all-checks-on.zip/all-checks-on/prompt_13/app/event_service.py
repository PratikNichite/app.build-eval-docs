from sqlmodel import select, desc
from app.database import get_session
from app.models import Event, EventCreate, EventUpdate
from typing import Optional


def create_event(event_data: EventCreate) -> Event:
    """Create a new event in the database."""
    with get_session() as session:
        event = Event(title=event_data.title, date=event_data.date, description=event_data.description)
        session.add(event)
        session.commit()
        session.refresh(event)
        return event


def get_all_events() -> list[Event]:
    """Retrieve all events from the database, ordered by date."""
    with get_session() as session:
        statement = select(Event).order_by(desc(Event.date), desc(Event.created_at))
        events = session.exec(statement).all()
        return list(events)


def get_event_by_id(event_id: int) -> Optional[Event]:
    """Retrieve a specific event by ID."""
    with get_session() as session:
        event = session.get(Event, event_id)
        return event


def delete_event(event_id: int) -> bool:
    """Delete an event by ID. Returns True if successful, False if event not found."""
    with get_session() as session:
        event = session.get(Event, event_id)
        if event is None:
            return False
        session.delete(event)
        session.commit()
        return True


def update_event(event_id: int, event_data: EventUpdate) -> Optional[Event]:
    """Update an existing event. Returns updated event or None if not found."""
    with get_session() as session:
        event = session.get(Event, event_id)
        if event is None:
            return None

        update_data = event_data.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(event, field, value)

        session.add(event)
        session.commit()
        session.refresh(event)
        return event
