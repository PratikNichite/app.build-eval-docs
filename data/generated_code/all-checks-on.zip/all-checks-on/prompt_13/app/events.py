from nicegui import ui
from app.event_service import create_event, get_all_events, delete_event
from app.models import EventCreate
from datetime import date


class TextStyles:
    HEADING = "text-2xl font-bold text-gray-800 mb-4"
    SUBHEADING = "text-lg font-semibold text-gray-700 mb-2"
    BODY = "text-base text-gray-600 leading-relaxed"
    CAPTION = "text-sm text-gray-500"


def apply_modern_theme():
    ui.colors(
        primary="#2563eb",  # Professional blue
        secondary="#64748b",  # Subtle gray
        accent="#10b981",  # Success green
        positive="#10b981",
        negative="#ef4444",  # Error red
        warning="#f59e0b",  # Warning amber
        info="#3b82f6",  # Info blue
    )


def create_event_card(event, on_delete_callback):
    """Create a modern event card with delete functionality."""
    with ui.card().classes("p-6 bg-white shadow-lg rounded-xl hover:shadow-xl transition-shadow mb-4"):
        with ui.row().classes("w-full justify-between items-start"):
            with ui.column().classes("flex-1"):
                ui.label(event.title).classes("text-xl font-bold text-gray-800 mb-2")
                ui.label(f"📅 {event.date.strftime('%B %d, %Y')}").classes("text-blue-600 font-medium mb-2")
                if event.description:
                    ui.label(event.description).classes("text-gray-600 leading-relaxed")
                else:
                    ui.label("No description provided").classes("text-gray-400 italic")

            # Delete button
            ui.button("🗑️", on_click=lambda: confirm_delete_event(event, on_delete_callback)).classes(
                "bg-red-500 hover:bg-red-600 text-white w-10 h-10 rounded-full shadow-md"
            ).props("flat")


async def confirm_delete_event(event, on_delete_callback):
    """Show confirmation dialog before deleting an event."""
    with ui.dialog() as dialog, ui.card():
        ui.label(f'Delete "{event.title}"?').classes("text-lg font-bold mb-4")
        ui.label("This action cannot be undone.").classes("text-gray-600 mb-4")

        with ui.row().classes("gap-2 justify-end"):
            ui.button("Cancel", on_click=lambda: dialog.submit(False)).props("outline")
            ui.button("Delete", on_click=lambda: dialog.submit(True)).classes("bg-red-500 text-white")

    result = await dialog
    if result:
        if delete_event(event.id):
            ui.notify(f'🗑️ Event "{event.title}" deleted successfully', type="positive")
            on_delete_callback()
        else:
            ui.notify("⚠️ Failed to delete event", type="negative")


def create():
    apply_modern_theme()

    @ui.page("/")
    async def index():
        # Page header
        with ui.row().classes("w-full justify-between items-center mb-8"):
            ui.label("Event Tracker").classes("text-3xl font-bold text-gray-800")
            ui.button("+ Add Event", on_click=lambda: show_add_event_form()).classes(
                "bg-primary text-white px-6 py-3 rounded-lg shadow-md hover:shadow-lg font-semibold"
            )

        # Events container
        events_container = ui.column().classes("w-full max-w-4xl mx-auto")

        def refresh_events():
            """Refresh the events list."""
            events_container.clear()
            events = get_all_events()

            if not events:
                with events_container:
                    with ui.card().classes(
                        "p-8 text-center bg-gray-50 border-dashed border-2 border-gray-300 rounded-xl"
                    ):
                        ui.label("📅").classes("text-4xl mb-4")
                        ui.label("No events yet").classes("text-xl font-semibold text-gray-600 mb-2")
                        ui.label("Add your first event to get started!").classes("text-gray-500")
            else:
                with events_container:
                    ui.label(f"{len(events)} Event{'s' if len(events) != 1 else ''}").classes(TextStyles.SUBHEADING)
                    for event in events:
                        create_event_card(event, refresh_events)

        async def show_add_event_form():
            """Show the add event form dialog."""
            with ui.dialog() as dialog, ui.card().classes("w-96"):
                ui.label("Add New Event").classes("text-xl font-bold mb-6")

                # Form fields
                ui.label("Event Title").classes("text-sm font-medium text-gray-700 mb-1")
                title_input = ui.input(placeholder="Enter event title").classes("w-full mb-4")

                ui.label("Event Date").classes("text-sm font-medium text-gray-700 mb-1")
                date_input = ui.date(value=date.today().isoformat()).classes("w-full mb-4")

                ui.label("Description (Optional)").classes("text-sm font-medium text-gray-700 mb-1")
                description_input = ui.textarea(placeholder="Event description").classes("w-full mb-4").props("rows=3")

                def submit_event():
                    """Handle form submission."""
                    title = title_input.value.strip()
                    if not title:
                        ui.notify("⚠️ Please enter an event title", type="warning")
                        return

                    try:
                        event_date = date.fromisoformat(date_input.value)
                        event_data = EventCreate(
                            title=title, date=event_date, description=description_input.value.strip()
                        )

                        created_event = create_event(event_data)
                        ui.notify(f'🎉 Event "{created_event.title}" created successfully!', type="positive")
                        dialog.submit(True)
                        refresh_events()

                    except ValueError:
                        ui.notify("⚠️ Please select a valid date", type="warning")
                    except Exception as e:
                        ui.notify(f"❌ Error creating event: {str(e)}", type="negative")

                # Action buttons
                with ui.row().classes("gap-2 justify-end"):
                    ui.button("Cancel", on_click=lambda: dialog.submit(False)).props("outline")
                    ui.button("Create Event", on_click=submit_event).classes("bg-primary text-white")

            await dialog

        # Initial load of events
        refresh_events()

        # Add some styling to the page
        ui.add_head_html("""
        <style>
            body {
                background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                min-height: 100vh;
            }
            .nicegui-content {
                padding: 2rem;
            }
        </style>
        """)
