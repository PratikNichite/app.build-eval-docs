import pytest
from app.database import reset_db
from app.weather_service import WeatherService


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


class TestWeatherServiceIntegrationUI:
    """Integration tests between UI and WeatherService."""

    @pytest.mark.asyncio
    async def test_end_to_end_weather_flow(self, new_db):
        """Test end-to-end weather forecast flow."""
        # Create a forecast directly via service
        forecast = await WeatherService.get_weather_forecast("Berlin")

        if forecast is not None:  # Only test if API is working
            assert forecast.city_name == "Berlin"
            assert forecast.id is not None

            # Check it appears in recent forecasts
            recent = WeatherService.get_recent_forecasts(1)
            assert len(recent) == 1
            assert recent[0].city_name == "Berlin"

    def test_trip_suggestion_logic_consistency(self):
        """Test that trip suggestion logic is consistent across service and UI."""
        # Test various scenarios to ensure UI would display correct recommendations
        test_cases = [
            (20, 0, True),  # Perfect weather
            (10, 0, False),  # Too cold
            (30, 0, False),  # Too hot
            (20, 10, False),  # Too much rain
            (15, 2, True),  # Boundary case - good
            (25, 4.9, True),  # Boundary case - good
        ]

        for max_temp, precipitation, expected_good in test_cases:
            from decimal import Decimal

            is_good, reason = WeatherService.evaluate_trip_suggestion(
                Decimal(str(max_temp)), Decimal(str(precipitation))
            )
            assert is_good == expected_good, f"Failed for temp={max_temp}, precip={precipitation}: {reason}"
