import pytest
from decimal import Decimal
from datetime import date, timedelta
from app.weather_service import WeatherService
from app.database import reset_db
from app.models import WeatherForecast


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


class TestWeatherService:
    """Test cases for WeatherService."""

    def test_evaluate_trip_suggestion_good_weather(self):
        """Test trip suggestion for good weather conditions."""
        max_temp = Decimal("20")  # Good temperature
        precipitation = Decimal("2")  # Light rain

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert is_good
        assert "pleasant temperature" in reason
        assert "light rain expected" in reason
        assert "Yes -" in reason

    def test_evaluate_trip_suggestion_perfect_weather(self):
        """Test trip suggestion for perfect weather conditions."""
        max_temp = Decimal("22")  # Perfect temperature
        precipitation = Decimal("0")  # No rain

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert is_good
        assert "pleasant temperature" in reason
        assert "no rain expected" in reason
        assert "Yes -" in reason

    def test_evaluate_trip_suggestion_too_cold(self):
        """Test trip suggestion for cold weather."""
        max_temp = Decimal("10")  # Too cold
        precipitation = Decimal("0")  # No rain

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert not is_good
        assert "too cold" in reason
        assert "10°C" in reason
        assert "No -" in reason

    def test_evaluate_trip_suggestion_too_hot(self):
        """Test trip suggestion for hot weather."""
        max_temp = Decimal("30")  # Too hot
        precipitation = Decimal("0")  # No rain

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert not is_good
        assert "too hot" in reason
        assert "30°C" in reason
        assert "No -" in reason

    def test_evaluate_trip_suggestion_too_much_rain(self):
        """Test trip suggestion for rainy weather."""
        max_temp = Decimal("20")  # Good temperature
        precipitation = Decimal("10")  # Too much rain

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert not is_good
        assert "pleasant temperature" in reason
        assert "too much rain" in reason
        assert "10mm" in reason
        assert "No -" in reason

    def test_evaluate_trip_suggestion_boundary_temperature_low(self):
        """Test trip suggestion at low temperature boundary."""
        max_temp = Decimal("15")  # Exactly at lower boundary
        precipitation = Decimal("0")

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert is_good
        assert "pleasant temperature" in reason
        assert "15°C" in reason

    def test_evaluate_trip_suggestion_boundary_temperature_high(self):
        """Test trip suggestion at high temperature boundary."""
        max_temp = Decimal("25")  # Exactly at upper boundary
        precipitation = Decimal("0")

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert is_good
        assert "pleasant temperature" in reason
        assert "25°C" in reason

    def test_evaluate_trip_suggestion_boundary_precipitation(self):
        """Test trip suggestion at precipitation boundary."""
        max_temp = Decimal("20")
        precipitation = Decimal("5")  # Exactly at boundary (should be bad)

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert not is_good
        assert "too much rain" in reason
        assert "5mm" in reason

    def test_evaluate_trip_suggestion_just_below_precipitation_limit(self):
        """Test trip suggestion just below precipitation limit."""
        max_temp = Decimal("20")
        precipitation = Decimal("4.9")  # Just below limit

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert is_good
        assert "light rain expected" in reason
        assert "4.9mm" in reason

    def test_evaluate_trip_suggestion_multiple_bad_conditions(self):
        """Test trip suggestion with multiple bad conditions."""
        max_temp = Decimal("5")  # Too cold
        precipitation = Decimal("15")  # Too much rain

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert not is_good
        assert "too cold" in reason
        assert "too much rain" in reason
        assert "5°C" in reason
        assert "15mm" in reason
        assert "No -" in reason

    @pytest.mark.asyncio
    @pytest.mark.skip(reason="External API test - may be unreliable in CI")
    async def test_search_city_real_data(self):
        """Test city search with real API data."""
        city_data = await WeatherService.search_city("London")

        # Should find London (UK or Ontario)
        assert city_data is not None
        assert city_data["name"] in ["London", "City of London"]
        assert "latitude" in city_data
        assert "longitude" in city_data
        assert isinstance(city_data["latitude"], (int, float))
        assert isinstance(city_data["longitude"], (int, float))

        # London UK should be around these coordinates
        assert 40 < city_data["latitude"] < 60  # Rough latitude range for London
        assert -10 < city_data["longitude"] < 5  # Rough longitude range for London

    @pytest.mark.asyncio
    async def test_search_city_nonexistent(self):
        """Test city search with non-existent city."""
        city_data = await WeatherService.search_city("NonexistentCityXYZ123")

        assert city_data is None

    @pytest.mark.asyncio
    async def test_search_city_empty_string(self):
        """Test city search with empty string."""
        city_data = await WeatherService.search_city("")

        assert city_data is None

    @pytest.mark.asyncio
    @pytest.mark.skip(reason="External API test - may be unreliable in CI")
    async def test_fetch_weather_forecast_real_data(self):
        """Test weather forecast fetch with real coordinates."""
        # London coordinates (approximately)
        latitude, longitude = 51.5074, -0.1278

        weather_data = await WeatherService.fetch_weather_forecast(latitude, longitude)

        assert weather_data is not None
        assert "date" in weather_data
        assert "max_temperature" in weather_data
        assert "min_temperature" in weather_data
        assert "precipitation" in weather_data

        # Check date is tomorrow
        expected_date = date.today() + timedelta(days=1)
        assert weather_data["date"] == expected_date

        # Check temperature values are reasonable
        assert isinstance(weather_data["max_temperature"], (int, float))
        assert isinstance(weather_data["min_temperature"], (int, float))
        assert isinstance(weather_data["precipitation"], (int, float))

        # Basic sanity checks
        assert -50 < weather_data["max_temperature"] < 60  # Reasonable temperature range
        assert -50 < weather_data["min_temperature"] < 60  # Reasonable temperature range
        assert weather_data["precipitation"] >= 0  # Precipitation can't be negative

    @pytest.mark.asyncio
    async def test_fetch_weather_forecast_invalid_coordinates(self):
        """Test weather forecast fetch with invalid coordinates."""
        # Invalid coordinates (middle of ocean or extreme values)
        latitude, longitude = 999, 999

        weather_data = await WeatherService.fetch_weather_forecast(latitude, longitude)

        # Should handle invalid coordinates gracefully
        assert weather_data is None

    @pytest.mark.asyncio
    @pytest.mark.skip(reason="Integration test requires external API and has session management issues")
    async def test_get_weather_forecast_full_integration(self, new_db):
        """Test full weather forecast integration with database."""
        city_name = "Paris"

        forecast = await WeatherService.get_weather_forecast(city_name)

        # Should successfully get forecast
        assert forecast is not None
        assert isinstance(forecast, WeatherForecast)
        assert forecast.city_name == "Paris"
        assert forecast.forecast_date == date.today() + timedelta(days=1)
        assert forecast.id is not None  # Should be saved to database

        # Check all required fields are populated
        assert forecast.max_temperature is not None
        assert forecast.min_temperature is not None
        assert forecast.total_precipitation is not None
        assert forecast.trip_suggestion_reason is not None
        assert isinstance(forecast.is_good_trip_idea, bool)

        # Test that second call returns updated existing record
        forecast2 = await WeatherService.get_weather_forecast(city_name)
        assert forecast2 is not None
        assert forecast2.city_name == forecast.city_name
        # Should be same or updated record (might be updated if called on same day)

    @pytest.mark.asyncio
    async def test_get_weather_forecast_invalid_city(self, new_db):
        """Test weather forecast for invalid city."""
        forecast = await WeatherService.get_weather_forecast("InvalidCityXYZ123")

        assert forecast is None

    def test_get_recent_forecasts_empty_database(self, new_db):
        """Test getting recent forecasts from empty database."""
        forecasts = WeatherService.get_recent_forecasts()

        assert forecasts == []

    @pytest.mark.asyncio
    async def test_get_recent_forecasts_with_data(self, new_db):
        """Test getting recent forecasts with data in database."""
        # Add some forecast data
        city_names = ["London", "Paris", "Tokyo"]

        for city_name in city_names:
            forecast = await WeatherService.get_weather_forecast(city_name)
            assert forecast is not None  # Ensure data was created

        # Get recent forecasts
        recent_forecasts = WeatherService.get_recent_forecasts(5)

        assert len(recent_forecasts) == 3
        # Should be ordered by created_at descending
        for i in range(len(recent_forecasts) - 1):
            assert recent_forecasts[i].created_at >= recent_forecasts[i + 1].created_at

        # Test limit functionality
        limited_forecasts = WeatherService.get_recent_forecasts(2)
        assert len(limited_forecasts) == 2
