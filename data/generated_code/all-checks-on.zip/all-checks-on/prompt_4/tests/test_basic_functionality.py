"""Basic functionality tests to ensure application works."""

import pytest
from decimal import Decimal
from app.weather_service import WeatherService
from app.database import reset_db


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_weather_service_logic():
    """Test the core weather evaluation logic."""
    # Good weather
    is_good, reason = WeatherService.evaluate_trip_suggestion(Decimal("20"), Decimal("0"))
    assert is_good
    assert "Yes -" in reason

    # Bad weather - too cold
    is_good, reason = WeatherService.evaluate_trip_suggestion(Decimal("5"), Decimal("0"))
    assert not is_good
    assert "No -" in reason
    assert "too cold" in reason

    # Bad weather - too hot
    is_good, reason = WeatherService.evaluate_trip_suggestion(Decimal("35"), Decimal("0"))
    assert not is_good
    assert "No -" in reason
    assert "too hot" in reason

    # Bad weather - too rainy
    is_good, reason = WeatherService.evaluate_trip_suggestion(Decimal("20"), Decimal("10"))
    assert not is_good
    assert "No -" in reason
    assert "too much rain" in reason


def test_database_operations(new_db):
    """Test basic database functionality."""
    # Test that we can get empty forecasts
    forecasts = WeatherService.get_recent_forecasts()
    assert forecasts == []
    assert len(forecasts) == 0


def test_boundary_conditions():
    """Test boundary conditions for weather evaluation."""
    # Temperature boundaries
    assert WeatherService.evaluate_trip_suggestion(Decimal("15"), Decimal("0"))[0] is True
    assert WeatherService.evaluate_trip_suggestion(Decimal("25"), Decimal("0"))[0] is True
    assert WeatherService.evaluate_trip_suggestion(Decimal("14.9"), Decimal("0"))[0] is False
    assert WeatherService.evaluate_trip_suggestion(Decimal("25.1"), Decimal("0"))[0] is False

    # Precipitation boundaries
    assert WeatherService.evaluate_trip_suggestion(Decimal("20"), Decimal("4.9"))[0] is True
    assert WeatherService.evaluate_trip_suggestion(Decimal("20"), Decimal("5"))[0] is False
    assert WeatherService.evaluate_trip_suggestion(Decimal("20"), Decimal("5.1"))[0] is False
