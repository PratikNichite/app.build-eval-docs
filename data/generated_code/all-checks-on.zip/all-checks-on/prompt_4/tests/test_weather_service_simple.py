import pytest
from decimal import Decimal
from datetime import date, timedelta
from app.weather_service import WeatherService
from app.database import reset_db, get_session
from app.models import WeatherForecast


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


class TestWeatherServiceLogic:
    """Test weather service logic without external dependencies."""

    def test_evaluate_trip_suggestion_good_weather(self):
        """Test trip suggestion for good weather conditions."""
        max_temp = Decimal("20")
        precipitation = Decimal("2")

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert is_good
        assert "pleasant temperature" in reason
        assert "light rain expected" in reason
        assert "Yes -" in reason

    def test_evaluate_trip_suggestion_perfect_weather(self):
        """Test trip suggestion for perfect weather conditions."""
        max_temp = Decimal("22")
        precipitation = Decimal("0")

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert is_good
        assert "pleasant temperature" in reason
        assert "no rain expected" in reason
        assert "Yes -" in reason

    def test_evaluate_trip_suggestion_too_cold(self):
        """Test trip suggestion for cold weather."""
        max_temp = Decimal("10")
        precipitation = Decimal("0")

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert not is_good
        assert "too cold" in reason
        assert "10°C" in reason
        assert "No -" in reason

    def test_evaluate_trip_suggestion_too_hot(self):
        """Test trip suggestion for hot weather."""
        max_temp = Decimal("30")
        precipitation = Decimal("0")

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert not is_good
        assert "too hot" in reason
        assert "30°C" in reason
        assert "No -" in reason

    def test_evaluate_trip_suggestion_too_much_rain(self):
        """Test trip suggestion for rainy weather."""
        max_temp = Decimal("20")
        precipitation = Decimal("10")

        is_good, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        assert not is_good
        assert "pleasant temperature" in reason
        assert "too much rain" in reason
        assert "10mm" in reason
        assert "No -" in reason

    def test_evaluate_trip_suggestion_boundary_cases(self):
        """Test trip suggestion at boundaries."""
        # Lower temperature boundary
        is_good, _ = WeatherService.evaluate_trip_suggestion(Decimal("15"), Decimal("0"))
        assert is_good

        # Upper temperature boundary
        is_good, _ = WeatherService.evaluate_trip_suggestion(Decimal("25"), Decimal("0"))
        assert is_good

        # Precipitation boundary (exactly 5mm should be bad)
        is_good, _ = WeatherService.evaluate_trip_suggestion(Decimal("20"), Decimal("5"))
        assert not is_good

        # Just below precipitation limit
        is_good, _ = WeatherService.evaluate_trip_suggestion(Decimal("20"), Decimal("4.9"))
        assert is_good

    def test_get_recent_forecasts_empty_database(self, new_db):
        """Test getting recent forecasts from empty database."""
        forecasts = WeatherService.get_recent_forecasts()
        assert forecasts == []

    def test_database_operations(self, new_db):
        """Test basic database operations."""
        tomorrow = date.today() + timedelta(days=1)

        # Create a forecast manually to test database
        with get_session() as session:
            forecast = WeatherForecast(
                city_name="Test City",
                forecast_date=tomorrow,
                max_temperature=Decimal("20.5"),
                min_temperature=Decimal("15.0"),
                total_precipitation=Decimal("2.5"),
                is_good_trip_idea=True,
                trip_suggestion_reason="Good weather for testing",
                latitude=Decimal("51.5074"),
                longitude=Decimal("-0.1278"),
            )
            session.add(forecast)
            session.commit()
            session.refresh(forecast)

        # Test retrieval
        recent_forecasts = WeatherService.get_recent_forecasts(5)
        assert len(recent_forecasts) == 1
        assert recent_forecasts[0].city_name == "Test City"
        assert recent_forecasts[0].max_temperature == Decimal("20.5")
        assert recent_forecasts[0].is_good_trip_idea is True
