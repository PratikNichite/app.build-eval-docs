from app.database import create_tables
import app.weather_forecast


def startup() -> None:
    # this function is called before the first request
    create_tables()
    app.weather_forecast.create()
