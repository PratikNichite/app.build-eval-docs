from nicegui import ui
from datetime import date, timedelta
from app.weather_service import WeatherService
from app.models import WeatherForecast


def create():
    """Create the weather forecast application pages."""

    # Apply modern theme
    ui.colors(
        primary="#2563eb",  # Professional blue
        secondary="#64748b",  # Subtle gray
        accent="#10b981",  # Success green
        positive="#10b981",
        negative="#ef4444",  # Error red
        warning="#f59e0b",  # Warning amber
        info="#3b82f6",  # Info blue
    )

    @ui.page("/")
    async def index():
        """Main weather forecast page."""
        ui.add_head_html("""
        <style>
            .weather-card {
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.3);
            }
            .gradient-bg {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            }
        </style>
        """)

        # Background
        ui.query("body").style("background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh")

        with ui.column().classes("w-full items-center pt-8"):
            # Header
            ui.label("☀️✈️ Weather Trip Advisor").classes("text-4xl font-bold text-white mb-2")
            ui.label("Check if tomorrow is a good day for your trip!").classes("text-lg text-white opacity-90 mb-8")

            # Main search card
            with ui.card().classes("weather-card p-8 shadow-2xl rounded-2xl w-96"):
                ui.label("🏙️ Enter City Name").classes("text-lg font-semibold text-gray-700 mb-4")

                city_input = (
                    ui.input(placeholder="e.g., London, Tokyo, New York 📍")
                    .classes("w-full mb-4")
                    .props("outlined clearable")
                )

                search_button = ui.button("🔍 Get Weather Forecast", icon="search").classes(
                    "w-full bg-primary text-white py-3 text-lg font-semibold rounded-lg"
                )

                # Loading indicator (initially hidden)
                loading_spinner = ui.spinner(size="lg").classes("mx-auto mt-4")
                loading_spinner.set_visibility(False)
                loading_label = ui.label("⏳ Fetching weather data...").classes("text-center text-gray-600 mt-2")
                loading_label.set_visibility(False)

            # Weather result card (initially hidden)
            result_card = ui.card().classes("weather-card p-8 shadow-2xl rounded-2xl w-96 mt-6")
            result_card.set_visibility(False)

            async def search_weather():
                """Handle weather search."""
                city_name = city_input.value
                if not city_name or not city_name.strip():
                    ui.notify("⚠️ Please enter a city name", type="negative")
                    return

                # Show loading
                result_card.set_visibility(False)
                loading_spinner.set_visibility(True)
                loading_label.set_visibility(True)
                search_button.set_enabled(False)

                try:
                    # Fetch weather forecast
                    forecast = await WeatherService.get_weather_forecast(city_name.strip())

                    if forecast is None:
                        ui.notify("🚫 City not found or weather data unavailable", type="negative")
                        return

                    # Display weather information
                    await display_weather_result(forecast)

                except Exception as e:
                    ui.notify(f"❌ Error fetching weather data: {str(e)}", type="negative")
                finally:
                    # Hide loading
                    loading_spinner.set_visibility(False)
                    loading_label.set_visibility(False)
                    search_button.set_enabled(True)

            async def display_weather_result(forecast: WeatherForecast):
                """Display the weather forecast result."""
                result_card.clear()

                with result_card:
                    # City and date header
                    ui.label(f"📍 {forecast.city_name}").classes("text-2xl font-bold text-gray-800 mb-2")
                    tomorrow = date.today() + timedelta(days=1)
                    ui.label(f"📅 Tomorrow - {tomorrow.strftime('%B %d, %Y')}").classes("text-lg text-gray-600 mb-6")

                    # Weather metrics in a grid
                    with ui.row().classes("gap-4 w-full mb-6"):
                        # Temperature card
                        with ui.card().classes("flex-1 p-4 bg-blue-50 border-l-4 border-blue-400"):
                            ui.label("🌡️").classes("text-2xl mb-1")
                            ui.label("🌡️ Temperature").classes("text-sm text-gray-600 uppercase tracking-wide")
                            ui.label(f"🔥 Max: {forecast.max_temperature}°C").classes("text-lg font-bold text-gray-800")
                            ui.label(f"❄️ Min: {forecast.min_temperature}°C").classes("text-base text-gray-600")

                    with ui.row().classes("gap-4 w-full mb-6"):
                        # Precipitation card
                        with ui.card().classes("flex-1 p-4 bg-blue-50 border-l-4 border-blue-400"):
                            ui.label("🌧️").classes("text-2xl mb-1")
                            ui.label("💧 Precipitation").classes("text-sm text-gray-600 uppercase tracking-wide")
                            ui.label(f"☔ {forecast.total_precipitation}mm").classes("text-lg font-bold text-gray-800")

                    # Trip recommendation
                    recommendation_color = (
                        "bg-green-50 border-green-400 text-green-800"
                        if forecast.is_good_trip_idea
                        else "bg-red-50 border-red-400 text-red-800"
                    )
                    recommendation_icon = "✅" if forecast.is_good_trip_idea else "❌"

                    with ui.card().classes(f"w-full p-4 {recommendation_color} border-l-4"):
                        ui.label(f"✈️ {recommendation_icon} Trip Recommendation").classes("text-lg font-bold mb-2")
                        ui.label(f"💭 {forecast.trip_suggestion_reason}").classes("text-base leading-relaxed")

                result_card.set_visibility(True)

            # Connect search functionality
            search_button.on_click(search_weather)
            city_input.on("keydown.enter", search_weather)

            # Recent searches section
            with ui.card().classes("weather-card p-6 shadow-xl rounded-xl w-96 mt-8"):
                ui.label("🕒 Recent Searches").classes("text-lg font-semibold text-gray-700 mb-4")
                recent_container = ui.column().classes("w-full gap-2")

                def load_recent_searches():
                    """Load and display recent weather searches."""
                    recent_container.clear()
                    recent_forecasts = WeatherService.get_recent_forecasts(5)

                    if not recent_forecasts:
                        with recent_container:
                            ui.label("📭 No recent searches").classes("text-gray-500 italic text-center py-4")
                        return

                    with recent_container:
                        for forecast in recent_forecasts:
                            status_icon = "✅" if forecast.is_good_trip_idea else "❌"
                            status_color = "text-green-600" if forecast.is_good_trip_idea else "text-red-600"

                            with ui.row().classes(
                                "w-full items-center justify-between p-2 hover:bg-gray-50 rounded cursor-pointer"
                            ):
                                with ui.column().classes("flex-1"):
                                    ui.label(f"📍 {forecast.city_name}").classes("font-medium text-gray-800")
                                    ui.label(
                                        f"🌡️ {forecast.max_temperature}°C, 💧 {forecast.total_precipitation}mm"
                                    ).classes("text-sm text-gray-600")
                                ui.label(status_icon).classes(f"text-lg {status_color}")

                # Load recent searches on page load
                load_recent_searches()

                # Refresh button for recent searches
                ui.button("🔄 Refresh", icon="refresh", on_click=load_recent_searches).classes("w-full mt-4").props(
                    "outline"
                )

    @ui.page("/history")
    def history_page():
        """Weather forecast history page."""
        ui.query("body").style("background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh")

        with ui.column().classes("w-full items-center pt-8"):
            # Header
            ui.label("📊✈️ Weather Forecast History").classes("text-3xl font-bold text-white mb-8")

            # Navigation back to main page
            ui.button("🔙 Back to Search", on_click=lambda: ui.navigate.to("/")).classes("mb-6 text-white").props(
                "flat"
            )

            # History card
            with ui.card().classes("weather-card p-8 shadow-2xl rounded-2xl w-full max-w-4xl"):
                ui.label("📋 Recent Weather Forecasts").classes("text-2xl font-bold text-gray-800 mb-6")

                # Get all recent forecasts
                forecasts = WeatherService.get_recent_forecasts(20)

                if not forecasts:
                    ui.label("📭 No weather forecasts found").classes("text-gray-500 text-center py-8")
                    return

                # Create table data
                table_data = []
                for forecast in forecasts:
                    table_data.append(
                        {
                            "city": forecast.city_name,
                            "date": forecast.forecast_date.strftime("%Y-%m-%d"),
                            "max_temp": f"{forecast.max_temperature}°C",
                            "min_temp": f"{forecast.min_temperature}°C",
                            "precipitation": f"{forecast.total_precipitation}mm",
                            "recommendation": "✅ Yes" if forecast.is_good_trip_idea else "❌ No",
                            "created": forecast.created_at.strftime("%Y-%m-%d %H:%M"),
                        }
                    )

                # Display table
                ui.table(
                    columns=[
                        {"name": "city", "label": "🏙️ City", "field": "city", "align": "left"},
                        {"name": "date", "label": "📅 Forecast Date", "field": "date", "align": "center"},
                        {"name": "max_temp", "label": "🔥 Max Temp", "field": "max_temp", "align": "center"},
                        {"name": "min_temp", "label": "❄️ Min Temp", "field": "min_temp", "align": "center"},
                        {
                            "name": "precipitation",
                            "label": "💧 Precipitation",
                            "field": "precipitation",
                            "align": "center",
                        },
                        {
                            "name": "recommendation",
                            "label": "✈️ Good for Trip?",
                            "field": "recommendation",
                            "align": "center",
                        },
                        {"name": "created", "label": "🕒 Searched At", "field": "created", "align": "center"},
                    ],
                    rows=table_data,
                    pagination=10,
                ).classes("w-full")
