from sqlmodel import SQLModel, Field
from datetime import datetime, date
from typing import Optional
from decimal import Decimal


# Persistent models (stored in database)
class WeatherForecast(SQLModel, table=True):
    __tablename__ = "weather_forecasts"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    city_name: str = Field(max_length=100, index=True)
    forecast_date: date = Field(index=True)
    max_temperature: Decimal = Field(decimal_places=1)
    min_temperature: Decimal = Field(decimal_places=1)
    total_precipitation: Decimal = Field(decimal_places=2, default=Decimal("0.00"))
    is_good_trip_idea: bool = Field()
    trip_suggestion_reason: str = Field(max_length=500)
    latitude: Optional[Decimal] = Field(default=None, decimal_places=6)
    longitude: Optional[Decimal] = Field(default=None, decimal_places=6)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class City(SQLModel, table=True):
    __tablename__ = "cities"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100, unique=True, index=True)
    latitude: Decimal = Field(decimal_places=6)
    longitude: Decimal = Field(decimal_places=6)
    country: Optional[str] = Field(default=None, max_length=100)
    timezone: Optional[str] = Field(default=None, max_length=50)
    created_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class WeatherForecastCreate(SQLModel, table=False):
    city_name: str = Field(max_length=100)
    forecast_date: date
    max_temperature: Decimal = Field(decimal_places=1)
    min_temperature: Decimal = Field(decimal_places=1)
    total_precipitation: Decimal = Field(decimal_places=2, default=Decimal("0.00"))
    is_good_trip_idea: bool
    trip_suggestion_reason: str = Field(max_length=500)
    latitude: Optional[Decimal] = Field(default=None, decimal_places=6)
    longitude: Optional[Decimal] = Field(default=None, decimal_places=6)


class WeatherForecastResponse(SQLModel, table=False):
    city_name: str
    forecast_date: str  # ISO format date string
    max_temperature: Decimal
    min_temperature: Decimal
    total_precipitation: Decimal
    is_good_trip_idea: bool
    trip_suggestion_reason: str
    created_at: str  # ISO format datetime string


class CityCreate(SQLModel, table=False):
    name: str = Field(max_length=100)
    latitude: Decimal = Field(decimal_places=6)
    longitude: Decimal = Field(decimal_places=6)
    country: Optional[str] = Field(default=None, max_length=100)
    timezone: Optional[str] = Field(default=None, max_length=50)


class CityResponse(SQLModel, table=False):
    id: int
    name: str
    latitude: Decimal
    longitude: Decimal
    country: Optional[str]
    timezone: Optional[str]
    created_at: str  # ISO format datetime string


class WeatherSearchRequest(SQLModel, table=False):
    city_name: str = Field(max_length=100, min_length=1)
