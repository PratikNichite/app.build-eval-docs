import httpx
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Optional
from sqlalchemy import desc
from app.models import WeatherForecast, City, WeatherForecastCreate
from app.database import get_session


class WeatherService:
    """Service to fetch weather data from Open-Meteo API and manage weather predictions."""

    BASE_URL = "https://api.open-meteo.com/v1"
    GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1"

    @staticmethod
    async def search_city(city_name: str) -> Optional[dict]:
        """Search for city coordinates using Open-Meteo Geocoding API."""
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{WeatherService.GEOCODING_URL}/search",
                    params={"name": city_name, "count": 1, "language": "en", "format": "json"},
                    timeout=10.0,
                )
                response.raise_for_status()
                data = response.json()

                if not data.get("results"):
                    return None

                result = data["results"][0]
                return {
                    "name": result["name"],
                    "latitude": result["latitude"],
                    "longitude": result["longitude"],
                    "country": result.get("country", ""),
                    "timezone": result.get("timezone", ""),
                }
            except Exception:
                return None

    @staticmethod
    async def fetch_weather_forecast(latitude: float, longitude: float) -> Optional[dict]:
        """Fetch tomorrow's weather forecast from Open-Meteo API."""
        tomorrow = date.today() + timedelta(days=1)

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{WeatherService.BASE_URL}/forecast",
                    params={
                        "latitude": latitude,
                        "longitude": longitude,
                        "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum",
                        "start_date": tomorrow.isoformat(),
                        "end_date": tomorrow.isoformat(),
                        "timezone": "auto",
                    },
                    timeout=10.0,
                )
                response.raise_for_status()
                data = response.json()

                if not data.get("daily"):
                    return None

                daily = data["daily"]
                return {
                    "date": tomorrow,
                    "max_temperature": daily["temperature_2m_max"][0],
                    "min_temperature": daily["temperature_2m_min"][0],
                    "precipitation": daily["precipitation_sum"][0] or 0.0,
                }
            except Exception:
                return None

    @staticmethod
    def evaluate_trip_suggestion(max_temp: Decimal, precipitation: Decimal) -> tuple[bool, str]:
        """Evaluate if tomorrow is a good day for a trip based on weather conditions."""
        reasons = []
        is_good = True

        # Check temperature range (15°C to 25°C)
        if max_temp < Decimal("15"):
            is_good = False
            reasons.append(f"too cold (max {max_temp}°C)")
        elif max_temp > Decimal("25"):
            is_good = False
            reasons.append(f"too hot (max {max_temp}°C)")
        else:
            reasons.append(f"pleasant temperature (max {max_temp}°C)")

        # Check precipitation (less than 5mm)
        if precipitation >= Decimal("5"):
            is_good = False
            reasons.append(f"too much rain ({precipitation}mm expected)")
        elif precipitation > Decimal("0"):
            reasons.append(f"light rain expected ({precipitation}mm)")
        else:
            reasons.append("no rain expected")

        if is_good:
            suggestion = f"Yes - {', '.join(reasons)}"
        else:
            suggestion = f"No - {', '.join(reasons)}"

        return is_good, suggestion

    @staticmethod
    async def get_weather_forecast(city_name: str) -> Optional[WeatherForecast]:
        """Get weather forecast for a city, fetching from API and storing in database."""
        # Search for city coordinates
        city_data = await WeatherService.search_city(city_name)
        if not city_data:
            return None

        # Fetch weather forecast
        weather_data = await WeatherService.fetch_weather_forecast(city_data["latitude"], city_data["longitude"])
        if not weather_data:
            return None

        # Convert to Decimal for database storage
        max_temp = Decimal(str(weather_data["max_temperature"]))
        min_temp = Decimal(str(weather_data["min_temperature"]))
        precipitation = Decimal(str(weather_data["precipitation"]))

        # Evaluate trip suggestion
        is_good_idea, reason = WeatherService.evaluate_trip_suggestion(max_temp, precipitation)

        # Create weather forecast record
        forecast_create = WeatherForecastCreate(
            city_name=city_data["name"],
            forecast_date=weather_data["date"],
            max_temperature=max_temp,
            min_temperature=min_temp,
            total_precipitation=precipitation,
            is_good_trip_idea=is_good_idea,
            trip_suggestion_reason=reason,
            latitude=Decimal(str(city_data["latitude"])),
            longitude=Decimal(str(city_data["longitude"])),
        )

        # Save to database and city data if not exists
        with get_session() as session:
            # Save city if not exists
            existing_city = session.query(City).filter(City.name == city_data["name"]).first()
            if not existing_city:
                city = City(
                    name=city_data["name"],
                    latitude=Decimal(str(city_data["latitude"])),
                    longitude=Decimal(str(city_data["longitude"])),
                    country=city_data.get("country"),
                    timezone=city_data.get("timezone"),
                )
                session.add(city)

            # Check if forecast already exists for today's request
            today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
            existing_forecast = (
                session.query(WeatherForecast)
                .filter(WeatherForecast.city_name == forecast_create.city_name)  # type: ignore[arg-type]
                .filter(WeatherForecast.forecast_date == forecast_create.forecast_date)  # type: ignore[arg-type]
                .filter(WeatherForecast.created_at >= today_start)  # type: ignore[arg-type]
                .first()
            )

            if existing_forecast:
                # Update existing forecast
                existing_forecast.max_temperature = forecast_create.max_temperature
                existing_forecast.min_temperature = forecast_create.min_temperature
                existing_forecast.total_precipitation = forecast_create.total_precipitation
                existing_forecast.is_good_trip_idea = forecast_create.is_good_trip_idea
                existing_forecast.trip_suggestion_reason = forecast_create.trip_suggestion_reason
                existing_forecast.updated_at = datetime.utcnow()
                session.commit()
                session.expunge(existing_forecast)  # Detach from session
                return existing_forecast
            else:
                # Create new forecast
                forecast = WeatherForecast(**forecast_create.model_dump())
                session.add(forecast)
                session.commit()
                session.refresh(forecast)
                session.expunge(forecast)  # Detach from session
                return forecast

    @staticmethod
    def get_recent_forecasts(limit: int = 10) -> list[WeatherForecast]:
        """Get recent weather forecasts from the database."""
        with get_session() as session:
            forecasts = (
                session.query(WeatherForecast)
                .order_by(
                    desc(WeatherForecast.created_at)  # type: ignore[arg-type]
                )
                .limit(limit)
                .all()
            )
            # Detach from session to avoid DetachedInstanceError
            for forecast in forecasts:
                session.expunge(forecast)
            return forecasts
