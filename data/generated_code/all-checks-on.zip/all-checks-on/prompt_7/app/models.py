from sqlmodel import SQLModel, Field, Column, JSON
from datetime import datetime
from typing import Optional, List, Dict
from enum import Enum
from decimal import Decimal


class GameStatus(str, Enum):
    PLAYING = "playing"
    PAUSED = "paused"
    GAME_OVER = "game_over"


class Direction(str, Enum):
    UP = "up"
    DOWN = "down"
    LEFT = "left"
    RIGHT = "right"


# Persistent models (stored in database)
class GameSession(SQLModel, table=True):
    __tablename__ = "game_sessions"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    player_name: str = Field(max_length=100, default="Anonymous")
    score: int = Field(default=0)
    high_score: int = Field(default=0)
    status: GameStatus = Field(default=GameStatus.PLAYING)
    current_direction: Direction = Field(default=Direction.RIGHT)
    grid_width: int = Field(default=20)
    grid_height: int = Field(default=20)
    game_speed: Decimal = Field(default=Decimal("0.2"))  # Time in seconds between moves
    snake_positions: List[Dict[str, int]] = Field(default=[], sa_column=Column(JSON))  # List of {x, y} coordinates
    food_position: Dict[str, int] = Field(default={}, sa_column=Column(JSON))  # {x, y} coordinates
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class HighScore(SQLModel, table=True):
    __tablename__ = "high_scores"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    player_name: str = Field(max_length=100)
    score: int = Field()
    snake_length: int = Field()
    grid_size: str = Field(max_length=10)  # Format: "WxH" (e.g., "20x20")
    achieved_at: datetime = Field(default_factory=datetime.utcnow)


class GameSettings(SQLModel, table=True):
    __tablename__ = "game_settings"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    player_name: str = Field(max_length=100, default="Anonymous")
    preferred_grid_width: int = Field(default=20)
    preferred_grid_height: int = Field(default=20)
    preferred_speed: Decimal = Field(default=Decimal("0.2"))
    sound_enabled: bool = Field(default=True)
    show_grid_lines: bool = Field(default=True)
    theme_colors: Dict[str, str] = Field(default={}, sa_column=Column(JSON))  # Color customization
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class GameSessionCreate(SQLModel, table=False):
    player_name: str = Field(max_length=100, default="Anonymous")
    grid_width: int = Field(default=20, ge=10, le=50)  # Grid size constraints
    grid_height: int = Field(default=20, ge=10, le=50)
    game_speed: Decimal = Field(default=Decimal("0.2"), ge=0.1, le=2.0)


class GameSessionUpdate(SQLModel, table=False):
    score: Optional[int] = Field(default=None, ge=0)
    status: Optional[GameStatus] = Field(default=None)
    current_direction: Optional[Direction] = Field(default=None)
    snake_positions: Optional[List[Dict[str, int]]] = Field(default=None)
    food_position: Optional[Dict[str, int]] = Field(default=None)
    updated_at: Optional[datetime] = Field(default_factory=datetime.utcnow)


class Position(SQLModel, table=False):
    x: int = Field(ge=0)
    y: int = Field(ge=0)


class GameMove(SQLModel, table=False):
    direction: Direction
    session_id: int


class GameState(SQLModel, table=False):
    """Current game state for UI rendering"""

    session_id: int
    player_name: str
    score: int
    high_score: int
    status: GameStatus
    snake_positions: List[Dict[str, int]]
    food_position: Dict[str, int]
    grid_width: int
    grid_height: int
    current_direction: Direction


class HighScoreCreate(SQLModel, table=False):
    player_name: str = Field(max_length=100)
    score: int = Field(ge=0)
    snake_length: int = Field(ge=1)
    grid_width: int = Field(ge=10, le=50)
    grid_height: int = Field(ge=10, le=50)

    @property
    def grid_size(self) -> str:
        return f"{self.grid_width}x{self.grid_height}"


class GameSettingsCreate(SQLModel, table=False):
    player_name: str = Field(max_length=100, default="Anonymous")
    preferred_grid_width: int = Field(default=20, ge=10, le=50)
    preferred_grid_height: int = Field(default=20, ge=10, le=50)
    preferred_speed: Decimal = Field(default=Decimal("0.2"), ge=0.1, le=2.0)
    sound_enabled: bool = Field(default=True)
    show_grid_lines: bool = Field(default=True)
    theme_colors: Optional[Dict[str, str]] = Field(default=None)


class GameSettingsUpdate(SQLModel, table=False):
    preferred_grid_width: Optional[int] = Field(default=None, ge=10, le=50)
    preferred_grid_height: Optional[int] = Field(default=None, ge=10, le=50)
    preferred_speed: Optional[Decimal] = Field(default=None, ge=0.1, le=2.0)
    sound_enabled: Optional[bool] = Field(default=None)
    show_grid_lines: Optional[bool] = Field(default=None)
    theme_colors: Optional[Dict[str, str]] = Field(default=None)
    updated_at: Optional[datetime] = Field(default_factory=datetime.utcnow)
