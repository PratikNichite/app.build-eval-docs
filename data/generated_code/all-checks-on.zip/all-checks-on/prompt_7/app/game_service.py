from typing import List, Dict, Optional, Tuple
import random
from sqlmodel import select, desc
from app.database import get_session
from app.models import GameSession, GameStatus, Direction, HighScore, GameSettings, GameState
from decimal import Decimal


class SnakeGameService:
    """Service class for handling Snake game logic and database operations"""

    @staticmethod
    def create_new_game(player_name: str = "Anonymous") -> GameSession:
        """Create a new game session with initial snake and food positions"""
        with get_session() as session:
            # Get player settings if they exist
            settings = session.exec(select(GameSettings).where(GameSettings.player_name == player_name)).first()

            if settings:
                grid_width = settings.preferred_grid_width
                grid_height = settings.preferred_grid_height
                speed = settings.preferred_speed
            else:
                grid_width = 20
                grid_height = 20
                speed = Decimal("0.2")

            # Initialize snake at center of grid
            center_x = grid_width // 2
            center_y = grid_height // 2
            initial_snake = [
                {"x": center_x, "y": center_y},
                {"x": center_x - 1, "y": center_y},
                {"x": center_x - 2, "y": center_y},
            ]

            # Get high score for this player
            stmt = select(HighScore).where(HighScore.player_name == player_name).order_by(desc(HighScore.score))
            high_score_record = session.exec(stmt).first()
            high_score = high_score_record.score if high_score_record else 0

            # Create new game session
            game_session = GameSession(
                player_name=player_name,
                score=0,
                high_score=high_score,
                status=GameStatus.PLAYING,
                current_direction=Direction.RIGHT,
                grid_width=grid_width,
                grid_height=grid_height,
                game_speed=speed,
                snake_positions=initial_snake,
                food_position=SnakeGameService._generate_food_position(initial_snake, grid_width, grid_height),
            )

            session.add(game_session)
            session.commit()
            session.refresh(game_session)
            return game_session

    @staticmethod
    def _generate_food_position(
        snake_positions: List[Dict[str, int]], grid_width: int, grid_height: int
    ) -> Dict[str, int]:
        """Generate a random food position that doesn't overlap with snake"""
        snake_coords = {(pos["x"], pos["y"]) for pos in snake_positions}

        while True:
            food_x = random.randint(0, grid_width - 1)
            food_y = random.randint(0, grid_height - 1)
            if (food_x, food_y) not in snake_coords:
                return {"x": food_x, "y": food_y}

    @staticmethod
    def move_snake(session_id: int, direction: Direction) -> Tuple[GameState, bool]:
        """
        Move the snake in the specified direction and update game state
        Returns (game_state, game_over)
        """
        with get_session() as session:
            game = session.get(GameSession, session_id)
            if game is None:
                raise ValueError(f"Game session {session_id} not found")

            if game.status != GameStatus.PLAYING:
                return SnakeGameService._create_game_state(game), game.status == GameStatus.GAME_OVER

            # Prevent immediate direction reversal
            opposite_directions = {
                Direction.UP: Direction.DOWN,
                Direction.DOWN: Direction.UP,
                Direction.LEFT: Direction.RIGHT,
                Direction.RIGHT: Direction.LEFT,
            }

            if len(game.snake_positions) > 1 and direction == opposite_directions.get(game.current_direction):
                direction = game.current_direction

            game.current_direction = direction

            # Calculate new head position
            head = game.snake_positions[0]
            new_head = {"x": head["x"], "y": head["y"]}

            match direction:
                case Direction.UP:
                    new_head["y"] -= 1
                case Direction.DOWN:
                    new_head["y"] += 1
                case Direction.LEFT:
                    new_head["x"] -= 1
                case Direction.RIGHT:
                    new_head["x"] += 1

            # Check wall collision
            if (
                new_head["x"] < 0
                or new_head["x"] >= game.grid_width
                or new_head["y"] < 0
                or new_head["y"] >= game.grid_height
            ):
                game.status = GameStatus.GAME_OVER
                session.commit()
                SnakeGameService._save_high_score(game)
                return SnakeGameService._create_game_state(game), True

            # Check self collision
            for segment in game.snake_positions:
                if new_head["x"] == segment["x"] and new_head["y"] == segment["y"]:
                    game.status = GameStatus.GAME_OVER
                    session.commit()
                    SnakeGameService._save_high_score(game)
                    return SnakeGameService._create_game_state(game), True

            # Move snake
            new_snake = [new_head] + game.snake_positions

            # Check food collision
            if new_head["x"] == game.food_position["x"] and new_head["y"] == game.food_position["y"]:
                # Snake grows, score increases
                game.score += 10
                game.food_position = SnakeGameService._generate_food_position(
                    new_snake, game.grid_width, game.grid_height
                )
            else:
                # Remove tail (snake doesn't grow)
                new_snake.pop()

            game.snake_positions = new_snake
            session.commit()

            return SnakeGameService._create_game_state(game), False

    @staticmethod
    def get_game_state(session_id: int) -> Optional[GameState]:
        """Get current game state"""
        with get_session() as session:
            game = session.get(GameSession, session_id)
            if game is None:
                return None
            return SnakeGameService._create_game_state(game)

    @staticmethod
    def _create_game_state(game: GameSession) -> GameState:
        """Convert GameSession to GameState"""
        return GameState(
            session_id=game.id or 0,
            player_name=game.player_name,
            score=game.score,
            high_score=game.high_score,
            status=game.status,
            snake_positions=game.snake_positions,
            food_position=game.food_position,
            grid_width=game.grid_width,
            grid_height=game.grid_height,
            current_direction=game.current_direction,
        )

    @staticmethod
    def _save_high_score(game: GameSession) -> None:
        """Save high score if current score is better"""
        if game.score > game.high_score:
            with get_session() as session:
                high_score = HighScore(
                    player_name=game.player_name,
                    score=game.score,
                    snake_length=len(game.snake_positions),
                    grid_size=f"{game.grid_width}x{game.grid_height}",
                )
                session.add(high_score)

                # Update game's high score
                current_game = session.get(GameSession, game.id)
                if current_game:
                    current_game.high_score = game.score

                session.commit()

    @staticmethod
    def get_high_scores(limit: int = 10) -> List[HighScore]:
        """Get top high scores"""
        with get_session() as session:
            stmt = select(HighScore).order_by(desc(HighScore.score)).limit(limit)
            high_scores = session.exec(stmt)
            return list(high_scores)

    @staticmethod
    def pause_game(session_id: int) -> bool:
        """Pause the game"""
        with get_session() as session:
            game = session.get(GameSession, session_id)
            if game and game.status == GameStatus.PLAYING:
                game.status = GameStatus.PAUSED
                session.commit()
                return True
            return False

    @staticmethod
    def resume_game(session_id: int) -> bool:
        """Resume the game"""
        with get_session() as session:
            game = session.get(GameSession, session_id)
            if game and game.status == GameStatus.PAUSED:
                game.status = GameStatus.PLAYING
                session.commit()
                return True
            return False
