from nicegui import ui, events
from typing import Optional
from app.game_service import SnakeGameService
from app.models import GameState, GameStatus, Direction


class SnakeGameUI:
    """Snake Game UI Component with keyboard controls and game rendering"""

    def __init__(self):
        self.game_state: Optional[GameState] = None
        self.game_timer: Optional[ui.timer] = None
        self.grid_container: Optional[ui.element] = None
        self.score_label: Optional[ui.label] = None
        self.high_score_label: Optional[ui.label] = None
        self.status_label: Optional[ui.label] = None
        self.game_over_dialog: Optional[ui.element] = None

        # Grid styling constants
        self.cell_size = 20  # pixels
        self.snake_color = "#10b981"  # emerald green
        self.food_color = "#ef4444"  # red
        self.grid_bg_color = "#f8fafc"  # light gray
        self.grid_border_color = "#e2e8f0"  # border gray

    def create_game(self) -> None:
        """Initialize a new game and render the UI"""
        # Create new game session
        game_session = SnakeGameService.create_new_game("Player")
        if game_session.id is not None:
            self.game_state = SnakeGameService.get_game_state(game_session.id)
            self._render_ui()
            self._start_game_loop()

    def _render_ui(self) -> None:
        """Render the complete game UI"""
        if not self.game_state:
            return

        # Main game container with modern styling
        with ui.column().classes("w-full max-w-4xl mx-auto p-6 bg-white rounded-xl shadow-lg"):
            # Header with score and controls
            self._render_header()

            # Game area
            self._render_game_area()

            # Instructions
            self._render_instructions()

        # Set up keyboard controls
        self._setup_keyboard_controls()

    def _render_header(self) -> None:
        """Render game header with scores and status"""
        if not self.game_state:
            return

        with ui.row().classes("w-full justify-between items-center mb-6"):
            # Title
            ui.label("🐍 Snake Game").classes("text-3xl font-bold text-gray-800")

            # Scores and status
            with ui.column().classes("text-right"):
                self.score_label = ui.label(f"Score: {self.game_state.score}").classes(
                    "text-xl font-semibold text-green-600"
                )
                self.high_score_label = ui.label(f"High Score: {self.game_state.high_score}").classes(
                    "text-lg text-gray-600"
                )
                self.status_label = ui.label(self._get_status_text()).classes("text-md font-medium text-blue-600")

    def _render_game_area(self) -> None:
        """Render the game grid and snake/food"""
        if not self.game_state:
            return

        grid_width = self.game_state.grid_width * self.cell_size
        grid_height = self.game_state.grid_height * self.cell_size

        # Game grid container
        self.grid_container = (
            ui.element("div")
            .classes("mx-auto relative border-2 border-gray-400 rounded-lg")
            .style(f"width: {grid_width}px; height: {grid_height}px; background-color: {self.grid_bg_color};")
        )

        with self.grid_container:
            self._render_game_elements()

    def _render_game_elements(self) -> None:
        """Render snake segments and food on the grid"""
        if not self.game_state or not self.grid_container:
            return

        # Clear existing elements
        self.grid_container.clear()

        with self.grid_container:
            # Render snake
            for i, segment in enumerate(self.game_state.snake_positions):
                is_head = i == 0
                color = "#059669" if is_head else self.snake_color  # Darker green for head
                border_style = "border: 2px solid #065f46;" if is_head else "border: 1px solid #047857;"

                ui.element("div").classes("absolute rounded").style(
                    f"left: {segment['x'] * self.cell_size}px; "
                    f"top: {segment['y'] * self.cell_size}px; "
                    f"width: {self.cell_size}px; "
                    f"height: {self.cell_size}px; "
                    f"background-color: {color}; "
                    f"{border_style} "
                    f"box-shadow: 0 2px 4px rgba(0,0,0,0.1);"
                )

            # Render food with pulsing animation
            food = self.game_state.food_position
            ui.element("div").classes("absolute rounded-full animate-pulse").style(
                f"left: {food['x'] * self.cell_size + 2}px; "
                f"top: {food['y'] * self.cell_size + 2}px; "
                f"width: {self.cell_size - 4}px; "
                f"height: {self.cell_size - 4}px; "
                f"background-color: {self.food_color}; "
                f"border: 2px solid #dc2626; "
                f"box-shadow: 0 0 10px rgba(239, 68, 68, 0.5);"
            )

    def _render_instructions(self) -> None:
        """Render game instructions and controls"""
        with ui.card().classes("mt-6 p-4 bg-gray-50"):
            ui.label("How to Play").classes("text-lg font-semibold mb-2")
            with ui.row().classes("gap-8 text-sm text-gray-600"):
                with ui.column():
                    ui.label("🎮 Controls:")
                    ui.label("Arrow Keys - Move snake")
                    ui.label("Space - Pause/Resume")
                    ui.label("R - Restart game")

                with ui.column():
                    ui.label("📝 Rules:")
                    ui.label("Eat red food to grow and score")
                    ui.label("Avoid walls and your own tail")
                    ui.label("Game gets faster as you score!")

    def _setup_keyboard_controls(self) -> None:
        """Set up keyboard event handlers for game controls"""
        ui.keyboard(self._handle_keydown)

    def _handle_keydown(self, e: events.KeyEventArguments) -> None:
        """Handle keyboard input for game controls"""
        try:
            # Handle different key formats
            if hasattr(e, "key") and hasattr(e.key, "code"):
                key_str = e.key.code
            elif hasattr(e, "key"):
                key_str = str(e.key)
            else:
                return

            if not self.game_state or self.game_state.status == GameStatus.GAME_OVER:
                if key_str.lower() in ["r", "keyr"]:
                    self._restart_game()
                return

            # Direction controls
            direction_map = {
                "ArrowUp": Direction.UP,
                "ArrowDown": Direction.DOWN,
                "ArrowLeft": Direction.LEFT,
                "ArrowRight": Direction.RIGHT,
                "KeyW": Direction.UP,  # WASD support
                "KeyS": Direction.DOWN,
                "KeyA": Direction.LEFT,
                "KeyD": Direction.RIGHT,
            }

            if key_str in direction_map:
                self._move_snake(direction_map[key_str])
            elif key_str in [" ", "Space"]:  # Space bar
                self._toggle_pause()
            elif key_str.lower() in ["r", "keyr"]:
                self._restart_game()
        except Exception:
            # Handle any keyboard event errors gracefully
            pass

    def _move_snake(self, direction: Direction) -> None:
        """Move snake in specified direction"""
        if not self.game_state or self.game_state.session_id == 0:
            return

        try:
            new_state, game_over = SnakeGameService.move_snake(self.game_state.session_id, direction)
            self.game_state = new_state

            if game_over:
                self._handle_game_over()
            else:
                self._update_display()

        except Exception as e:
            ui.notify(f"🐛 Error moving snake: {str(e)}", type="negative")

    def _start_game_loop(self) -> None:
        """Start the automatic game movement timer"""
        if not self.game_state:
            return

        # Start timer with 200ms interval (moves every 200ms)
        self.game_timer = ui.timer(0.2, self._auto_move)

    def _auto_move(self) -> None:
        """Automatically move snake in current direction"""
        if not self.game_state or self.game_state.status != GameStatus.PLAYING:
            return

        self._move_snake(self.game_state.current_direction)

    def _update_display(self) -> None:
        """Update all UI elements with current game state"""
        if not self.game_state:
            return

        # Update scores and status
        if self.score_label:
            self.score_label.set_text(f"Score: {self.game_state.score}")
        if self.high_score_label:
            self.high_score_label.set_text(f"High Score: {self.game_state.high_score}")
        if self.status_label:
            self.status_label.set_text(self._get_status_text())

        # Re-render game elements
        self._render_game_elements()

    def _handle_game_over(self) -> None:
        """Handle game over state"""
        if self.game_timer:
            self.game_timer.cancel()

        # Show game over message
        ui.notify("💥 Game Over! Press R to restart", type="warning", timeout=5000)

        if self.status_label:
            self.status_label.set_text("💥 Game Over! Press R to restart")
            self.status_label.classes(remove="text-blue-600", add="text-red-600")

    def _toggle_pause(self) -> None:
        """Toggle game pause state"""
        if not self.game_state or self.game_state.session_id == 0:
            return

        if self.game_state.status == GameStatus.PLAYING:
            if SnakeGameService.pause_game(self.game_state.session_id):
                self.game_state.status = GameStatus.PAUSED
                if self.game_timer:
                    self.game_timer.cancel()
                ui.notify("⏸️ Game Paused", type="info")

        elif self.game_state.status == GameStatus.PAUSED:
            if SnakeGameService.resume_game(self.game_state.session_id):
                self.game_state.status = GameStatus.PLAYING
                self._start_game_loop()
                ui.notify("▶️ Game Resumed", type="info")

        self._update_display()

    def _restart_game(self) -> None:
        """Restart the game"""
        if self.game_timer:
            self.game_timer.cancel()

        # Reset game state
        self.__init__()

        # Create new game
        self.create_game()

        ui.notify("🚀 New Game Started!", type="positive")

    def _get_status_text(self) -> str:
        """Get current game status text"""
        if not self.game_state:
            return "Loading..."

        match self.game_state.status:
            case GameStatus.PLAYING:
                return "Playing"
            case GameStatus.PAUSED:
                return "Paused - Press Space to resume"
            case GameStatus.GAME_OVER:
                return "Game Over - Press R to restart"
            case _:
                return "Unknown"


def create() -> None:
    """Create and set up the Snake game page"""

    @ui.page("/")
    def snake_game_page():
        # Apply modern theme colors
        ui.colors(
            primary="#10b981",  # Snake green
            secondary="#64748b",  # Gray
            accent="#ef4444",  # Food red
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        # Page title and meta
        ui.page_title("Snake Game")
        ui.add_head_html('<meta name="viewport" content="width=device-width, initial-scale=1.0">')

        # Add custom CSS for animations and focus handling
        ui.add_head_html("""
        <style>
            body { 
                margin: 0; 
                background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
                min-height: 100vh;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            }
            .animate-pulse {
                animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
            }
            @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.7; }
            }
            /* Remove focus outline for keyboard navigation */
            *:focus { outline: none; }
            /* Prevent text selection on game elements */
            .q-page { user-select: none; }
        </style>
        """)

        # Initialize and create the game
        game_ui = SnakeGameUI()
        game_ui.create_game()

    @ui.page("/highscores")
    def high_scores_page():
        ui.page_title("Snake Game - High Scores")

        with ui.column().classes("w-full max-w-2xl mx-auto p-6"):
            ui.label("🏆 High Scores").classes("text-3xl font-bold text-center mb-6")

            # Get high scores
            high_scores = SnakeGameService.get_high_scores(10)

            if not high_scores:
                ui.label("No high scores yet! Play the game to set records.").classes("text-center text-gray-600")
            else:
                with ui.card().classes("w-full p-4"):
                    for i, score in enumerate(high_scores, 1):
                        with ui.row().classes("w-full justify-between items-center py-2 border-b border-gray-200"):
                            ui.label(f"{i}. {score.player_name}").classes("font-semibold")
                            with ui.row().classes("gap-4 text-sm text-gray-600"):
                                ui.label(f"Score: {score.score}")
                                ui.label(f"Length: {score.snake_length}")
                                ui.label(f"Grid: {score.grid_size}")
                                ui.label(f"{score.achieved_at.strftime('%Y-%m-%d')}")

            # Navigation
            with ui.row().classes("gap-4 mt-6 justify-center"):
                ui.button("🎮 Play Game", on_click=lambda: ui.navigate.to("/")).classes("px-6 py-2")
                ui.button("🔄 Refresh", on_click=lambda: ui.navigate.reload()).classes("px-6 py-2").props("outline")
