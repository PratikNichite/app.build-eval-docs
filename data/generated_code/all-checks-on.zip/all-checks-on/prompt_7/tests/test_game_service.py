import pytest
from app.game_service import SnakeGameService
from app.models import GameSession, GameStatus, Direction
from app.database import reset_db


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_create_new_game(new_db):
    """Test creating a new game with proper initialization"""
    game = SnakeGameService.create_new_game("TestPlayer")

    assert game.player_name == "TestPlayer"
    assert game.score == 0
    assert game.high_score == 0
    assert game.status == GameStatus.PLAYING
    assert game.current_direction == Direction.RIGHT
    assert game.grid_width == 20
    assert game.grid_height == 20
    assert len(game.snake_positions) == 3  # Initial snake length

    # Check initial snake position (should be in center moving right)
    center_x, center_y = 10, 10
    expected_snake = [
        {"x": center_x, "y": center_y},  # head
        {"x": center_x - 1, "y": center_y},  # body
        {"x": center_x - 2, "y": center_y},  # tail
    ]
    assert game.snake_positions == expected_snake

    # Food should be positioned somewhere valid
    assert "x" in game.food_position
    assert "y" in game.food_position
    assert 0 <= game.food_position["x"] < 20
    assert 0 <= game.food_position["y"] < 20

    # Food should not overlap with snake
    snake_coords = {(pos["x"], pos["y"]) for pos in game.snake_positions}
    food_coord = (game.food_position["x"], game.food_position["y"])
    assert food_coord not in snake_coords


def test_move_snake_basic_movement(new_db):
    """Test basic snake movement in all directions"""
    game = SnakeGameService.create_new_game("TestPlayer")
    assert game.id is not None

    # Test moving right (default direction)
    initial_head = game.snake_positions[0]
    new_state, game_over = SnakeGameService.move_snake(game.id, Direction.RIGHT)

    assert not game_over
    assert new_state.snake_positions[0]["x"] == initial_head["x"] + 1
    assert new_state.snake_positions[0]["y"] == initial_head["y"]

    # Test moving up
    current_head = new_state.snake_positions[0]
    new_state, game_over = SnakeGameService.move_snake(game.id, Direction.UP)

    assert not game_over
    assert new_state.snake_positions[0]["x"] == current_head["x"]
    assert new_state.snake_positions[0]["y"] == current_head["y"] - 1


def test_move_snake_prevents_immediate_reversal(new_db):
    """Test that snake cannot immediately reverse direction"""
    game = SnakeGameService.create_new_game("TestPlayer")
    assert game.id is not None

    # Try to move left (opposite of initial RIGHT direction)
    initial_head = game.snake_positions[0]
    new_state, game_over = SnakeGameService.move_snake(game.id, Direction.LEFT)

    # Should continue moving RIGHT, not LEFT
    assert not game_over
    assert new_state.snake_positions[0]["x"] == initial_head["x"] + 1
    assert new_state.current_direction == Direction.RIGHT


def test_wall_collision_detection(new_db):
    """Test collision with walls causes game over"""
    game = SnakeGameService.create_new_game("TestPlayer")
    assert game.id is not None

    # Move snake to top wall
    new_state = None
    game_over = False
    for _ in range(15):  # Move up to hit the wall
        new_state, game_over = SnakeGameService.move_snake(game.id, Direction.UP)
        if game_over:
            break

    assert game_over
    assert new_state is not None
    assert new_state.status == GameStatus.GAME_OVER


def test_self_collision_detection(new_db):
    """Test collision with snake's own body causes game over"""
    game = SnakeGameService.create_new_game("TestPlayer")
    assert game.id is not None

    # Create a scenario where snake will hit itself
    # First, make the snake longer by feeding it
    for _ in range(5):
        # Temporarily set food at the next position to make snake grow
        head = game.snake_positions[0]
        game.food_position = {"x": head["x"] + 1, "y": head["y"]}
        new_state, _ = SnakeGameService.move_snake(game.id, Direction.RIGHT)
        updated_state = SnakeGameService.get_game_state(game.id)
        if updated_state is None:
            break
        # Note: updated_state is GameState, not GameSession

    # Now try to make the snake hit itself by making a loop
    # Move in a pattern that will cause self collision
    moves = [Direction.UP, Direction.LEFT, Direction.DOWN, Direction.RIGHT]
    updated_state = SnakeGameService.get_game_state(game.id)

    # Initialize variables to avoid unbound issues
    new_state = None
    game_over = False

    for direction in moves * 3:  # Repeat pattern to ensure collision
        if updated_state is None:
            break
        new_state, game_over = SnakeGameService.move_snake(updated_state.session_id, direction)
        if game_over:
            break
        updated_state = SnakeGameService.get_game_state(updated_state.session_id)

    # The collision detection logic should be tested
    # This test mainly ensures the logic doesn't crash when checking for collisions
    assert updated_state is not None or game_over
    assert new_state is not None or game_over


def test_food_consumption_increases_score_and_length(new_db):
    """Test eating food increases score and snake length"""
    game = SnakeGameService.create_new_game("TestPlayer")
    assert game.id is not None

    initial_length = len(game.snake_positions)
    initial_score = game.score

    # Manually position food right in front of snake head
    head = game.snake_positions[0]
    # Update game in database to set food position
    from app.database import get_session

    with get_session() as session:
        db_game = session.get(GameSession, game.id)
        if db_game:
            db_game.food_position = {"x": head["x"] + 1, "y": head["y"]}
            session.commit()

    # Move snake to eat the food
    new_state, game_over = SnakeGameService.move_snake(game.id, Direction.RIGHT)

    assert not game_over
    assert new_state.score == initial_score + 10  # Score increases by 10
    assert len(new_state.snake_positions) == initial_length + 1  # Snake grows

    # New food should be generated at different position
    assert new_state.food_position != {"x": head["x"] + 1, "y": head["y"]}


def test_high_score_tracking(new_db):
    """Test high score is saved when game ends with new record"""
    # Create a game and end it with a score
    game = SnakeGameService.create_new_game("HighScorePlayer")
    assert game.id is not None

    # Manually set a score for testing
    from app.database import get_session

    with get_session() as session:
        db_game = session.get(GameSession, game.id)
        if db_game:
            db_game.score = 100  # Set a high score
            db_game.status = GameStatus.GAME_OVER
            session.commit()
            session.refresh(db_game)

            # This should trigger high score saving
            SnakeGameService._save_high_score(db_game)

    # Check that high score was saved
    high_scores = SnakeGameService.get_high_scores(1)
    assert len(high_scores) > 0
    assert high_scores[0].player_name == "HighScorePlayer"
    assert high_scores[0].score == 100


def test_pause_and_resume_game(new_db):
    """Test pausing and resuming game functionality"""
    game = SnakeGameService.create_new_game("TestPlayer")
    assert game.id is not None

    # Pause the game
    pause_result = SnakeGameService.pause_game(game.id)
    assert pause_result

    # Check game is paused
    paused_state = SnakeGameService.get_game_state(game.id)
    assert paused_state is not None
    assert paused_state.status == GameStatus.PAUSED

    # Resume the game
    resume_result = SnakeGameService.resume_game(game.id)
    assert resume_result

    # Check game is resumed
    resumed_state = SnakeGameService.get_game_state(game.id)
    assert resumed_state is not None
    assert resumed_state.status == GameStatus.PLAYING


def test_get_game_state_with_invalid_id(new_db):
    """Test getting game state with non-existent ID returns None"""
    result = SnakeGameService.get_game_state(999999)
    assert result is None


def test_food_generation_avoids_snake_body(new_db):
    """Test that food is never generated on snake body"""
    # Create a longer snake by manually setting positions
    from app.database import get_session

    game = SnakeGameService.create_new_game("TestPlayer")
    assert game.id is not None

    # Create a snake that covers most of a small grid
    long_snake = []
    for i in range(10):
        for j in range(2):  # Two rows
            long_snake.append({"x": i, "y": j})

    with get_session() as session:
        db_game = session.get(GameSession, game.id)
        if db_game:
            db_game.snake_positions = long_snake
            db_game.grid_width = 10
            db_game.grid_height = 10
            session.commit()

    # Generate new food position
    new_food = SnakeGameService._generate_food_position(long_snake, 10, 10)

    # Verify food is not on snake
    snake_coords = {(pos["x"], pos["y"]) for pos in long_snake}
    food_coord = (new_food["x"], new_food["y"])
    assert food_coord not in snake_coords

    # Verify food is within grid bounds
    assert 0 <= new_food["x"] < 10
    assert 0 <= new_food["y"] < 10


def test_move_snake_with_invalid_game_id(new_db):
    """Test moving snake with invalid game ID raises error"""
    with pytest.raises(ValueError, match="Game session .* not found"):
        SnakeGameService.move_snake(999999, Direction.UP)


def test_game_state_conversion(new_db):
    """Test GameSession to GameState conversion"""
    game = SnakeGameService.create_new_game("TestPlayer")
    assert game.id is not None

    game_state = SnakeGameService.get_game_state(game.id)
    assert game_state is not None

    # Verify all fields are correctly converted
    assert game_state.session_id == game.id
    assert game_state.player_name == game.player_name
    assert game_state.score == game.score
    assert game_state.status == game.status
    assert game_state.snake_positions == game.snake_positions
    assert game_state.food_position == game.food_position
    assert game_state.grid_width == game.grid_width
    assert game_state.grid_height == game.grid_height


def test_multiple_games_isolation(new_db):
    """Test that multiple game sessions don't interfere with each other"""
    game1 = SnakeGameService.create_new_game("Player1")
    game2 = SnakeGameService.create_new_game("Player2")

    assert game1.id != game2.id
    assert game1.player_name != game2.player_name

    # Move each game independently
    if game1.id and game2.id:
        state1, _ = SnakeGameService.move_snake(game1.id, Direction.UP)
        state2, _ = SnakeGameService.move_snake(game2.id, Direction.DOWN)

        # States should be different
        assert state1.session_id != state2.session_id
        assert state1.current_direction != state2.current_direction


def test_edge_case_single_cell_grid(new_db):
    """Test game behavior with minimal grid size"""
    from app.database import get_session

    game = SnakeGameService.create_new_game("EdgeCasePlayer")
    assert game.id is not None

    # Set very small grid (edge case)
    with get_session() as session:
        db_game = session.get(GameSession, game.id)
        if db_game:
            db_game.grid_width = 3
            db_game.grid_height = 3
            # Reset snake to fit in smaller grid
            db_game.snake_positions = [{"x": 1, "y": 1}]
            db_game.food_position = {"x": 0, "y": 0}
            session.commit()

    # Try to move - should hit wall quickly
    moves_until_collision = 0
    game_over = False

    while not game_over and moves_until_collision < 10:
        new_state, game_over = SnakeGameService.move_snake(game.id, Direction.RIGHT)
        moves_until_collision += 1

    # Should hit wall within 2 moves in a 3x3 grid
    assert moves_until_collision <= 3
