import pytest
from datetime import datetime, timedelta
from decimal import Decimal
from app.models import (
    GameSession,
    HighScore,
    GameSettings,
    GameStatus,
    Direction,
    GameSessionCreate,
    GameSessionUpdate,
    GameState,
    HighScoreCreate,
)
from app.database import reset_db, get_session
from sqlmodel import select, desc


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_game_session_model_creation(new_db):
    """Test GameSession model creation and database storage"""
    with get_session() as session:
        game_session = GameSession(
            player_name="TestPlayer",
            score=100,
            high_score=150,
            status=GameStatus.PLAYING,
            current_direction=Direction.RIGHT,
            grid_width=20,
            grid_height=20,
            game_speed=Decimal("0.2"),
            snake_positions=[{"x": 5, "y": 5}, {"x": 4, "y": 5}],
            food_position={"x": 10, "y": 10},
        )

        session.add(game_session)
        session.commit()
        session.refresh(game_session)

        # Verify the session was created with an ID
        assert game_session.id is not None
        assert game_session.player_name == "TestPlayer"
        assert game_session.score == 100
        assert game_session.status == GameStatus.PLAYING
        assert game_session.current_direction == Direction.RIGHT

        # Verify JSON fields
        assert len(game_session.snake_positions) == 2
        assert game_session.snake_positions[0] == {"x": 5, "y": 5}
        assert game_session.food_position == {"x": 10, "y": 10}


def test_high_score_model_creation(new_db):
    """Test HighScore model creation and database storage"""
    with get_session() as session:
        high_score = HighScore(player_name="HighScorePlayer", score=500, snake_length=25, grid_size="20x20")

        session.add(high_score)
        session.commit()
        session.refresh(high_score)

        assert high_score.id is not None
        assert high_score.player_name == "HighScorePlayer"
        assert high_score.score == 500
        assert high_score.snake_length == 25
        assert high_score.grid_size == "20x20"
        assert isinstance(high_score.achieved_at, datetime)


def test_game_settings_model_creation(new_db):
    """Test GameSettings model creation and database storage"""
    with get_session() as session:
        settings = GameSettings(
            player_name="SettingsPlayer",
            preferred_grid_width=25,
            preferred_grid_height=25,
            preferred_speed=Decimal("0.15"),
            sound_enabled=True,
            show_grid_lines=False,
            theme_colors={"snake": "#green", "food": "#red"},
        )

        session.add(settings)
        session.commit()
        session.refresh(settings)

        assert settings.id is not None
        assert settings.player_name == "SettingsPlayer"
        assert settings.preferred_grid_width == 25
        assert settings.preferred_speed == Decimal("0.15")
        assert settings.theme_colors == {"snake": "#green", "food": "#red"}


def test_game_session_create_schema_validation():
    """Test GameSessionCreate schema validation"""
    # Valid data
    valid_data = GameSessionCreate(player_name="ValidPlayer", grid_width=20, grid_height=20, game_speed=Decimal("0.2"))

    assert valid_data.player_name == "ValidPlayer"
    assert valid_data.grid_width == 20
    assert valid_data.game_speed == Decimal("0.2")

    # Test default values
    default_data = GameSessionCreate()
    assert default_data.player_name == "Anonymous"
    assert default_data.grid_width == 20
    assert default_data.grid_height == 20


def test_game_session_update_schema():
    """Test GameSessionUpdate schema with optional fields"""
    update_data = GameSessionUpdate(score=100, status=GameStatus.PAUSED, current_direction=Direction.LEFT)

    assert update_data.score == 100
    assert update_data.status == GameStatus.PAUSED
    assert update_data.current_direction == Direction.LEFT

    # Test with None values (optional fields)
    partial_update = GameSessionUpdate(score=50)
    assert partial_update.score == 50
    assert partial_update.status is None
    assert partial_update.current_direction is None


def test_game_state_schema():
    """Test GameState schema for UI rendering"""
    game_state = GameState(
        session_id=1,
        player_name="UIPlayer",
        score=75,
        high_score=100,
        status=GameStatus.PLAYING,
        snake_positions=[{"x": 1, "y": 1}],
        food_position={"x": 5, "y": 5},
        grid_width=15,
        grid_height=15,
        current_direction=Direction.DOWN,
    )

    assert game_state.session_id == 1
    assert game_state.player_name == "UIPlayer"
    assert game_state.score == 75
    assert game_state.status == GameStatus.PLAYING
    assert game_state.current_direction == Direction.DOWN


def test_high_score_create_schema():
    """Test HighScoreCreate schema with grid size property"""
    high_score_data = HighScoreCreate(
        player_name="PropertyTestPlayer", score=200, snake_length=10, grid_width=20, grid_height=15
    )

    assert high_score_data.grid_size == "20x15"
    assert high_score_data.player_name == "PropertyTestPlayer"
    assert high_score_data.score == 200


def test_enum_values():
    """Test enum values are correctly defined"""
    # GameStatus enum
    assert GameStatus.PLAYING == "playing"
    assert GameStatus.PAUSED == "paused"
    assert GameStatus.GAME_OVER == "game_over"

    # Direction enum
    assert Direction.UP == "up"
    assert Direction.DOWN == "down"
    assert Direction.LEFT == "left"
    assert Direction.RIGHT == "right"


def test_database_relationships_and_queries(new_db):
    """Test database queries and relationships work correctly"""
    with get_session() as session:
        # Create multiple game sessions for the same player
        player_name = "QueryTestPlayer"

        game1 = GameSession(player_name=player_name, score=50, status=GameStatus.GAME_OVER)
        game2 = GameSession(player_name=player_name, score=75, status=GameStatus.PLAYING)

        session.add(game1)
        session.add(game2)
        session.commit()

        # Query games by player
        player_games = session.exec(select(GameSession).where(GameSession.player_name == player_name)).all()

        assert len(player_games) == 2
        scores = [game.score for game in player_games]
        assert 50 in scores
        assert 75 in scores

        # Query by status
        playing_games = session.exec(select(GameSession).where(GameSession.status == GameStatus.PLAYING)).all()

        assert len(playing_games) >= 1
        assert all(game.status == GameStatus.PLAYING for game in playing_games)


def test_high_score_ordering(new_db):
    """Test high scores are correctly ordered by score"""
    with get_session() as session:
        # Create multiple high scores
        scores = [100, 300, 200, 150]

        for i, score in enumerate(scores):
            high_score = HighScore(player_name=f"Player{i}", score=score, snake_length=score // 10, grid_size="20x20")
            session.add(high_score)

        session.commit()

        # Query high scores ordered by score descending
        stmt = select(HighScore).order_by(desc(HighScore.score))
        ordered_scores = session.exec(stmt).all()

        # Should be ordered: 300, 200, 150, 100
        assert len(ordered_scores) == 4
        assert ordered_scores[0].score == 300
        assert ordered_scores[1].score == 200
        assert ordered_scores[2].score == 150
        assert ordered_scores[3].score == 100


def test_json_field_storage_and_retrieval(new_db):
    """Test JSON fields store and retrieve complex data correctly"""
    with get_session() as session:
        # Test complex snake positions
        complex_snake = [{"x": 0, "y": 0}, {"x": 1, "y": 0}, {"x": 2, "y": 0}, {"x": 3, "y": 0}]

        # Test complex theme colors
        complex_theme = {
            "snake_head": "#darkgreen",
            "snake_body": "#lightgreen",
            "food": "#red",
            "background": "#gray",
            "grid_lines": "#lightgray",
        }

        game = GameSession(player_name="JSONTestPlayer", snake_positions=complex_snake, food_position={"x": 5, "y": 5})

        settings = GameSettings(player_name="JSONTestPlayer", theme_colors=complex_theme)

        session.add(game)
        session.add(settings)
        session.commit()
        session.refresh(game)
        session.refresh(settings)

        # Verify complex data was stored and retrieved correctly
        assert game.snake_positions == complex_snake
        assert game.food_position == {"x": 5, "y": 5}
        assert settings.theme_colors == complex_theme


def test_model_field_constraints(new_db):
    """Test model field constraints and validation"""
    with get_session() as session:
        # Test string length constraints
        long_name = "x" * 200  # Exceeds 100 character limit

        try:
            game = GameSession(player_name=long_name)
            session.add(game)
            session.commit()
        except Exception as e:
            # Should fail due to string length constraint
            session.rollback()  # Rollback the failed transaction
            assert "too long" in str(e).lower() or "constraint" in str(e).lower() or "length" in str(e).lower()

        # Test valid length name with fresh session
        valid_game = GameSession(player_name="ValidName")
        session.add(valid_game)
        session.commit()  # Should succeed

        assert valid_game.id is not None


def test_timestamp_fields(new_db):
    """Test that timestamp fields are set correctly"""
    with get_session() as session:
        game = GameSession(player_name="TimestampTest")
        high_score = HighScore(player_name="TimestampTest", score=100, snake_length=5, grid_size="20x20")
        settings = GameSettings(player_name="TimestampTest")

        session.add(game)
        session.add(high_score)
        session.add(settings)
        session.commit()
        session.refresh(game)
        session.refresh(high_score)
        session.refresh(settings)

        # Check that timestamps were set
        now = datetime.utcnow()

        assert isinstance(game.created_at, datetime)
        assert isinstance(game.updated_at, datetime)
        assert isinstance(high_score.achieved_at, datetime)
        assert isinstance(settings.created_at, datetime)
        assert isinstance(settings.updated_at, datetime)

        # Timestamps should be recent (within last minute)
        time_diff = now - game.created_at
        assert time_diff < timedelta(minutes=1)


def test_decimal_field_precision(new_db):
    """Test Decimal field precision is maintained"""
    with get_session() as session:
        # Test precise decimal values
        precise_speed = Decimal("0.123456789")

        game = GameSession(player_name="DecimalTest", game_speed=precise_speed)

        settings = GameSettings(player_name="DecimalTest", preferred_speed=precise_speed)

        session.add(game)
        session.add(settings)
        session.commit()
        session.refresh(game)
        session.refresh(settings)

        # Verify decimal precision is maintained
        assert isinstance(game.game_speed, Decimal)
        assert isinstance(settings.preferred_speed, Decimal)

        # Note: Exact precision may vary based on database backend
        # Test that values are approximately correct
        assert abs(game.game_speed - precise_speed) < Decimal("0.0001")
        assert abs(settings.preferred_speed - precise_speed) < Decimal("0.0001")
