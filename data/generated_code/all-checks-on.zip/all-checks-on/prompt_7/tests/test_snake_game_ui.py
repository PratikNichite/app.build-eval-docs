import pytest
from nicegui.testing import User
from app.snake_game import SnakeGameUI
from app.game_service import SnakeGameService
from app.models import GameStatus, Direction
from app.database import reset_db


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


async def test_snake_game_page_loads(user: User, new_db) -> None:
    """Test that the snake game page loads correctly"""
    await user.open("/")

    # Check for game title
    await user.should_see("🐍 Snake Game")

    # Check for instructions
    await user.should_see("How to Play")


async def test_high_scores_page_loads(user: User, new_db) -> None:
    """Test that high scores page loads correctly"""
    await user.open("/highscores")

    # Check for high scores title
    await user.should_see("🏆 High Scores")

    # Should show empty message when no scores exist
    await user.should_see("No high scores yet!")

    # Check for navigation buttons
    await user.should_see("🎮 Play Game")


async def test_game_creates_initial_state(user: User, new_db) -> None:
    """Test that a new game creates proper initial state"""
    # Create a game UI instance for testing
    game_ui = SnakeGameUI()
    game_ui.create_game()

    # Verify game state was created
    assert game_ui.game_state is not None
    assert game_ui.game_state.score == 0
    assert game_ui.game_state.status == GameStatus.PLAYING
    assert len(game_ui.game_state.snake_positions) == 3  # Initial snake length


async def test_game_ui_keyboard_controls(user: User, new_db) -> None:
    """Test keyboard controls functionality"""
    await user.open("/")

    # Note: Testing actual keyboard events in NiceGUI testing is limited
    # This test verifies the page loaded successfully
    await user.should_see("Snake Game")


async def test_game_ui_components_exist(user: User, new_db) -> None:
    """Test that all required UI components are present"""
    await user.open("/")

    # Check instructions are present
    await user.should_see("Controls:")
    await user.should_see("Rules:")
    await user.should_see("Arrow Keys - Move snake")
    await user.should_see("Space - Pause/Resume")
    await user.should_see("R - Restart game")


def test_snake_game_ui_initialization():
    """Test SnakeGameUI class initialization"""
    game_ui = SnakeGameUI()

    # Check initial state
    assert game_ui.game_state is None
    assert game_ui.game_timer is None
    assert game_ui.grid_container is None
    assert game_ui.score_label is None

    # Check styling constants
    assert game_ui.cell_size == 20
    assert game_ui.snake_color == "#10b981"
    assert game_ui.food_color == "#ef4444"


def test_game_ui_move_snake_logic(new_db):
    """Test UI move snake logic without creating UI components"""
    # Test that SnakeGameService.move_snake works correctly
    game = SnakeGameService.create_new_game("TestPlayer")
    assert game.id is not None

    initial_head = game.snake_positions[0]
    new_state, game_over = SnakeGameService.move_snake(game.id, Direction.RIGHT)

    assert not game_over
    assert new_state.snake_positions[0]["x"] == initial_head["x"] + 1


def test_game_ui_pause_logic(new_db):
    """Test game pause/resume logic without creating UI components"""
    # Test that SnakeGameService pause/resume works correctly
    game = SnakeGameService.create_new_game("TestPlayer")
    assert game.id is not None

    # Test pause
    pause_result = SnakeGameService.pause_game(game.id)
    assert pause_result

    state = SnakeGameService.get_game_state(game.id)
    assert state is not None
    assert state.status == GameStatus.PAUSED

    # Test resume
    resume_result = SnakeGameService.resume_game(game.id)
    assert resume_result

    state = SnakeGameService.get_game_state(game.id)
    assert state is not None
    assert state.status == GameStatus.PLAYING


async def test_high_scores_with_data(user: User, new_db) -> None:
    """Test high scores page with actual score data"""
    # Manually add a high score for testing
    from app.database import get_session
    from app.models import HighScore

    with get_session() as session:
        high_score = HighScore(player_name="TestPlayer", score=150, snake_length=8, grid_size="20x20")
        session.add(high_score)
        session.commit()

    # Navigate to high scores page
    await user.open("/highscores")

    # Should now show the high score data
    await user.should_see("TestPlayer")
    await user.should_see("Score: 150")
    await user.should_see("Length: 8")


async def test_navigation_between_pages(user: User, new_db) -> None:
    """Test navigation between game and high scores pages"""
    # Start on main game page
    await user.open("/")
    await user.should_see("🐍 Snake Game")

    # Navigate to high scores (would need actual button click in real UI)
    await user.open("/highscores")
    await user.should_see("🏆 High Scores")

    # Navigate back to game
    await user.open("/")
    await user.should_see("🐍 Snake Game")


def test_game_ui_handles_invalid_state():
    """Test UI handles invalid or missing game state gracefully"""
    game_ui = SnakeGameUI()

    # Test methods with no game state
    assert game_ui._get_status_text() == "Loading..."

    # These should not crash when game_state is None
    game_ui._update_display()  # Should handle None gracefully

    # Test with invalid session ID
    game_ui.game_state = None
    game_ui._move_snake(Direction.UP)  # Should return early


def test_game_ui_styling_constants():
    """Test that UI styling constants are properly defined"""
    game_ui = SnakeGameUI()

    # Verify color constants are hex values
    assert game_ui.snake_color.startswith("#")
    assert game_ui.food_color.startswith("#")
    assert game_ui.grid_bg_color.startswith("#")
    assert game_ui.grid_border_color.startswith("#")

    # Verify cell size is reasonable
    assert isinstance(game_ui.cell_size, int)
    assert game_ui.cell_size > 0


async def test_game_renders_without_errors(user: User, new_db) -> None:
    """Smoke test to ensure game renders without crashing"""
    await user.open("/")

    # Basic checks that page loaded successfully
    await user.should_see("Snake Game")
    await user.should_see("Score:")

    # Should not see any error messages
    await user.should_not_see("Error")
    await user.should_not_see("Failed")


def test_food_generation_logic(new_db):
    """Test food generation works correctly"""
    game = SnakeGameService.create_new_game("TestPlayer")

    # Food should be positioned within grid bounds
    food = game.food_position
    assert 0 <= food["x"] < game.grid_width
    assert 0 <= food["y"] < game.grid_height

    # Food should not be on snake
    snake_coords = {(pos["x"], pos["y"]) for pos in game.snake_positions}
    food_coord = (food["x"], food["y"])
    assert food_coord not in snake_coords


def test_game_ui_method_existence(new_db):
    """Test that UI methods exist and can be called safely"""
    game_ui = SnakeGameUI()

    # Test that methods exist
    assert hasattr(game_ui, "_restart_game")
    assert hasattr(game_ui, "_get_status_text")
    assert hasattr(game_ui, "_handle_keydown")

    # Test status text with no game state
    status = game_ui._get_status_text()
    assert status == "Loading..."


def test_direction_mapping_in_keyboard_handler():
    """Test that direction mapping is correctly defined"""
    # Test the direction mapping that would be used in keyboard handler
    direction_map = {
        "ArrowUp": Direction.UP,
        "ArrowDown": Direction.DOWN,
        "ArrowLeft": Direction.LEFT,
        "ArrowRight": Direction.RIGHT,
    }

    # Verify all directions are mapped
    assert len(direction_map) == 4
    assert all(isinstance(direction, Direction) for direction in direction_map.values())

    # Verify arrow key strings are correctly defined
    expected_keys = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"]
    assert all(key in direction_map for key in expected_keys)
