import pytest
from datetime import datetime

from app.database import reset_db
from app.movie_service import create_movie, get_all_movies, get_movie, update_movie, delete_movie, get_movies_by_status
from app.models import MovieCreate, MovieUpdate, WatchStatus


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_create_movie(new_db):
    """Test creating a new movie."""
    movie_data = MovieCreate(
        title="The Matrix", director="The Wachowskis", release_year=1999, watch_status=WatchStatus.PLANNED
    )

    movie = create_movie(movie_data)

    assert movie.id is not None
    assert movie.title == "The Matrix"
    assert movie.director == "The Wachowskis"
    assert movie.release_year == 1999
    assert movie.watch_status == WatchStatus.PLANNED
    assert isinstance(movie.created_at, datetime)


def test_create_movie_with_default_status(new_db):
    """Test creating a movie with default status."""
    movie_data = MovieCreate(title="Inception", director="Christopher Nolan", release_year=2010)

    movie = create_movie(movie_data)

    assert movie.watch_status == WatchStatus.PLANNED


def test_get_all_movies_empty(new_db):
    """Test getting all movies when database is empty."""
    movies = get_all_movies()
    assert movies == []


def test_get_all_movies_multiple(new_db):
    """Test getting all movies with multiple entries."""
    movie1_data = MovieCreate(title="The Matrix", director="The Wachowskis", release_year=1999)
    movie2_data = MovieCreate(title="Inception", director="Christopher Nolan", release_year=2010)

    create_movie(movie1_data)
    create_movie(movie2_data)

    movies = get_all_movies()
    assert len(movies) == 2
    # Should be ordered by created_at desc (newest first)
    assert movies[0].title == "Inception"
    assert movies[1].title == "The Matrix"


def test_get_movie_by_id(new_db):
    """Test getting a specific movie by ID."""
    movie_data = MovieCreate(title="Pulp Fiction", director="Quentin Tarantino", release_year=1994)

    created_movie = create_movie(movie_data)
    assert created_movie.id is not None
    retrieved_movie = get_movie(created_movie.id)

    assert retrieved_movie is not None
    assert retrieved_movie.id == created_movie.id
    assert retrieved_movie.title == "Pulp Fiction"


def test_get_movie_nonexistent(new_db):
    """Test getting a movie that doesn't exist."""
    movie = get_movie(999)
    assert movie is None


def test_update_movie_all_fields(new_db):
    """Test updating all fields of a movie."""
    movie_data = MovieCreate(
        title="Original Title", director="Original Director", release_year=2000, watch_status=WatchStatus.PLANNED
    )

    created_movie = create_movie(movie_data)

    update_data = MovieUpdate(
        title="Updated Title", director="Updated Director", release_year=2001, watch_status=WatchStatus.COMPLETED
    )

    assert created_movie.id is not None
    updated_movie = update_movie(created_movie.id, update_data)

    assert updated_movie is not None
    assert updated_movie.title == "Updated Title"
    assert updated_movie.director == "Updated Director"
    assert updated_movie.release_year == 2001
    assert updated_movie.watch_status == WatchStatus.COMPLETED
    assert updated_movie.updated_at > updated_movie.created_at


def test_update_movie_partial_fields(new_db):
    """Test updating only some fields of a movie."""
    movie_data = MovieCreate(
        title="Original Title", director="Original Director", release_year=2000, watch_status=WatchStatus.PLANNED
    )

    created_movie = create_movie(movie_data)

    update_data = MovieUpdate(watch_status=WatchStatus.WATCHING)

    assert created_movie.id is not None
    updated_movie = update_movie(created_movie.id, update_data)

    assert updated_movie is not None
    assert updated_movie.title == "Original Title"  # Unchanged
    assert updated_movie.director == "Original Director"  # Unchanged
    assert updated_movie.release_year == 2000  # Unchanged
    assert updated_movie.watch_status == WatchStatus.WATCHING  # Updated


def test_update_movie_nonexistent(new_db):
    """Test updating a movie that doesn't exist."""
    update_data = MovieUpdate(title="New Title")

    result = update_movie(999, update_data)
    assert result is None


def test_delete_movie(new_db):
    """Test deleting a movie."""
    movie_data = MovieCreate(title="To Be Deleted", director="Some Director", release_year=2020)

    created_movie = create_movie(movie_data)

    # Delete the movie
    assert created_movie.id is not None
    success = delete_movie(created_movie.id)
    assert success

    # Verify it's gone
    deleted_movie = get_movie(created_movie.id)
    assert deleted_movie is None


def test_delete_movie_nonexistent(new_db):
    """Test deleting a movie that doesn't exist."""
    success = delete_movie(999)
    assert not success


def test_get_movies_by_status(new_db):
    """Test filtering movies by watch status."""
    planned_movie = MovieCreate(
        title="Planned Movie", director="Director 1", release_year=2020, watch_status=WatchStatus.PLANNED
    )

    watching_movie = MovieCreate(
        title="Watching Movie", director="Director 2", release_year=2021, watch_status=WatchStatus.WATCHING
    )

    completed_movie = MovieCreate(
        title="Completed Movie", director="Director 3", release_year=2022, watch_status=WatchStatus.COMPLETED
    )

    create_movie(planned_movie)
    create_movie(watching_movie)
    create_movie(completed_movie)

    # Test each status filter
    planned_movies = get_movies_by_status(WatchStatus.PLANNED)
    assert len(planned_movies) == 1
    assert planned_movies[0].title == "Planned Movie"

    watching_movies = get_movies_by_status(WatchStatus.WATCHING)
    assert len(watching_movies) == 1
    assert watching_movies[0].title == "Watching Movie"

    completed_movies = get_movies_by_status(WatchStatus.COMPLETED)
    assert len(completed_movies) == 1
    assert completed_movies[0].title == "Completed Movie"


def test_get_movies_by_status_empty(new_db):
    """Test filtering by status when no movies match."""
    movies = get_movies_by_status(WatchStatus.COMPLETED)
    assert movies == []


def test_movie_validation_year_bounds(new_db):
    """Test that movie year validation works."""
    # This should work
    valid_movie = MovieCreate(title="Valid Movie", director="Director", release_year=1995)
    movie = create_movie(valid_movie)
    assert movie.release_year == 1995

    # Test with boundary values
    early_movie = MovieCreate(title="Early Movie", director="Director", release_year=1888)
    movie = create_movie(early_movie)
    assert movie.release_year == 1888

    future_movie = MovieCreate(title="Future Movie", director="Director", release_year=2030)
    movie = create_movie(future_movie)
    assert movie.release_year == 2030


def test_movie_title_and_director_required(new_db):
    """Test that title and director fields are required."""
    # These tests would fail validation at the Pydantic level
    # if we tried to create MovieCreate with empty strings
    # The validation happens before database operations

    movie_data = MovieCreate(title="Valid Title", director="Valid Director", release_year=2000)
    movie = create_movie(movie_data)
    assert movie.title == "Valid Title"
    assert movie.director == "Valid Director"
