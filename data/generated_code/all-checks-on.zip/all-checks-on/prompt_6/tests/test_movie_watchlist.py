import pytest
from nicegui.testing import User
from nicegui import ui

from app.database import reset_db
from app.movie_service import create_movie
from app.models import MovieCreate, WatchStatus


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


async def test_movie_watchlist_page_loads(user: User, new_db) -> None:
    """Test that the movie watchlist page loads properly."""
    await user.open("/")

    # Check main title is present
    await user.should_see("Movie Watchlist Manager")

    # Check add button is present
    await user.should_see("Add New Movie")

    # Check statistics cards are present
    await user.should_see("Planned")
    await user.should_see("Watching")
    await user.should_see("Completed")

    # Check table section is present
    await user.should_see("Your Movies")


async def test_add_new_movie_dialog_opens(user: User, new_db) -> None:
    """Test that the add movie dialog opens when button is clicked."""
    await user.open("/")

    # Click add button
    user.find("Add New Movie").click()

    # Check dialog content appears
    await user.should_see("Add New Movie")
    await user.should_see("Movie Title")
    await user.should_see("Director")
    await user.should_see("Release Year")
    await user.should_see("Watch Status")


async def test_add_movie_form_validation(user: User, new_db) -> None:
    """Test form validation for adding movies."""
    await user.open("/")

    # Open add dialog
    user.find("Add New Movie").click()

    # Try to submit with empty fields
    user.find("Add Movie").click()

    # Should show validation error
    await user.should_see("Please fill in all required fields")


async def test_movie_statistics_display(user: User, new_db) -> None:
    """Test that movie statistics are displayed correctly."""
    # Add test data
    planned_movie = MovieCreate(
        title="Planned Movie", director="Director 1", release_year=2020, watch_status=WatchStatus.PLANNED
    )

    watching_movie = MovieCreate(
        title="Watching Movie", director="Director 2", release_year=2021, watch_status=WatchStatus.WATCHING
    )

    completed_movie1 = MovieCreate(
        title="Completed Movie 1", director="Director 3", release_year=2022, watch_status=WatchStatus.COMPLETED
    )

    completed_movie2 = MovieCreate(
        title="Completed Movie 2", director="Director 4", release_year=2023, watch_status=WatchStatus.COMPLETED
    )

    create_movie(planned_movie)
    create_movie(watching_movie)
    create_movie(completed_movie1)
    create_movie(completed_movie2)

    await user.open("/")

    # Statistics should reflect the created movies
    # Note: These are displayed as text elements, so we check for the numbers
    await user.should_see("1")  # Planned count
    await user.should_see("1")  # Watching count
    await user.should_see("2")  # Completed count


async def test_movies_table_displays_data(user: User, new_db) -> None:
    """Test that the movies table displays movie data correctly."""
    await user.open("/")

    # Check that table component exists
    table_elements = list(user.find(ui.table).elements)
    assert len(table_elements) >= 1

    # Add test movies through the service
    movie1 = MovieCreate(
        title="The Matrix", director="The Wachowskis", release_year=1999, watch_status=WatchStatus.COMPLETED
    )

    create_movie(movie1)

    # Refresh page to see new data
    await user.open("/")

    # The table should now show the movie data
    # Note: Due to NiceGUI table rendering, we may need to check the table rows directly
    table = list(user.find(ui.table).elements)[0]
    assert len(table.rows) >= 1
    assert any("The Matrix" in str(row) for row in table.rows)


async def test_empty_table_state(user: User, new_db) -> None:
    """Test that the page handles empty movie list correctly."""
    await user.open("/")

    # Statistics should show 0
    await user.should_see("0")  # Should appear in statistics cards

    # Table should still be present but empty
    await user.should_see("Your Movies")


async def test_movie_table_columns(user: User, new_db) -> None:
    """Test that the movie table has correct column headers."""
    await user.open("/")

    # Check table headers
    await user.should_see("Title")
    await user.should_see("Director")
    await user.should_see("Year")
    await user.should_see("Status")
    # Note: Actions are now below the table, not in a column


async def test_ui_components_present(user: User, new_db) -> None:
    """Test that all essential UI components are present."""
    await user.open("/")

    # Check for table component
    table_elements = list(user.find(ui.table).elements)
    assert len(table_elements) == 1

    # Check for button component
    button_elements = list(user.find(ui.button).elements)
    assert len(button_elements) >= 1  # At least the "Add New Movie" button


async def test_page_layout_structure(user: User, new_db) -> None:
    """Test that the page has proper layout structure."""
    await user.open("/")

    # Check for cards (statistics and main content)
    card_elements = list(user.find(ui.card).elements)
    assert len(card_elements) >= 4  # 3 stat cards + 1 main content card

    # Check for rows and columns
    row_elements = list(user.find(ui.row).elements)
    assert len(row_elements) >= 2  # Header row + stats row

    column_elements = list(user.find(ui.column).elements)
    assert len(column_elements) >= 0  # May have columns for layout
