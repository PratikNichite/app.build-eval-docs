from sqlmodel import select, desc
from typing import Optional
from datetime import datetime

from app.database import get_session
from app.models import Movie, MovieCreate, MovieUpdate, WatchStatus


def create_movie(movie_data: MovieCreate) -> Movie:
    """Create a new movie entry in the database."""
    with get_session() as session:
        movie = Movie(
            title=movie_data.title,
            director=movie_data.director,
            release_year=movie_data.release_year,
            watch_status=movie_data.watch_status,
        )
        session.add(movie)
        session.commit()
        session.refresh(movie)
        return movie


def get_all_movies() -> list[Movie]:
    """Retrieve all movies from the database."""
    with get_session() as session:
        statement = select(Movie).order_by(desc(Movie.created_at))
        movies = session.exec(statement).all()
        return list(movies)


def get_movie(movie_id: int) -> Optional[Movie]:
    """Retrieve a specific movie by ID."""
    with get_session() as session:
        movie = session.get(Movie, movie_id)
        return movie


def update_movie(movie_id: int, movie_update: MovieUpdate) -> Optional[Movie]:
    """Update an existing movie entry."""
    with get_session() as session:
        movie = session.get(Movie, movie_id)
        if movie is None:
            return None

        # Update only provided fields
        update_data = movie_update.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(movie, field, value)

        movie.updated_at = datetime.utcnow()
        session.add(movie)
        session.commit()
        session.refresh(movie)
        return movie


def delete_movie(movie_id: int) -> bool:
    """Delete a movie entry from the database."""
    with get_session() as session:
        movie = session.get(Movie, movie_id)
        if movie is None:
            return False

        session.delete(movie)
        session.commit()
        return True


def get_movies_by_status(status: WatchStatus) -> list[Movie]:
    """Retrieve movies filtered by watch status."""
    with get_session() as session:
        statement = select(Movie).where(Movie.watch_status == status).order_by(desc(Movie.created_at))
        movies = session.exec(statement).all()
        return list(movies)
