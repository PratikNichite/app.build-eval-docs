from nicegui import ui
from typing import Optional
from datetime import datetime

from app.movie_service import (
    create_movie,
    get_all_movies,
    update_movie as update_movie_service,
    delete_movie,
    get_movie,
)
from app.models import MovieCreate, MovieUpdate, WatchStatus


class MovieWatchlistUI:
    def __init__(self):
        self.movies_table: Optional[ui.table] = None
        self.form_dialog: Optional[ui.dialog] = None
        self.edit_dialog: Optional[ui.dialog] = None

    def create_movie_form(self) -> None:
        """Create the add movie form dialog."""
        with ui.dialog() as self.form_dialog, ui.card():
            ui.label("Add New Movie").classes("text-xl font-bold mb-4")

            with ui.column().classes("gap-4 w-80"):
                title_input = ui.input("Movie Title", placeholder="Enter movie title").classes("w-full")
                director_input = ui.input("Director", placeholder="Enter director name").classes("w-full")
                year_input = ui.number(
                    "Release Year", value=datetime.now().year, precision=0, min=1888, max=2030
                ).classes("w-full")
                status_select = ui.select(
                    options={status.value: status.value for status in WatchStatus},
                    value=WatchStatus.PLANNED.value,
                    label="Watch Status",
                ).classes("w-full")

                with ui.row().classes("gap-2 justify-end w-full"):
                    ui.button("Cancel", on_click=self.form_dialog.close).props("outline")
                    ui.button(
                        "Add Movie",
                        on_click=lambda: self.save_movie(
                            title_input.value or "",
                            director_input.value or "",
                            int(year_input.value or datetime.now().year),
                            status_select.value or WatchStatus.PLANNED.value,
                        ),
                    )

    def save_movie(self, title: str, director: str, year: int, status: str) -> None:
        """Save a new movie to the database."""
        if not title.strip() or not director.strip():
            ui.notify("Please fill in all required fields", type="negative")
            return

        try:
            movie_data = MovieCreate(
                title=title.strip(), director=director.strip(), release_year=year, watch_status=WatchStatus(status)
            )
            create_movie(movie_data)
            ui.notify(f'🎉 Movie "{title}" added successfully!', type="positive")
            if self.form_dialog:
                self.form_dialog.close()
            self.refresh_table()
        except Exception as e:
            ui.notify(f"😟 Error adding movie: {str(e)}", type="negative")

    def create_edit_dialog(self, movie_id: int) -> None:
        """Create the edit movie dialog."""
        movie = get_movie(movie_id)
        if movie is None:
            ui.notify("Movie not found", type="negative")
            return

        with ui.dialog() as self.edit_dialog, ui.card():
            ui.label("Edit Movie").classes("text-xl font-bold mb-4")

            with ui.column().classes("gap-4 w-80"):
                title_input = ui.input("Movie Title", value=movie.title).classes("w-full")
                director_input = ui.input("Director", value=movie.director).classes("w-full")
                year_input = ui.number(
                    "Release Year", value=movie.release_year, precision=0, min=1888, max=2030
                ).classes("w-full")
                status_select = ui.select(
                    options={status.value: status.value for status in WatchStatus},
                    value=movie.watch_status.value,
                    label="Watch Status",
                ).classes("w-full")

                with ui.row().classes("gap-2 justify-end w-full"):
                    ui.button("Cancel", on_click=self.edit_dialog.close).props("outline")
                    ui.button(
                        "Save Changes",
                        on_click=lambda: self.update_movie(
                            movie_id,
                            title_input.value or "",
                            director_input.value or "",
                            int(year_input.value or movie.release_year),
                            status_select.value or movie.watch_status.value,
                        ),
                    )

        self.edit_dialog.open()

    def update_movie(self, movie_id: int, title: str, director: str, year: int, status: str) -> None:
        """Update an existing movie in the database."""
        if not title.strip() or not director.strip():
            ui.notify("Please fill in all required fields", type="negative")
            return

        try:
            movie_update = MovieUpdate(
                title=title.strip(), director=director.strip(), release_year=year, watch_status=WatchStatus(status)
            )
            updated_movie = update_movie_service(movie_id, movie_update)
            if updated_movie:
                ui.notify(f'✨ Movie "{title}" updated successfully!', type="positive")
                if self.edit_dialog:
                    self.edit_dialog.close()
                self.refresh_table()
            else:
                ui.notify("😟 Failed to update movie", type="negative")
        except Exception as e:
            ui.notify(f"😟 Error updating movie: {str(e)}", type="negative")

    async def confirm_delete(self, movie_id: int, movie_title: str) -> None:
        """Show confirmation dialog before deleting a movie."""
        with ui.dialog() as dialog, ui.card():
            ui.label("Confirm Deletion").classes("text-lg font-bold mb-4")
            ui.label(f'🗑️ Are you sure you want to delete "{movie_title}"?').classes("mb-4")
            ui.label("This action cannot be undone.").classes("text-sm text-gray-500 mb-4")

            with ui.row().classes("gap-2 justify-end"):
                ui.button("Cancel", on_click=lambda: dialog.submit("Cancel"))
                ui.button("Delete", on_click=lambda: dialog.submit("Delete")).props("color=negative")

        result = await dialog
        if result == "Delete":
            self.delete_movie(movie_id, movie_title)

    def delete_movie(self, movie_id: int, movie_title: str) -> None:
        """Delete a movie from the database."""
        try:
            success = delete_movie(movie_id)
            if success:
                ui.notify(f'👍 Movie "{movie_title}" deleted successfully!', type="positive")
                self.refresh_table()
            else:
                ui.notify("❌ Failed to delete movie", type="negative")
        except Exception as e:
            ui.notify(f"❌ Error deleting movie: {str(e)}", type="negative")

    def create_table(self) -> None:
        """Create the movies table."""
        movies = get_all_movies()

        columns = [
            {"name": "title", "label": "Title", "field": "title", "required": True, "align": "left"},
            {"name": "director", "label": "Director", "field": "director", "align": "left"},
            {"name": "release_year", "label": "Year", "field": "release_year", "align": "center"},
            {"name": "watch_status", "label": "Status", "field": "watch_status", "align": "center"},
        ]

        rows = []
        for movie in movies:
            if movie.id is not None:
                rows.append(
                    {
                        "id": movie.id,
                        "title": movie.title,
                        "director": movie.director,
                        "release_year": movie.release_year,
                        "watch_status": movie.watch_status.value,
                    }
                )

        self.movies_table = ui.table(columns=columns, rows=rows, row_key="id").classes("w-full")

        # Add action buttons below the table
        if movies:
            ui.label("Actions").classes("text-lg font-semibold mt-4 mb-2")
            with ui.column().classes("gap-2"):
                for movie in movies:
                    if movie.id is not None:
                        with ui.row().classes("gap-2 items-center"):
                            ui.label(f"{movie.title}:").classes("w-48 text-sm")
                            ui.button(
                                "Edit", on_click=lambda e, movie_id=movie.id: self.create_edit_dialog(movie_id)
                            ).classes("text-sm")
                            ui.button(
                                "Delete",
                                on_click=lambda e, movie_id=movie.id, title=movie.title: self.confirm_delete(
                                    movie_id, title
                                ),
                            ).props("color=negative").classes("text-sm")

    def refresh_table(self) -> None:
        """Refresh the movies table with updated data."""
        # For now, just refresh the whole page to ensure table updates
        ui.navigate.reload()


def create():
    """Create the movie watchlist page."""

    @ui.page("/")
    def index():
        # Apply modern theme
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        # Main content
        watchlist = MovieWatchlistUI()
        watchlist.create_movie_form()

        # Page header
        with ui.row().classes("w-full items-center justify-between mb-6"):
            ui.label("🎬 Movie Watchlist Manager").classes("text-3xl font-bold text-gray-800")
            ui.button(
                "Add New Movie", on_click=lambda: watchlist.form_dialog.open() if watchlist.form_dialog else None
            ).props("icon=add")

        # Statistics cards
        movies = get_all_movies()
        planned_count = sum(1 for m in movies if m.watch_status == WatchStatus.PLANNED)
        watching_count = sum(1 for m in movies if m.watch_status == WatchStatus.WATCHING)
        completed_count = sum(1 for m in movies if m.watch_status == WatchStatus.COMPLETED)

        with ui.row().classes("gap-4 w-full mb-6"):
            with ui.card().classes("p-4 bg-blue-50 border-l-4 border-blue-400"):
                ui.label("Planned").classes("text-sm text-blue-600 uppercase tracking-wider")
                ui.label(str(planned_count)).classes("text-2xl font-bold text-blue-800")

            with ui.card().classes("p-4 bg-orange-50 border-l-4 border-orange-400"):
                ui.label("Watching").classes("text-sm text-orange-600 uppercase tracking-wider")
                ui.label(str(watching_count)).classes("text-2xl font-bold text-orange-800")

            with ui.card().classes("p-4 bg-green-50 border-l-4 border-green-400"):
                ui.label("Completed").classes("text-sm text-green-600 uppercase tracking-wider")
                ui.label(str(completed_count)).classes("text-2xl font-bold text-green-800")

        # Movies table
        with ui.card().classes("w-full p-4"):
            ui.label("Your Movies").classes("text-xl font-semibold mb-4")
            watchlist.create_table()

        return watchlist
