from sqlmodel import SQLModel, Field
from datetime import datetime
from typing import Optional
from enum import Enum


class WatchStatus(str, Enum):
    PLANNED = "Planned"
    WATCHING = "Watching"
    COMPLETED = "Completed"


# Persistent model (stored in database)
class Movie(SQLModel, table=True):
    __tablename__ = "movies"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    title: str = Field(max_length=200)
    director: str = Field(max_length=100)
    release_year: int = Field(ge=1888, le=2030)  # First movie was 1888, reasonable upper limit
    watch_status: WatchStatus = Field(default=WatchStatus.PLANNED)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class MovieCreate(SQLModel, table=False):
    title: str = Field(max_length=200)
    director: str = Field(max_length=100)
    release_year: int = Field(ge=1888, le=2030)
    watch_status: WatchStatus = Field(default=WatchStatus.PLANNED)


class MovieUpdate(SQLModel, table=False):
    title: Optional[str] = Field(default=None, max_length=200)
    director: Optional[str] = Field(default=None, max_length=100)
    release_year: Optional[int] = Field(default=None, ge=1888, le=2030)
    watch_status: Optional[WatchStatus] = Field(default=None)
