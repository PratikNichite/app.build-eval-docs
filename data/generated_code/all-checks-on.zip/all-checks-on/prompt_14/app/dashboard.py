from datetime import date, timedelta
from decimal import Decimal
from nicegui import ui, app
from app.services import UserService, MetricsService, VisualizationService, SuggestionService
from app.models import DailyMetric, DailyMetricUpdate


def create():
    # Apply modern theme
    ui.colors(
        primary="#2563eb",
        secondary="#64748b",
        accent="#10b981",
        positive="#10b981",
        negative="#ef4444",
        warning="#f59e0b",
        info="#3b82f6",
    )

    @ui.page("/")
    async def dashboard():
        await ui.context.client.connected()

        # Get or create default user
        user = UserService.get_or_create_default_user()
        current_date = date.today()

        # Store user in tab storage
        app.storage.tab["user_id"] = user.id
        app.storage.tab["current_date"] = current_date.isoformat()

        # Page header
        with ui.row().classes("w-full justify-between items-center mb-6"):
            ui.label("💚 Personal Wellness Dashboard").classes("text-3xl font-bold text-gray-800")
            ui.label(f"Welcome back, {user.name}! 👋").classes("text-lg text-gray-600")

        # Date selector
        with ui.card().classes("w-full p-4 mb-6 shadow-md"):
            with ui.row().classes("items-center gap-4"):
                ui.label("Viewing data for:").classes("text-sm font-medium text-gray-700")
                date_input = ui.date(value=current_date.isoformat()).classes("w-48")

                def handle_date_change(e):
                    app.storage.tab["current_date"] = e.value
                    ui.navigate.reload()

                date_input.on("update:model-value", handle_date_change)

                # Quick date navigation
                ui.button("Yesterday", on_click=lambda: navigate_date(-1)).props("outline size=sm")
                ui.button("Today", on_click=lambda: navigate_date(0)).props("size=sm").classes("bg-primary text-white")

        # Get current metric for the selected date
        selected_date = date.fromisoformat(app.storage.tab.get("current_date", current_date.isoformat()))
        if user.id is not None:
            current_metric = MetricsService.get_or_create_daily_metric(user.id, selected_date)
        else:
            ui.notify("❌ Error: Invalid user", type="negative")
            return

        # Main content in two columns
        with ui.row().classes("w-full gap-6"):
            # Left column - Data Entry
            with ui.column().classes("w-1/2"):
                await create_data_entry_form(current_metric)

            # Right column - Suggestions and Quick Stats
            with ui.column().classes("w-1/2"):
                if user.id is not None:
                    await create_suggestions_panel(current_metric, user.id)

        # Full-width visualization section
        with ui.card().classes("w-full p-6 mt-6 shadow-lg"):
            ui.label("📈 Trends & Insights").classes("text-xl font-bold text-gray-800 mb-4")
            if user.id is not None:
                await create_visualization_section(user.id)


def navigate_date(days_offset: int):
    """Navigate to a different date"""
    current_date_str = app.storage.tab.get("current_date", date.today().isoformat())
    current_date = date.fromisoformat(current_date_str)

    if days_offset == 0:
        new_date = date.today()
    else:
        new_date = current_date + timedelta(days=days_offset)

    app.storage.tab["current_date"] = new_date.isoformat()
    ui.navigate.reload()


async def create_data_entry_form(metric: DailyMetric):
    """Create the data entry form for daily metrics"""
    with ui.card().classes("w-full p-6 shadow-lg"):
        ui.label("📝 Daily Metrics Entry").classes("text-xl font-bold text-gray-800 mb-4")

        # Sleep Duration
        ui.label("Sleep Duration (hours)").classes("text-sm font-medium text-gray-700 mb-1")
        sleep_input = ui.number(
            value=float(metric.sleep_duration) if metric.sleep_duration else None,
            min=0,
            max=24,
            step=0.5,
            placeholder="e.g., 7.5",
        ).classes("w-full mb-4")

        # Work Hours
        ui.label("Work Hours").classes("text-sm font-medium text-gray-700 mb-1")
        work_input = ui.number(
            value=float(metric.work_hours) if metric.work_hours else None,
            min=0,
            max=24,
            step=0.5,
            placeholder="e.g., 8.0",
        ).classes("w-full mb-4")

        # Social Time
        ui.label("Social Time (hours)").classes("text-sm font-medium text-gray-700 mb-1")
        social_input = ui.number(
            value=float(metric.social_time) if metric.social_time else None,
            min=0,
            max=24,
            step=0.5,
            placeholder="e.g., 2.0",
        ).classes("w-full mb-4")

        # Screen Time
        ui.label("Screen Time (hours)").classes("text-sm font-medium text-gray-700 mb-1")
        screen_input = ui.number(
            value=float(metric.screen_time) if metric.screen_time else None,
            min=0,
            max=24,
            step=0.5,
            placeholder="e.g., 6.0",
        ).classes("w-full mb-4")

        # Emotional Energy
        ui.label("Emotional Energy Level (1-10)").classes("text-sm font-medium text-gray-700 mb-1")
        energy_input = ui.number(
            value=metric.emotional_energy if metric.emotional_energy else None,
            min=1,
            max=10,
            step=1,
            placeholder="Rate from 1 (low) to 10 (high)",
        ).classes("w-full mb-4")

        # Notes
        ui.label("Notes (optional)").classes("text-sm font-medium text-gray-700 mb-1")
        notes_input = (
            ui.textarea(
                value=metric.notes if metric.notes else "", placeholder="Any additional notes about your day..."
            )
            .classes("w-full mb-4")
            .props("rows=3")
        )

        # Save button
        async def save_metrics():
            try:
                update_data = DailyMetricUpdate(
                    sleep_duration=Decimal(str(sleep_input.value)) if sleep_input.value is not None else None,
                    work_hours=Decimal(str(work_input.value)) if work_input.value is not None else None,
                    social_time=Decimal(str(social_input.value)) if social_input.value is not None else None,
                    screen_time=Decimal(str(screen_input.value)) if screen_input.value is not None else None,
                    emotional_energy=int(energy_input.value) if energy_input.value is not None else None,
                    notes=notes_input.value or "",
                )

                if metric.id is not None:
                    updated_metric = MetricsService.update_daily_metric(metric.id, update_data)
                    if updated_metric:
                        ui.notify("✅ Metrics saved successfully!", type="positive")
                        # Reload page to refresh suggestions and visualizations
                        ui.navigate.reload()
                    else:
                        ui.notify("❌ Failed to save metrics", type="negative")
                else:
                    ui.notify("❌ Error: Could not find metric to update", type="negative")

            except Exception as e:
                ui.notify(f"❌ Error saving metrics: {str(e)}", type="negative")

        ui.button("Save Metrics", on_click=save_metrics).classes(
            "w-full bg-primary text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-600 transition-colors"
        )


async def create_suggestions_panel(metric: DailyMetric, user_id: int):
    """Create the suggestions and quick stats panel"""
    with ui.card().classes("w-full p-6 shadow-lg mb-4"):
        ui.label("💡 Today's Insights").classes("text-xl font-bold text-gray-800 mb-4")

        # Get recent metrics for pattern analysis
        recent_metrics = MetricsService.get_last_n_days_metrics(user_id, 7)
        suggestions = SuggestionService.generate_suggestions(metric, recent_metrics)

        if suggestions:
            for suggestion in suggestions:
                with ui.row().classes("items-start gap-2 mb-2"):
                    ui.label(suggestion).classes("text-sm text-gray-700 leading-relaxed")
        else:
            ui.label("🗳 Enter your daily metrics to get personalized suggestions!").classes(
                "text-sm text-gray-500 italic"
            )

    # Quick stats card
    with ui.card().classes("w-full p-6 shadow-lg"):
        ui.label("📆 Weekly Summary").classes("text-xl font-bold text-gray-800 mb-4")

        stats = VisualizationService.get_summary_stats(recent_metrics)

        if stats:
            for field, data in stats.items():
                field_name = field.replace("_", " ").title()
                if field == "emotional_energy":
                    ui.label(f"{field_name}: {data['avg']}/10 avg").classes("text-sm text-gray-600 mb-1")
                else:
                    ui.label(f"{field_name}: {data['avg']}h avg").classes("text-sm text-gray-600 mb-1")
        else:
            ui.label("🔍 Track metrics for a few days to see your weekly summary!").classes(
                "text-sm text-gray-500 italic"
            )


async def create_visualization_section(user_id: int):
    """Create charts and visualizations"""
    # Get last 30 days of data
    metrics = MetricsService.get_last_n_days_metrics(user_id, 30)

    if not metrics:
        ui.label("🗳 Start tracking your daily metrics to see trends and patterns here!").classes(
            "text-center text-gray-500 italic py-8"
        )
        return

    # Create tabs for different visualizations
    with ui.tabs().classes("w-full") as tabs:
        sleep_tab = ui.tab("Sleep & Energy")
        work_tab = ui.tab("Work & Screen Time")
        social_tab = ui.tab("Social & Balance")

    with ui.tab_panels(tabs, value=sleep_tab).classes("w-full"):
        # Sleep & Energy panel
        with ui.tab_panel(sleep_tab):
            with ui.row().classes("w-full gap-4"):
                # Sleep duration chart
                sleep_data = VisualizationService.prepare_chart_data(metrics, "sleep_duration")
                if any(v is not None for v in sleep_data["values"]):
                    create_line_chart("Sleep Duration (hours)", sleep_data, "sleep-chart")

                # Energy levels chart
                energy_data = VisualizationService.prepare_chart_data(metrics, "emotional_energy")
                if any(v is not None for v in energy_data["values"]):
                    create_line_chart("Emotional Energy (1-10)", energy_data, "energy-chart")

        # Work & Screen Time panel
        with ui.tab_panel(work_tab):
            with ui.row().classes("w-full gap-4"):
                # Work hours chart
                work_data = VisualizationService.prepare_chart_data(metrics, "work_hours")
                if any(v is not None for v in work_data["values"]):
                    create_line_chart("Work Hours", work_data, "work-chart")

                # Screen time chart
                screen_data = VisualizationService.prepare_chart_data(metrics, "screen_time")
                if any(v is not None for v in screen_data["values"]):
                    create_line_chart("Screen Time (hours)", screen_data, "screen-chart")

        # Social & Balance panel
        with ui.tab_panel(social_tab):
            with ui.row().classes("w-full gap-4"):
                # Social time chart
                social_data = VisualizationService.prepare_chart_data(metrics, "social_time")
                if any(v is not None for v in social_data["values"]):
                    create_line_chart("Social Time (hours)", social_data, "social-chart")

                # Combined balance view
                create_balance_chart(metrics)


def create_line_chart(title: str, data: dict, chart_id: str):
    """Create a line chart with the given data"""
    chart_config = {
        "chart": {"type": "line", "height": 300},
        "title": {"text": title, "style": {"fontSize": "16px", "fontWeight": "bold"}},
        "xAxis": {"categories": data["dates"], "title": {"text": "Date"}},
        "yAxis": {"title": {"text": data["field"]}, "min": 0},
        "series": [
            {
                "name": data["field"],
                "data": data["values"],
                "color": "#2563eb",
                "marker": {"enabled": True, "radius": 4},
            }
        ],
        "plotOptions": {"line": {"dataLabels": {"enabled": False}, "enableMouseTracking": True, "connectNulls": False}},
        "legend": {"enabled": False},
        "credits": {"enabled": False},
    }

    with ui.card().classes("w-1/2 p-4"):
        ui.highchart(chart_config).classes("w-full h-80")


def create_balance_chart(metrics):
    """Create a stacked area chart showing daily balance"""
    dates = [m.metric_date.isoformat() for m in metrics]

    # Prepare data for stacked chart
    sleep_data = [float(m.sleep_duration) if m.sleep_duration else 0 for m in metrics]
    work_data = [float(m.work_hours) if m.work_hours else 0 for m in metrics]
    social_data = [float(m.social_time) if m.social_time else 0 for m in metrics]
    screen_data = [float(m.screen_time) if m.screen_time else 0 for m in metrics]

    chart_config = {
        "chart": {"type": "area", "height": 350},
        "title": {"text": "Daily Time Balance", "style": {"fontSize": "16px", "fontWeight": "bold"}},
        "xAxis": {"categories": dates, "title": {"text": "Date"}},
        "yAxis": {"title": {"text": "Hours"}, "min": 0},
        "plotOptions": {"area": {"stacking": "normal", "lineColor": "#666666", "lineWidth": 1}},
        "series": [
            {"name": "Sleep", "data": sleep_data, "color": "#8b5cf6"},
            {"name": "Work", "data": work_data, "color": "#ef4444"},
            {"name": "Social", "data": social_data, "color": "#10b981"},
            {"name": "Screen", "data": screen_data, "color": "#f59e0b"},
        ],
        "credits": {"enabled": False},
    }

    with ui.card().classes("w-full p-4"):
        ui.highchart(chart_config).classes("w-full h-96")
