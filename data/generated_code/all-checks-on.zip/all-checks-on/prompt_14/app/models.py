from sqlmodel import SQLModel, Field, Relationship
from datetime import datetime, date
from typing import Optional, List
from decimal import Decimal


# Persistent models (stored in database)
class User(SQLModel, table=True):
    __tablename__ = "users"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100)
    email: str = Field(unique=True, max_length=255)
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)

    daily_metrics: List["DailyMetric"] = Relationship(back_populates="user")


class DailyMetric(SQLModel, table=True):
    __tablename__ = "daily_metrics"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="users.id")
    metric_date: date = Field(description="Date for which metrics are recorded")

    # Sleep duration in hours (can be decimal, e.g., 7.5 hours)
    sleep_duration: Optional[Decimal] = Field(default=None, description="Sleep duration in hours")

    # Work hours (can be decimal, e.g., 8.5 hours)
    work_hours: Optional[Decimal] = Field(default=None, description="Work hours for the day")

    # Social time in hours (can be decimal)
    social_time: Optional[Decimal] = Field(default=None, description="Social time in hours")

    # Screen time in hours (can be decimal)
    screen_time: Optional[Decimal] = Field(default=None, description="Screen time in hours")

    # Emotional energy level (1-10 scale)
    emotional_energy: Optional[int] = Field(default=None, ge=1, le=10, description="Emotional energy level (1-10)")

    # Notes for additional context
    notes: str = Field(default="", max_length=1000, description="Additional notes for the day")

    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    user: User = Relationship(back_populates="daily_metrics")


# Non-persistent schemas (for validation, forms, API requests/responses)
class UserCreate(SQLModel, table=False):
    name: str = Field(max_length=100)
    email: str = Field(max_length=255)


class UserUpdate(SQLModel, table=False):
    name: Optional[str] = Field(default=None, max_length=100)
    email: Optional[str] = Field(default=None, max_length=255)
    is_active: Optional[bool] = Field(default=None)


class DailyMetricCreate(SQLModel, table=False):
    user_id: int
    metric_date: date
    sleep_duration: Optional[Decimal] = Field(default=None)
    work_hours: Optional[Decimal] = Field(default=None)
    social_time: Optional[Decimal] = Field(default=None)
    screen_time: Optional[Decimal] = Field(default=None)
    emotional_energy: Optional[int] = Field(default=None, ge=1, le=10)
    notes: str = Field(default="", max_length=1000)


class DailyMetricUpdate(SQLModel, table=False):
    sleep_duration: Optional[Decimal] = Field(default=None)
    work_hours: Optional[Decimal] = Field(default=None)
    social_time: Optional[Decimal] = Field(default=None)
    screen_time: Optional[Decimal] = Field(default=None)
    emotional_energy: Optional[int] = Field(default=None, ge=1, le=10)
    notes: Optional[str] = Field(default=None, max_length=1000)


class DailyMetricResponse(SQLModel, table=False):
    id: int
    user_id: int
    metric_date: date
    sleep_duration: Optional[Decimal]
    work_hours: Optional[Decimal]
    social_time: Optional[Decimal]
    screen_time: Optional[Decimal]
    emotional_energy: Optional[int]
    notes: str
    created_at: datetime
    updated_at: datetime
