from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Optional, List, Dict, Any
from sqlmodel import select, and_, asc
from app.database import get_session
from app.models import User, DailyMetric, DailyMetricUpdate


class UserService:
    @staticmethod
    def get_or_create_default_user() -> User:
        """Get or create a default user for this demo application."""
        with get_session() as session:
            user = session.exec(select(User).where(User.email == "demo@example.com")).first()
            if user is None:
                user = User(name="Demo User", email="demo@example.com")
                session.add(user)
                session.commit()
                session.refresh(user)
            return user

    @staticmethod
    def get_user_by_id(user_id: int) -> Optional[User]:
        """Get user by ID."""
        with get_session() as session:
            return session.get(User, user_id)


class MetricsService:
    @staticmethod
    def get_or_create_daily_metric(user_id: int, metric_date: date) -> DailyMetric:
        """Get existing daily metric or create a new one for the given date."""
        with get_session() as session:
            metric = session.exec(
                select(DailyMetric).where(and_(DailyMetric.user_id == user_id, DailyMetric.metric_date == metric_date))
            ).first()

            if metric is None:
                metric = DailyMetric(user_id=user_id, metric_date=metric_date)
                session.add(metric)
                session.commit()
                session.refresh(metric)
            return metric

    @staticmethod
    def update_daily_metric(metric_id: int, update_data: DailyMetricUpdate) -> Optional[DailyMetric]:
        """Update an existing daily metric."""
        with get_session() as session:
            metric = session.get(DailyMetric, metric_id)
            if metric is None:
                return None

            update_dict = update_data.model_dump(exclude_unset=True)
            for field, value in update_dict.items():
                setattr(metric, field, value)

            metric.updated_at = datetime.utcnow()
            session.add(metric)
            session.commit()
            session.refresh(metric)
            return metric

    @staticmethod
    def get_metrics_for_date_range(user_id: int, start_date: date, end_date: date) -> List[DailyMetric]:
        """Get all metrics for a user within a date range."""
        with get_session() as session:
            return list(
                session.exec(
                    select(DailyMetric)
                    .where(
                        and_(
                            DailyMetric.user_id == user_id,
                            DailyMetric.metric_date >= start_date,
                            DailyMetric.metric_date <= end_date,
                        )
                    )
                    .order_by(asc(DailyMetric.metric_date))
                ).all()
            )

    @staticmethod
    def get_last_n_days_metrics(user_id: int, days: int = 30) -> List[DailyMetric]:
        """Get metrics for the last N days."""
        end_date = date.today()
        start_date = end_date - timedelta(days=days - 1)
        return MetricsService.get_metrics_for_date_range(user_id, start_date, end_date)


class VisualizationService:
    @staticmethod
    def prepare_chart_data(metrics: List[DailyMetric], field: str) -> Dict[str, Any]:
        """Prepare data for chart visualization."""
        dates = []
        values = []

        for metric in metrics:
            dates.append(metric.metric_date.isoformat())
            value = getattr(metric, field)
            values.append(float(value) if value is not None else None)

        return {"dates": dates, "values": values, "field": field.replace("_", " ").title()}

    @staticmethod
    def get_summary_stats(metrics: List[DailyMetric]) -> Dict[str, Any]:
        """Calculate summary statistics for metrics."""
        if not metrics:
            return {}

        stats = {}
        fields = ["sleep_duration", "work_hours", "social_time", "screen_time", "emotional_energy"]

        for field in fields:
            values = [getattr(m, field) for m in metrics if getattr(m, field) is not None]
            if values:
                if field == "emotional_energy":
                    values = [int(v) for v in values]
                else:
                    values = [float(v) for v in values]

                stats[field] = {
                    "avg": round(sum(values) / len(values), 1),
                    "min": min(values),
                    "max": max(values),
                    "count": len(values),
                }

        return stats


class SuggestionService:
    @staticmethod
    def generate_suggestions(current_metric: DailyMetric, recent_metrics: List[DailyMetric]) -> List[str]:
        """Generate break and wellness suggestions based on current and recent metrics."""
        suggestions = []

        # Work hours suggestions
        if current_metric.work_hours and current_metric.work_hours > Decimal("8"):
            suggestions.append("⚠️ You've worked over 8 hours today. Consider taking a break!")

        # Screen time suggestions
        if current_metric.screen_time and current_metric.screen_time > Decimal("6"):
            suggestions.append(
                "📱 High screen time detected. Try the 20-20-20 rule: every 20 minutes, look at something 20 feet away for 20 seconds."
            )

        # Sleep duration suggestions
        if current_metric.sleep_duration and current_metric.sleep_duration < Decimal("7"):
            suggestions.append("😴 You got less than 7 hours of sleep. Try to get to bed earlier tonight.")
        elif current_metric.sleep_duration and current_metric.sleep_duration > Decimal("9"):
            suggestions.append("😴 You slept more than 9 hours. Consider maintaining a consistent sleep schedule.")

        # Social time suggestions
        if current_metric.social_time and current_metric.social_time < Decimal("1"):
            suggestions.append("👥 Low social interaction today. Consider reaching out to friends or family.")

        # Energy level suggestions
        if current_metric.emotional_energy and current_metric.emotional_energy <= 3:
            suggestions.append(
                "💚 Low energy levels detected. Consider taking a walk, practicing deep breathing, or doing something you enjoy."
            )

        # Combined work + screen time
        if (
            current_metric.work_hours
            and current_metric.screen_time
            and current_metric.work_hours + current_metric.screen_time > Decimal("10")
        ):
            suggestions.append("⏰ High combined work and screen time. Take regular breaks every hour.")

        # Recent patterns analysis
        if len(recent_metrics) >= 3:
            recent_sleep = [m.sleep_duration for m in recent_metrics[-3:] if m.sleep_duration]
            if recent_sleep and all(s < Decimal("6.5") for s in recent_sleep):
                suggestions.append(
                    "📊 Pattern Alert: You've had low sleep for several days. Prioritize rest this weekend."
                )

            recent_energy = [m.emotional_energy for m in recent_metrics[-3:] if m.emotional_energy]
            if recent_energy and all(e <= 4 for e in recent_energy):
                suggestions.append(
                    "📊 Pattern Alert: Your energy levels have been consistently low. Consider scheduling some relaxation time."
                )

        # Positive reinforcement
        if current_metric.emotional_energy and current_metric.emotional_energy >= 8:
            suggestions.append("🌟 Great energy levels today! Keep up the good work!")

        if (
            current_metric.sleep_duration
            and current_metric.social_time
            and current_metric.sleep_duration >= Decimal("7")
            and current_metric.social_time >= Decimal("2")
        ):
            suggestions.append("✨ Nice balance of sleep and social time today - you're taking good care of yourself!")

        return suggestions
