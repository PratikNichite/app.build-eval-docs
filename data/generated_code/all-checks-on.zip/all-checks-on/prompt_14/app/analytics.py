from nicegui import ui, app
from app.services import UserService, MetricsService, VisualizationService


def create():
    @ui.page("/analytics")
    async def analytics_page():
        await ui.context.client.connected()

        # Get user from session or default
        user_id = app.storage.tab.get("user_id")
        if user_id is None:
            user = UserService.get_or_create_default_user()
            if user.id is not None:
                user_id = user.id
                app.storage.tab["user_id"] = user_id
            else:
                ui.notify("Error: Could not create user", type="negative")
                return

        # Page header
        with ui.row().classes("w-full justify-between items-center mb-6"):
            ui.label("📊 Detailed Analytics").classes("text-3xl font-bold text-gray-800")
            ui.button("← Back to Dashboard", on_click=lambda: ui.navigate.to("/")).props("outline")

        # Time period selector
        with ui.card().classes("w-full p-4 mb-6 shadow-md"):
            with ui.row().classes("items-center gap-4"):
                ui.label("Analysis Period:").classes("text-sm font-medium text-gray-700")

                period = ui.select(["Last 7 days", "Last 30 days", "Last 90 days"], value="Last 30 days").classes(
                    "w-48"
                )

                def update_period(e):
                    app.storage.tab["analysis_period"] = e.value
                    ui.navigate.reload()

                period.on("update:model-value", update_period)

        # Get data based on selected period
        period_value = app.storage.tab.get("analysis_period", "Last 30 days")
        days_map = {"Last 7 days": 7, "Last 30 days": 30, "Last 90 days": 90}
        days = days_map.get(period_value, 30)

        metrics = MetricsService.get_last_n_days_metrics(user_id, days)

        if not metrics:
            ui.label("🗳 No data available for the selected period. Start tracking your daily metrics!").classes(
                "text-center text-gray-500 italic py-8"
            )
            return

        # Summary statistics cards
        await create_summary_cards(metrics)

        # Detailed charts
        await create_detailed_charts(metrics, period_value)

        # Correlation analysis
        await create_correlation_analysis(metrics)


async def create_summary_cards(metrics):
    """Create summary statistic cards"""
    stats = VisualizationService.get_summary_stats(metrics)

    ui.label("📊 Summary Statistics").classes("text-2xl font-bold text-gray-800 mb-4")

    with ui.row().classes("w-full gap-4 mb-6"):
        # Sleep card
        if "sleep_duration" in stats:
            create_stat_card(
                "Average Sleep",
                f"{stats['sleep_duration']['avg']} hours",
                get_sleep_insight(stats["sleep_duration"]["avg"]),
                "😴",
            )

        # Work card
        if "work_hours" in stats:
            create_stat_card(
                "Average Work",
                f"{stats['work_hours']['avg']} hours",
                get_work_insight(stats["work_hours"]["avg"]),
                "💼",
            )

        # Energy card
        if "emotional_energy" in stats:
            create_stat_card(
                "Average Energy",
                f"{stats['emotional_energy']['avg']}/10",
                get_energy_insight(stats["emotional_energy"]["avg"]),
                "⚡",
            )

        # Screen time card
        if "screen_time" in stats:
            create_stat_card(
                "Average Screen Time",
                f"{stats['screen_time']['avg']} hours",
                get_screen_insight(stats["screen_time"]["avg"]),
                "📱",
            )


def create_stat_card(title: str, value: str, insight: str, icon: str):
    """Create a statistic card with insight"""
    with ui.card().classes("flex-1 p-6 shadow-lg"):
        with ui.row().classes("items-center gap-3 mb-2"):
            ui.label(icon).classes("text-2xl")
            ui.label(title).classes("text-lg font-semibold text-gray-700")

        ui.label(value).classes("text-3xl font-bold text-primary mb-2")
        ui.label(insight).classes("text-sm text-gray-600")


def get_sleep_insight(avg_sleep: float) -> str:
    """Get insight text for sleep duration"""
    if avg_sleep < 6:
        return "Below recommended range. Try to get more rest."
    elif avg_sleep < 7:
        return "On the lower end. Consider going to bed earlier."
    elif avg_sleep <= 9:
        return "Good sleep duration! Keep it up."
    else:
        return "Above average. Consider consistent timing."


def get_work_insight(avg_work: float) -> str:
    """Get insight text for work hours"""
    if avg_work < 6:
        return "Light work schedule"
    elif avg_work <= 8:
        return "Standard work hours"
    elif avg_work <= 10:
        return "Extended work hours. Consider breaks."
    else:
        return "Very long hours. Prioritize work-life balance."


def get_energy_insight(avg_energy: float) -> str:
    """Get insight text for energy levels"""
    if avg_energy < 4:
        return "Low energy. Consider lifestyle changes."
    elif avg_energy < 6:
        return "Below average. Look for patterns."
    elif avg_energy < 8:
        return "Good energy levels overall."
    else:
        return "Excellent energy! You're doing great."


def get_screen_insight(avg_screen: float) -> str:
    """Get insight text for screen time"""
    if avg_screen < 4:
        return "Low screen time. Great job!"
    elif avg_screen < 6:
        return "Moderate screen usage."
    elif avg_screen < 8:
        return "High screen time. Consider breaks."
    else:
        return "Very high usage. Try to reduce."


async def create_detailed_charts(metrics, period: str):
    """Create detailed analytical charts"""
    ui.label("💾 Detailed Trends").classes("text-2xl font-bold text-gray-800 mb-4 mt-8")

    # Comprehensive time series chart
    dates = [m.metric_date.isoformat() for m in metrics]

    chart_config = {
        "chart": {"type": "line", "height": 400, "zoomType": "x"},
        "title": {"text": f"All Metrics Over Time - {period}", "style": {"fontSize": "18px", "fontWeight": "bold"}},
        "xAxis": {"categories": dates, "title": {"text": "Date"}, "labels": {"rotation": -45}},
        "yAxis": [
            {"title": {"text": "Hours"}, "min": 0},
            {"title": {"text": "Energy Level (1-10)"}, "min": 1, "max": 10, "opposite": True},
        ],
        "series": [
            {
                "name": "Sleep Duration",
                "data": [float(m.sleep_duration) if m.sleep_duration else None for m in metrics],
                "color": "#8b5cf6",
                "yAxis": 0,
            },
            {
                "name": "Work Hours",
                "data": [float(m.work_hours) if m.work_hours else None for m in metrics],
                "color": "#ef4444",
                "yAxis": 0,
            },
            {
                "name": "Social Time",
                "data": [float(m.social_time) if m.social_time else None for m in metrics],
                "color": "#10b981",
                "yAxis": 0,
            },
            {
                "name": "Screen Time",
                "data": [float(m.screen_time) if m.screen_time else None for m in metrics],
                "color": "#f59e0b",
                "yAxis": 0,
            },
            {
                "name": "Energy Level",
                "data": [int(m.emotional_energy) if m.emotional_energy else None for m in metrics],
                "color": "#06b6d4",
                "yAxis": 1,
                "type": "spline",
                "marker": {"enabled": True, "radius": 3},
            },
        ],
        "plotOptions": {"line": {"connectNulls": False}, "spline": {"connectNulls": False}},
        "legend": {"align": "top"},
        "credits": {"enabled": False},
        "tooltip": {"shared": True, "crosshairs": True},
    }

    with ui.card().classes("w-full p-4 mb-6"):
        ui.highchart(chart_config).classes("w-full")


async def create_correlation_analysis(metrics):
    """Create correlation analysis section"""
    ui.label("🔍 Pattern Analysis").classes("text-2xl font-bold text-gray-800 mb-4 mt-8")

    # Calculate some basic correlations
    correlations = calculate_correlations(metrics)

    with ui.row().classes("w-full gap-6"):
        # Weekday vs Weekend analysis
        with ui.card().classes("w-1/2 p-6 shadow-lg"):
            ui.label("Weekday vs Weekend Patterns").classes("text-lg font-semibold text-gray-700 mb-4")
            weekday_weekend_analysis = analyze_weekday_weekend(metrics)

            for pattern in weekday_weekend_analysis:
                ui.label(pattern).classes("text-sm text-gray-600 mb-2")

        # Sleep vs Energy correlation
        with ui.card().classes("w-1/2 p-6 shadow-lg"):
            ui.label("Key Insights").classes("text-lg font-semibold text-gray-700 mb-4")

            for insight in correlations:
                ui.label(insight).classes("text-sm text-gray-600 mb-2")


def calculate_correlations(metrics):
    """Calculate and return correlation insights"""
    insights = []

    # Sleep vs Energy correlation
    sleep_energy_pairs = [
        (float(m.sleep_duration), int(m.emotional_energy))
        for m in metrics
        if m.sleep_duration is not None and m.emotional_energy is not None
    ]

    if len(sleep_energy_pairs) >= 5:
        avg_sleep_low_energy = sum(s for s, e in sleep_energy_pairs if e <= 5) / max(
            1, len([s for s, e in sleep_energy_pairs if e <= 5])
        )
        avg_sleep_high_energy = sum(s for s, e in sleep_energy_pairs if e >= 7) / max(
            1, len([s for s, e in sleep_energy_pairs if e >= 7])
        )

        if avg_sleep_high_energy > avg_sleep_low_energy + 0.5:
            insights.append("💡 You tend to have higher energy on days with more sleep")

    # Work vs Energy correlation
    work_energy_pairs = [
        (float(m.work_hours), int(m.emotional_energy))
        for m in metrics
        if m.work_hours is not None and m.emotional_energy is not None
    ]

    if len(work_energy_pairs) >= 5:
        high_work_days = [e for w, e in work_energy_pairs if w > 8]
        normal_work_days = [e for w, e in work_energy_pairs if w <= 8]

        if high_work_days and normal_work_days:
            if sum(normal_work_days) / len(normal_work_days) > sum(high_work_days) / len(high_work_days) + 0.5:
                insights.append("⚠️ Your energy tends to be lower on days with longer work hours")

    # Screen time analysis
    screen_times = [float(m.screen_time) for m in metrics if m.screen_time is not None]
    if screen_times:
        avg_screen = sum(screen_times) / len(screen_times)
        if avg_screen > 6:
            insights.append("📱 Consider implementing regular screen breaks to reduce eye strain")

    if not insights:
        insights.append("🔍 Keep tracking for a few more days to discover patterns!")

    return insights


def analyze_weekday_weekend(metrics):
    """Analyze weekday vs weekend patterns"""
    patterns = []

    weekday_metrics = [m for m in metrics if m.metric_date.weekday() < 5]  # Mon-Fri
    weekend_metrics = [m for m in metrics if m.metric_date.weekday() >= 5]  # Sat-Sun

    if not weekday_metrics or not weekend_metrics:
        return ["📊 Need more data to compare weekday vs weekend patterns"]

    # Sleep comparison
    weekday_sleep = [float(m.sleep_duration) for m in weekday_metrics if m.sleep_duration]
    weekend_sleep = [float(m.sleep_duration) for m in weekend_metrics if m.sleep_duration]

    if weekday_sleep and weekend_sleep:
        avg_weekday_sleep = sum(weekday_sleep) / len(weekday_sleep)
        avg_weekend_sleep = sum(weekend_sleep) / len(weekend_sleep)

        if avg_weekend_sleep > avg_weekday_sleep + 0.5:
            patterns.append(f"😴 You sleep {avg_weekend_sleep - avg_weekday_sleep:.1f}h more on weekends")
        elif avg_weekday_sleep > avg_weekend_sleep + 0.5:
            patterns.append(f"😴 You sleep {avg_weekday_sleep - avg_weekend_sleep:.1f}h more on weekdays")

    # Work hours comparison
    weekday_work = [float(m.work_hours) for m in weekday_metrics if m.work_hours]
    weekend_work = [float(m.work_hours) for m in weekend_metrics if m.work_hours]

    if weekday_work and weekend_work:
        avg_weekday_work = sum(weekday_work) / len(weekday_work)
        avg_weekend_work = sum(weekend_work) / len(weekend_work)

        if avg_weekday_work > avg_weekend_work + 1:
            patterns.append(f"💼 You work {avg_weekday_work - avg_weekend_work:.1f}h more on weekdays")

    # Social time comparison
    weekday_social = [float(m.social_time) for m in weekday_metrics if m.social_time]
    weekend_social = [float(m.social_time) for m in weekend_metrics if m.social_time]

    if weekday_social and weekend_social:
        avg_weekday_social = sum(weekday_social) / len(weekday_social)
        avg_weekend_social = sum(weekend_social) / len(weekend_social)

        if avg_weekend_social > avg_weekday_social + 0.5:
            patterns.append(f"👥 You socialize {avg_weekend_social - avg_weekday_social:.1f}h more on weekends")

    if not patterns:
        patterns.append("📊 Your weekday and weekend patterns are quite similar!")

    return patterns
