"""
Smoke tests for analytics functionality - tests the core logic without UI interactions
"""

import pytest
from datetime import date, timedelta
from decimal import Decimal
from app.database import reset_db
from app.services import UserService, MetricsService
from app.models import DailyMetricUpdate
from app.analytics import (
    get_sleep_insight,
    get_work_insight,
    get_energy_insight,
    get_screen_insight,
    calculate_correlations,
    analyze_weekday_weekend,
)


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_insight_functions():
    """Test insight generation functions"""
    # Sleep insights
    assert "Below recommended" in get_sleep_insight(5.5)
    assert "Good sleep duration" in get_sleep_insight(8.0)
    assert "Above average" in get_sleep_insight(10.0)

    # Work insights
    assert "Light work schedule" in get_work_insight(5.0)
    assert "Standard work hours" in get_work_insight(7.5)
    assert "Very long hours" in get_work_insight(12.0)

    # Energy insights
    assert "Low energy" in get_energy_insight(3.0)
    assert "Good energy levels" in get_energy_insight(7.0)
    assert "Excellent energy" in get_energy_insight(9.0)

    # Screen insights
    assert "Low screen time" in get_screen_insight(3.0)
    assert "High screen time" in get_screen_insight(7.0)
    assert "Very high usage" in get_screen_insight(9.0)


def test_correlation_analysis_empty():
    """Test correlation analysis with empty data"""
    insights = calculate_correlations([])
    assert len(insights) > 0
    assert "Keep tracking" in insights[0]


def test_correlation_analysis_with_data(new_db):
    """Test correlation analysis with sample data"""
    user = UserService.get_or_create_default_user()
    metrics = []

    if user.id is not None:
        # Create data with clear patterns
        for i in range(7):
            test_date = date.today() - timedelta(days=i)
            metric = MetricsService.get_or_create_daily_metric(user.id, test_date)

            # Pattern: more sleep = more energy
            if i < 3:
                sleep_hours = 8.5
                energy_level = 8
            else:
                sleep_hours = 6.0
                energy_level = 4

            update_data = DailyMetricUpdate(
                sleep_duration=Decimal(str(sleep_hours)),
                emotional_energy=energy_level,
                work_hours=Decimal("9"),
                screen_time=Decimal("7"),
            )

            if metric.id is not None:
                updated_metric = MetricsService.update_daily_metric(metric.id, update_data)
                if updated_metric is not None:
                    metrics.append(updated_metric)

        if metrics:
            insights = calculate_correlations(metrics)
            assert len(insights) > 0

            # Should detect sleep-energy correlation
            sleep_insights = [i for i in insights if "higher energy on days with more sleep" in i]
            assert len(sleep_insights) > 0


def test_weekday_weekend_analysis_empty():
    """Test weekday/weekend analysis with no data"""
    patterns = analyze_weekday_weekend([])
    assert len(patterns) > 0
    assert "Need more data" in patterns[0]


def test_weekday_weekend_analysis_with_data(new_db):
    """Test weekday/weekend analysis with sample data"""
    user = UserService.get_or_create_default_user()
    metrics = []

    if user.id is not None:
        # Create a full week of data starting from Monday
        today = date.today()
        while today.weekday() != 0:  # Find Monday
            today -= timedelta(days=1)

        for i in range(7):
            test_date = today + timedelta(days=i)
            metric = MetricsService.get_or_create_daily_metric(user.id, test_date)

            # Weekend vs weekday patterns
            if test_date.weekday() >= 5:  # Weekend
                sleep_hours = 9.0
                work_hours = 1.0
                social_hours = 4.0
            else:  # Weekday
                sleep_hours = 7.0
                work_hours = 8.0
                social_hours = 1.5

            update_data = DailyMetricUpdate(
                sleep_duration=Decimal(str(sleep_hours)),
                work_hours=Decimal(str(work_hours)),
                social_time=Decimal(str(social_hours)),
            )

            if metric.id is not None:
                updated_metric = MetricsService.update_daily_metric(metric.id, update_data)
                if updated_metric is not None:
                    metrics.append(updated_metric)

        if len(metrics) >= 7:
            patterns = analyze_weekday_weekend(metrics)
            assert len(patterns) > 0

            # Should detect weekend patterns
            weekend_patterns = [p for p in patterns if "weekend" in p.lower()]
            assert len(weekend_patterns) > 0


def test_weekday_weekend_similar_patterns(new_db):
    """Test weekday/weekend analysis when patterns are similar"""
    user = UserService.get_or_create_default_user()
    metrics = []

    if user.id is not None:
        # Create similar data for all days
        today = date.today()
        while today.weekday() != 0:  # Find Monday
            today -= timedelta(days=1)

        for i in range(7):
            test_date = today + timedelta(days=i)
            metric = MetricsService.get_or_create_daily_metric(user.id, test_date)

            # Similar patterns for all days
            update_data = DailyMetricUpdate(
                sleep_duration=Decimal("8.0"), work_hours=Decimal("6.0"), social_time=Decimal("2.0")
            )

            if metric.id is not None:
                updated_metric = MetricsService.update_daily_metric(metric.id, update_data)
                if updated_metric is not None:
                    metrics.append(updated_metric)

        if len(metrics) >= 7:
            patterns = analyze_weekday_weekend(metrics)
            similar_patterns = [p for p in patterns if "quite similar" in p]
            assert len(similar_patterns) > 0


def test_analytics_data_range_handling(new_db):
    """Test analytics handling of different data ranges"""
    user = UserService.get_or_create_default_user()

    if user.id is not None:
        # Create 30 days of varied data
        for i in range(30):
            test_date = date.today() - timedelta(days=i)
            metric = MetricsService.get_or_create_daily_metric(user.id, test_date)

            update_data = DailyMetricUpdate(
                sleep_duration=Decimal(str(7 + (i % 3))),
                work_hours=Decimal(str(8 + (i % 2))),
                emotional_energy=6 + (i % 4),
                screen_time=Decimal(str(5 + (i % 3))),
                social_time=Decimal(str(2 + (i % 2))),
            )

            if metric.id is not None:
                MetricsService.update_daily_metric(metric.id, update_data)

        # Test different ranges
        last_7_days = MetricsService.get_last_n_days_metrics(user.id, 7)
        last_30_days = MetricsService.get_last_n_days_metrics(user.id, 30)
        last_90_days = MetricsService.get_last_n_days_metrics(user.id, 90)

        assert len(last_7_days) == 7
        assert len(last_30_days) == 30
        assert len(last_90_days) == 30  # Only 30 days of data exist

        # All should be valid for analysis
        insights_7 = calculate_correlations(last_7_days)
        insights_30 = calculate_correlations(last_30_days)

        assert len(insights_7) > 0
        assert len(insights_30) > 0


def test_analytics_edge_cases(new_db):
    """Test analytics with edge case data"""
    user = UserService.get_or_create_default_user()

    if user.id is not None:
        # Create data with extreme values
        today = date.today()
        metric = MetricsService.get_or_create_daily_metric(user.id, today)

        update_data = DailyMetricUpdate(
            sleep_duration=Decimal("0.5"),  # Very low sleep
            work_hours=Decimal("16.0"),  # Very high work
            emotional_energy=1,  # Minimum energy
            screen_time=Decimal("12.0"),  # Very high screen time
            social_time=Decimal("0.0"),  # No social time
        )

        if metric.id is not None:
            updated_metric = MetricsService.update_daily_metric(metric.id, update_data)
            if updated_metric is not None:
                # Should handle extreme values without crashing
                insights = calculate_correlations([updated_metric])
                assert isinstance(insights, list)

                # Should have insights for extreme values
                screen_insights = [i for i in insights if "screen" in i.lower()]
                assert len(screen_insights) > 0
