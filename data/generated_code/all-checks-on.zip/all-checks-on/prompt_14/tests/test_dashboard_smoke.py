"""
Smoke tests for dashboard functionality - tests the core logic without UI interactions
"""

import pytest
from datetime import date, timedelta
from decimal import Decimal
from app.database import reset_db
from app.services import UserService, MetricsService, VisualizationService, SuggestionService
from app.models import DailyMetricUpdate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_dashboard_user_creation_flow(new_db):
    """Test the core user creation flow that dashboard uses"""
    user = UserService.get_or_create_default_user()
    assert user.name == "Demo User"
    assert user.email == "demo@example.com"
    assert user.id is not None


def test_dashboard_metric_creation_flow(new_db):
    """Test the core metric creation flow that dashboard uses"""
    user = UserService.get_or_create_default_user()
    today = date.today()

    if user.id is not None:
        metric = MetricsService.get_or_create_daily_metric(user.id, today)
        assert metric.user_id == user.id
        assert metric.metric_date == today
        assert metric.id is not None


def test_dashboard_data_save_flow(new_db):
    """Test the data saving flow used by the dashboard form"""
    user = UserService.get_or_create_default_user()
    today = date.today()

    if user.id is not None:
        metric = MetricsService.get_or_create_daily_metric(user.id, today)

        # Simulate form data save
        update_data = DailyMetricUpdate(
            sleep_duration=Decimal("7.5"),
            work_hours=Decimal("8.0"),
            social_time=Decimal("2.0"),
            screen_time=Decimal("6.0"),
            emotional_energy=7,
            notes="Test day",
        )

        if metric.id is not None:
            updated_metric = MetricsService.update_daily_metric(metric.id, update_data)
            assert updated_metric is not None
            assert updated_metric.sleep_duration == Decimal("7.5")
            assert updated_metric.emotional_energy == 7


def test_dashboard_suggestions_generation(new_db):
    """Test suggestion generation used by dashboard"""
    user = UserService.get_or_create_default_user()
    today = date.today()

    if user.id is not None:
        metric = MetricsService.get_or_create_daily_metric(user.id, today)

        # Create data that should trigger suggestions
        update_data = DailyMetricUpdate(
            work_hours=Decimal("10"),  # High work hours
            screen_time=Decimal("8"),  # High screen time
            emotional_energy=3,  # Low energy
        )

        if metric.id is not None:
            updated_metric = MetricsService.update_daily_metric(metric.id, update_data)
            if updated_metric is not None:
                suggestions = SuggestionService.generate_suggestions(updated_metric, [])

                # Should have suggestions for high work hours, high screen time, and low energy
                work_suggestions = [s for s in suggestions if "worked over 8 hours" in s]
                screen_suggestions = [s for s in suggestions if "screen time" in s.lower()]
                energy_suggestions = [s for s in suggestions if "energy" in s.lower()]

                assert len(work_suggestions) > 0
                assert len(screen_suggestions) > 0
                assert len(energy_suggestions) > 0


def test_dashboard_visualization_data_preparation(new_db):
    """Test visualization data preparation used by dashboard"""
    user = UserService.get_or_create_default_user()

    if user.id is not None:
        # Create sample data for multiple days
        for i in range(5):
            test_date = date.today() - timedelta(days=i)
            metric = MetricsService.get_or_create_daily_metric(user.id, test_date)

            update_data = DailyMetricUpdate(
                sleep_duration=Decimal(str(7 + i)),
                emotional_energy=min(10, 7 + i),  # Cap at 10 for validation
            )

            if metric.id is not None:
                MetricsService.update_daily_metric(metric.id, update_data)

        # Get data for visualization
        metrics = MetricsService.get_last_n_days_metrics(user.id, 5)
        assert len(metrics) == 5

        # Test chart data preparation
        sleep_data = VisualizationService.prepare_chart_data(metrics, "sleep_duration")
        assert len(sleep_data["dates"]) == 5
        assert len(sleep_data["values"]) == 5
        assert sleep_data["field"] == "Sleep Duration"

        # Test summary statistics
        stats = VisualizationService.get_summary_stats(metrics)
        assert "sleep_duration" in stats
        assert "emotional_energy" in stats


def test_dashboard_date_navigation_flow(new_db):
    """Test date navigation flow used by dashboard"""
    user = UserService.get_or_create_default_user()

    if user.id is not None:
        today = date.today()
        yesterday = today - timedelta(days=1)

        # Create metrics for different dates
        today_metric = MetricsService.get_or_create_daily_metric(user.id, today)
        yesterday_metric = MetricsService.get_or_create_daily_metric(user.id, yesterday)

        assert today_metric.metric_date == today
        assert yesterday_metric.metric_date == yesterday
        assert today_metric.id != yesterday_metric.id


def test_dashboard_weekly_summary_flow(new_db):
    """Test weekly summary generation used by dashboard"""
    user = UserService.get_or_create_default_user()

    if user.id is not None:
        # Create a week of data
        for i in range(7):
            test_date = date.today() - timedelta(days=i)
            metric = MetricsService.get_or_create_daily_metric(user.id, test_date)

            update_data = DailyMetricUpdate(
                sleep_duration=Decimal(str(7 + (i % 3))),
                work_hours=Decimal(str(8 + (i % 2))),
                emotional_energy=6 + (i % 4),
            )

            if metric.id is not None:
                MetricsService.update_daily_metric(metric.id, update_data)

        # Get weekly summary
        weekly_metrics = MetricsService.get_last_n_days_metrics(user.id, 7)
        stats = VisualizationService.get_summary_stats(weekly_metrics)

        assert len(weekly_metrics) == 7
        assert "sleep_duration" in stats
        assert "work_hours" in stats
        assert "emotional_energy" in stats

        # Check that averages are calculated
        assert isinstance(stats["sleep_duration"]["avg"], float)
        assert stats["sleep_duration"]["count"] == 7


def test_dashboard_empty_data_handling(new_db):
    """Test how dashboard handles empty/missing data"""
    user = UserService.get_or_create_default_user()

    if user.id is not None:
        # Create metric with no data
        today = date.today()
        metric = MetricsService.get_or_create_daily_metric(user.id, today)

        # Should handle empty metric gracefully
        suggestions = SuggestionService.generate_suggestions(metric, [])
        assert isinstance(suggestions, list)

        # Should handle empty metrics list
        empty_stats = VisualizationService.get_summary_stats([])
        assert empty_stats == {}

        # Should handle chart data with no values
        chart_data = VisualizationService.prepare_chart_data([metric], "sleep_duration")
        assert len(chart_data["dates"]) == 1
        assert chart_data["values"][0] is None
