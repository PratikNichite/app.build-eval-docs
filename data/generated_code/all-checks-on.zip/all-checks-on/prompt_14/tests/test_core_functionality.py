"""
Core functionality tests for the personal dashboard application.
Tests the essential business logic without UI interactions.
"""

import pytest
from datetime import date, timedelta
from decimal import Decimal
from app.database import reset_db
from app.services import UserService, MetricsService, VisualizationService, SuggestionService
from app.models import DailyMetricUpdate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


@pytest.fixture()
def demo_user(new_db):
    """Create a demo user for testing"""
    return UserService.get_or_create_default_user()


def test_user_management(demo_user):
    """Test basic user management functionality"""
    assert demo_user.name == "Demo User"
    assert demo_user.email == "demo@example.com"
    assert demo_user.id is not None

    # Test user retrieval
    if demo_user.id is not None:
        retrieved_user = UserService.get_user_by_id(demo_user.id)
        assert retrieved_user is not None
        assert retrieved_user.id == demo_user.id


def test_daily_metrics_crud(demo_user):
    """Test creating, reading, updating daily metrics"""
    if demo_user.id is None:
        pytest.skip("Demo user ID is None")

    today = date.today()

    # Create/get daily metric
    metric = MetricsService.get_or_create_daily_metric(demo_user.id, today)
    assert metric.user_id == demo_user.id
    assert metric.metric_date == today
    assert metric.id is not None

    # Update the metric
    update_data = DailyMetricUpdate(
        sleep_duration=Decimal("7.5"), work_hours=Decimal("8.0"), emotional_energy=7, notes="Test day"
    )

    if metric.id is not None:
        updated_metric = MetricsService.update_daily_metric(metric.id, update_data)
        assert updated_metric is not None
        assert updated_metric.sleep_duration == Decimal("7.5")
        assert updated_metric.work_hours == Decimal("8.0")
        assert updated_metric.emotional_energy == 7
        assert updated_metric.notes == "Test day"


def test_metrics_data_retrieval(demo_user):
    """Test retrieving metrics for different date ranges"""
    if demo_user.id is None:
        pytest.skip("Demo user ID is None")

    # Create metrics for the last 5 days
    for i in range(5):
        test_date = date.today() - timedelta(days=i)
        metric = MetricsService.get_or_create_daily_metric(demo_user.id, test_date)

        if metric.id is not None:
            update_data = DailyMetricUpdate(sleep_duration=Decimal(str(7 + i % 2)), emotional_energy=min(10, 6 + i))
            MetricsService.update_daily_metric(metric.id, update_data)

    # Test retrieval
    last_3_days = MetricsService.get_last_n_days_metrics(demo_user.id, 3)
    assert len(last_3_days) == 3

    last_5_days = MetricsService.get_last_n_days_metrics(demo_user.id, 5)
    assert len(last_5_days) == 5


def test_visualization_data_preparation(demo_user):
    """Test data preparation for visualizations"""
    if demo_user.id is None:
        pytest.skip("Demo user ID is None")

    # Create sample data
    for i in range(3):
        test_date = date.today() - timedelta(days=i)
        metric = MetricsService.get_or_create_daily_metric(demo_user.id, test_date)

        if metric.id is not None:
            update_data = DailyMetricUpdate(sleep_duration=Decimal(str(7.5 + i)), emotional_energy=min(10, 7 + i))
            MetricsService.update_daily_metric(metric.id, update_data)

    # Get data for visualization
    metrics = MetricsService.get_last_n_days_metrics(demo_user.id, 3)

    # Test chart data preparation
    sleep_data = VisualizationService.prepare_chart_data(metrics, "sleep_duration")
    assert len(sleep_data["dates"]) == 3
    assert len(sleep_data["values"]) == 3
    assert sleep_data["field"] == "Sleep Duration"

    # Test summary statistics
    stats = VisualizationService.get_summary_stats(metrics)
    assert "sleep_duration" in stats
    assert "emotional_energy" in stats
    assert stats["sleep_duration"]["count"] == 3


def test_suggestion_generation(demo_user):
    """Test wellness suggestion generation"""
    if demo_user.id is None:
        pytest.skip("Demo user ID is None")

    today = date.today()
    metric = MetricsService.get_or_create_daily_metric(demo_user.id, today)

    if metric.id is not None:
        # Test high work hours suggestion
        update_data = DailyMetricUpdate(work_hours=Decimal("10"))
        updated_metric = MetricsService.update_daily_metric(metric.id, update_data)

        if updated_metric is not None:
            suggestions = SuggestionService.generate_suggestions(updated_metric, [])
            work_suggestions = [s for s in suggestions if "worked over 8 hours" in s]
            assert len(work_suggestions) > 0

        # Test low energy suggestion
        update_data = DailyMetricUpdate(emotional_energy=2)
        updated_metric = MetricsService.update_daily_metric(metric.id, update_data)

        if updated_metric is not None:
            suggestions = SuggestionService.generate_suggestions(updated_metric, [])
            energy_suggestions = [s for s in suggestions if "energy" in s.lower()]
            assert len(energy_suggestions) > 0


def test_empty_data_handling():
    """Test handling of empty or missing data"""
    # Test empty metrics list
    empty_stats = VisualizationService.get_summary_stats([])
    assert empty_stats == {}

    # Test chart data with empty list
    empty_chart = VisualizationService.prepare_chart_data([], "sleep_duration")
    assert empty_chart["dates"] == []
    assert empty_chart["values"] == []


def test_decimal_precision_handling(demo_user):
    """Test that decimal values are handled correctly"""
    if demo_user.id is None:
        pytest.skip("Demo user ID is None")

    today = date.today()
    metric = MetricsService.get_or_create_daily_metric(demo_user.id, today)

    if metric.id is not None:
        # Test decimal precision
        update_data = DailyMetricUpdate(
            sleep_duration=Decimal("7.75"), work_hours=Decimal("8.25"), social_time=Decimal("1.5")
        )

        updated_metric = MetricsService.update_daily_metric(metric.id, update_data)

        if updated_metric is not None:
            assert updated_metric.sleep_duration == Decimal("7.75")
            assert updated_metric.work_hours == Decimal("8.25")
            assert updated_metric.social_time == Decimal("1.5")


def test_energy_level_validation(demo_user):
    """Test that energy levels are properly constrained"""
    if demo_user.id is None:
        pytest.skip("Demo user ID is None")

    today = date.today()
    metric = MetricsService.get_or_create_daily_metric(demo_user.id, today)

    if metric.id is not None:
        # Test valid energy levels
        for energy in [1, 5, 10]:
            update_data = DailyMetricUpdate(emotional_energy=energy)
            updated_metric = MetricsService.update_daily_metric(metric.id, update_data)

            if updated_metric is not None:
                assert updated_metric.emotional_energy == energy


def test_date_range_queries(demo_user):
    """Test querying metrics for specific date ranges"""
    if demo_user.id is None:
        pytest.skip("Demo user ID is None")

    # Create metrics for a week
    today = date.today()
    start_date = today - timedelta(days=6)

    for i in range(7):
        test_date = start_date + timedelta(days=i)
        MetricsService.get_or_create_daily_metric(demo_user.id, test_date)

    # Test specific date range
    mid_week_start = start_date + timedelta(days=2)
    mid_week_end = start_date + timedelta(days=4)

    mid_week_metrics = MetricsService.get_metrics_for_date_range(demo_user.id, mid_week_start, mid_week_end)

    assert len(mid_week_metrics) == 3
    assert mid_week_metrics[0].metric_date == mid_week_start
    assert mid_week_metrics[-1].metric_date == mid_week_end


def test_pattern_recognition_suggestions(demo_user):
    """Test pattern-based suggestions"""
    if demo_user.id is None:
        pytest.skip("Demo user ID is None")

    # Create recent metrics with consistent low sleep
    recent_metrics = []
    for i in range(3):
        test_date = date.today() - timedelta(days=i)
        metric = MetricsService.get_or_create_daily_metric(demo_user.id, test_date)

        if metric.id is not None:
            update_data = DailyMetricUpdate(sleep_duration=Decimal("6"))
            updated_metric = MetricsService.update_daily_metric(metric.id, update_data)
            if updated_metric is not None:
                recent_metrics.append(updated_metric)

    if recent_metrics:
        current_metric = recent_metrics[0]
        suggestions = SuggestionService.generate_suggestions(current_metric, recent_metrics)

        # Should detect pattern of low sleep
        pattern_suggestions = [s for s in suggestions if "Pattern Alert" in s and "sleep" in s]
        assert len(pattern_suggestions) > 0


def test_positive_reinforcement_suggestions(demo_user):
    """Test positive reinforcement in suggestions"""
    if demo_user.id is None:
        pytest.skip("Demo user ID is None")

    today = date.today()
    metric = MetricsService.get_or_create_daily_metric(demo_user.id, today)

    if metric.id is not None:
        # Create good balance metrics
        update_data = DailyMetricUpdate(sleep_duration=Decimal("8"), social_time=Decimal("3"), emotional_energy=9)

        updated_metric = MetricsService.update_daily_metric(metric.id, update_data)

        if updated_metric is not None:
            suggestions = SuggestionService.generate_suggestions(updated_metric, [])

            # Should have positive reinforcement
            positive_suggestions = [s for s in suggestions if "✨" in s or "🌟" in s]
            assert len(positive_suggestions) > 0
