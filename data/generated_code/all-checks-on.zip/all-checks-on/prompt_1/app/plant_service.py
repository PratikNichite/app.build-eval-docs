from datetime import date, datetime
from typing import Optional
from sqlmodel import select
from app.database import get_session
from app.models import Plant, PlantCreate, PlantUpdate, PlantResponse


def calculate_plant_mood(plant: Plant) -> str:
    """Calculate plant mood based on watering and fertilizing dates."""
    today = date.today()

    # Check watering status
    days_since_watered = None
    if plant.last_watered:
        days_since_watered = (today - plant.last_watered).days

    # Check fertilizing status
    days_since_fertilized = None
    if plant.last_fertilized:
        days_since_fertilized = (today - plant.last_fertilized).days

    # Determine mood based on care status
    if days_since_watered is None:
        return "New Plant 🌱"
    elif days_since_watered >= 14:
        return "Very Thirsty 🥵"
    elif days_since_watered >= 7:
        return "Thirsty 💧"
    elif days_since_fertilized is None or days_since_fertilized >= 30:
        if days_since_watered <= 3:
            return "Needs Food 🍽️"
        else:
            return "Content 😊"
    elif days_since_watered <= 3 and days_since_fertilized <= 14:
        return "Very Happy 🌿✨"
    else:
        return "Happy 😊"


def create_plant(plant_data: PlantCreate) -> Optional[Plant]:
    """Create a new plant."""
    try:
        with get_session() as session:
            plant = Plant(
                name=plant_data.name,
                species=plant_data.species,
                last_watered=plant_data.last_watered,
                last_fertilized=plant_data.last_fertilized,
            )
            session.add(plant)
            session.commit()
            session.refresh(plant)
            return plant
    except Exception:
        return None


def get_all_plants() -> list[PlantResponse]:
    """Get all plants with their mood calculated."""
    with get_session() as session:
        statement = select(Plant)
        plants = session.exec(statement).all()

        return [
            PlantResponse(
                id=plant.id if plant.id is not None else 0,
                name=plant.name,
                species=plant.species,
                last_watered=plant.last_watered,
                last_fertilized=plant.last_fertilized,
                created_at=plant.created_at,
                updated_at=plant.updated_at,
                mood=calculate_plant_mood(plant),
            )
            for plant in plants
            if plant.id is not None
        ]


def get_plant_by_id(plant_id: int) -> Optional[Plant]:
    """Get a plant by ID."""
    with get_session() as session:
        return session.get(Plant, plant_id)


def update_plant(plant_id: int, plant_data: PlantUpdate) -> Optional[Plant]:
    """Update an existing plant."""
    try:
        with get_session() as session:
            plant = session.get(Plant, plant_id)
            if plant is None:
                return None

            # Update only provided fields
            if plant_data.name is not None:
                plant.name = plant_data.name
            if plant_data.species is not None:
                plant.species = plant_data.species
            if plant_data.last_watered is not None:
                plant.last_watered = plant_data.last_watered
            if plant_data.last_fertilized is not None:
                plant.last_fertilized = plant_data.last_fertilized

            plant.updated_at = datetime.utcnow()
            session.add(plant)
            session.commit()
            session.refresh(plant)
            return plant
    except Exception:
        return None


def delete_plant(plant_id: int) -> bool:
    """Delete a plant by ID."""
    try:
        with get_session() as session:
            plant = session.get(Plant, plant_id)
            if plant is None:
                return False

            session.delete(plant)
            session.commit()
            return True
    except Exception:
        return False


def water_plant_today(plant_id: int) -> Optional[Plant]:
    """Mark a plant as watered today."""
    return update_plant(plant_id, PlantUpdate(last_watered=date.today()))


def fertilize_plant_today(plant_id: int) -> Optional[Plant]:
    """Mark a plant as fertilized today."""
    return update_plant(plant_id, PlantUpdate(last_fertilized=date.today()))
