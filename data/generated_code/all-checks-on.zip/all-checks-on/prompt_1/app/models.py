from sqlmodel import SQLModel, Field
from datetime import datetime, date
from typing import Optional


# Persistent models (stored in database)
class Plant(SQLModel, table=True):
    __tablename__ = "plants"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100)
    species: str = Field(max_length=100)
    last_watered: Optional[date] = Field(default=None)
    last_fertilized: Optional[date] = Field(default=None)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class PlantCreate(SQLModel, table=False):
    name: str = Field(max_length=100)
    species: str = Field(max_length=100)
    last_watered: Optional[date] = Field(default=None)
    last_fertilized: Optional[date] = Field(default=None)


class PlantUpdate(SQLModel, table=False):
    name: Optional[str] = Field(default=None, max_length=100)
    species: Optional[str] = Field(default=None, max_length=100)
    last_watered: Optional[date] = Field(default=None)
    last_fertilized: Optional[date] = Field(default=None)


class PlantResponse(SQLModel, table=False):
    id: int
    name: str
    species: str
    last_watered: Optional[date] = None
    last_fertilized: Optional[date] = None
    created_at: datetime
    updated_at: datetime
    mood: str  # Calculated field for plant mood based on care status
