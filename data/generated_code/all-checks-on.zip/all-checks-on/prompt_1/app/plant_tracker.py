from datetime import date
from nicegui import ui
from app.plant_service import (
    create_plant,
    get_all_plants,
    update_plant,
    delete_plant,
    water_plant_today,
    fertilize_plant_today,
)
from app.models import PlantCreate, PlantUpdate


def create():
    @ui.page("/")
    def plant_tracker_page():
        # Apply modern theme
        ui.colors(
            primary="#10b981",  # Plant green
            secondary="#64748b",  # Subtle gray
            accent="#f59e0b",  # Sunlight yellow
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        # Page header
        with ui.row().classes("w-full justify-between items-center mb-6"):
            ui.label("🌱 Plant Care Tracker").classes("text-3xl font-bold text-primary")
            ui.button("Add New Plant", on_click=lambda: show_add_plant_dialog()).classes(
                "bg-primary text-white px-6 py-2 rounded-lg shadow-md hover:shadow-lg"
            )

        # Plants container
        plants_container = ui.column().classes("w-full gap-4")

        def refresh_plants():
            """Refresh the plants display."""
            plants_container.clear()
            plants = get_all_plants()

            if not plants:
                with plants_container:
                    with ui.card().classes("p-8 text-center bg-gray-50"):
                        ui.icon("park", size="3rem").classes("text-gray-400 mb-4")
                        ui.label("No plants yet!").classes("text-xl text-gray-600 mb-2")
                        ui.label("Add your first plant to get started.").classes("text-gray-500")
                return

            with plants_container:
                for plant in plants:
                    create_plant_card(plant)

        def create_plant_card(plant):
            """Create a card for displaying plant information."""
            with ui.card().classes("p-6 shadow-lg hover:shadow-xl transition-shadow bg-white rounded-xl"):
                with ui.row().classes("w-full justify-between items-start mb-4"):
                    with ui.column().classes("flex-1"):
                        ui.label(plant.name).classes("text-xl font-bold text-gray-800")
                        ui.label(f"Species: {plant.species}").classes("text-gray-600")
                        ui.label(f"Mood: {plant.mood}").classes("text-lg font-semibold text-primary mt-2")

                    # Action buttons
                    with ui.column().classes("gap-2"):
                        ui.button(
                            "💧", on_click=lambda _, p_id=plant.id: water_plant(p_id) if p_id is not None else None
                        ).props("round size=sm").classes("bg-blue-500 text-white").tooltip("Water today")

                        ui.button(
                            "🌱", on_click=lambda _, p_id=plant.id: fertilize_plant(p_id) if p_id is not None else None
                        ).props("round size=sm").classes("bg-amber-500 text-white").tooltip("Fertilize today")

                        ui.button(
                            "✏️",
                            on_click=lambda _, p_id=plant.id: show_edit_plant_dialog(p_id)
                            if p_id is not None
                            else None,
                        ).props("round size=sm").classes("bg-gray-500 text-white").tooltip("Edit plant")

                        ui.button(
                            "🗑️",
                            on_click=lambda _, p_id=plant.id: confirm_delete_plant(p_id) if p_id is not None else None,
                        ).props("round size=sm").classes("bg-red-500 text-white").tooltip("Delete plant")

                # Care information
                with ui.row().classes("w-full gap-6 mt-4 pt-4 border-t border-gray-200"):
                    with ui.column().classes("flex-1"):
                        ui.label("Last Watered").classes("text-sm font-medium text-gray-700")
                        last_watered = plant.last_watered.strftime("%B %d, %Y") if plant.last_watered else "Never"
                        ui.label(last_watered).classes("text-gray-600")

                    with ui.column().classes("flex-1"):
                        ui.label("Last Fertilized").classes("text-sm font-medium text-gray-700")
                        last_fertilized = (
                            plant.last_fertilized.strftime("%B %d, %Y") if plant.last_fertilized else "Never"
                        )
                        ui.label(last_fertilized).classes("text-gray-600")

        async def show_add_plant_dialog():
            """Show dialog for adding a new plant."""
            with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
                ui.label("Add New Plant").classes("text-xl font-bold mb-6")

                name_input = ui.input("Plant Name", placeholder="e.g., My Fiddle Leaf Fig").classes("w-full mb-4")
                species_input = ui.input("Species", placeholder="e.g., Ficus lyrata").classes("w-full mb-4")

                ui.label("Last Watered (optional)").classes("text-sm font-medium text-gray-700 mb-1")
                last_watered_input = ui.date().classes("w-full mb-4")

                ui.label("Last Fertilized (optional)").classes("text-sm font-medium text-gray-700 mb-1")
                last_fertilized_input = ui.date().classes("w-full mb-6")

                with ui.row().classes("gap-2 justify-end w-full"):
                    ui.button("Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
                    ui.button("Add Plant", on_click=lambda: dialog.submit("add")).classes("bg-primary text-white")

            result = await dialog
            if result == "add":
                if not name_input.value or not species_input.value:
                    ui.notify("Please fill in plant name and species", type="negative")
                    return

                # Parse dates
                last_watered = None
                if last_watered_input.value:
                    try:
                        last_watered = date.fromisoformat(last_watered_input.value)
                    except ValueError:
                        pass

                last_fertilized = None
                if last_fertilized_input.value:
                    try:
                        last_fertilized = date.fromisoformat(last_fertilized_input.value)
                    except ValueError:
                        pass

                plant_data = PlantCreate(
                    name=name_input.value,
                    species=species_input.value,
                    last_watered=last_watered,
                    last_fertilized=last_fertilized,
                )

                plant = create_plant(plant_data)
                if plant:
                    ui.notify(f"✨ Added {plant.name} successfully!", type="positive")
                    refresh_plants()
                else:
                    ui.notify("Failed to add plant", type="negative")

        async def show_edit_plant_dialog(plant_id: int):
            """Show dialog for editing an existing plant."""
            from app.plant_service import get_plant_by_id

            plant = get_plant_by_id(plant_id)
            if plant is None:
                ui.notify("Plant not found", type="negative")
                return

            with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
                ui.label("Edit Plant").classes("text-xl font-bold mb-6")

                name_input = ui.input("Plant Name", value=plant.name).classes("w-full mb-4")
                species_input = ui.input("Species", value=plant.species).classes("w-full mb-4")

                ui.label("Last Watered").classes("text-sm font-medium text-gray-700 mb-1")
                last_watered_input = ui.date(
                    value=plant.last_watered.isoformat() if plant.last_watered else None
                ).classes("w-full mb-4")

                ui.label("Last Fertilized").classes("text-sm font-medium text-gray-700 mb-1")
                last_fertilized_input = ui.date(
                    value=plant.last_fertilized.isoformat() if plant.last_fertilized else None
                ).classes("w-full mb-6")

                with ui.row().classes("gap-2 justify-end w-full"):
                    ui.button("Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
                    ui.button("Update Plant", on_click=lambda: dialog.submit("update")).classes("bg-primary text-white")

            result = await dialog
            if result == "update":
                if not name_input.value or not species_input.value:
                    ui.notify("Please fill in plant name and species", type="negative")
                    return

                # Parse dates
                last_watered = None
                if last_watered_input.value:
                    try:
                        last_watered = date.fromisoformat(last_watered_input.value)
                    except ValueError:
                        pass

                last_fertilized = None
                if last_fertilized_input.value:
                    try:
                        last_fertilized = date.fromisoformat(last_fertilized_input.value)
                    except ValueError:
                        pass

                plant_data = PlantUpdate(
                    name=name_input.value,
                    species=species_input.value,
                    last_watered=last_watered,
                    last_fertilized=last_fertilized,
                )

                updated_plant = update_plant(plant_id, plant_data)
                if updated_plant:
                    ui.notify(f"✅ Updated {updated_plant.name} successfully!", type="positive")
                    refresh_plants()
                else:
                    ui.notify("Failed to update plant", type="negative")

        async def confirm_delete_plant(plant_id: int):
            """Confirm and delete a plant."""
            from app.plant_service import get_plant_by_id

            plant = get_plant_by_id(plant_id)
            if plant is None:
                ui.notify("Plant not found", type="negative")
                return

            with ui.dialog() as dialog, ui.card().classes("w-80 p-6"):
                ui.label("Delete Plant").classes("text-xl font-bold mb-4")
                ui.label(f'Are you sure you want to delete "{plant.name}"?').classes("text-gray-600 mb-6")

                with ui.row().classes("gap-2 justify-end w-full"):
                    ui.button("Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
                    ui.button("Delete", on_click=lambda: dialog.submit("delete")).classes("bg-red-500 text-white")

            result = await dialog
            if result == "delete":
                if delete_plant(plant_id):
                    ui.notify(f"🗑️ Deleted {plant.name}", type="warning")
                    refresh_plants()
                else:
                    ui.notify("Failed to delete plant", type="negative")

        def water_plant(plant_id: int):
            """Water a plant today."""
            plant = water_plant_today(plant_id)
            if plant:
                ui.notify(f"💧 Watered {plant.name}!", type="positive")
                refresh_plants()
            else:
                ui.notify("Failed to water plant", type="negative")

        def fertilize_plant(plant_id: int):
            """Fertilize a plant today."""
            plant = fertilize_plant_today(plant_id)
            if plant:
                ui.notify(f"🌱 Fertilized {plant.name}!", type="positive")
                refresh_plants()
            else:
                ui.notify("Failed to fertilize plant", type="negative")

        # Initial load
        refresh_plants()
