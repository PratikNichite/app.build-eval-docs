import pytest
from datetime import date, timedelta
from nicegui.testing import User
from nicegui import ui
from app.database import reset_db
from app.plant_service import create_plant
from app.models import PlantCreate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


async def test_empty_plants_display(user: User, new_db) -> None:
    """Test display when no plants exist."""
    await user.open("/")

    # Should show empty state message
    await user.should_see("No plants yet!")
    await user.should_see("Add your first plant to get started.")


async def test_add_plant_button_exists(user: User, new_db) -> None:
    """Test that add plant button is present."""
    await user.open("/")

    # Should show add plant button
    await user.should_see("Add New Plant")


async def test_plant_display_with_data(user: User, new_db) -> None:
    """Test plant display when plants exist."""
    # Create test plant
    plant_data = PlantCreate(
        name="Test Fiddle Fig",
        species="Ficus lyrata",
        last_watered=date.today() - timedelta(days=3),
        last_fertilized=date.today() - timedelta(days=10),
    )
    create_plant(plant_data)

    await user.open("/")

    # Should show plant information
    await user.should_see("Test Fiddle Fig")
    await user.should_see("Species: Ficus lyrata")
    await user.should_see("Mood:")


async def test_plant_mood_display(user: User, new_db) -> None:
    """Test that plant mood is displayed correctly."""
    # Create a thirsty plant
    plant_data = PlantCreate(
        name="Thirsty Plant", species="Test Species", last_watered=date.today() - timedelta(days=8)
    )
    create_plant(plant_data)

    await user.open("/")

    # Should show thirsty mood
    await user.should_see("Thirsty Plant")
    await user.should_see("Mood: Thirsty 💧")


async def test_plant_care_dates_display(user: User, new_db) -> None:
    """Test that care dates are displayed properly."""
    # Create plant with specific dates
    last_watered = date.today() - timedelta(days=5)
    last_fertilized = date.today() - timedelta(days=15)

    plant_data = PlantCreate(
        name="Dated Plant", species="Test Species", last_watered=last_watered, last_fertilized=last_fertilized
    )
    create_plant(plant_data)

    await user.open("/")

    # Should show formatted dates
    await user.should_see("Last Watered")
    await user.should_see("Last Fertilized")
    await user.should_see(last_watered.strftime("%B %d, %Y"))
    await user.should_see(last_fertilized.strftime("%B %d, %Y"))


async def test_plant_never_watered_display(user: User, new_db) -> None:
    """Test display for plant that was never watered."""
    plant_data = PlantCreate(name="New Plant", species="Test Species")
    create_plant(plant_data)

    await user.open("/")

    # Should show "Never" for care dates
    await user.should_see("Never")


async def test_plant_action_buttons_present(user: User, new_db) -> None:
    """Test that plant action buttons are present."""
    plant_data = PlantCreate(name="Button Test Plant", species="Test Species")
    create_plant(plant_data)

    await user.open("/")

    # Check that action buttons exist (by tooltip text)
    buttons = list(user.find(ui.button).elements)

    # Should have buttons for: Add New Plant, Water, Fertilize, Edit, Delete
    assert len(buttons) >= 5

    # Check for specific action buttons by looking for their emoji content
    water_buttons = [btn for btn in buttons if "💧" in str(btn._props)]
    fertilize_buttons = [btn for btn in buttons if "🌱" in str(btn._props)]
    edit_buttons = [btn for btn in buttons if "✏️" in str(btn._props)]
    delete_buttons = [btn for btn in buttons if "🗑️" in str(btn._props)]

    # Should have one of each action button per plant
    assert len(water_buttons) >= 1
    assert len(fertilize_buttons) >= 1
    assert len(edit_buttons) >= 1
    assert len(delete_buttons) >= 1


async def test_multiple_plants_display(user: User, new_db) -> None:
    """Test display with multiple plants."""
    # Create multiple plants
    plant1_data = PlantCreate(name="Plant One", species="Species One")
    plant2_data = PlantCreate(name="Plant Two", species="Species Two")

    create_plant(plant1_data)
    create_plant(plant2_data)

    await user.open("/")

    # Should show both plants
    await user.should_see("Plant One")
    await user.should_see("Species One")
    await user.should_see("Plant Two")
    await user.should_see("Species Two")


async def test_page_header_elements(user: User, new_db) -> None:
    """Test that page header contains expected elements."""
    await user.open("/")

    # Should show page title and add button
    await user.should_see("🌱 Plant Care Tracker")
    await user.should_see("Add New Plant")


async def test_plant_card_structure(user: User, new_db) -> None:
    """Test the structure of plant cards."""
    # Create a plant with full data
    plant_data = PlantCreate(
        name="Full Data Plant",
        species="Complete Species",
        last_watered=date.today() - timedelta(days=2),
        last_fertilized=date.today() - timedelta(days=7),
    )
    create_plant(plant_data)

    await user.open("/")

    # Check card contains all expected elements
    await user.should_see("Full Data Plant")
    await user.should_see("Species: Complete Species")
    await user.should_see("Mood:")
    await user.should_see("Last Watered")
    await user.should_see("Last Fertilized")

    # Should show formatted dates, not "Never"
    await user.should_not_see("Never")


async def test_different_plant_moods(user: User, new_db) -> None:
    """Test that different plant conditions show different moods."""
    # New plant
    new_plant_data = PlantCreate(name="New Plant", species="Test")
    create_plant(new_plant_data)

    # Very thirsty plant
    thirsty_plant_data = PlantCreate(
        name="Very Thirsty Plant", species="Test", last_watered=date.today() - timedelta(days=15)
    )
    create_plant(thirsty_plant_data)

    await user.open("/")

    # Should show different moods
    await user.should_see("New Plant 🌱")
    await user.should_see("Very Thirsty 🥵")


async def test_plant_tracker_loads_successfully(user: User, new_db) -> None:
    """Smoke test to ensure the plant tracker page loads without errors."""
    await user.open("/")

    # Basic elements should be present
    await user.should_see("Plant Care Tracker")

    # Page should load without throwing errors
    # If we get here, the page loaded successfully
