import pytest
from datetime import date, timedelta
from app.database import reset_db
from app.plant_service import (
    create_plant,
    get_all_plants,
    get_plant_by_id,
    update_plant,
    delete_plant,
    water_plant_today,
    fertilize_plant_today,
    calculate_plant_mood,
)
from app.models import Plant, PlantCreate, PlantUpdate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_calculate_plant_mood_new_plant():
    """Test mood calculation for a plant with no care dates."""
    plant = Plant(name="Test", species="Test Species")
    mood = calculate_plant_mood(plant)
    assert mood == "New Plant 🌱"


def test_calculate_plant_mood_very_thirsty():
    """Test mood calculation for a plant that hasn't been watered in 14+ days."""
    plant = Plant(name="Test", species="Test Species", last_watered=date.today() - timedelta(days=15))
    mood = calculate_plant_mood(plant)
    assert mood == "Very Thirsty 🥵"


def test_calculate_plant_mood_thirsty():
    """Test mood calculation for a plant that hasn't been watered in 7-13 days."""
    plant = Plant(name="Test", species="Test Species", last_watered=date.today() - timedelta(days=8))
    mood = calculate_plant_mood(plant)
    assert mood == "Thirsty 💧"


def test_calculate_plant_mood_needs_food():
    """Test mood calculation for well-watered plant that needs fertilizer."""
    plant = Plant(
        name="Test", species="Test Species", last_watered=date.today() - timedelta(days=2), last_fertilized=None
    )
    mood = calculate_plant_mood(plant)
    assert mood == "Needs Food 🍽️"


def test_calculate_plant_mood_very_happy():
    """Test mood calculation for recently watered and fertilized plant."""
    plant = Plant(
        name="Test",
        species="Test Species",
        last_watered=date.today() - timedelta(days=1),
        last_fertilized=date.today() - timedelta(days=5),
    )
    mood = calculate_plant_mood(plant)
    assert mood == "Very Happy 🌿✨"


def test_calculate_plant_mood_happy():
    """Test mood calculation for a content plant."""
    plant = Plant(
        name="Test",
        species="Test Species",
        last_watered=date.today() - timedelta(days=5),
        last_fertilized=date.today() - timedelta(days=20),
    )
    mood = calculate_plant_mood(plant)
    assert mood == "Happy 😊"


def test_create_plant_success(new_db):
    """Test successful plant creation."""
    plant_data = PlantCreate(
        name="Fiddle Leaf Fig",
        species="Ficus lyrata",
        last_watered=date.today() - timedelta(days=3),
        last_fertilized=date.today() - timedelta(days=10),
    )

    plant = create_plant(plant_data)
    assert plant is not None
    assert plant.name == "Fiddle Leaf Fig"
    assert plant.species == "Ficus lyrata"
    assert plant.last_watered == date.today() - timedelta(days=3)
    assert plant.last_fertilized == date.today() - timedelta(days=10)
    assert plant.id is not None


def test_create_plant_minimal_data(new_db):
    """Test plant creation with minimal required data."""
    plant_data = PlantCreate(name="Snake Plant", species="Sansevieria trifasciata")

    plant = create_plant(plant_data)
    assert plant is not None
    assert plant.name == "Snake Plant"
    assert plant.species == "Sansevieria trifasciata"
    assert plant.last_watered is None
    assert plant.last_fertilized is None


def test_get_all_plants_empty(new_db):
    """Test getting all plants when database is empty."""
    plants = get_all_plants()
    assert plants == []


def test_get_all_plants_with_data(new_db):
    """Test getting all plants with mood calculation."""
    # Create test plants
    plant1_data = PlantCreate(name="Plant 1", species="Species 1")
    plant2_data = PlantCreate(name="Plant 2", species="Species 2", last_watered=date.today() - timedelta(days=8))

    create_plant(plant1_data)
    create_plant(plant2_data)

    plants = get_all_plants()
    assert len(plants) == 2

    # Check that moods are calculated
    plant_names = [p.name for p in plants]
    assert "Plant 1" in plant_names
    assert "Plant 2" in plant_names

    # Find the thirsty plant
    thirsty_plant = next(p for p in plants if p.name == "Plant 2")
    assert thirsty_plant.mood == "Thirsty 💧"


def test_get_plant_by_id_success(new_db):
    """Test successful plant retrieval by ID."""
    plant_data = PlantCreate(name="Test Plant", species="Test Species")
    created_plant = create_plant(plant_data)
    assert created_plant is not None
    assert created_plant.id is not None

    retrieved_plant = get_plant_by_id(created_plant.id)
    assert retrieved_plant is not None
    assert retrieved_plant.name == "Test Plant"
    assert retrieved_plant.id == created_plant.id


def test_get_plant_by_id_not_found(new_db):
    """Test plant retrieval with non-existent ID."""
    plant = get_plant_by_id(999)
    assert plant is None


def test_update_plant_success(new_db):
    """Test successful plant update."""
    # Create initial plant
    plant_data = PlantCreate(name="Old Name", species="Old Species")
    created_plant = create_plant(plant_data)
    assert created_plant is not None
    assert created_plant.id is not None

    # Update plant
    update_data = PlantUpdate(name="New Name", species="New Species", last_watered=date.today())

    updated_plant = update_plant(created_plant.id, update_data)
    assert updated_plant is not None
    assert updated_plant.name == "New Name"
    assert updated_plant.species == "New Species"
    assert updated_plant.last_watered == date.today()
    assert updated_plant.id == created_plant.id


def test_update_plant_partial(new_db):
    """Test partial plant update (only some fields)."""
    # Create initial plant
    plant_data = PlantCreate(
        name="Original Name", species="Original Species", last_watered=date.today() - timedelta(days=5)
    )
    created_plant = create_plant(plant_data)
    assert created_plant is not None
    assert created_plant.id is not None

    # Update only name
    update_data = PlantUpdate(name="Updated Name")

    updated_plant = update_plant(created_plant.id, update_data)
    assert updated_plant is not None
    assert updated_plant.name == "Updated Name"
    assert updated_plant.species == "Original Species"  # Should remain unchanged
    assert updated_plant.last_watered == date.today() - timedelta(days=5)  # Should remain unchanged


def test_update_plant_not_found(new_db):
    """Test updating non-existent plant."""
    update_data = PlantUpdate(name="New Name")
    result = update_plant(999, update_data)
    assert result is None


def test_delete_plant_success(new_db):
    """Test successful plant deletion."""
    # Create plant
    plant_data = PlantCreate(name="To Delete", species="Test Species")
    created_plant = create_plant(plant_data)
    assert created_plant is not None
    assert created_plant.id is not None

    # Delete plant
    success = delete_plant(created_plant.id)
    assert success

    # Verify plant is gone
    retrieved_plant = get_plant_by_id(created_plant.id)
    assert retrieved_plant is None


def test_delete_plant_not_found(new_db):
    """Test deleting non-existent plant."""
    success = delete_plant(999)
    assert not success


def test_water_plant_today_success(new_db):
    """Test watering a plant today."""
    # Create plant
    plant_data = PlantCreate(
        name="Thirsty Plant", species="Test Species", last_watered=date.today() - timedelta(days=10)
    )
    created_plant = create_plant(plant_data)
    assert created_plant is not None
    assert created_plant.id is not None

    # Water plant today
    watered_plant = water_plant_today(created_plant.id)
    assert watered_plant is not None
    assert watered_plant.last_watered == date.today()
    assert watered_plant.name == "Thirsty Plant"


def test_water_plant_today_not_found(new_db):
    """Test watering non-existent plant."""
    result = water_plant_today(999)
    assert result is None


def test_fertilize_plant_today_success(new_db):
    """Test fertilizing a plant today."""
    # Create plant
    plant_data = PlantCreate(name="Hungry Plant", species="Test Species")
    created_plant = create_plant(plant_data)
    assert created_plant is not None
    assert created_plant.id is not None

    # Fertilize plant today
    fertilized_plant = fertilize_plant_today(created_plant.id)
    assert fertilized_plant is not None
    assert fertilized_plant.last_fertilized == date.today()
    assert fertilized_plant.name == "Hungry Plant"


def test_fertilize_plant_today_not_found(new_db):
    """Test fertilizing non-existent plant."""
    result = fertilize_plant_today(999)
    assert result is None


def test_plant_mood_integration(new_db):
    """Test complete workflow with mood calculation."""
    # Create plant
    plant_data = PlantCreate(name="Mood Test", species="Test Species")
    created_plant = create_plant(plant_data)
    assert created_plant is not None
    assert created_plant.id is not None

    # Check initial mood
    plants = get_all_plants()
    mood_plant = next(p for p in plants if p.name == "Mood Test")
    assert mood_plant.mood == "New Plant 🌱"

    # Water the plant
    water_plant_today(created_plant.id)

    # Check updated mood
    plants = get_all_plants()
    mood_plant = next(p for p in plants if p.name == "Mood Test")
    assert mood_plant.mood == "Needs Food 🍽️"

    # Fertilize the plant
    fertilize_plant_today(created_plant.id)

    # Check final mood
    plants = get_all_plants()
    mood_plant = next(p for p in plants if p.name == "Mood Test")
    assert mood_plant.mood == "Very Happy 🌿✨"
