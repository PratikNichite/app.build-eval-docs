import httpx
from datetime import datetime
from sqlmodel import select, desc
from typing import Optional

from app.database import get_session
from app.models import Joke, JokeCreate, JokeUpdate, JokeResponse


class JokeService:
    OFFICIAL_JOKE_API_URL = "https://official-joke-api.appspot.com/random_joke"

    @staticmethod
    async def fetch_random_joke_from_api() -> Optional[dict]:
        """Fetch a random joke from the Official Joke API."""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(JokeService.OFFICIAL_JOKE_API_URL)
                response.raise_for_status()
                return response.json()
        except Exception:
            return None

    @staticmethod
    def create_joke(joke_data: JokeCreate) -> Optional[JokeResponse]:
        """Create a new joke in the database."""
        with get_session() as session:
            joke = Joke(
                setup=joke_data.setup,
                punchline=joke_data.punchline,
                user_comment=joke_data.user_comment,
            )
            session.add(joke)
            session.commit()
            session.refresh(joke)

            if joke.id is None:
                return None

            return JokeResponse(
                id=joke.id,
                setup=joke.setup,
                punchline=joke.punchline,
                user_comment=joke.user_comment,
                created_at=joke.created_at.isoformat(),
                updated_at=joke.updated_at.isoformat(),
            )

    @staticmethod
    def get_all_jokes() -> list[JokeResponse]:
        """Retrieve all jokes from the database."""
        with get_session() as session:
            statement = select(Joke).order_by(desc(Joke.created_at))
            jokes = session.exec(statement).all()

            return [
                JokeResponse(
                    id=joke.id if joke.id is not None else 0,
                    setup=joke.setup,
                    punchline=joke.punchline,
                    user_comment=joke.user_comment,
                    created_at=joke.created_at.isoformat(),
                    updated_at=joke.updated_at.isoformat(),
                )
                for joke in jokes
            ]

    @staticmethod
    def get_joke_by_id(joke_id: int) -> Optional[JokeResponse]:
        """Retrieve a specific joke by ID."""
        with get_session() as session:
            joke = session.get(Joke, joke_id)
            if joke is None:
                return None

            return JokeResponse(
                id=joke.id if joke.id is not None else 0,
                setup=joke.setup,
                punchline=joke.punchline,
                user_comment=joke.user_comment,
                created_at=joke.created_at.isoformat(),
                updated_at=joke.updated_at.isoformat(),
            )

    @staticmethod
    def update_joke(joke_id: int, joke_data: JokeUpdate) -> Optional[JokeResponse]:
        """Update an existing joke."""
        with get_session() as session:
            joke = session.get(Joke, joke_id)
            if joke is None:
                return None

            if joke_data.setup is not None:
                joke.setup = joke_data.setup
            if joke_data.punchline is not None:
                joke.punchline = joke_data.punchline
            if joke_data.user_comment is not None:
                joke.user_comment = joke_data.user_comment

            joke.updated_at = datetime.utcnow()
            session.add(joke)
            session.commit()
            session.refresh(joke)

            return JokeResponse(
                id=joke.id if joke.id is not None else 0,
                setup=joke.setup,
                punchline=joke.punchline,
                user_comment=joke.user_comment,
                created_at=joke.created_at.isoformat(),
                updated_at=joke.updated_at.isoformat(),
            )

    @staticmethod
    def delete_joke(joke_id: int) -> bool:
        """Delete a joke from the database."""
        with get_session() as session:
            joke = session.get(Joke, joke_id)
            if joke is None:
                return False

            session.delete(joke)
            session.commit()
            return True

    @staticmethod
    async def fetch_and_save_random_joke() -> Optional[JokeResponse]:
        """Fetch a random joke from API and save it to database."""
        api_joke = await JokeService.fetch_random_joke_from_api()
        if api_joke is None:
            return None

        joke_create = JokeCreate(
            setup=api_joke.get("setup", ""),
            punchline=api_joke.get("punchline", ""),
            user_comment="",
        )

        return JokeService.create_joke(joke_create)
