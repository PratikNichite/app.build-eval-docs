from nicegui import ui
from app.joke_service import JokeService
from app.models import JokeUpdate


def apply_modern_theme():
    """Apply a modern color theme to the application."""
    ui.colors(
        primary="#2563eb",
        secondary="#64748b",
        accent="#10b981",
        positive="#10b981",
        negative="#ef4444",
        warning="#f59e0b",
        info="#3b82f6",
    )


def create_joke_card(joke_response):
    """Create a styled card for displaying a joke."""
    with ui.card().classes("w-full p-6 bg-white shadow-lg rounded-xl hover:shadow-xl transition-shadow mb-4"):
        # Joke content
        ui.label(f"Setup: {joke_response.setup}").classes("text-lg font-semibold text-gray-800 mb-2")
        ui.label(f"Punchline: {joke_response.punchline}").classes("text-lg text-gray-700 mb-3")

        # User comment section
        if joke_response.user_comment:
            with ui.card().classes("bg-gray-50 p-3 rounded-lg mb-3"):
                ui.label("Your comment:").classes("text-sm font-medium text-gray-600 mb-1")
                ui.label(joke_response.user_comment).classes("text-gray-700")
        else:
            ui.label("No comment added yet").classes("text-sm text-gray-400 italic mb-3")

        # Action buttons
        with ui.row().classes("gap-2 justify-end"):
            ui.button("Edit", on_click=lambda joke_id=joke_response.id: ui.navigate.to(f"/edit/{joke_id}")).classes(
                "bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded"
            )

            ui.button("Delete", on_click=lambda: delete_joke_with_confirmation(joke_response.id)).classes(
                "bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded"
            )


async def delete_joke_with_confirmation(joke_id: int):
    """Delete a joke after user confirmation."""
    with ui.dialog() as dialog, ui.card():
        ui.label("Are you sure you want to delete this joke?").classes("text-lg mb-4")
        with ui.row().classes("gap-2 justify-end"):
            ui.button("Cancel", on_click=lambda: dialog.submit(False)).props("outline")
            ui.button("Delete", on_click=lambda: dialog.submit(True)).classes("bg-red-500 text-white")

    result = await dialog
    if result:
        success = JokeService.delete_joke(joke_id)
        if success:
            ui.notify("Joke deleted successfully! ✅", type="positive")
        else:
            ui.notify("Failed to delete joke ❌", type="negative")
        ui.navigate.to("/")


async def fetch_random_joke():
    """Fetch a random joke from API and save it."""
    try:
        ui.notify("Fetching random joke... ⏳", type="info")
        joke = await JokeService.fetch_and_save_random_joke()

        if joke:
            ui.notify("Random joke fetched and saved successfully! 😂", type="positive")
        else:
            ui.notify("Failed to fetch random joke. Please try again. 😟", type="negative")

        ui.navigate.to("/")
    except Exception as e:
        ui.notify(f"Error fetching joke: {str(e)} 💥", type="negative")


def create():
    """Create all joke collector pages and components."""
    apply_modern_theme()

    @ui.page("/")
    def homepage():
        # Page header
        with ui.row().classes("w-full items-center justify-between mb-6"):
            ui.label("🎭 Joke Collector").classes("text-3xl font-bold text-gray-800")
            ui.button("Fetch Random Joke", on_click=fetch_random_joke).classes(
                "bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold"
            )

        ui.separator().classes("mb-6")

        # Jokes list
        jokes = JokeService.get_all_jokes()

        if not jokes:
            with ui.card().classes("w-full p-8 text-center bg-gray-50 rounded-xl"):
                ui.label("No jokes yet! 😔").classes("text-xl text-gray-600 mb-2")
                ui.label('Click "Fetch Random Joke" to get started.').classes("text-gray-500")
        else:
            ui.label(f"Your Joke Collection ({len(jokes)} jokes)").classes("text-xl font-semibold text-gray-700 mb-4")

            for joke in jokes:
                create_joke_card(joke)

    @ui.page("/edit/{joke_id}")
    def edit_joke_page(joke_id: int):
        joke = JokeService.get_joke_by_id(joke_id)

        if joke is None:
            ui.label("Joke not found").classes("text-xl text-red-500 text-center mt-8")
            ui.button("Back to Home", on_click=lambda: ui.navigate.to("/")).classes("mt-4")
            return

        # Page header
        ui.label("✏️ Edit Joke").classes("text-3xl font-bold text-gray-800 mb-6")

        with ui.card().classes("w-full max-w-2xl p-6 shadow-lg rounded-xl"):
            # Display current joke (read-only)
            ui.label("Setup:").classes("text-sm font-medium text-gray-700 mb-1")
            ui.label(joke.setup).classes("text-lg text-gray-800 mb-4 p-3 bg-gray-50 rounded")

            ui.label("Punchline:").classes("text-sm font-medium text-gray-700 mb-1")
            ui.label(joke.punchline).classes("text-lg text-gray-800 mb-4 p-3 bg-gray-50 rounded")

            # Editable comment section
            ui.label("Your Comment:").classes("text-sm font-medium text-gray-700 mb-1")
            comment_input = (
                ui.textarea(value=joke.user_comment, placeholder="Add your personal comment about this joke...")
                .classes("w-full mb-4")
                .props("rows=3")
            )

            # Action buttons
            with ui.row().classes("gap-2 justify-end"):
                ui.button("Cancel", on_click=lambda: ui.navigate.to("/")).classes("px-4 py-2").props("outline")

                def save_changes():
                    try:
                        joke_update = JokeUpdate(user_comment=comment_input.value)
                        updated_joke = JokeService.update_joke(joke_id, joke_update)

                        if updated_joke:
                            ui.notify("Joke updated successfully! ✨", type="positive")
                            ui.navigate.to("/")
                        else:
                            ui.notify("Failed to update joke 😔", type="negative")
                    except Exception as e:
                        ui.notify(f"Error updating joke: {str(e)} ⚠️", type="negative")

                ui.button("Save Changes", on_click=save_changes).classes(
                    "bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded"
                )
