from app.database import create_tables
import app.joke_collector


def startup() -> None:
    # this function is called before the first request
    create_tables()
    app.joke_collector.create()
