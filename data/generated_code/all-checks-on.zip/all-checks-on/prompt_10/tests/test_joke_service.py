import pytest
from app.joke_service import JokeService
from app.models import JokeCreate, JokeUpdate
from app.database import reset_db


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_create_joke(new_db):
    """Test creating a new joke."""
    joke_data = JokeCreate(
        setup="Why don't scientists trust atoms?",
        punchline="Because they make up everything!",
        user_comment="Classic chemistry joke",
    )

    result = JokeService.create_joke(joke_data)

    assert result is not None
    assert result.setup == joke_data.setup
    assert result.punchline == joke_data.punchline
    assert result.user_comment == joke_data.user_comment
    assert result.id > 0


def test_create_joke_with_empty_comment(new_db):
    """Test creating a joke without a user comment."""
    joke_data = JokeCreate(setup="What do you call a bear with no teeth?", punchline="A gummy bear!")

    result = JokeService.create_joke(joke_data)

    assert result is not None
    assert result.user_comment == ""


def test_get_all_jokes_empty_database(new_db):
    """Test retrieving jokes from empty database."""
    jokes = JokeService.get_all_jokes()
    assert jokes == []


def test_get_all_jokes_with_data(new_db):
    """Test retrieving all jokes when database has data."""
    # Create multiple jokes
    joke1_data = JokeCreate(setup="Setup 1", punchline="Punchline 1", user_comment="Comment 1")
    joke2_data = JokeCreate(setup="Setup 2", punchline="Punchline 2", user_comment="")

    JokeService.create_joke(joke1_data)
    JokeService.create_joke(joke2_data)

    jokes = JokeService.get_all_jokes()

    assert len(jokes) == 2
    # Jokes should be ordered by created_at desc (newest first)
    assert jokes[0].setup == "Setup 2"
    assert jokes[1].setup == "Setup 1"


def test_get_joke_by_id_existing(new_db):
    """Test retrieving a specific joke by ID."""
    joke_data = JokeCreate(setup="Test setup", punchline="Test punchline", user_comment="Test comment")

    created_joke = JokeService.create_joke(joke_data)
    assert created_joke is not None

    retrieved_joke = JokeService.get_joke_by_id(created_joke.id)

    assert retrieved_joke is not None
    assert retrieved_joke.id == created_joke.id
    assert retrieved_joke.setup == joke_data.setup
    assert retrieved_joke.punchline == joke_data.punchline
    assert retrieved_joke.user_comment == joke_data.user_comment


def test_get_joke_by_id_nonexistent(new_db):
    """Test retrieving a joke that doesn't exist."""
    result = JokeService.get_joke_by_id(99999)
    assert result is None


def test_update_joke_comment_only(new_db):
    """Test updating only the comment of a joke."""
    joke_data = JokeCreate(setup="Original setup", punchline="Original punchline", user_comment="Original comment")

    created_joke = JokeService.create_joke(joke_data)
    assert created_joke is not None

    update_data = JokeUpdate(user_comment="Updated comment")
    updated_joke = JokeService.update_joke(created_joke.id, update_data)

    assert updated_joke is not None
    assert updated_joke.setup == "Original setup"
    assert updated_joke.punchline == "Original punchline"
    assert updated_joke.user_comment == "Updated comment"
    assert updated_joke.updated_at != updated_joke.created_at


def test_update_joke_all_fields(new_db):
    """Test updating all fields of a joke."""
    joke_data = JokeCreate(setup="Original setup", punchline="Original punchline", user_comment="Original comment")

    created_joke = JokeService.create_joke(joke_data)
    assert created_joke is not None

    update_data = JokeUpdate(setup="Updated setup", punchline="Updated punchline", user_comment="Updated comment")
    updated_joke = JokeService.update_joke(created_joke.id, update_data)

    assert updated_joke is not None
    assert updated_joke.setup == "Updated setup"
    assert updated_joke.punchline == "Updated punchline"
    assert updated_joke.user_comment == "Updated comment"


def test_update_nonexistent_joke(new_db):
    """Test updating a joke that doesn't exist."""
    update_data = JokeUpdate(user_comment="This won't work")
    result = JokeService.update_joke(99999, update_data)
    assert result is None


def test_delete_joke_existing(new_db):
    """Test deleting an existing joke."""
    joke_data = JokeCreate(setup="To be deleted", punchline="Soon to be gone", user_comment="Delete me")

    created_joke = JokeService.create_joke(joke_data)
    assert created_joke is not None

    # Verify joke exists before deletion
    retrieved_joke = JokeService.get_joke_by_id(created_joke.id)
    assert retrieved_joke is not None

    # Delete the joke
    success = JokeService.delete_joke(created_joke.id)
    assert success

    # Verify joke is gone after deletion
    retrieved_joke = JokeService.get_joke_by_id(created_joke.id)
    assert retrieved_joke is None


def test_delete_nonexistent_joke(new_db):
    """Test deleting a joke that doesn't exist."""
    success = JokeService.delete_joke(99999)
    assert not success


@pytest.mark.asyncio
async def test_fetch_random_joke_from_api():
    """Test fetching a random joke from the Official Joke API."""
    joke_data = await JokeService.fetch_random_joke_from_api()

    # This test fetches real data from the API
    if joke_data is not None:
        assert "setup" in joke_data
        assert "punchline" in joke_data
        assert isinstance(joke_data["setup"], str)
        assert isinstance(joke_data["punchline"], str)
        assert len(joke_data["setup"]) > 0
        assert len(joke_data["punchline"]) > 0


@pytest.mark.asyncio
async def test_fetch_and_save_random_joke(new_db):
    """Test the complete flow of fetching and saving a random joke."""
    result = await JokeService.fetch_and_save_random_joke()

    # This test depends on API availability
    if result is not None:
        assert result.id > 0
        assert len(result.setup) > 0
        assert len(result.punchline) > 0
        assert result.user_comment == ""

        # Verify the joke was actually saved to database
        saved_joke = JokeService.get_joke_by_id(result.id)
        assert saved_joke is not None
        assert saved_joke.setup == result.setup
        assert saved_joke.punchline == result.punchline


def test_joke_response_serialization(new_db):
    """Test that jokes are properly serialized with datetime strings."""
    joke_data = JokeCreate(setup="Serialization test", punchline="Should work fine", user_comment="")

    result = JokeService.create_joke(joke_data)

    assert result is not None
    assert isinstance(result.created_at, str)
    assert isinstance(result.updated_at, str)
    # Should be valid ISO format
    assert "T" in result.created_at
    assert "T" in result.updated_at


def test_crud_operations_sequence(new_db):
    """Test a complete sequence of CRUD operations."""
    # Create
    joke_data = JokeCreate(setup="CRUD test setup", punchline="CRUD test punchline", user_comment="Initial comment")
    created = JokeService.create_joke(joke_data)
    assert created is not None

    # Read
    retrieved = JokeService.get_joke_by_id(created.id)
    assert retrieved is not None
    assert retrieved.setup == joke_data.setup

    # Update
    update_data = JokeUpdate(user_comment="Updated comment")
    updated = JokeService.update_joke(created.id, update_data)
    assert updated is not None
    assert updated.user_comment == "Updated comment"

    # Verify in list
    all_jokes = JokeService.get_all_jokes()
    assert len(all_jokes) == 1
    assert all_jokes[0].id == created.id

    # Delete
    success = JokeService.delete_joke(created.id)
    assert success

    # Verify deletion
    all_jokes_after_delete = JokeService.get_all_jokes()
    assert len(all_jokes_after_delete) == 0
