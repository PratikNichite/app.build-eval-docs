import pytest
from app.joke_service import JokeService
from app.models import JokeCreate, JokeUpdate
from app.database import reset_db


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_complete_joke_workflow(new_db):
    """Test the complete joke management workflow."""
    # Step 1: Verify empty state
    jokes = JokeService.get_all_jokes()
    assert len(jokes) == 0

    # Step 2: Create a joke (simulating API fetch)
    joke_data = JokeCreate(
        setup="Why do programmers prefer dark mode?", punchline="Because light attracts bugs!", user_comment=""
    )
    created_joke = JokeService.create_joke(joke_data)
    assert created_joke is not None
    assert created_joke.id > 0

    # Step 3: Verify joke appears in list
    jokes = JokeService.get_all_jokes()
    assert len(jokes) == 1
    assert jokes[0].setup == joke_data.setup

    # Step 4: Edit the joke (add comment)
    update_data = JokeUpdate(user_comment="This is a classic developer joke!")
    updated_joke = JokeService.update_joke(created_joke.id, update_data)
    assert updated_joke is not None
    assert updated_joke.user_comment == "This is a classic developer joke!"

    # Step 5: Verify update persisted
    retrieved_joke = JokeService.get_joke_by_id(created_joke.id)
    assert retrieved_joke is not None
    assert retrieved_joke.user_comment == "This is a classic developer joke!"

    # Step 6: Delete the joke
    success = JokeService.delete_joke(created_joke.id)
    assert success

    # Step 7: Verify joke is gone
    jokes = JokeService.get_all_jokes()
    assert len(jokes) == 0

    retrieved_joke = JokeService.get_joke_by_id(created_joke.id)
    assert retrieved_joke is None


def test_multiple_jokes_ordering(new_db):
    """Test that multiple jokes are properly ordered by creation time."""
    # Create jokes with slight delay to ensure different timestamps
    joke1_data = JokeCreate(setup="First joke", punchline="First punchline", user_comment="First comment")
    JokeService.create_joke(joke1_data)

    joke2_data = JokeCreate(setup="Second joke", punchline="Second punchline", user_comment="Second comment")
    JokeService.create_joke(joke2_data)

    joke3_data = JokeCreate(setup="Third joke", punchline="Third punchline", user_comment="")
    JokeService.create_joke(joke3_data)

    # Get all jokes - should be ordered newest first
    jokes = JokeService.get_all_jokes()
    assert len(jokes) == 3

    # Newest should be first (joke3), oldest should be last (joke1)
    assert jokes[0].setup == "Third joke"
    assert jokes[1].setup == "Second joke"
    assert jokes[2].setup == "First joke"


def test_error_handling_edge_cases(new_db):
    """Test error handling for edge cases."""
    # Test with very long content (within limits)
    long_setup = "A" * 500  # Still within 1000 char limit
    long_punchline = "B" * 500
    long_comment = "C" * 1000  # At the limit

    joke_data = JokeCreate(setup=long_setup, punchline=long_punchline, user_comment=long_comment)

    created_joke = JokeService.create_joke(joke_data)
    assert created_joke is not None
    assert created_joke.setup == long_setup
    assert created_joke.punchline == long_punchline
    assert created_joke.user_comment == long_comment

    # Test partial updates
    update_data = JokeUpdate(setup="Updated setup")
    updated_joke = JokeService.update_joke(created_joke.id, update_data)
    assert updated_joke is not None
    assert updated_joke.setup == "Updated setup"
    assert updated_joke.punchline == long_punchline  # Should remain unchanged
    assert updated_joke.user_comment == long_comment  # Should remain unchanged


@pytest.mark.asyncio
async def test_api_integration_with_fallback(new_db):
    """Test API integration with proper fallback handling."""
    # This test will work whether the API is available or not
    result = await JokeService.fetch_and_save_random_joke()

    if result is not None:
        # API was available - verify joke was saved
        assert result.id > 0
        assert len(result.setup) > 0
        assert len(result.punchline) > 0

        # Verify it's in the database
        jokes = JokeService.get_all_jokes()
        assert len(jokes) == 1
        assert jokes[0].id == result.id
    else:
        # API was not available - ensure database is still clean
        jokes = JokeService.get_all_jokes()
        assert len(jokes) == 0
