from sqlmodel import SQLModel, Field, Relationship, JSON, Column
from datetime import datetime
from typing import Optional, List
from decimal import Decimal
from enum import Enum


class BrickColor(str, Enum):
    RED = "red"
    ORANGE = "orange"
    YELLOW = "yellow"
    GREEN = "green"
    BLUE = "blue"
    PURPLE = "purple"


class GameStatus(str, Enum):
    WAITING = "waiting"
    PLAYING = "playing"
    PAUSED = "paused"
    GAME_OVER = "game_over"
    LEVEL_COMPLETE = "level_complete"
    WON = "won"


# Persistent models (stored in database)
class Player(SQLModel, table=True):
    __tablename__ = "players"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100)
    high_score: int = Field(default=0)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    games: List["Game"] = Relationship(back_populates="player")


class Level(SQLModel, table=True):
    __tablename__ = "levels"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    level_number: int = Field(unique=True)
    name: str = Field(max_length=100)
    brick_layout: List[List[str]] = Field(sa_column=Column(JSON))  # 2D array of brick colors
    ball_speed: Decimal = Field(default=Decimal("5.0"))
    created_at: datetime = Field(default_factory=datetime.utcnow)

    games: List["Game"] = Relationship(back_populates="level")


class Game(SQLModel, table=True):
    __tablename__ = "games"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    player_id: int = Field(foreign_key="players.id")
    level_id: int = Field(foreign_key="levels.id")
    score: int = Field(default=0)
    lives: int = Field(default=3)
    status: GameStatus = Field(default=GameStatus.WAITING)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = Field(default=None)

    player: Player = Relationship(back_populates="games")
    level: Level = Relationship(back_populates="games")
    game_state: Optional["GameState"] = Relationship(back_populates="game")
    bricks: List["Brick"] = Relationship(back_populates="game")


class GameState(SQLModel, table=True):
    __tablename__ = "game_states"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    game_id: int = Field(foreign_key="games.id", unique=True)

    # Ball state
    ball_x: Decimal = Field(default=Decimal("400.0"))  # Ball X position
    ball_y: Decimal = Field(default=Decimal("300.0"))  # Ball Y position
    ball_velocity_x: Decimal = Field(default=Decimal("3.0"))  # Ball X velocity
    ball_velocity_y: Decimal = Field(default=Decimal("-3.0"))  # Ball Y velocity
    ball_radius: Decimal = Field(default=Decimal("10.0"))

    # Paddle state
    paddle_x: Decimal = Field(default=Decimal("350.0"))  # Paddle X position
    paddle_y: Decimal = Field(default=Decimal("550.0"))  # Paddle Y position
    paddle_width: Decimal = Field(default=Decimal("100.0"))
    paddle_height: Decimal = Field(default=Decimal("15.0"))

    # Game area dimensions
    game_width: Decimal = Field(default=Decimal("800.0"))
    game_height: Decimal = Field(default=Decimal("600.0"))

    updated_at: datetime = Field(default_factory=datetime.utcnow)

    game: Game = Relationship(back_populates="game_state")


class Brick(SQLModel, table=True):
    __tablename__ = "bricks"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    game_id: int = Field(foreign_key="games.id")
    row: int  # Grid row position
    col: int  # Grid column position
    x: Decimal  # Pixel X position
    y: Decimal  # Pixel Y position
    width: Decimal = Field(default=Decimal("60.0"))
    height: Decimal = Field(default=Decimal("20.0"))
    color: BrickColor
    is_destroyed: bool = Field(default=False)
    points: int = Field(default=10)  # Points awarded when destroyed
    created_at: datetime = Field(default_factory=datetime.utcnow)
    destroyed_at: Optional[datetime] = Field(default=None)

    game: Game = Relationship(back_populates="bricks")


# Non-persistent schemas (for validation, forms, API requests/responses)
class PlayerCreate(SQLModel, table=False):
    name: str = Field(max_length=100)


class PlayerUpdate(SQLModel, table=False):
    name: Optional[str] = Field(default=None, max_length=100)
    high_score: Optional[int] = Field(default=None)


class LevelCreate(SQLModel, table=False):
    level_number: int
    name: str = Field(max_length=100)
    brick_layout: List[List[str]]
    ball_speed: Decimal = Field(default=Decimal("5.0"))


class GameCreate(SQLModel, table=False):
    player_id: int
    level_id: int


class GameStateUpdate(SQLModel, table=False):
    ball_x: Optional[Decimal] = Field(default=None)
    ball_y: Optional[Decimal] = Field(default=None)
    ball_velocity_x: Optional[Decimal] = Field(default=None)
    ball_velocity_y: Optional[Decimal] = Field(default=None)
    paddle_x: Optional[Decimal] = Field(default=None)
    paddle_y: Optional[Decimal] = Field(default=None)


class BrickUpdate(SQLModel, table=False):
    is_destroyed: Optional[bool] = Field(default=None)
    destroyed_at: Optional[datetime] = Field(default=None)


class GameUpdate(SQLModel, table=False):
    score: Optional[int] = Field(default=None)
    lives: Optional[int] = Field(default=None)
    status: Optional[GameStatus] = Field(default=None)
    completed_at: Optional[datetime] = Field(default=None)


# Response schemas for API
class BrickResponse(SQLModel, table=False):
    id: int
    row: int
    col: int
    x: Decimal
    y: Decimal
    width: Decimal
    height: Decimal
    color: BrickColor
    is_destroyed: bool
    points: int


class GameStateResponse(SQLModel, table=False):
    ball_x: Decimal
    ball_y: Decimal
    ball_velocity_x: Decimal
    ball_velocity_y: Decimal
    ball_radius: Decimal
    paddle_x: Decimal
    paddle_y: Decimal
    paddle_width: Decimal
    paddle_height: Decimal
    game_width: Decimal
    game_height: Decimal


class GameResponse(SQLModel, table=False):
    id: int
    score: int
    lives: int
    status: GameStatus
    created_at: str  # ISO format
    player_name: str
    level_name: str
    level_number: int
