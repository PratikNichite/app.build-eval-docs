from app.database import create_tables
from nicegui import ui
import app.brick_breaker


def startup() -> None:
    # this function is called before the first request
    create_tables()
    app.brick_breaker.create()

    @ui.page("/")
    def index():
        ui.label("🎮 Game Collection").classes("text-4xl font-bold text-center mb-8 text-primary")

        with ui.column().classes("items-center gap-6 mt-8"):
            ui.label("Available Games").classes("text-2xl font-semibold text-gray-700 mb-4")

            with ui.card().classes("p-6 shadow-lg rounded-xl hover:shadow-xl transition-shadow max-w-md"):
                ui.label("🧱 Brick Breaker").classes("text-xl font-bold text-primary mb-2")
                ui.label("Classic arcade game! Break all the bricks with your paddle and ball.").classes(
                    "text-gray-600 mb-4"
                )
                ui.link("Play Brick Breaker", "/brick-breaker").classes(
                    "bg-primary text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors"
                )
