from nicegui import ui, events
from typing import List, Optional
import math
import random
from dataclasses import dataclass
from enum import Enum


class GameState(Enum):
    READY = "ready"
    PLAYING = "playing"
    GAME_OVER = "game_over"
    LEVEL_COMPLETE = "level_complete"


@dataclass
class Position:
    x: float
    y: float


@dataclass
class Velocity:
    x: float
    y: float


@dataclass
class Ball:
    position: Position
    velocity: Velocity
    radius: float = 8


@dataclass
class Paddle:
    position: Position
    width: float = 80
    height: float = 12


@dataclass
class Brick:
    position: Position
    width: float = 60
    height: float = 20
    color: str = "#3b82f6"
    destroyed: bool = False


class BrickBreakerGame:
    def __init__(self, canvas_width: int = 800, canvas_height: int = 600):
        self.canvas_width = canvas_width
        self.canvas_height = canvas_height
        self.game_state = GameState.READY

        # Game objects
        self.ball = Ball(position=Position(canvas_width / 2, canvas_height - 50), velocity=Velocity(3, -3))
        self.paddle = Paddle(position=Position(canvas_width / 2 - 40, canvas_height - 30))
        self.bricks: List[Brick] = []

        # Game state
        self.lives = 3
        self.score = 0
        self.level = 1

        # UI elements
        self.canvas: Optional[ui.element] = None
        self.score_label: Optional[ui.label] = None
        self.lives_label: Optional[ui.label] = None
        self.level_label: Optional[ui.label] = None
        self.status_label: Optional[ui.label] = None
        self.game_timer: Optional[ui.timer] = None

        # Controls
        self.keys_pressed = set()

        self.create_bricks()

    def create_bricks(self) -> None:
        """Create a grid of bricks at the top of the screen."""
        self.bricks = []
        brick_colors = ["#ef4444", "#f59e0b", "#10b981", "#3b82f6", "#8b5cf6"]

        rows = 5
        cols = 12
        brick_width = 60
        brick_height = 20
        padding = 5

        start_x = (self.canvas_width - (cols * (brick_width + padding) - padding)) / 2
        start_y = 50

        for row in range(rows):
            for col in range(cols):
                x = start_x + col * (brick_width + padding)
                y = start_y + row * (brick_height + padding)
                color = brick_colors[row % len(brick_colors)]

                self.bricks.append(Brick(position=Position(x, y), width=brick_width, height=brick_height, color=color))

    def reset_ball(self) -> None:
        """Reset ball position and velocity for new life."""
        self.ball.position = Position(self.canvas_width / 2, self.canvas_height - 50)
        # Randomize initial ball direction slightly
        angle = random.uniform(-0.3, 0.3)
        speed = 4
        self.ball.velocity = Velocity(speed * math.sin(angle), -speed * math.cos(angle))

    def update_physics(self) -> None:
        """Update ball physics and collision detection."""
        if self.game_state != GameState.PLAYING:
            return

        # Move ball
        self.ball.position.x += self.ball.velocity.x
        self.ball.position.y += self.ball.velocity.y

        # Wall collisions
        if self.ball.position.x <= self.ball.radius or self.ball.position.x >= self.canvas_width - self.ball.radius:
            self.ball.velocity.x *= -1
            self.ball.position.x = max(
                self.ball.radius, min(self.canvas_width - self.ball.radius, self.ball.position.x)
            )

        if self.ball.position.y <= self.ball.radius:
            self.ball.velocity.y *= -1
            self.ball.position.y = self.ball.radius

        # Ball goes off bottom - lose life
        if self.ball.position.y >= self.canvas_height:
            self.lives -= 1
            if self.lives <= 0:
                self.game_state = GameState.GAME_OVER
            else:
                self.reset_ball()
                self.game_state = GameState.READY
            return

        # Paddle collision
        if (
            self.ball.position.y + self.ball.radius >= self.paddle.position.y
            and self.ball.position.y - self.ball.radius <= self.paddle.position.y + self.paddle.height
            and self.ball.position.x >= self.paddle.position.x
            and self.ball.position.x <= self.paddle.position.x + self.paddle.width
        ):
            # Calculate hit position relative to paddle center
            hit_pos = (self.ball.position.x - (self.paddle.position.x + self.paddle.width / 2)) / (
                self.paddle.width / 2
            )
            hit_pos = max(-1, min(1, hit_pos))  # Clamp to [-1, 1]

            # Adjust ball angle based on hit position
            angle = hit_pos * math.pi / 3  # Max 60 degrees
            speed = math.sqrt(self.ball.velocity.x**2 + self.ball.velocity.y**2)

            self.ball.velocity.x = speed * math.sin(angle)
            self.ball.velocity.y = -abs(speed * math.cos(angle))  # Always upward

            # Ensure ball doesn't get stuck in paddle
            self.ball.position.y = self.paddle.position.y - self.ball.radius

        # Brick collisions
        for brick in self.bricks:
            if brick.destroyed:
                continue

            if (
                self.ball.position.x + self.ball.radius >= brick.position.x
                and self.ball.position.x - self.ball.radius <= brick.position.x + brick.width
                and self.ball.position.y + self.ball.radius >= brick.position.y
                and self.ball.position.y - self.ball.radius <= brick.position.y + brick.height
            ):
                # Destroy brick
                brick.destroyed = True
                self.score += 10

                # Determine collision side and reflect ball
                ball_center_x = self.ball.position.x
                ball_center_y = self.ball.position.y
                brick_center_x = brick.position.x + brick.width / 2
                brick_center_y = brick.position.y + brick.height / 2

                # Calculate overlap on each axis
                overlap_x = min(self.ball.radius + brick.width / 2 - abs(ball_center_x - brick_center_x), 0) * -1
                overlap_y = min(self.ball.radius + brick.height / 2 - abs(ball_center_y - brick_center_y), 0) * -1

                # Reflect based on smallest overlap
                if overlap_x < overlap_y:
                    self.ball.velocity.x *= -1
                else:
                    self.ball.velocity.y *= -1

                break

        # Check level completion
        if all(brick.destroyed for brick in self.bricks):
            self.game_state = GameState.LEVEL_COMPLETE
            self.level += 1

    def update_paddle(self) -> None:
        """Update paddle position based on key input."""
        if "ArrowLeft" in self.keys_pressed:
            self.paddle.position.x = max(0, self.paddle.position.x - 6)
        if "ArrowRight" in self.keys_pressed:
            self.paddle.position.x = min(self.canvas_width - self.paddle.width, self.paddle.position.x + 6)

    def render(self) -> None:
        """Render the game state to canvas."""
        if not self.canvas:
            return

        # Build SVG content
        svg_content = ""

        # Draw bricks
        for brick in self.bricks:
            if not brick.destroyed:
                svg_content += f'''
                    <rect x="{brick.position.x}" y="{brick.position.y}" 
                          width="{brick.width}" height="{brick.height}" 
                          fill="{brick.color}" stroke="white" stroke-width="1"/>
                '''

        # Draw paddle
        svg_content += f'''
            <rect x="{self.paddle.position.x}" y="{self.paddle.position.y}" 
                  width="{self.paddle.width}" height="{self.paddle.height}" 
                  fill="#64748b" rx="6"/>
        '''

        # Draw ball
        svg_content += f'''
            <circle cx="{self.ball.position.x}" cy="{self.ball.position.y}" 
                    r="{self.ball.radius}" fill="#ef4444"/>
        '''

        # Update canvas content
        self.canvas._props["innerHTML"] = svg_content
        self.canvas.update()

        # Update UI labels
        if self.score_label:
            self.score_label.set_text(f"Score: {self.score}")
        if self.lives_label:
            self.lives_label.set_text(f"Lives: {self.lives}")
        if self.level_label:
            self.level_label.set_text(f"Level: {self.level}")

        if self.status_label:
            match self.game_state:
                case GameState.READY:
                    self.status_label.set_text("Press SPACE to start 🚀")
                case GameState.PLAYING:
                    self.status_label.set_text("Use arrow keys to move paddle ✨")
                case GameState.GAME_OVER:
                    self.status_label.set_text("Game Over! Press R to restart 😭")
                case GameState.LEVEL_COMPLETE:
                    self.status_label.set_text("Level Complete! Press SPACE to continue 🎉")

    def game_loop(self) -> None:
        """Main game loop."""
        self.update_paddle()
        self.update_physics()
        self.render()

    def handle_key(self, e: events.KeyEventArguments) -> None:
        """Handle keyboard input."""
        if e.action.keydown:
            self.keys_pressed.add(e.key)

            if e.key == " ":  # Space
                if self.game_state == GameState.READY:
                    self.game_state = GameState.PLAYING
                elif self.game_state == GameState.LEVEL_COMPLETE:
                    self.create_bricks()
                    self.reset_ball()
                    self.game_state = GameState.READY
            elif e.key == "r" or e.key == "R":
                if self.game_state == GameState.GAME_OVER:
                    self.restart_game()

        if e.action.keyup:
            self.keys_pressed.discard(e.key)

    def restart_game(self) -> None:
        """Restart the game."""
        self.lives = 3
        self.score = 0
        self.level = 1
        self.create_bricks()
        self.reset_ball()
        self.game_state = GameState.READY

    def start_game_timer(self) -> None:
        """Start the game loop timer."""
        if self.game_timer:
            self.game_timer.cancel()

        self.game_timer = ui.timer(1 / 60, self.game_loop)


def create():
    """Create the Brick Breaker game page."""

    @ui.page("/brick-breaker")
    async def brick_breaker_page():
        ui.add_head_html("""
            <style>
                .game-container {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    padding: 20px;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    font-family: 'Arial', sans-serif;
                }
                .game-canvas {
                    border: 3px solid white;
                    border-radius: 8px;
                    background: #1a1a2e;
                    box-shadow: 0 8px 32px rgba(0,0,0,0.3);
                }
                .game-hud {
                    display: flex;
                    gap: 30px;
                    margin-bottom: 20px;
                    color: white;
                    font-size: 18px;
                    font-weight: bold;
                }
                .game-title {
                    color: white;
                    font-size: 2.5rem;
                    font-weight: bold;
                    margin-bottom: 20px;
                    text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
                }
                .game-instructions {
                    color: rgba(255,255,255,0.9);
                    text-align: center;
                    margin-top: 20px;
                    font-size: 14px;
                }
            </style>
        """)

        game = BrickBreakerGame()

        with ui.column().classes("game-container"):
            ui.label("🧱 BRICK BREAKER").classes("game-title")

            # Game HUD
            with ui.row().classes("game-hud"):
                game.score_label = ui.label("Score: 0")
                game.lives_label = ui.label("Lives: 3")
                game.level_label = ui.label("Level: 1")

            # Game canvas
            with (
                ui.element("svg")
                .props(f'width="{game.canvas_width}" height="{game.canvas_height}"')
                .classes("game-canvas") as canvas
            ):
                game.canvas = canvas

            # Status display
            game.status_label = ui.label("Press SPACE to start").classes("text-white text-lg mt-4")

            # Instructions
            with ui.column().classes("game-instructions"):
                ui.label("Controls:")
                ui.label("← → Arrow keys to move paddle")
                ui.label("SPACE to start/continue • R to restart when game over")

        # Set up keyboard event handlers
        ui.keyboard(on_key=game.handle_key)

        # Initial render and start game timer
        game.render()
        game.start_game_timer()
