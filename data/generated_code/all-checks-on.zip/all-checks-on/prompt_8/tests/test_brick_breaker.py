from nicegui.testing import User
from app.brick_breaker import BrickBreakerGame, GameState, Position, Velocity, Ball, Paddle, Brick


class TestBrickBreakerLogic:
    """Logic-focused tests for game mechanics."""

    def test_game_initialization(self):
        """Test game initializes with correct default values."""
        game = BrickBreakerGame()

        assert game.canvas_width == 800
        assert game.canvas_height == 600
        assert game.game_state == GameState.READY
        assert game.lives == 3
        assert game.score == 0
        assert game.level == 1
        assert len(game.bricks) == 60  # 5 rows × 12 cols
        assert not any(brick.destroyed for brick in game.bricks)

    def test_ball_wall_collision(self):
        """Test ball bounces off walls correctly."""
        game = BrickBreakerGame()

        # Test left wall collision
        game.ball.position.x = 5  # Near left wall
        game.ball.velocity.x = -3
        game.game_state = GameState.PLAYING
        game.update_physics()

        assert game.ball.velocity.x > 0  # Should bounce right
        assert game.ball.position.x >= game.ball.radius

        # Test right wall collision
        game.ball.position.x = game.canvas_width - 5  # Near right wall
        game.ball.velocity.x = 3
        game.game_state = GameState.PLAYING
        game.update_physics()

        assert game.ball.velocity.x < 0  # Should bounce left
        assert game.ball.position.x <= game.canvas_width - game.ball.radius

        # Test top wall collision
        game.ball.position.y = 5  # Near top wall
        game.ball.velocity.y = -3
        game.game_state = GameState.PLAYING
        game.update_physics()

        assert game.ball.velocity.y > 0  # Should bounce down
        assert game.ball.position.y >= game.ball.radius

    def test_ball_goes_off_bottom(self):
        """Test ball going off bottom decreases lives."""
        game = BrickBreakerGame()
        game.game_state = GameState.PLAYING
        initial_lives = game.lives

        # Move ball below screen
        game.ball.position.y = game.canvas_height + 10
        game.update_physics()

        assert game.lives == initial_lives - 1
        if game.lives > 0:
            assert game.game_state == GameState.READY
        else:
            assert game.game_state == GameState.GAME_OVER

    def test_paddle_collision(self):
        """Test ball bounces off paddle with angle adjustment."""
        game = BrickBreakerGame()
        game.game_state = GameState.PLAYING

        # Position ball above paddle center
        game.paddle.position.x = 300
        game.ball.position.x = 300 + game.paddle.width / 2  # Center hit
        game.ball.position.y = game.paddle.position.y - game.ball.radius - 1
        game.ball.velocity.y = 3  # Moving down

        game.update_physics()

        # Ball should bounce up
        assert game.ball.velocity.y < 0
        assert game.ball.position.y == game.paddle.position.y - game.ball.radius

    def test_brick_collision(self):
        """Test brick collision destroys brick and increases score."""
        game = BrickBreakerGame()
        game.game_state = GameState.PLAYING
        initial_score = game.score

        # Get first brick
        brick = game.bricks[0]
        assert not brick.destroyed

        # Position ball to hit brick
        game.ball.position.x = brick.position.x + brick.width / 2
        game.ball.position.y = brick.position.y + brick.height + game.ball.radius + 1
        game.ball.velocity.y = -3  # Moving up toward brick

        game.update_physics()

        assert brick.destroyed
        assert game.score == initial_score + 10

    def test_level_completion(self):
        """Test level completes when all bricks are destroyed."""
        game = BrickBreakerGame()
        game.game_state = GameState.PLAYING

        # Destroy all bricks
        for brick in game.bricks:
            brick.destroyed = True

        game.update_physics()

        assert game.game_state == GameState.LEVEL_COMPLETE

    def test_paddle_movement_boundaries(self):
        """Test paddle stays within screen boundaries."""
        game = BrickBreakerGame()

        # Test left boundary
        game.paddle.position.x = -10
        game.keys_pressed.add("ArrowLeft")
        game.update_paddle()
        assert game.paddle.position.x >= 0

        # Test right boundary
        game.paddle.position.x = game.canvas_width
        game.keys_pressed.add("ArrowRight")
        game.update_paddle()
        assert game.paddle.position.x <= game.canvas_width - game.paddle.width

    def test_ball_reset(self):
        """Test ball resets to correct position."""
        game = BrickBreakerGame()

        # Move ball somewhere else
        game.ball.position.x = 100
        game.ball.position.y = 100
        game.ball.velocity.x = 5
        game.ball.velocity.y = 5

        game.reset_ball()

        assert game.ball.position.x == game.canvas_width / 2
        assert game.ball.position.y == game.canvas_height - 50
        assert game.ball.velocity.y < 0  # Should be moving up

    def test_game_restart(self):
        """Test game restart resets all values."""
        game = BrickBreakerGame()

        # Change game state
        game.lives = 1
        game.score = 100
        game.level = 3
        game.game_state = GameState.GAME_OVER
        game.bricks[0].destroyed = True

        game.restart_game()

        assert game.lives == 3
        assert game.score == 0
        assert game.level == 1
        assert game.game_state == GameState.READY
        assert not any(brick.destroyed for brick in game.bricks)

    def test_brick_creation(self):
        """Test brick grid is created correctly."""
        game = BrickBreakerGame()

        # Check we have the right number of bricks
        assert len(game.bricks) == 60  # 5 rows × 12 cols

        # Check bricks have different colors by row
        colors_found = set()
        for brick in game.bricks:
            colors_found.add(brick.color)

        assert len(colors_found) >= 5  # Should have at least 5 different colors

        # Check all bricks are positioned within canvas
        for brick in game.bricks:
            assert brick.position.x >= 0
            assert brick.position.x + brick.width <= game.canvas_width
            assert brick.position.y >= 0
            assert brick.position.y + brick.height <= game.canvas_height / 2

    def test_paddle_hit_angle_calculation(self):
        """Test paddle hit position affects ball angle."""
        game = BrickBreakerGame()
        game.game_state = GameState.PLAYING

        # Set up paddle and ball for collision test
        game.paddle.position.x = 300
        game.ball.position.y = game.paddle.position.y - game.ball.radius - 1
        game.ball.velocity.y = 3

        # Test hit on left side of paddle
        game.ball.position.x = game.paddle.position.x + 10  # Left side
        game.ball.velocity.x = 1

        game.update_physics()

        # Ball should bounce with leftward component
        assert game.ball.velocity.x < 0
        assert game.ball.velocity.y < 0  # Always upward after paddle hit

    def test_multiple_brick_collisions_prevented(self):
        """Test ball only collides with one brick per frame."""
        game = BrickBreakerGame()
        game.game_state = GameState.PLAYING

        # Position ball to potentially hit multiple bricks
        game.ball.position.x = game.bricks[0].position.x + game.bricks[0].width / 2
        game.ball.position.y = game.bricks[0].position.y + game.bricks[0].height + game.ball.radius + 1
        game.ball.velocity.y = -3

        initial_score = game.score
        game.update_physics()

        # Should only destroy one brick and add 10 points
        destroyed_count = sum(1 for brick in game.bricks if brick.destroyed)
        assert destroyed_count == 1
        assert game.score == initial_score + 10


async def test_brick_breaker_page_loads(user: User) -> None:
    """Smoke test - verify the brick breaker page loads and displays key elements."""
    await user.open("/brick-breaker")

    # Check page elements are present
    await user.should_see("BRICK BREAKER")
    await user.should_see("Score: 0")
    await user.should_see("Lives: 3")
    await user.should_see("Level: 1")
    await user.should_see("Press SPACE to start")
    await user.should_see("Controls:")


async def test_home_page_shows_game_link(user: User) -> None:
    """Test home page displays the game collection with brick breaker link."""
    await user.open("/")

    await user.should_see("Game Collection")
    await user.should_see("Brick Breaker")
    await user.should_see("Classic arcade game")


class TestDataStructures:
    """Test the data classes and enums used in the game."""

    def test_position_creation(self):
        """Test Position dataclass."""
        pos = Position(10.5, 20.3)
        assert pos.x == 10.5
        assert pos.y == 20.3

    def test_velocity_creation(self):
        """Test Velocity dataclass."""
        vel = Velocity(-3.0, 4.5)
        assert vel.x == -3.0
        assert vel.y == 4.5

    def test_ball_creation(self):
        """Test Ball dataclass."""
        ball = Ball(Position(100, 200), Velocity(3, -3), 10)
        assert ball.position.x == 100
        assert ball.position.y == 200
        assert ball.velocity.x == 3
        assert ball.velocity.y == -3
        assert ball.radius == 10

    def test_paddle_creation(self):
        """Test Paddle dataclass."""
        paddle = Paddle(Position(50, 500), 100, 15)
        assert paddle.position.x == 50
        assert paddle.position.y == 500
        assert paddle.width == 100
        assert paddle.height == 15

    def test_brick_creation(self):
        """Test Brick dataclass."""
        brick = Brick(Position(60, 80), 50, 20, "#ff0000", False)
        assert brick.position.x == 60
        assert brick.position.y == 80
        assert brick.width == 50
        assert brick.height == 20
        assert brick.color == "#ff0000"
        assert not brick.destroyed

    def test_game_state_enum(self):
        """Test GameState enum values."""
        assert GameState.READY.value == "ready"
        assert GameState.PLAYING.value == "playing"
        assert GameState.GAME_OVER.value == "game_over"
        assert GameState.LEVEL_COMPLETE.value == "level_complete"
