from app.memory_game import MemoryGameState
from nicegui.testing import User


class TestMemoryGameState:
    """Test the game logic without UI interactions."""

    def test_initialization(self):
        """Test game state initialization."""
        game = MemoryGameState()

        assert game.grid_size == 6
        assert game.total_pairs == 18
        assert len(game.cards) == 36
        assert len(game.card_states) == 36
        assert all(state == "hidden" for state in game.card_states)
        assert game.first_card is None
        assert game.second_card is None
        assert game.attempts == 0
        assert game.matched_pairs == 0
        assert not game.is_processing

    def test_card_shuffling(self):
        """Test that cards are properly shuffled."""
        game1 = MemoryGameState()
        game2 = MemoryGameState()

        # While it's theoretically possible for two shuffles to be identical,
        # the probability is extremely low with 36 cards
        assert game1.cards != game2.cards

    def test_card_pairs_creation(self):
        """Test that all cards have exactly one matching pair."""
        game = MemoryGameState()

        # Count occurrences of each icon
        icon_counts = {}
        for card in game.cards:
            icon_counts[card] = icon_counts.get(card, 0) + 1

        # Each icon should appear exactly twice
        assert len(icon_counts) == game.total_pairs
        assert all(count == 2 for count in icon_counts.values())

    def test_game_reset(self):
        """Test game reset functionality."""
        game = MemoryGameState()

        # Simulate some game progress
        game.attempts = 5
        game.matched_pairs = 3
        game.first_card = 2
        game.second_card = 5
        game.is_processing = True
        game.card_states[0] = "matched"
        game.card_states[1] = "revealed"

        # Reset the game
        game.initialize_game()

        # Check all values are reset
        assert game.attempts == 0
        assert game.matched_pairs == 0
        assert game.first_card is None
        assert game.second_card is None
        assert not game.is_processing
        assert all(state == "hidden" for state in game.card_states)

    def test_icon_selection(self):
        """Test that icons are selected from the available pool."""
        game = MemoryGameState()

        # Get unique icons in the game
        unique_icons = list(set(game.cards))

        # All icons should be from the available icon set
        assert len(unique_icons) == game.total_pairs
        assert all(icon in game.icons for icon in unique_icons)

    def test_win_condition_check(self):
        """Test win condition detection."""
        game = MemoryGameState()

        # Initially not won
        assert game.matched_pairs < game.total_pairs

        # Simulate winning
        game.matched_pairs = game.total_pairs
        assert game.matched_pairs == game.total_pairs

    def test_match_logic(self):
        """Test matching logic for cards."""
        game = MemoryGameState()

        # Find two cards with the same icon
        first_icon = game.cards[0]
        matching_index = -1
        for i in range(1, len(game.cards)):
            if game.cards[i] == first_icon:
                matching_index = i
                break

        assert matching_index != -1  # Should find a match

        # Simulate revealing matching cards
        game.first_card = 0
        game.second_card = matching_index
        game.card_states[0] = "revealed"
        game.card_states[matching_index] = "revealed"

        # Check that they should match
        assert game.cards[game.first_card] == game.cards[game.second_card]

    def test_no_match_logic(self):
        """Test non-matching logic for cards."""
        game = MemoryGameState()

        # Find two cards with different icons
        first_icon = game.cards[0]
        different_index = -1
        for i in range(1, len(game.cards)):
            if game.cards[i] != first_icon:
                different_index = i
                break

        assert different_index != -1  # Should find a non-match

        # Simulate revealing non-matching cards
        game.first_card = 0
        game.second_card = different_index

        # Check that they should not match
        assert game.cards[game.first_card] != game.cards[game.second_card]


class TestMemoryGameUI:
    """Test UI interactions and game flow."""

    async def test_game_page_loads(self, user: User) -> None:
        """Test that the memory game page loads correctly."""
        await user.open("/memory-game")

        # Check main elements are present
        await user.should_see("Memory Card Game")
        await user.should_see("Attempts: 0")
        await user.should_see("Pairs Found: 0/18")
        await user.should_see("New Game")
        await user.should_see("How to Play:")

    async def test_game_instructions_present(self, user: User) -> None:
        """Test that game instructions are displayed."""
        await user.open("/memory-game")

        await user.should_see("How to Play:")
        await user.should_see("Click on cards to reveal them")
        await user.should_see("Find matching pairs of icons")
        await user.should_see("Match all pairs to win the game!")

    async def test_control_buttons_present(self, user: User) -> None:
        """Test that control buttons are present."""
        await user.open("/memory-game")

        await user.should_see("New Game")
        await user.should_see("Reset")


class TestMemoryGameEdgeCases:
    """Test edge cases and error conditions."""

    def test_empty_icon_list_handling(self):
        """Test behavior when icon list is insufficient."""
        game = MemoryGameState()

        # Backup original icons
        original_icons = game.icons.copy()

        # Set insufficient icons
        game.icons = ["🌟"]  # Only one icon, but need 18

        # This should not crash, but select available icons
        try:
            game.initialize_game()
            # Should work with the available icon (though game wouldn't be very interesting)
        except ValueError:
            # It's acceptable to raise an error for insufficient icons
            pass
        finally:
            # Restore original icons
            game.icons = original_icons

    def test_grid_size_consistency(self):
        """Test that grid size produces valid number of pairs."""
        game = MemoryGameState()

        # Grid size should produce even number of cards
        total_cards = game.grid_size * game.grid_size
        assert total_cards % 2 == 0

        # Number of pairs should be half the total cards
        assert game.total_pairs == total_cards // 2

    def test_card_states_consistency(self):
        """Test that card states list matches cards list."""
        game = MemoryGameState()

        assert len(game.cards) == len(game.card_states)

        # After reset, should still be consistent
        game.initialize_game()
        assert len(game.cards) == len(game.card_states)

    def test_multiple_game_instances(self):
        """Test that multiple game instances are independent."""
        game1 = MemoryGameState()
        game2 = MemoryGameState()

        # Modify one game
        game1.attempts = 10
        game1.matched_pairs = 5

        # Other game should be unaffected
        assert game2.attempts == 0
        assert game2.matched_pairs == 0

    def test_card_state_transitions(self):
        """Test valid card state transitions."""
        game = MemoryGameState()

        # All cards start hidden
        assert all(state == "hidden" for state in game.card_states)

        # Can transition to revealed
        game.card_states[0] = "revealed"
        assert game.card_states[0] == "revealed"

        # Can transition to matched
        game.card_states[0] = "matched"
        assert game.card_states[0] == "matched"

        # Can go back to hidden (for non-matches)
        game.card_states[1] = "revealed"
        game.card_states[1] = "hidden"
        assert game.card_states[1] == "hidden"


class TestMemoryGamePerformance:
    """Test performance characteristics of the game."""

    def test_game_initialization_speed(self):
        """Test that game initialization is fast."""
        import time

        start_time = time.time()
        for _ in range(100):
            MemoryGameState()
        end_time = time.time()

        # Should be able to initialize 100 games in under 1 second
        assert end_time - start_time < 1.0

    def test_shuffling_distribution(self):
        """Test that shuffling produces good distribution."""
        games = [MemoryGameState() for _ in range(10)]

        # Check that first position has different cards across games
        first_positions = [game.cards[0] for game in games]
        unique_first_positions = len(set(first_positions))

        # Should have some variety (not all the same)
        assert unique_first_positions > 1

    def test_large_icon_pool(self):
        """Test that the icon pool is large enough for the game."""
        game = MemoryGameState()

        # Should have enough icons for the game
        assert len(game.icons) >= game.total_pairs

        # All icons should be unique
        assert len(game.icons) == len(set(game.icons))
