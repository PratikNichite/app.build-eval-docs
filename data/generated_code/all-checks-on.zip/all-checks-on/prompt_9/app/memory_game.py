from typing import Optional
from nicegui import ui, app
import random
import asyncio


class MemoryGameState:
    """State management for the memory card matching game."""

    def __init__(self):
        self.grid_size = 6
        self.total_pairs = (self.grid_size * self.grid_size) // 2
        self.cards: list[str] = []
        self.card_states: list[str] = []  # 'hidden', 'revealed', 'matched'
        self.first_card: Optional[int] = None
        self.second_card: Optional[int] = None
        self.attempts = 0
        self.matched_pairs = 0
        self.is_processing = False

        # Available card icons (emoji)
        self.icons = [
            "🌟",
            "🎈",
            "🎭",
            "🎨",
            "🎯",
            "🎪",
            "🎸",
            "🎹",
            "🎺",
            "🎻",
            "🎮",
            "🎲",
            "🃏",
            "🎳",
            "⚽",
            "🏀",
            "🏈",
            "🎾",
            "🥎",
            "🏐",
            "🏓",
            "🏸",
            "🥅",
            "⛳",
            "🎊",
            "🎉",
            "🌈",
            "⭐",
            "💫",
            "✨",
            "🔥",
            "💎",
            "🍎",
            "🍌",
            "🍊",
            "🍓",
        ]

        self.initialize_game()

    def initialize_game(self):
        """Initialize or reset the game."""
        # Select random icons for the pairs
        selected_icons = random.sample(self.icons, self.total_pairs)
        # Create pairs
        self.cards = selected_icons * 2
        # Shuffle the cards
        random.shuffle(self.cards)
        # Initialize all cards as hidden
        self.card_states = ["hidden"] * len(self.cards)

        # Reset game state
        self.first_card = None
        self.second_card = None
        self.attempts = 0
        self.matched_pairs = 0
        self.is_processing = False


def create():
    """Create the memory game module."""

    @ui.page("/memory-game")
    async def memory_game_page():
        ui.colors(primary="#3b82f6", secondary="#64748b", accent="#10b981")

        # Initialize game state in tab storage
        await ui.context.client.connected()
        if "game_state" not in app.storage.tab:
            app.storage.tab["game_state"] = MemoryGameState()

        game_state: MemoryGameState = app.storage.tab["game_state"]

        # UI containers
        attempts_label = ui.label(f"Attempts: {game_state.attempts}").classes("text-xl font-bold text-gray-700 mb-4")
        pairs_label = ui.label(f"Pairs Found: {game_state.matched_pairs}/{game_state.total_pairs}").classes(
            "text-xl font-bold text-gray-700 mb-4"
        )

        async def handle_card_click(card_index: int):
            """Handle card click events."""
            if (
                game_state.is_processing
                or game_state.card_states[card_index] in ["revealed", "matched"]
                or (game_state.first_card is not None and game_state.second_card is not None)
            ):
                return

            # Reveal the clicked card
            game_state.card_states[card_index] = "revealed"
            card_buttons[card_index].clear()
            with card_buttons[card_index]:
                ui.label(game_state.cards[card_index]).classes("text-4xl")

            if game_state.first_card is None:
                # First card selected
                game_state.first_card = card_index
            elif game_state.second_card is None:
                # Second card selected
                game_state.second_card = card_index
                game_state.attempts += 1
                attempts_label.set_text(f"Attempts: {game_state.attempts}")

                # Check for match
                await check_match()

        def show_message(text: str, color: str = "text-blue-600", duration: float = 2.0):
            """Display a temporary message with automatic clearing."""
            message_label.set_text(text)
            message_label.classes(
                replace=f"text-lg font-semibold text-center h-8 mb-4 transition-all duration-300 {color}"
            )

            # Clear message after duration
            async def clear_message():
                await asyncio.sleep(duration)
                message_label.set_text("")
                message_label.classes(replace="text-lg font-semibold text-center h-8 mb-4 transition-all duration-300")

            # Don't await this - let it run in background
            asyncio.create_task(clear_message())

        async def check_match():
            """Check if the two revealed cards match."""
            if game_state.first_card is None or game_state.second_card is None:
                return

            game_state.is_processing = True

            # Show processing message during the delay
            show_message("Flipping cards... 🕵️‍♀️", "text-purple-600", 1.0)
            await asyncio.sleep(1)  # Show cards for a moment

            first_card = game_state.first_card
            second_card = game_state.second_card

            if game_state.cards[first_card] == game_state.cards[second_card]:
                # Match found
                game_state.card_states[first_card] = "matched"
                game_state.card_states[second_card] = "matched"
                game_state.matched_pairs += 1
                pairs_label.set_text(f"Pairs Found: {game_state.matched_pairs}/{game_state.total_pairs}")

                # Show success message
                match_messages = ["It's a match! 🎉", "Great job! ✨", "Perfect! 🌟", "Excellent! 🎊", "Amazing! 💫"]
                show_message(random.choice(match_messages), "text-green-600", 2.0)

                # Remove matched cards with animation
                card_buttons[first_card].clear()
                card_buttons[second_card].clear()
                with card_buttons[first_card]:
                    ui.label("✓").classes("text-4xl text-green-500")
                with card_buttons[second_card]:
                    ui.label("✓").classes("text-4xl text-green-500")

                # Check for win condition
                if game_state.matched_pairs == game_state.total_pairs:
                    await show_win_dialog()
            else:
                # No match - flip cards back
                game_state.card_states[first_card] = "hidden"
                game_state.card_states[second_card] = "hidden"

                # Show no match message
                no_match_messages = [
                    "No match! Try again... 🤔",
                    "Oops! Keep going! 🍀",
                    "Close! Try again! 🎯",
                    "Not quite! Keep trying! 💪",
                    "Almost! Don't give up! 🌈",
                ]
                show_message(random.choice(no_match_messages), "text-orange-600", 2.0)

                card_buttons[first_card].clear()
                card_buttons[second_card].clear()
                with card_buttons[first_card]:
                    ui.label("?").classes("text-4xl text-gray-400")
                with card_buttons[second_card]:
                    ui.label("?").classes("text-4xl text-gray-400")

            # Reset card selection
            game_state.first_card = None
            game_state.second_card = None
            game_state.is_processing = False

        async def show_win_dialog():
            """Show the win dialog."""
            with ui.dialog() as dialog, ui.card().classes("p-8 text-center shadow-2xl"):
                ui.label("🏆 PHENOMENAL MEMORY! 🏆").classes("text-4xl font-bold text-yellow-500 mb-4")
                ui.label("You've found all pairs!").classes("text-2xl font-bold text-green-600 mb-2")
                ui.label("🎊 Outstanding achievement! 🎊").classes("text-xl text-purple-600 mb-4")
                ui.label(f"Completed in {game_state.attempts} attempts").classes("text-lg text-gray-600 mb-6")

                with ui.row().classes("gap-4 justify-center"):

                    def play_again():
                        dialog.submit("play_again")
                        reset_game()

                    ui.button("Ready for another round? 🚀", on_click=play_again).classes(
                        "bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-3 rounded-lg font-bold shadow-lg hover:shadow-xl transition-all"
                    )
                    ui.button("Celebrate & Close 🎉", on_click=lambda: dialog.submit("close")).classes(
                        "bg-gradient-to-r from-green-500 to-blue-500 text-white px-8 py-3 rounded-lg font-bold shadow-lg hover:shadow-xl transition-all"
                    )

            await dialog

        def reset_game():
            """Reset the game to initial state."""
            game_state.initialize_game()
            attempts_label.set_text(f"Attempts: {game_state.attempts}")
            pairs_label.set_text(f"Pairs Found: {game_state.matched_pairs}/{game_state.total_pairs}")

            # Clear any existing message
            message_label.set_text("")
            message_label.classes(replace="text-lg font-semibold text-center h-8 mb-4 transition-all duration-300")

            # Show new game message
            show_message("New game started! Good luck! 🍀", "text-blue-600", 2.5)

            # Reset all card buttons
            for i, button in enumerate(card_buttons):
                button.clear()
                with button:
                    ui.label("?").classes("text-4xl text-gray-400")

        # Game header
        with ui.column().classes("w-full max-w-4xl mx-auto p-6"):
            ui.label("🧠 Memory Card Game").classes("text-4xl font-bold text-center text-blue-600 mb-6")

            # Game stats
            with ui.row().classes("justify-center gap-8 mb-4"):
                attempts_label
                pairs_label

            # Message display area
            message_label = (
                ui.label("")
                .classes("text-lg font-semibold text-center h-8 mb-4 transition-all duration-300")
                .style("min-height: 2rem;")
            )

            # Control buttons
            with ui.row().classes("justify-center gap-4 mb-6"):
                ui.button("New Game", on_click=reset_game).classes(
                    "bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg font-semibold"
                )
                ui.button("Reset", on_click=reset_game).classes(
                    "bg-orange-500 hover:bg-orange-600 text-white px-6 py-2 rounded-lg font-semibold"
                )

            # Game grid
            card_buttons = []
            with ui.grid(columns=game_state.grid_size).classes("gap-3 justify-center"):
                for i in range(len(game_state.cards)):
                    card_button = ui.button(on_click=lambda _=None, idx=i: handle_card_click(idx)).classes(
                        "w-16 h-16 bg-blue-100 hover:bg-blue-200 border-2 border-blue-300 "
                        "rounded-lg shadow-md hover:shadow-lg transition-all duration-200 "
                        "flex items-center justify-center"
                    )

                    # Initialize card display based on current state
                    if game_state.card_states[i] == "hidden":
                        with card_button:
                            ui.label("?").classes("text-4xl text-gray-400")
                    elif game_state.card_states[i] == "revealed":
                        with card_button:
                            ui.label(game_state.cards[i]).classes("text-4xl")
                    elif game_state.card_states[i] == "matched":
                        with card_button:
                            ui.label("✓").classes("text-4xl text-green-500")

                    card_buttons.append(card_button)

            # Game instructions
            with ui.card().classes("mt-8 p-4 bg-gray-50"):
                ui.label("How to Play:").classes("text-lg font-semibold mb-2")
                ui.label("• Click on cards to reveal them").classes("text-gray-600")
                ui.label("• Find matching pairs of icons").classes("text-gray-600")
                ui.label("• Match all pairs to win the game!").classes("text-gray-600")
