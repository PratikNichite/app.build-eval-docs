from sqlmodel import SQLModel, Field, Relationship
from datetime import datetime
from typing import Optional, List, Dict, Any
from enum import Enum


class CardState(str, Enum):
    """Enum for card states in the memory game."""

    FACE_DOWN = "face_down"
    FACE_UP = "face_up"
    MATCHED = "matched"


class GameStatus(str, Enum):
    """Enum for game status."""

    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    PAUSED = "paused"


# Persistent models (stored in database)
class Game(SQLModel, table=True):
    """Model for tracking memory card game sessions."""

    __tablename__ = "games"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    player_name: str = Field(max_length=100)
    grid_size: int = Field(default=6, description="Grid size (6 for 6x6 grid)")
    total_pairs: int = Field(default=18, description="Total number of card pairs")
    matched_pairs: int = Field(default=0, description="Number of matched pairs")
    attempts: int = Field(default=0, description="Number of card flip attempts")
    status: GameStatus = Field(default=GameStatus.IN_PROGRESS)
    start_time: datetime = Field(default_factory=datetime.utcnow)
    end_time: Optional[datetime] = Field(default=None)
    best_score: Optional[int] = Field(default=None, description="Best attempts for this player")

    # Relationships
    cards: List["Card"] = Relationship(back_populates="game")
    moves: List["GameMove"] = Relationship(back_populates="game")


class Card(SQLModel, table=True):
    """Model for individual cards in the memory game."""

    __tablename__ = "cards"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    game_id: int = Field(foreign_key="games.id")
    position_x: int = Field(description="X coordinate in grid (0-5)")
    position_y: int = Field(description="Y coordinate in grid (0-5)")
    icon_name: str = Field(max_length=50, description="Icon identifier for the card")
    pair_id: int = Field(description="Identifier for matching pair (1-18)")
    state: CardState = Field(default=CardState.FACE_DOWN)
    matched_at: Optional[datetime] = Field(default=None)

    # Relationships
    game: Game = Relationship(back_populates="cards")


class GameMove(SQLModel, table=True):
    """Model for tracking individual moves/attempts in the game."""

    __tablename__ = "game_moves"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    game_id: int = Field(foreign_key="games.id")
    move_number: int = Field(description="Sequential move number in the game")
    first_card_id: int = Field(foreign_key="cards.id")
    second_card_id: int = Field(foreign_key="cards.id")
    is_match: bool = Field(description="Whether the two cards matched")
    created_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    game: Game = Relationship(back_populates="moves")


class CardIcon(SQLModel, table=True):
    """Model for available card icons/symbols."""

    __tablename__ = "card_icons"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(unique=True, max_length=50, description="Icon identifier")
    display_name: str = Field(max_length=100, description="Human-readable name")
    icon_class: str = Field(max_length=100, description="CSS class or icon reference")
    color: Optional[str] = Field(default=None, max_length=7, description="Hex color code")
    is_active: bool = Field(default=True)


class PlayerStats(SQLModel, table=True):
    """Model for tracking player statistics across games."""

    __tablename__ = "player_stats"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    player_name: str = Field(unique=True, max_length=100)
    games_played: int = Field(default=0)
    games_won: int = Field(default=0)
    best_attempts: Optional[int] = Field(default=None, description="Lowest attempts to win")
    total_attempts: int = Field(default=0)
    average_attempts: Optional[float] = Field(default=None)
    fastest_time: Optional[int] = Field(default=None, description="Fastest win time in seconds")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class GameCreate(SQLModel, table=False):
    """Schema for creating a new memory game."""

    player_name: str = Field(max_length=100)
    grid_size: int = Field(default=6, ge=4, le=8, description="Grid size (4x4 to 8x8)")


class GameUpdate(SQLModel, table=False):
    """Schema for updating game state."""

    matched_pairs: Optional[int] = Field(default=None, ge=0)
    attempts: Optional[int] = Field(default=None, ge=0)
    status: Optional[GameStatus] = Field(default=None)
    end_time: Optional[datetime] = Field(default=None)


class CardFlip(SQLModel, table=False):
    """Schema for card flip actions."""

    game_id: int
    card_id: int
    position_x: int = Field(ge=0, le=7)
    position_y: int = Field(ge=0, le=7)


class MoveResult(SQLModel, table=False):
    """Schema for move result responses."""

    is_match: bool
    first_card: Dict[str, Any]
    second_card: Dict[str, Any]
    attempts: int
    matched_pairs: int
    game_completed: bool


class GameSummary(SQLModel, table=False):
    """Schema for game completion summary."""

    game_id: int
    player_name: str
    attempts: int
    duration_seconds: int
    is_personal_best: bool
    total_games_played: int
