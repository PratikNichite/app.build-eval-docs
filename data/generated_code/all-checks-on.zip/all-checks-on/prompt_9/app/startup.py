from app.database import create_tables
from nicegui import ui
import app.memory_game


def startup() -> None:
    # this function is called before the first request
    create_tables()
    app.memory_game.create()

    @ui.page("/")
    def index():
        ui.label("🎮 Welcome to Memory Game!").classes("text-4xl font-bold text-center text-blue-600 mt-8 mb-4")
        ui.label("Test your memory with our card matching game").classes("text-lg text-center text-gray-600 mb-8")

        with ui.row().classes("justify-center"):
            ui.link("🧠 Play Memory Game", "/memory-game").classes(
                "bg-blue-500 hover:bg-blue-600 text-white px-8 py-4 rounded-lg "
                "font-semibold text-xl shadow-lg hover:shadow-xl transition-all"
            )
