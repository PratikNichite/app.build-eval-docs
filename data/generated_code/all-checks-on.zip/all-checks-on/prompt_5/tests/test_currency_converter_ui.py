"""UI tests for currency converter"""

import pytest
from nicegui.testing import User
from nicegui import ui
from app.database import reset_db
from app.models import Currency
from sqlmodel import Session
from app.database import ENGINE


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


async def test_currency_converter_page_loads(user: User, new_db) -> None:
    """Test currency converter page loads successfully"""
    # Setup test currencies
    with Session(ENGINE) as session:
        currencies = [
            Currency(code="USD", name="US Dollar"),
            Currency(code="EUR", name="Euro"),
            Currency(code="GBP", name="British Pound"),
        ]
        for currency in currencies:
            session.add(currency)
        session.commit()

    await user.open("/")

    # Check main elements are present
    await user.should_see("Currency Converter")
    await user.should_see("Amount")
    await user.should_see("From")
    await user.should_see("To")
    await user.should_see("Convert Currency")


async def test_currency_conversion_ui_elements(user: User, new_db) -> None:
    """Test UI elements work correctly"""
    # Setup test currencies
    with Session(ENGINE) as session:
        currencies = [Currency(code="USD", name="US Dollar"), Currency(code="EUR", name="Euro")]
        for currency in currencies:
            session.add(currency)
        session.commit()

    await user.open("/")
    await user.should_see("Convert Currency")

    # Test that amount input exists
    amount_inputs = list(user.find(ui.number).elements)
    assert len(amount_inputs) > 0

    # Test that select elements exist
    select_elements = list(user.find(ui.select).elements)
    assert len(select_elements) >= 2  # From and To currency selects


async def test_currency_converter_validation(user: User, new_db) -> None:
    """Test form validation works correctly"""
    # Setup test currencies
    with Session(ENGINE) as session:
        currency = Currency(code="USD", name="US Dollar")
        session.add(currency)
        session.commit()

    await user.open("/")
    await user.should_see("Convert Currency")

    # Try to convert without entering amount
    user.find("Convert Currency").click()

    # Should see validation message
    await user.should_see("Please enter an amount")


async def test_currency_swap_button_exists(user: User, new_db) -> None:
    """Test currency swap button is present"""
    # Setup test currencies
    with Session(ENGINE) as session:
        currencies = [Currency(code="USD", name="US Dollar"), Currency(code="EUR", name="Euro")]
        for currency in currencies:
            session.add(currency)
        session.commit()

    await user.open("/")
    await user.should_see("Convert Currency")

    # Find buttons - swap button should exist
    buttons = user.find(ui.button).elements
    assert len(buttons) >= 2  # At least convert button and swap button


async def test_conversion_history_display(user: User, new_db) -> None:
    """Test conversion history section displays"""
    await user.open("/")

    # Should see recent conversions section
    await user.should_see("Recent Conversions")
    await user.should_see("Refresh")


async def test_empty_conversion_history(user: User, new_db) -> None:
    """Test display when no conversion history exists"""
    await user.open("/")

    # Should see empty state message
    await user.should_see("No conversion history yet")


async def test_currency_loading_when_empty_db(user: User, new_db) -> None:
    """Test currencies are loaded from API when database is empty"""
    await user.open("/")

    # Should eventually see the converter (currencies will be loaded from API)
    await user.should_see("Convert Currency")


async def test_negative_amount_validation(user: User, new_db) -> None:
    """Test validation for negative amounts"""
    # Setup test currencies
    with Session(ENGINE) as session:
        currency = Currency(code="USD", name="US Dollar")
        session.add(currency)
        session.commit()

    await user.open("/")
    await user.should_see("Convert Currency")

    # Try to enter negative amount by setting it directly
    amount_input = list(user.find(ui.number).elements)
    if amount_input:
        # Set a negative value - this test verifies the UI handles it gracefully
        amount_input[0].set_value(-100.0)

        # Click convert - should trigger validation
        user.find("Convert Currency").click()

        # The main validation happens in the backend logic
        # UI should not crash and should handle the validation gracefully


async def test_result_display_area_exists(user: User, new_db) -> None:
    """Test result display area is present"""
    await user.open("/")

    # Should see result label and textarea
    await user.should_see("Result")

    # Check textarea for results exists
    textareas = list(user.find(ui.textarea).elements)
    assert len(textareas) > 0


async def test_currency_labels_present(user: User, new_db) -> None:
    """Test all required labels are present"""
    await user.open("/")

    # Check all required labels
    await user.should_see("Currency Converter")
    await user.should_see("Amount")
    await user.should_see("From")
    await user.should_see("To")
    await user.should_see("Result")


async def test_ui_layout_structure(user: User, new_db) -> None:
    """Test UI has proper structure"""
    await user.open("/")

    # Check main structural elements exist
    cards = list(user.find(ui.card).elements)
    assert len(cards) >= 2  # Main converter card + history card

    columns = list(user.find(ui.column).elements)
    assert len(columns) > 0

    rows = list(user.find(ui.row).elements)
    assert len(rows) > 0


async def test_button_styling_and_icons(user: User, new_db) -> None:
    """Test buttons have proper styling"""
    await user.open("/")

    buttons = user.find(ui.button).elements

    # Should have multiple buttons (convert, swap, refresh)
    assert len(buttons) >= 3

    # Convert button should exist with text - just check buttons exist
    # The exact button properties may vary in NiceGUI implementation

    # At minimum, buttons should be clickable
    for button in buttons:
        assert hasattr(button, "on_click") or hasattr(button, "_event_handlers")


async def test_input_field_properties(user: User, new_db) -> None:
    """Test input fields have correct properties"""
    await user.open("/")

    # Number input should exist with proper constraints
    number_inputs = list(user.find(ui.number).elements)
    assert len(number_inputs) > 0

    # Select inputs should exist
    select_inputs = list(user.find(ui.select).elements)
    assert len(select_inputs) >= 2  # From and To currency selects
