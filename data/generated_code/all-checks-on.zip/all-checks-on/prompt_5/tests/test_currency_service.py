"""Tests for currency service functionality"""

import pytest
from decimal import Decimal
from app.currency_service import CurrencyService
from app.models import ConversionRequest, Currency, ConversionHistory
from app.database import reset_db
from sqlmodel import Session
from app.database import ENGINE


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


class TestCurrencyService:
    """Test currency service logic"""

    @pytest.mark.asyncio
    async def test_get_available_currencies_real_api(self):
        """Test fetching currencies from real Frankfurter API"""
        currencies = await CurrencyService.get_available_currencies()

        assert isinstance(currencies, dict)
        assert len(currencies) > 0
        # Common currencies should be present
        assert "USD" in currencies
        assert "EUR" in currencies
        # Check USD exists with expected name
        assert "US Dollar" in currencies["USD"] or "United States Dollar" in currencies["USD"]

    @pytest.mark.asyncio
    async def test_get_exchange_rate_same_currency(self):
        """Test exchange rate for same currency returns 1.0"""
        rate = await CurrencyService.get_exchange_rate("USD", "USD")
        assert rate == Decimal("1.0")

    @pytest.mark.asyncio
    async def test_get_exchange_rate_real_api(self):
        """Test exchange rate fetching from real API"""
        rate = await CurrencyService.get_exchange_rate("USD", "EUR")

        # Rate should be a positive decimal
        assert isinstance(rate, Decimal)
        assert rate > Decimal("0")
        # Reasonable range for USD to EUR (roughly 0.7 to 1.2)
        assert Decimal("0.5") < rate < Decimal("1.5")

    @pytest.mark.asyncio
    async def test_convert_currency_success(self, new_db):
        """Test successful currency conversion with real API"""
        # Setup test currencies
        with Session(ENGINE) as session:
            usd_currency = Currency(code="USD", name="US Dollar")
            eur_currency = Currency(code="EUR", name="Euro")
            session.add(usd_currency)
            session.add(eur_currency)
            session.commit()
            session.refresh(usd_currency)
            session.refresh(eur_currency)

        request = ConversionRequest(amount=Decimal("100.00"), from_currency_code="USD", to_currency_code="EUR")

        result = await CurrencyService.convert_currency(request)

        assert result.original_amount == Decimal("100.00")
        assert result.converted_amount > Decimal("0")
        assert result.from_currency_code == "USD"
        assert result.to_currency_code == "EUR"
        assert result.exchange_rate > Decimal("0")

        # Verify conversion history was stored
        history = CurrencyService.get_conversion_history(limit=1)
        assert len(history) == 1
        assert history[0].original_amount == Decimal("100.00")

    @pytest.mark.asyncio
    async def test_convert_same_currency(self, new_db):
        """Test conversion between same currency"""
        # Setup test currency
        with Session(ENGINE) as session:
            usd_currency = Currency(code="USD", name="US Dollar")
            session.add(usd_currency)
            session.commit()

        request = ConversionRequest(amount=Decimal("100.00"), from_currency_code="USD", to_currency_code="USD")

        result = await CurrencyService.convert_currency(request)

        assert result.original_amount == Decimal("100.00")
        assert result.converted_amount == Decimal("100.00")
        assert result.exchange_rate == Decimal("1.0")

    @pytest.mark.asyncio
    async def test_initialize_currencies_real_api(self, new_db):
        """Test currency initialization with real API"""
        await CurrencyService.initialize_currencies()

        # Check currencies were added to database
        currencies = CurrencyService.get_stored_currencies()
        currency_codes = {c.code for c in currencies}

        assert len(currencies) > 30  # Should have many currencies
        assert "USD" in currency_codes
        assert "EUR" in currency_codes
        assert "GBP" in currency_codes
        assert "JPY" in currency_codes

    @pytest.mark.asyncio
    async def test_initialize_currencies_no_duplicates(self, new_db):
        """Test currency initialization doesn't create duplicates"""
        # Add existing currency
        with Session(ENGINE) as session:
            existing = Currency(code="USD", name="US Dollar")
            session.add(existing)
            session.commit()

        initial_count = len(CurrencyService.get_stored_currencies())

        await CurrencyService.initialize_currencies()

        currencies = CurrencyService.get_stored_currencies()
        usd_currencies = [c for c in currencies if c.code == "USD"]

        # Should only have one USD currency
        assert len(usd_currencies) == 1
        # Should have added new currencies but not duplicated USD
        assert len(currencies) > initial_count

    def test_get_stored_currencies_only_active(self, new_db):
        """Test getting stored currencies returns only active ones"""
        with Session(ENGINE) as session:
            active_currency = Currency(code="USD", name="US Dollar", is_active=True)
            inactive_currency = Currency(code="EUR", name="Euro", is_active=False)
            session.add(active_currency)
            session.add(inactive_currency)
            session.commit()

        currencies = CurrencyService.get_stored_currencies()
        currency_codes = {c.code for c in currencies}

        assert "USD" in currency_codes
        assert "EUR" not in currency_codes
        assert len(currencies) == 1

    def test_get_conversion_history_limit(self, new_db):
        """Test conversion history respects limit parameter"""
        # Setup test data
        with Session(ENGINE) as session:
            usd = Currency(code="USD", name="US Dollar")
            eur = Currency(code="EUR", name="Euro")
            session.add(usd)
            session.add(eur)
            session.commit()
            session.refresh(usd)
            session.refresh(eur)

            # Add multiple conversion records
            for i in range(15):
                if usd.id is not None and eur.id is not None:
                    conversion = ConversionHistory(
                        from_currency_id=usd.id,
                        to_currency_id=eur.id,
                        original_amount=Decimal("100.00"),
                        converted_amount=Decimal("85.00"),
                        exchange_rate=Decimal("0.85"),
                    )
                    session.add(conversion)
            session.commit()

        # Test default limit
        history = CurrencyService.get_conversion_history()
        assert len(history) == 10  # Default limit

        # Test custom limit
        history_limited = CurrencyService.get_conversion_history(limit=5)
        assert len(history_limited) == 5

    def test_get_conversion_history_empty(self, new_db):
        """Test conversion history when no records exist"""
        history = CurrencyService.get_conversion_history()
        assert history == []
        assert len(history) == 0

    def test_conversion_request_validation(self):
        """Test conversion request validates amount"""
        # Valid request
        valid_request = ConversionRequest(amount=Decimal("100.00"), from_currency_code="USD", to_currency_code="EUR")
        assert valid_request.amount == Decimal("100.00")

        # Invalid amount (should raise validation error when used with pydantic)
        with pytest.raises(ValueError):
            ConversionRequest(
                amount=Decimal("-100.00"),  # Negative amount
                from_currency_code="USD",
                to_currency_code="EUR",
            )

    def test_currency_data_integrity(self, new_db):
        """Test currency data is stored correctly"""
        with Session(ENGINE) as session:
            currency = Currency(code="USD", name="US Dollar", symbol="$", is_active=True)
            session.add(currency)
            session.commit()
            session.refresh(currency)

            assert currency.id is not None
            assert currency.code == "USD"
            assert currency.name == "US Dollar"
            assert currency.symbol == "$"
            assert currency.is_active
            assert currency.created_at is not None

    def test_conversion_history_relationships(self, new_db):
        """Test conversion history properly links to currencies"""
        with Session(ENGINE) as session:
            usd = Currency(code="USD", name="US Dollar")
            eur = Currency(code="EUR", name="Euro")
            session.add(usd)
            session.add(eur)
            session.commit()
            session.refresh(usd)
            session.refresh(eur)

            if usd.id is not None and eur.id is not None:
                conversion = ConversionHistory(
                    from_currency_id=usd.id,
                    to_currency_id=eur.id,
                    original_amount=Decimal("100.00"),
                    converted_amount=Decimal("85.00"),
                    exchange_rate=Decimal("0.85"),
                )
                session.add(conversion)
                session.commit()
                session.refresh(conversion)

                # Test relationships work
                assert conversion.from_currency.code == "USD"
                assert conversion.to_currency.code == "EUR"

    @pytest.mark.asyncio
    async def test_high_precision_conversion(self, new_db):
        """Test conversion maintains precision for large amounts"""
        # Setup test currencies
        with Session(ENGINE) as session:
            usd = Currency(code="USD", name="US Dollar")
            eur = Currency(code="EUR", name="Euro")
            session.add(usd)
            session.add(eur)
            session.commit()

        request = ConversionRequest(amount=Decimal("999999.99"), from_currency_code="USD", to_currency_code="EUR")

        result = await CurrencyService.convert_currency(request)

        # Should handle large amounts without precision loss
        assert result.original_amount == Decimal("999999.99")
        assert result.converted_amount > Decimal("0")
        assert result.exchange_rate > Decimal("0")
