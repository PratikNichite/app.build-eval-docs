from app.database import create_tables
import app.currency_converter
import app.conversion_history


def startup() -> None:
    # this function is called before the first request
    create_tables()

    # Create the currency converter module
    app.currency_converter.create()
