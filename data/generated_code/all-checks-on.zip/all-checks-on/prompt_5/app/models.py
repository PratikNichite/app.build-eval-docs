from sqlmodel import SQLModel, Field, Relationship
from datetime import datetime
from typing import Optional, List
from decimal import Decimal


# Persistent models (stored in database)
class Currency(SQLModel, table=True):
    """Currency model to store available currencies from Frankfurter API"""

    __tablename__ = "currencies"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    code: str = Field(unique=True, max_length=3, description="ISO 4217 currency code (e.g., USD, EUR)")
    name: str = Field(max_length=100, description="Full currency name")
    symbol: Optional[str] = Field(default=None, max_length=10, description="Currency symbol")
    is_active: bool = Field(default=True, description="Whether currency is available for conversion")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    from_conversions: List["ConversionHistory"] = Relationship(
        back_populates="from_currency", sa_relationship_kwargs={"foreign_keys": "[ConversionHistory.from_currency_id]"}
    )
    to_conversions: List["ConversionHistory"] = Relationship(
        back_populates="to_currency", sa_relationship_kwargs={"foreign_keys": "[ConversionHistory.to_currency_id]"}
    )


class ExchangeRate(SQLModel, table=True):
    """Exchange rate model to cache rates from Frankfurter API"""

    __tablename__ = "exchange_rates"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    from_currency_code: str = Field(max_length=3, description="Source currency code")
    to_currency_code: str = Field(max_length=3, description="Target currency code")
    rate: Decimal = Field(decimal_places=6, description="Exchange rate")
    date: datetime = Field(description="Date of the exchange rate")
    created_at: datetime = Field(default_factory=datetime.utcnow)


class ConversionHistory(SQLModel, table=True):
    """Conversion history to track user conversions"""

    __tablename__ = "conversion_history"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    from_currency_id: int = Field(foreign_key="currencies.id")
    to_currency_id: int = Field(foreign_key="currencies.id")
    original_amount: Decimal = Field(decimal_places=2, description="Amount to convert")
    converted_amount: Decimal = Field(decimal_places=2, description="Converted amount")
    exchange_rate: Decimal = Field(decimal_places=6, description="Exchange rate used")
    conversion_date: datetime = Field(default_factory=datetime.utcnow)
    created_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    from_currency: Currency = Relationship(
        back_populates="from_conversions",
        sa_relationship_kwargs={"foreign_keys": "[ConversionHistory.from_currency_id]"},
    )
    to_currency: Currency = Relationship(
        back_populates="to_conversions", sa_relationship_kwargs={"foreign_keys": "[ConversionHistory.to_currency_id]"}
    )


# Non-persistent schemas (for validation, forms, API requests/responses)
class CurrencyCreate(SQLModel, table=False):
    """Schema for creating a new currency"""

    code: str = Field(max_length=3, description="ISO 4217 currency code")
    name: str = Field(max_length=100, description="Full currency name")
    symbol: Optional[str] = Field(default=None, max_length=10, description="Currency symbol")
    is_active: bool = Field(default=True)


class CurrencyUpdate(SQLModel, table=False):
    """Schema for updating currency information"""

    name: Optional[str] = Field(default=None, max_length=100)
    symbol: Optional[str] = Field(default=None, max_length=10)
    is_active: Optional[bool] = Field(default=None)


class ConversionRequest(SQLModel, table=False):
    """Schema for currency conversion request"""

    amount: Decimal = Field(gt=0, decimal_places=2, description="Amount to convert")
    from_currency_code: str = Field(max_length=3, description="Source currency code")
    to_currency_code: str = Field(max_length=3, description="Target currency code")


class ConversionResponse(SQLModel, table=False):
    """Schema for currency conversion response"""

    original_amount: Decimal = Field(decimal_places=2)
    converted_amount: Decimal = Field(decimal_places=2)
    from_currency_code: str = Field(max_length=3)
    to_currency_code: str = Field(max_length=3)
    exchange_rate: Decimal = Field(decimal_places=6)
    conversion_date: str = Field(description="ISO formatted date string")


class ExchangeRateResponse(SQLModel, table=False):
    """Schema for exchange rate API response"""

    base: str = Field(max_length=3, description="Base currency code")
    date: str = Field(description="Rate date in YYYY-MM-DD format")
    rates: dict[str, float] = Field(description="Currency rates dictionary")


class CurrencyListResponse(SQLModel, table=False):
    """Schema for currency list response"""

    currencies: List[Currency] = Field(description="List of available currencies")


class ConversionHistoryResponse(SQLModel, table=False):
    """Schema for conversion history response"""

    id: int
    original_amount: Decimal = Field(decimal_places=2)
    converted_amount: Decimal = Field(decimal_places=2)
    from_currency_code: str = Field(max_length=3)
    to_currency_code: str = Field(max_length=3)
    exchange_rate: Decimal = Field(decimal_places=6)
    conversion_date: str = Field(description="ISO formatted date string")
    from_currency_name: str = Field(description="Full name of source currency")
    to_currency_name: str = Field(description="Full name of target currency")
