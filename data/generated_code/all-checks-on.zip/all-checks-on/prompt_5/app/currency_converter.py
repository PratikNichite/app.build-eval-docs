"""Currency converter UI module"""

from decimal import Decimal, InvalidOperation
from nicegui import ui
from app.currency_service import CurrencyService
from app.models import ConversionRequest
from app.conversion_history import create_history_section


class CurrencyConverter:
    """Currency converter UI component"""

    def __init__(self):
        self.amount_input = None
        self.from_currency_select = None
        self.to_currency_select = None
        self.result_display = None
        self.currencies = []
        self.loading = False

    async def load_currencies(self):
        """Load currencies from database and API if needed"""
        try:
            # Try to get currencies from database first
            self.currencies = CurrencyService.get_stored_currencies()

            # If no currencies in database, initialize from API
            if not self.currencies:
                ui.notify("🔄 Loading currencies from API...", type="info")
                await CurrencyService.initialize_currencies()
                self.currencies = CurrencyService.get_stored_currencies()

            # Update dropdown options
            if self.currencies:
                currency_options = {c.code: f"{c.code} - {c.name}" for c in self.currencies}

                if self.from_currency_select:
                    self.from_currency_select.set_options(currency_options)
                    self.from_currency_select.set_value("EUR")  # Default to EUR

                if self.to_currency_select:
                    self.to_currency_select.set_options(currency_options)
                    self.to_currency_select.set_value("USD")  # Default to USD

        except Exception as e:
            ui.notify(f"❌ Failed to load currencies: {str(e)}", type="negative")

    async def convert_currency(self):
        """Handle currency conversion"""
        if self.loading:
            return

        try:
            # Validate inputs
            if not self.amount_input or not self.amount_input.value:
                ui.notify("⚠️ Please enter an amount", type="warning")
                return

            if not self.from_currency_select or not self.from_currency_select.value:
                ui.notify("⚠️ Please select source currency", type="warning")
                return

            if not self.to_currency_select or not self.to_currency_select.value:
                ui.notify("⚠️ Please select target currency", type="warning")
                return

            # Parse amount
            try:
                amount = Decimal(str(self.amount_input.value))
                if amount <= 0:
                    ui.notify("⚠️ Amount must be greater than 0", type="warning")
                    return
            except (InvalidOperation, ValueError):
                ui.notify("⚠️ Please enter a valid number", type="warning")
                return

            # Show loading state
            self.loading = True
            if self.result_display:
                self.result_display.set_value("🔄 Converting...")

            # Create conversion request
            request = ConversionRequest(
                amount=amount,
                from_currency_code=self.from_currency_select.value,
                to_currency_code=self.to_currency_select.value,
            )

            # Perform conversion
            result = await CurrencyService.convert_currency(request)

            # Display result
            if self.result_display:
                result_text = (
                    f"💰 {result.original_amount:,.2f} {result.from_currency_code} = "
                    f"{result.converted_amount:,.2f} {result.to_currency_code}\n"
                    f"📊 Exchange Rate: 1 {result.from_currency_code} = "
                    f"{result.exchange_rate:.6f} {result.to_currency_code}"
                )
                self.result_display.set_value(result_text)

            ui.notify("✅ Conversion completed successfully!", type="positive")

        except Exception as e:
            ui.notify(f"❌ Conversion failed: {str(e)}", type="negative")
            if self.result_display:
                self.result_display.set_value("❌ Conversion failed")
        finally:
            self.loading = False

    def swap_currencies(self):
        """Swap source and target currencies"""
        if self.from_currency_select and self.to_currency_select:
            from_value = self.from_currency_select.value
            to_value = self.to_currency_select.value

            self.from_currency_select.set_value(to_value)
            self.to_currency_select.set_value(from_value)

    async def create_ui(self):
        """Create the currency converter UI"""
        # Apply modern theme
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        # Main container
        with ui.column().classes("w-full max-w-2xl mx-auto p-6"):
            # Header
            ui.label("💱 Currency Converter").classes("text-3xl font-bold text-gray-800 mb-2 text-center")
            ui.label("🌍 Convert between different currencies using live exchange rates").classes(
                "text-lg text-gray-600 mb-8 text-center"
            )

            # Main conversion card
            with ui.card().classes("p-8 shadow-xl rounded-2xl bg-white w-full"):
                # Amount input
                ui.label("Amount").classes("text-sm font-semibold text-gray-700 mb-2")
                self.amount_input = (
                    ui.number(placeholder="Enter amount to convert", format="%.2f", min=0.01, step=0.01)
                    .classes("w-full mb-6")
                    .props("outlined dense")
                )

                # Currency selection row
                with ui.row().classes("w-full gap-4 mb-6 items-end"):
                    # From currency
                    with ui.column().classes("flex-1"):
                        ui.label("From").classes("text-sm font-semibold text-gray-700 mb-2")
                        self.from_currency_select = (
                            ui.select(options={}, with_input=True).classes("w-full").props("outlined dense")
                        )

                    # Swap button
                    ui.button(icon="swap_horiz", on_click=self.swap_currencies).classes(
                        "bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-full p-2"
                    ).props("flat round")

                    # To currency
                    with ui.column().classes("flex-1"):
                        ui.label("To").classes("text-sm font-semibold text-gray-700 mb-2")
                        self.to_currency_select = (
                            ui.select(options={}, with_input=True).classes("w-full").props("outlined dense")
                        )

                # Convert button
                ui.button("Convert Currency", on_click=self.convert_currency, icon="currency_exchange").classes(
                    "w-full bg-primary text-white font-semibold py-3 px-6 rounded-lg hover:shadow-lg transition-shadow mb-6"
                )

                # Result display
                ui.label("💡 Result").classes("text-sm font-semibold text-gray-700 mb-2")
                self.result_display = (
                    ui.textarea(value="💵 Enter amount and select currencies to see conversion result")
                    .classes("w-full bg-gray-50 border-gray-200")
                    .props("outlined rows=3 readonly")
                )

        # Load currencies after UI is created
        await self.load_currencies()

        # Add conversion history section
        create_history_section()


def create():
    """Create currency converter page"""

    @ui.page("/")
    async def currency_converter_page():
        converter = CurrencyConverter()
        await converter.create_ui()
