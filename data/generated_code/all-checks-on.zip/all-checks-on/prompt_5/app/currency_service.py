"""Currency conversion service using Frankfurter API"""

import httpx
from decimal import Decimal
from datetime import datetime
from typing import Dict, List
from sqlmodel import Session, select, desc
from app.database import ENGINE
from app.models import Currency, ConversionHistory, ConversionRequest, ConversionResponse


class CurrencyService:
    """Service class for currency operations using Frankfurter API"""

    BASE_URL = "https://api.frankfurter.app"

    @staticmethod
    async def get_available_currencies() -> Dict[str, str]:
        """Fetch available currencies from Frankfurter API"""
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{CurrencyService.BASE_URL}/currencies")
            response.raise_for_status()
            return response.json()

    @staticmethod
    async def get_exchange_rate(from_currency: str, to_currency: str) -> Decimal:
        """Get current exchange rate between two currencies"""
        if from_currency == to_currency:
            return Decimal("1.0")

        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{CurrencyService.BASE_URL}/latest", params={"from": from_currency, "to": to_currency}
            )
            response.raise_for_status()
            data = response.json()
            rate = data["rates"][to_currency]
            return Decimal(str(rate)).quantize(Decimal("0.000001"))

    @staticmethod
    async def convert_currency(request: ConversionRequest) -> ConversionResponse:
        """Convert amount from one currency to another"""
        rate = await CurrencyService.get_exchange_rate(request.from_currency_code, request.to_currency_code)

        converted_amount = (request.amount * rate).quantize(Decimal("0.01"))

        # Store conversion in history
        with Session(ENGINE) as session:
            # Get currency objects
            from_currency = session.exec(select(Currency).where(Currency.code == request.from_currency_code)).first()
            to_currency = session.exec(select(Currency).where(Currency.code == request.to_currency_code)).first()

            if from_currency and to_currency and from_currency.id is not None and to_currency.id is not None:
                history = ConversionHistory(
                    from_currency_id=from_currency.id,
                    to_currency_id=to_currency.id,
                    original_amount=request.amount,
                    converted_amount=converted_amount,
                    exchange_rate=rate,
                )
                session.add(history)
                session.commit()

        return ConversionResponse(
            original_amount=request.amount,
            converted_amount=converted_amount,
            from_currency_code=request.from_currency_code,
            to_currency_code=request.to_currency_code,
            exchange_rate=rate,
            conversion_date=datetime.now().isoformat(),
        )

    @staticmethod
    async def initialize_currencies() -> None:
        """Initialize database with available currencies from API"""
        try:
            currencies_data = await CurrencyService.get_available_currencies()

            with Session(ENGINE) as session:
                # Get existing currencies
                existing = session.exec(select(Currency)).all()
                existing_codes = {c.code for c in existing}

                # Add new currencies
                for code, name in currencies_data.items():
                    if code not in existing_codes:
                        currency = Currency(code=code, name=name)
                        session.add(currency)

                session.commit()
        except Exception as e:
            print(f"❌ Failed to initialize currencies: {e}")

    @staticmethod
    def get_stored_currencies() -> List[Currency]:
        """Get currencies from database"""
        with Session(ENGINE) as session:
            currencies = session.exec(select(Currency).where(Currency.is_active)).all()
            return list(currencies)

    @staticmethod
    def get_conversion_history(limit: int = 10) -> List[ConversionHistory]:
        """Get recent conversion history"""
        with Session(ENGINE) as session:
            history = session.exec(
                select(ConversionHistory).order_by(desc(ConversionHistory.conversion_date)).limit(limit)
            ).all()
            return list(history)
