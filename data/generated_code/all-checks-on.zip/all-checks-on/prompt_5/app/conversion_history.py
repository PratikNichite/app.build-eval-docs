"""Conversion history UI component"""

from nicegui import ui
from app.currency_service import CurrencyService


def create_history_section():
    """Create conversion history section"""

    def refresh_history():
        """Refresh the conversion history display"""
        history = CurrencyService.get_conversion_history()

        # Clear existing content
        history_container.clear()

        if not history:
            with history_container:
                ui.label("📝 No conversion history yet").classes("text-gray-500 text-center p-4")
            return

        # Create table for history
        with history_container:
            columns = [
                {"name": "date", "label": "📅 Date", "field": "date", "align": "left"},
                {"name": "from_amount", "label": "💰 From", "field": "from_amount", "align": "right"},
                {"name": "to_amount", "label": "💵 To", "field": "to_amount", "align": "right"},
                {"name": "rate", "label": "📊 Rate", "field": "rate", "align": "right"},
            ]

            rows = []
            for h in history:
                if h.from_currency and h.to_currency:
                    rows.append(
                        {
                            "date": h.conversion_date.strftime("%Y-%m-%d %H:%M"),
                            "from_amount": f"{h.original_amount:,.2f} {h.from_currency.code}",
                            "to_amount": f"{h.converted_amount:,.2f} {h.to_currency.code}",
                            "rate": f"{h.exchange_rate:.6f}",
                        }
                    )

            ui.table(columns=columns, rows=rows, row_key="date").classes("w-full")

    # History section
    with ui.column().classes("w-full max-w-2xl mx-auto p-6 mt-8"):
        with ui.card().classes("p-6 shadow-lg rounded-xl bg-white w-full"):
            # Header with refresh button
            with ui.row().classes("w-full justify-between items-center mb-4"):
                ui.label("📈 Recent Conversions").classes("text-xl font-bold text-gray-800")
                ui.button("🔄 Refresh", on_click=refresh_history, icon="refresh").classes(
                    "bg-gray-100 hover:bg-gray-200 text-gray-600"
                ).props("flat")

            # History container
            history_container = ui.column().classes("w-full")

            # Initial load
            refresh_history()
