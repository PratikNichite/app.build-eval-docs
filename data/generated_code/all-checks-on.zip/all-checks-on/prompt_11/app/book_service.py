from typing import Optional
from sqlmodel import select, desc
from datetime import datetime

from app.database import get_session
from app.models import Book, BookCreate, BookUpdate, BookSearch, ReadingStatus


class BookService:
    """Service class for handling book operations."""

    def create_book(self, book_data: BookCreate) -> Book:
        """Create a new book."""
        with get_session() as session:
            book = Book(
                title=book_data.title,
                author=book_data.author,
                genre=book_data.genre,
                reading_status=book_data.reading_status,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )
            session.add(book)
            session.commit()
            session.refresh(book)
            return book

    def get_book(self, book_id: int) -> Optional[Book]:
        """Get a book by ID."""
        with get_session() as session:
            return session.get(Book, book_id)

    def get_all_books(self) -> list[Book]:
        """Get all books."""
        with get_session() as session:
            statement = select(Book).order_by(desc(Book.created_at))
            return list(session.exec(statement))

    def search_books(self, search_params: BookSearch) -> list[Book]:
        """Search books based on search parameters."""
        with get_session() as session:
            statement = select(Book)

            # Apply filters with AND logic (all conditions must match)
            if search_params.title:
                statement = statement.where(Book.title.ilike(f"%{search_params.title}%"))  # type: ignore[attr-defined]

            if search_params.author:
                statement = statement.where(Book.author.ilike(f"%{search_params.author}%"))  # type: ignore[attr-defined]

            if search_params.genre:
                statement = statement.where(Book.genre.ilike(f"%{search_params.genre}%"))  # type: ignore[attr-defined]

            if search_params.reading_status:
                statement = statement.where(Book.reading_status == search_params.reading_status)

            statement = statement.order_by(desc(Book.created_at))
            return list(session.exec(statement))

    def update_book(self, book_id: int, book_data: BookUpdate) -> Optional[Book]:
        """Update a book."""
        with get_session() as session:
            book = session.get(Book, book_id)
            if book is None:
                return None

            if book_data.title is not None:
                book.title = book_data.title
            if book_data.author is not None:
                book.author = book_data.author
            if book_data.genre is not None:
                book.genre = book_data.genre
            if book_data.reading_status is not None:
                book.reading_status = book_data.reading_status

            book.updated_at = datetime.utcnow()
            session.add(book)
            session.commit()
            session.refresh(book)
            return book

    def delete_book(self, book_id: int) -> bool:
        """Delete a book."""
        with get_session() as session:
            book = session.get(Book, book_id)
            if book is None:
                return False

            session.delete(book)
            session.commit()
            return True

    def get_book_count_by_status(self) -> dict[ReadingStatus, int]:
        """Get count of books by reading status."""
        with get_session() as session:
            books = session.exec(select(Book)).all()
            counts = {status: 0 for status in ReadingStatus}
            for book in books:
                counts[book.reading_status] += 1
            return counts


# Global service instance
book_service = BookService()
