from nicegui import ui
from typing import Optional

from app.book_service import book_service
from app.models import Book, BookCreate, BookUpdate, BookSearch, ReadingStatus


def apply_modern_theme():
    """Apply a modern color theme to the application."""
    ui.colors(
        primary="#2563eb",  # Professional blue
        secondary="#64748b",  # Subtle gray
        accent="#10b981",  # Success green
        positive="#10b981",
        negative="#ef4444",  # Error red
        warning="#f59e0b",  # Warning amber
        info="#3b82f6",  # Info blue
    )


class TextStyles:
    """Reusable text styles for consistent typography."""

    HEADING = "text-2xl font-bold text-gray-800 mb-4"
    SUBHEADING = "text-lg font-semibold text-gray-700 mb-2"
    BODY = "text-base text-gray-600 leading-relaxed"
    CAPTION = "text-sm text-gray-500"


def create_metric_card(title: str, value: str, color: str = "blue"):
    """Create a metric card for dashboard statistics."""
    with ui.card().classes("p-6 bg-white shadow-lg rounded-xl hover:shadow-xl transition-shadow"):
        ui.label(title).classes("text-sm text-gray-500 uppercase tracking-wider")
        ui.label(value).classes(f"text-3xl font-bold text-{color}-600 mt-2")


def create_book_card(book: Book, on_edit, on_delete):
    """Create a book card with actions."""
    status_colors = {
        ReadingStatus.READ: "bg-green-100 text-green-800",
        ReadingStatus.UNREAD: "bg-gray-100 text-gray-800",
        ReadingStatus.READING: "bg-blue-100 text-blue-800",
    }

    with ui.card().classes("p-4 shadow-md hover:shadow-lg transition-shadow"):
        # Book title and author
        ui.label(book.title).classes("text-lg font-bold text-gray-800 mb-1")
        ui.label(f"by {book.author}").classes("text-sm text-gray-600 mb-2")

        # Genre and status
        with ui.row().classes("gap-2 mb-3"):
            ui.label(book.genre).classes("px-2 py-1 bg-gray-200 text-gray-700 rounded-full text-xs")
            status_class = status_colors.get(book.reading_status, "bg-gray-100 text-gray-800")
            ui.label(book.reading_status.value).classes(f"px-2 py-1 {status_class} rounded-full text-xs")

        # Action buttons
        with ui.row().classes("gap-2 justify-end"):
            ui.button("Edit", on_click=lambda: on_edit(book)).props("size=sm color=primary outline")
            ui.button("Delete", on_click=lambda: on_delete(book.id) if book.id else None).props(
                "size=sm color=negative outline"
            )


class LibraryApp:
    """Main library application class."""

    def __init__(self):
        self.books: list[Book] = []
        self.search_title = ""
        self.search_author = ""
        self.current_book: Optional[Book] = None
        # UI component references
        self.total_books_label: Optional[ui.label] = None
        self.read_books_label: Optional[ui.label] = None
        self.reading_books_label: Optional[ui.label] = None
        self.unread_books_label: Optional[ui.label] = None
        self.books_container: Optional[ui.column] = None
        self.refresh_books()

    def refresh_books(self):
        """Refresh the books list."""
        self.books = book_service.get_all_books()

    def search_books(self):
        """Search books based on current search criteria."""
        search_params = BookSearch(
            title=self.search_title if self.search_title.strip() else None,
            author=self.search_author if self.search_author.strip() else None,
        )
        self.books = book_service.search_books(search_params)

    def clear_search(self):
        """Clear search filters and show all books."""
        self.search_title = ""
        self.search_author = ""
        self.refresh_books()

    async def add_book_dialog(self):
        """Show dialog to add a new book."""
        with ui.dialog() as dialog, ui.card().classes("w-96"):
            ui.label("Add New Book").classes(TextStyles.SUBHEADING)

            title_input = ui.input("Title").classes("w-full mb-2")
            author_input = ui.input("Author").classes("w-full mb-2")
            genre_input = ui.input("Genre").classes("w-full mb-2")
            status_select = ui.select(
                options=[status.value for status in ReadingStatus],
                value=ReadingStatus.UNREAD.value,
                label="Reading Status",
            ).classes("w-full mb-4")

            with ui.row().classes("gap-2 justify-end w-full"):
                ui.button("Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
                ui.button("Add Book", on_click=lambda: dialog.submit("add")).props("color=primary")

        result = await dialog

        if result == "add":
            if title_input.value and author_input.value and genre_input.value:
                book_data = BookCreate(
                    title=title_input.value,
                    author=author_input.value,
                    genre=genre_input.value,
                    reading_status=ReadingStatus(status_select.value),
                )
                book_service.create_book(book_data)
                ui.notify("Book added successfully!", type="positive")
                self.refresh_books()
                self.update_dashboard()
                self.update_books_display()
            else:
                ui.notify("Please fill in all fields", type="negative")

    async def edit_book_dialog(self, book: Book):
        """Show dialog to edit an existing book."""
        with ui.dialog() as dialog, ui.card().classes("w-96"):
            ui.label("Edit Book").classes(TextStyles.SUBHEADING)

            title_input = ui.input("Title", value=book.title).classes("w-full mb-2")
            author_input = ui.input("Author", value=book.author).classes("w-full mb-2")
            genre_input = ui.input("Genre", value=book.genre).classes("w-full mb-2")
            status_select = ui.select(
                options=[status.value for status in ReadingStatus],
                value=book.reading_status.value,
                label="Reading Status",
            ).classes("w-full mb-4")

            with ui.row().classes("gap-2 justify-end w-full"):
                ui.button("Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
                ui.button("Update Book", on_click=lambda: dialog.submit("update")).props("color=primary")

        result = await dialog

        if result == "update" and book.id is not None:
            if title_input.value and author_input.value and genre_input.value:
                book_data = BookUpdate(
                    title=title_input.value,
                    author=author_input.value,
                    genre=genre_input.value,
                    reading_status=ReadingStatus(status_select.value),
                )
                book_service.update_book(book.id, book_data)
                ui.notify("Book updated successfully!", type="positive")
                self.refresh_books()
                self.update_dashboard()
                self.update_books_display()
            else:
                ui.notify("Please fill in all fields", type="negative")

    async def delete_book_confirm(self, book_id: int):
        """Confirm and delete a book."""
        with ui.dialog() as dialog, ui.card():
            ui.label("Confirm Deletion").classes(TextStyles.SUBHEADING)
            ui.label("Are you sure you want to delete this book? This action cannot be undone.")

            with ui.row().classes("gap-2 justify-end w-full mt-4"):
                ui.button("Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
                ui.button("Delete", on_click=lambda: dialog.submit("delete")).props("color=negative")

        result = await dialog

        if result == "delete":
            if book_service.delete_book(book_id):
                ui.notify("Book deleted successfully!", type="positive")
                self.refresh_books()
                self.update_dashboard()
                self.update_books_display()
            else:
                ui.notify("Failed to delete book", type="negative")

    def update_dashboard(self):
        """Update dashboard statistics."""
        counts = book_service.get_book_count_by_status()
        total_books = sum(counts.values())

        # Update metric cards
        if self.total_books_label is not None:
            self.total_books_label.set_text(str(total_books))
        if self.read_books_label is not None:
            self.read_books_label.set_text(str(counts[ReadingStatus.READ]))
        if self.reading_books_label is not None:
            self.reading_books_label.set_text(str(counts[ReadingStatus.READING]))
        if self.unread_books_label is not None:
            self.unread_books_label.set_text(str(counts[ReadingStatus.UNREAD]))

    def update_books_display(self):
        """Update the books display grid."""
        if self.books_container is not None:
            self.books_container.clear()

            if not self.books:
                with self.books_container:
                    ui.label("No books found. Add some books to get started! 📖✍️").classes(
                        "text-center text-gray-500 py-8"
                    )
                return

            with self.books_container:
                with ui.row().classes("gap-4 w-full flex-wrap"):
                    for book in self.books:
                        create_book_card(book, self.edit_book_dialog, self.delete_book_confirm)


def create():
    """Create and setup the library application."""
    apply_modern_theme()
    app_instance = LibraryApp()

    @ui.page("/")
    def index():
        # Header
        with ui.row().classes("w-full justify-between items-center mb-6 p-4 bg-white shadow-sm"):
            ui.label("Welcome to My Awesome Library! 📚✨").classes("text-3xl font-bold text-primary")
            ui.button("Add New Book", on_click=app_instance.add_book_dialog).props("color=primary")

        with ui.column().classes("w-full max-w-7xl mx-auto p-4"):
            # Dashboard metrics
            ui.label("Dashboard Overview").classes(TextStyles.HEADING)

            with ui.row().classes("gap-4 w-full mb-6"):
                # Metric cards
                with ui.card().classes("p-6 bg-white shadow-lg rounded-xl hover:shadow-xl transition-shadow"):
                    ui.label("Total Books").classes("text-sm text-gray-500 uppercase tracking-wider")
                    app_instance.total_books_label = ui.label("0").classes("text-3xl font-bold text-blue-600 mt-2")

                with ui.card().classes("p-6 bg-white shadow-lg rounded-xl hover:shadow-xl transition-shadow"):
                    ui.label("Read").classes("text-sm text-gray-500 uppercase tracking-wider")
                    app_instance.read_books_label = ui.label("0").classes("text-3xl font-bold text-green-600 mt-2")

                with ui.card().classes("p-6 bg-white shadow-lg rounded-xl hover:shadow-xl transition-shadow"):
                    ui.label("Currently Reading").classes("text-sm text-gray-500 uppercase tracking-wider")
                    app_instance.reading_books_label = ui.label("0").classes("text-3xl font-bold text-blue-600 mt-2")

                with ui.card().classes("p-6 bg-white shadow-lg rounded-xl hover:shadow-xl transition-shadow"):
                    ui.label("Unread").classes("text-sm text-gray-500 uppercase tracking-wider")
                    app_instance.unread_books_label = ui.label("0").classes("text-3xl font-bold text-gray-600 mt-2")

            # Search section
            ui.label("Search Books").classes(TextStyles.HEADING)

            with ui.card().classes("p-4 mb-6"):
                with ui.row().classes("gap-4 w-full items-end"):
                    title_search = (
                        ui.input("Search by title").classes("flex-1").bind_value(app_instance, "search_title")
                    )
                    author_search = (
                        ui.input("Search by author").classes("flex-1").bind_value(app_instance, "search_author")
                    )

                    with ui.column().classes("gap-2"):
                        ui.button(
                            "Search",
                            on_click=lambda: (app_instance.search_books(), app_instance.update_books_display()),
                        ).props("color=primary")
                        ui.button(
                            "Clear",
                            on_click=lambda: (
                                app_instance.clear_search(),
                                title_search.set_value(""),
                                author_search.set_value(""),
                                app_instance.update_books_display(),
                            ),
                        ).props("outline")

            # Books section
            ui.label("Your Books").classes(TextStyles.HEADING)

            app_instance.books_container = ui.column().classes("w-full")

            # Initial load
            app_instance.update_dashboard()
            app_instance.update_books_display()
