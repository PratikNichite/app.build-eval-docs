from sqlmodel import SQLModel, Field
from datetime import datetime
from typing import Optional
from enum import Enum


class ReadingStatus(str, Enum):
    """Enumeration for book reading status."""

    READ = "Read"
    UNREAD = "Unread"
    READING = "Reading"


# Persistent models (stored in database)
class Book(SQLModel, table=True):
    """Book model for storing book information in the database."""

    __tablename__ = "books"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    title: str = Field(max_length=500, index=True)
    author: str = Field(max_length=300, index=True)
    genre: str = Field(max_length=100)
    reading_status: ReadingStatus = Field(default=ReadingStatus.UNREAD)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class BookCreate(SQLModel, table=False):
    """Schema for creating a new book."""

    title: str = Field(max_length=500)
    author: str = Field(max_length=300)
    genre: str = Field(max_length=100)
    reading_status: ReadingStatus = Field(default=ReadingStatus.UNREAD)


class BookUpdate(SQLModel, table=False):
    """Schema for updating an existing book."""

    title: Optional[str] = Field(default=None, max_length=500)
    author: Optional[str] = Field(default=None, max_length=300)
    genre: Optional[str] = Field(default=None, max_length=100)
    reading_status: Optional[ReadingStatus] = Field(default=None)


class BookRead(SQLModel, table=False):
    """Schema for reading book data (API responses)."""

    id: int
    title: str
    author: str
    genre: str
    reading_status: ReadingStatus
    created_at: datetime
    updated_at: datetime


class BookSearch(SQLModel, table=False):
    """Schema for book search parameters."""

    title: Optional[str] = Field(default=None, max_length=500)
    author: Optional[str] = Field(default=None, max_length=300)
    genre: Optional[str] = Field(default=None, max_length=100)
    reading_status: Optional[ReadingStatus] = Field(default=None)
