import pytest
from datetime import datetime

from app.book_service import book_service
from app.models import BookCreate, BookUpdate, BookSearch, ReadingStatus
from app.database import reset_db


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_create_book(new_db):
    """Test creating a new book."""
    book_data = BookCreate(
        title="The Great Gatsby",
        author="F. Scott Fitzgerald",
        genre="Classic Fiction",
        reading_status=ReadingStatus.UNREAD,
    )

    book = book_service.create_book(book_data)

    assert book.id is not None
    assert book.title == "The Great Gatsby"
    assert book.author == "F. Scott Fitzgerald"
    assert book.genre == "Classic Fiction"
    assert book.reading_status == ReadingStatus.UNREAD
    assert isinstance(book.created_at, datetime)
    assert isinstance(book.updated_at, datetime)


def test_get_book(new_db):
    """Test retrieving a book by ID."""
    # Create a book first
    book_data = BookCreate(title="1984", author="George Orwell", genre="Dystopian Fiction")
    created_book = book_service.create_book(book_data)

    # Retrieve the book
    if created_book.id is not None:
        retrieved_book = book_service.get_book(created_book.id)
    else:
        retrieved_book = None

    assert retrieved_book is not None
    assert retrieved_book.id == created_book.id
    assert retrieved_book.title == "1984"
    assert retrieved_book.author == "George Orwell"


def test_get_book_nonexistent(new_db):
    """Test retrieving a non-existent book."""
    book = book_service.get_book(999)
    assert book is None


def test_get_all_books(new_db):
    """Test retrieving all books."""
    # Initially empty
    books = book_service.get_all_books()
    assert books == []

    # Create some books
    book1_data = BookCreate(title="Book 1", author="Author 1", genre="Genre 1")
    book2_data = BookCreate(title="Book 2", author="Author 2", genre="Genre 2")

    book_service.create_book(book1_data)
    book_service.create_book(book2_data)

    books = book_service.get_all_books()
    assert len(books) == 2

    # Should be ordered by created_at desc (newest first)
    assert books[0].title == "Book 2"
    assert books[1].title == "Book 1"


def test_search_books_by_title(new_db):
    """Test searching books by title."""
    # Create test books
    book1_data = BookCreate(title="Python Programming", author="John Doe", genre="Technology")
    book2_data = BookCreate(title="Java Fundamentals", author="Jane Smith", genre="Technology")
    book3_data = BookCreate(title="Advanced Python", author="Bob Johnson", genre="Technology")

    book_service.create_book(book1_data)
    book_service.create_book(book2_data)
    book_service.create_book(book3_data)

    # Search for books with "Python" in title
    search_params = BookSearch(title="Python")
    results = book_service.search_books(search_params)

    assert len(results) == 2
    titles = [book.title for book in results]
    assert "Python Programming" in titles
    assert "Advanced Python" in titles


def test_search_books_by_author(new_db):
    """Test searching books by author."""
    # Create test books
    book1_data = BookCreate(title="Book A", author="Stephen King", genre="Horror")
    book2_data = BookCreate(title="Book B", author="Stephen Hawking", genre="Science")
    book3_data = BookCreate(title="Book C", author="John Doe", genre="Fiction")

    book_service.create_book(book1_data)
    book_service.create_book(book2_data)
    book_service.create_book(book3_data)

    # Search for books with "Stephen" in author
    search_params = BookSearch(author="Stephen")
    results = book_service.search_books(search_params)

    assert len(results) == 2
    authors = [book.author for book in results]
    assert "Stephen King" in authors
    assert "Stephen Hawking" in authors


def test_search_books_multiple_criteria(new_db):
    """Test searching books with multiple criteria."""
    # Create test books
    book1_data = BookCreate(title="Python Web Development", author="John Smith", genre="Technology")
    book2_data = BookCreate(title="Python Data Science", author="Jane Doe", genre="Technology")
    book3_data = BookCreate(title="Java Programming", author="John Smith", genre="Technology")

    book_service.create_book(book1_data)
    book_service.create_book(book2_data)
    book_service.create_book(book3_data)

    # Search for books with "Python" in title and "John" in author
    search_params = BookSearch(title="Python", author="John")
    results = book_service.search_books(search_params)

    assert len(results) == 1
    assert results[0].title == "Python Web Development"
    assert results[0].author == "John Smith"


def test_search_books_by_status(new_db):
    """Test searching books by reading status."""
    # Create books with different statuses
    book1_data = BookCreate(title="Book 1", author="Author 1", genre="Genre 1", reading_status=ReadingStatus.READ)
    book2_data = BookCreate(title="Book 2", author="Author 2", genre="Genre 2", reading_status=ReadingStatus.READING)
    book3_data = BookCreate(title="Book 3", author="Author 3", genre="Genre 3", reading_status=ReadingStatus.UNREAD)

    book_service.create_book(book1_data)
    book_service.create_book(book2_data)
    book_service.create_book(book3_data)

    # Search for read books
    search_params = BookSearch(reading_status=ReadingStatus.READ)
    results = book_service.search_books(search_params)

    assert len(results) == 1
    assert results[0].reading_status == ReadingStatus.READ


def test_update_book(new_db):
    """Test updating a book."""
    # Create a book
    book_data = BookCreate(
        title="Original Title", author="Original Author", genre="Original Genre", reading_status=ReadingStatus.UNREAD
    )
    book = book_service.create_book(book_data)
    original_updated_at = book.updated_at

    # Update the book
    update_data = BookUpdate(title="Updated Title", reading_status=ReadingStatus.READING)
    if book.id is not None:
        updated_book = book_service.update_book(book.id, update_data)
    else:
        updated_book = None

    assert updated_book is not None
    assert updated_book.title == "Updated Title"
    assert updated_book.author == "Original Author"  # Unchanged
    assert updated_book.genre == "Original Genre"  # Unchanged
    assert updated_book.reading_status == ReadingStatus.READING
    assert updated_book.updated_at > original_updated_at


def test_update_book_nonexistent(new_db):
    """Test updating a non-existent book."""
    update_data = BookUpdate(title="New Title")
    result = book_service.update_book(999, update_data)
    assert result is None


def test_delete_book(new_db):
    """Test deleting a book."""
    # Create a book
    book_data = BookCreate(title="To Delete", author="Author", genre="Genre")
    book = book_service.create_book(book_data)

    # Verify it exists
    if book.id is not None:
        retrieved_book = book_service.get_book(book.id)
        assert retrieved_book is not None

        # Delete the book
        result = book_service.delete_book(book.id)
        assert result

        # Verify it's gone
        deleted_book = book_service.get_book(book.id)
        assert deleted_book is None
    else:
        assert False, "Book ID should not be None"


def test_delete_book_nonexistent(new_db):
    """Test deleting a non-existent book."""
    result = book_service.delete_book(999)
    assert not result


def test_get_book_count_by_status(new_db):
    """Test getting book counts by reading status."""
    # Initially all counts should be 0
    counts = book_service.get_book_count_by_status()
    assert counts[ReadingStatus.READ] == 0
    assert counts[ReadingStatus.READING] == 0
    assert counts[ReadingStatus.UNREAD] == 0

    # Create books with different statuses
    book1_data = BookCreate(title="Book 1", author="Author 1", genre="Genre 1", reading_status=ReadingStatus.READ)
    book2_data = BookCreate(title="Book 2", author="Author 2", genre="Genre 2", reading_status=ReadingStatus.READ)
    book3_data = BookCreate(title="Book 3", author="Author 3", genre="Genre 3", reading_status=ReadingStatus.READING)
    book4_data = BookCreate(title="Book 4", author="Author 4", genre="Genre 4", reading_status=ReadingStatus.UNREAD)
    book5_data = BookCreate(title="Book 5", author="Author 5", genre="Genre 5", reading_status=ReadingStatus.UNREAD)
    book6_data = BookCreate(title="Book 6", author="Author 6", genre="Genre 6", reading_status=ReadingStatus.UNREAD)

    book_service.create_book(book1_data)
    book_service.create_book(book2_data)
    book_service.create_book(book3_data)
    book_service.create_book(book4_data)
    book_service.create_book(book5_data)
    book_service.create_book(book6_data)

    # Check counts
    counts = book_service.get_book_count_by_status()
    assert counts[ReadingStatus.READ] == 2
    assert counts[ReadingStatus.READING] == 1
    assert counts[ReadingStatus.UNREAD] == 3


def test_empty_search_returns_all_books(new_db):
    """Test that empty search parameters return all books."""
    # Create some books
    book1_data = BookCreate(title="Book 1", author="Author 1", genre="Genre 1")
    book2_data = BookCreate(title="Book 2", author="Author 2", genre="Genre 2")

    book_service.create_book(book1_data)
    book_service.create_book(book2_data)

    # Empty search should return all books
    search_params = BookSearch()
    results = book_service.search_books(search_params)

    assert len(results) == 2


def test_case_insensitive_search(new_db):
    """Test that search is case-insensitive."""
    # Create a book
    book_data = BookCreate(title="The Great Gatsby", author="F. Scott Fitzgerald", genre="Classic")
    book_service.create_book(book_data)

    # Search with different cases
    search_params1 = BookSearch(title="great")
    search_params2 = BookSearch(title="GREAT")
    search_params3 = BookSearch(author="scott")
    search_params4 = BookSearch(author="SCOTT")

    results1 = book_service.search_books(search_params1)
    results2 = book_service.search_books(search_params2)
    results3 = book_service.search_books(search_params3)
    results4 = book_service.search_books(search_params4)

    assert len(results1) == 1
    assert len(results2) == 1
    assert len(results3) == 1
    assert len(results4) == 1
