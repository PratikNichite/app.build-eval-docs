import pytest

from app.database import reset_db
from app.book_service import book_service
from app.models import BookCreate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_library_ui_module_imports(new_db):
    """Test that the library UI module can be imported without errors."""
    import app.library_ui

    # Test module functions exist
    assert hasattr(app.library_ui, "create")
    assert hasattr(app.library_ui, "LibraryApp")
    assert hasattr(app.library_ui, "apply_modern_theme")


def test_library_app_initialization(new_db):
    """Test LibraryApp class initialization."""
    from app.library_ui import LibraryApp

    app_instance = LibraryApp()

    # Check initial state
    assert app_instance.books == []
    assert app_instance.search_title == ""
    assert app_instance.search_author == ""
    assert app_instance.current_book is None

    # Check UI references are initialized
    assert app_instance.total_books_label is None
    assert app_instance.read_books_label is None
    assert app_instance.reading_books_label is None
    assert app_instance.unread_books_label is None
    assert app_instance.books_container is None


def test_library_app_refresh_books(new_db):
    """Test that refresh_books method works correctly."""
    from app.library_ui import LibraryApp

    # Create some test books
    book1_data = BookCreate(title="Book 1", author="Author 1", genre="Genre 1")
    book2_data = BookCreate(title="Book 2", author="Author 2", genre="Genre 2")

    book_service.create_book(book1_data)
    book_service.create_book(book2_data)

    app_instance = LibraryApp()
    app_instance.refresh_books()

    assert len(app_instance.books) == 2
    assert app_instance.books[0].title == "Book 2"  # Newest first
    assert app_instance.books[1].title == "Book 1"


def test_library_app_search_books(new_db):
    """Test that search_books method works correctly."""
    from app.library_ui import LibraryApp

    # Create test books
    book1_data = BookCreate(title="Python Programming", author="John Doe", genre="Technology")
    book2_data = BookCreate(title="Java Fundamentals", author="Jane Smith", genre="Technology")

    book_service.create_book(book1_data)
    book_service.create_book(book2_data)

    app_instance = LibraryApp()

    # Search by title
    app_instance.search_title = "Python"
    app_instance.search_books()

    assert len(app_instance.books) == 1
    assert app_instance.books[0].title == "Python Programming"


def test_library_app_clear_search(new_db):
    """Test that clear_search method works correctly."""
    from app.library_ui import LibraryApp

    # Create test books
    book1_data = BookCreate(title="Book 1", author="Author 1", genre="Genre 1")
    book2_data = BookCreate(title="Book 2", author="Author 2", genre="Genre 2")

    book_service.create_book(book1_data)
    book_service.create_book(book2_data)

    app_instance = LibraryApp()

    # Set search criteria
    app_instance.search_title = "Book 1"
    app_instance.search_books()
    assert len(app_instance.books) == 1

    # Clear search
    app_instance.clear_search()
    assert app_instance.search_title == ""
    assert app_instance.search_author == ""
    assert len(app_instance.books) == 2  # Should show all books


def test_create_book_card_function(new_db):
    """Test the create_book_card function exists and can be imported."""
    from app.library_ui import create_book_card

    # Test that function exists and is callable
    assert callable(create_book_card)


def test_text_styles_class():
    """Test TextStyles class constants."""
    from app.library_ui import TextStyles

    assert hasattr(TextStyles, "HEADING")
    assert hasattr(TextStyles, "SUBHEADING")
    assert hasattr(TextStyles, "BODY")
    assert hasattr(TextStyles, "CAPTION")

    # Check they're strings
    assert isinstance(TextStyles.HEADING, str)
    assert isinstance(TextStyles.SUBHEADING, str)
    assert isinstance(TextStyles.BODY, str)
    assert isinstance(TextStyles.CAPTION, str)
