from nicegui import ui
from datetime import datetime, date
from sqlmodel import select, desc
from app.database import get_session
from app.models import Event, EventCreate


def apply_modern_theme():
    """Apply modern color scheme for the application"""
    ui.colors(
        primary="#2563eb",  # Professional blue
        secondary="#64748b",  # Subtle gray
        accent="#10b981",  # Success green
        positive="#10b981",
        negative="#ef4444",  # Error red
        warning="#f59e0b",  # Warning amber
        info="#3b82f6",  # Info blue
    )


class EventService:
    """Service class for event CRUD operations"""

    @staticmethod
    def create_event(event_data: EventCreate) -> Event:
        """Create a new event"""
        with get_session() as session:
            event = Event(
                title=event_data.title,
                event_date=event_data.event_date,
                description=event_data.description,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )
            session.add(event)
            session.commit()
            session.refresh(event)
            return event

    @staticmethod
    def get_all_events() -> list[Event]:
        """Get all events ordered by event date"""
        with get_session() as session:
            statement = select(Event).order_by(desc(Event.event_date), desc(Event.created_at))
            events = session.exec(statement).all()
            return list(events)

    @staticmethod
    def delete_event(event_id: int) -> bool:
        """Delete an event by ID"""
        with get_session() as session:
            event = session.get(Event, event_id)
            if event is None:
                return False
            session.delete(event)
            session.commit()
            return True


def create_event_card(event: Event, on_delete_callback) -> ui.card:
    """Create a modern card for displaying an event"""
    with ui.card().classes("p-6 bg-white shadow-lg rounded-xl hover:shadow-xl transition-shadow w-full") as card:
        # Event header with title and date
        with ui.row().classes("w-full justify-between items-start mb-4"):
            with ui.column().classes("flex-1"):
                ui.label(event.title).classes("text-xl font-bold text-gray-800")
                ui.label(event.event_date.strftime("%B %d, %Y")).classes("text-sm text-blue-600 font-medium")

            # Delete button
            if event.id is not None:
                event_id = event.id  # Capture the ID to avoid closure issues
                ui.button(icon="delete", on_click=lambda: confirm_delete(event_id, on_delete_callback)).classes(
                    "text-red-500 hover:bg-red-50 rounded-full p-2"
                ).props("flat dense round")

        # Event description
        if event.description:
            ui.label(event.description).classes("text-gray-600 leading-relaxed")
        else:
            ui.label("No description provided").classes("text-gray-400 italic")

        # Creation timestamp
        ui.label(f"Created: {event.created_at.strftime('%m/%d/%Y at %I:%M %p')}").classes("text-xs text-gray-400 mt-3")

    return card


async def confirm_delete(event_id: int, callback):
    """Show confirmation dialog before deleting an event"""
    with ui.dialog() as dialog, ui.card().classes("p-6"):
        ui.label("Delete Event").classes("text-lg font-bold mb-2")
        ui.label("Are you sure you want to delete this event? This action cannot be undone.").classes(
            "text-gray-600 mb-4"
        )

        with ui.row().classes("gap-2 justify-end"):
            ui.button("Cancel", on_click=lambda: dialog.submit(False)).props("outline")
            ui.button("Delete", on_click=lambda: dialog.submit(True)).classes("bg-red-500 text-white")

    result = await dialog
    if result:
        success = EventService.delete_event(event_id)
        if success:
            ui.notify("✅ Event deleted successfully", type="positive")
            callback()  # Refresh the events list
        else:
            ui.notify("❌ Failed to delete event", type="negative")


def create_add_event_form(on_success_callback):
    """Create a modern form for adding new events"""
    with ui.card().classes("p-6 shadow-lg rounded-xl bg-white mb-6"):
        ui.label("Add New Event").classes("text-xl font-bold text-gray-800 mb-4")

        # Form fields
        title_input = ui.input(label="Event Title", placeholder="Enter event title").classes("w-full mb-4")
        title_input.props("outlined dense")

        ui.label("Event Date").classes("text-sm font-medium text-gray-700 mb-1")
        date_input = ui.date(value=date.today().isoformat()).classes("w-full mb-4")
        date_input.props("outlined dense")

        description_input = ui.textarea(label="Description (optional)", placeholder="Enter event description").classes(
            "w-full mb-4"
        )
        description_input.props("outlined dense rows=3")

        # Action buttons
        with ui.row().classes("gap-2 justify-end"):
            ui.button("Clear", on_click=lambda: clear_form()).props("outline")
            ui.button("Add Event", on_click=lambda: add_event()).classes("bg-blue-500 text-white")

        def clear_form():
            """Clear all form fields"""
            title_input.set_value("")
            date_input.set_value(date.today().isoformat())
            description_input.set_value("")

        def add_event():
            """Add a new event with validation"""
            title = title_input.value.strip() if title_input.value else ""
            event_date_str = date_input.value
            description = description_input.value.strip() if description_input.value else ""

            # Validation
            if not title:
                ui.notify("❌ Event title is required", type="negative")
                return

            if not event_date_str:
                ui.notify("❌ Event date is required", type="negative")
                return

            try:
                # Parse the date
                event_date = date.fromisoformat(event_date_str)

                # Create event
                event_data = EventCreate(title=title, event_date=event_date, description=description)

                EventService.create_event(event_data)
                ui.notify("✅ Event added successfully!", type="positive")

                # Clear form and refresh list
                clear_form()
                on_success_callback()

            except ValueError:
                ui.notify("❌ Invalid date format", type="negative")
            except Exception as e:
                ui.notify(f"❌ Error adding event: {str(e)}", type="negative")


def create():
    """Create the event tracker application"""
    apply_modern_theme()

    @ui.page("/")
    def index():
        # Page header
        with ui.column().classes("w-full max-w-4xl mx-auto p-6"):
            ui.label("📅 Event Tracker").classes("text-3xl font-bold text-gray-800 mb-2")
            ui.label("Manage your events with ease").classes("text-gray-600 mb-8")

            # Events container
            events_container = ui.column().classes("w-full gap-4")

            def refresh_events():
                """Refresh the events list"""
                events_container.clear()
                events = EventService.get_all_events()

                if not events:
                    with events_container:
                        with ui.card().classes("p-8 text-center bg-gray-50 rounded-xl"):
                            ui.label("📝").classes("text-4xl mb-2")
                            ui.label("✨ No events yet").classes("text-xl font-semibold text-gray-600 mb-1")
                            ui.label("Create your first event using the form above").classes("text-gray-500")
                else:
                    with events_container:
                        ui.label(f"🎉 Your Events ({len(events)})").classes("text-lg font-semibold text-gray-700 mb-4")
                        for event in events:
                            create_event_card(event, refresh_events)

            # Add event form
            create_add_event_form(refresh_events)

            # Initial load of events
            refresh_events()
