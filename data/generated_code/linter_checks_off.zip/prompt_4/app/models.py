from sqlmodel import SQLModel, Field
from datetime import datetime
from datetime import date as Date
from typing import Optional
from decimal import Decimal


# Persistent models (stored in database)
class MaintenanceEntry(SQLModel, table=True):
    """Record of completed maintenance service"""

    __tablename__ = "maintenance_entries"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    date: Date = Field(description="Date when the maintenance was performed")
    service_type: str = Field(
        max_length=200, description="Type of service performed (e.g., Oil Change, Brake Inspection)"
    )
    mileage: int = Field(description="Car mileage at the time of service")
    cost: Decimal = Field(decimal_places=2, description="Cost of the service")
    notes: str = Field(default="", max_length=1000, description="Additional notes about the service")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class ServiceReminder(SQLModel, table=True):
    """Upcoming service reminder"""

    __tablename__ = "service_reminders"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    estimated_date: Date = Field(description="Estimated date for the upcoming service")
    service_type: str = Field(max_length=200, description="Type of service needed")
    estimated_mileage: int = Field(description="Estimated mileage when service should be performed")
    notes: str = Field(default="", max_length=1000, description="Additional notes about the upcoming service")
    is_completed: bool = Field(default=False, description="Whether this reminder has been completed")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class MaintenanceEntryCreate(SQLModel, table=False):
    """Schema for creating a new maintenance entry"""

    date: Date
    service_type: str = Field(max_length=200)
    mileage: int = Field(gt=0, description="Mileage must be positive")
    cost: Decimal = Field(decimal_places=2, description="Cost must be non-negative")
    notes: str = Field(default="", max_length=1000)


class MaintenanceEntryUpdate(SQLModel, table=False):
    """Schema for updating an existing maintenance entry"""

    date: Optional[Date] = None
    service_type: Optional[str] = Field(default=None, max_length=200)
    mileage: Optional[int] = Field(default=None, gt=0)
    cost: Optional[Decimal] = Field(default=None, decimal_places=2)
    notes: Optional[str] = Field(default=None, max_length=1000)


class ServiceReminderCreate(SQLModel, table=False):
    """Schema for creating a new service reminder"""

    estimated_date: Date
    service_type: str = Field(max_length=200)
    estimated_mileage: int = Field(gt=0, description="Estimated mileage must be positive")
    notes: str = Field(default="", max_length=1000)


class ServiceReminderUpdate(SQLModel, table=False):
    """Schema for updating an existing service reminder"""

    estimated_date: Optional[Date] = None
    service_type: Optional[str] = Field(default=None, max_length=200)
    estimated_mileage: Optional[int] = Field(default=None, gt=0)
    notes: Optional[str] = Field(default=None, max_length=1000)
    is_completed: Optional[bool] = None
