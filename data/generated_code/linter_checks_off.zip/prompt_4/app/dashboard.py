from nicegui import ui
from datetime import date, datetime
from decimal import Decimal
from app.services import (
    create_maintenance_entry,
    get_all_maintenance_entries,
    delete_maintenance_entry,
    create_service_reminder,
    get_all_service_reminders,
    complete_service_reminder,
    delete_service_reminder,
)
from app.models import MaintenanceEntryCreate, ServiceReminderCreate


def apply_modern_theme():
    """Apply modern color theme for the dashboard"""
    ui.colors(
        primary="#2563eb",
        secondary="#64748b",
        accent="#10b981",
        positive="#10b981",
        negative="#ef4444",
        warning="#f59e0b",
        info="#3b82f6",
    )


def create_metric_card(title: str, value: str, icon: str = "📊"):
    """Create a modern metric card"""
    with ui.card().classes("p-6 bg-white shadow-lg rounded-xl hover:shadow-xl transition-shadow"):
        with ui.row().classes("items-center gap-4"):
            ui.label(icon).classes("text-2xl")
            with ui.column().classes("gap-1"):
                ui.label(title).classes("text-sm text-gray-500 uppercase tracking-wider")
                ui.label(value).classes("text-3xl font-bold text-gray-800")


def create_maintenance_form(refresh_callback):
    """Create form for adding new maintenance entries"""
    with ui.card().classes("p-6 shadow-lg rounded-lg"):
        ui.label("🔧 Record Maintenance Entry").classes("text-xl font-bold mb-6")

        # Form fields
        ui.label("📅 Service Date").classes("text-sm font-medium text-gray-700 mb-1")
        date_input = ui.date(value=date.today().isoformat()).classes("w-full mb-4")
        service_input = ui.input(label="🛠️ Service Type", placeholder="Oil Change, Brake Inspection, etc.").classes(
            "w-full mb-4"
        )
        mileage_input = ui.number(label="🛣️ Current Mileage", format="%.0f", min=0).classes("w-full mb-4")
        cost_input = ui.number(label="💵 Cost ($)", format="%.2f", min=0, step=0.01).classes("w-full mb-4")
        notes_input = (
            ui.textarea(label="📝 Notes (optional)", placeholder="Any additional details...")
            .classes("w-full mb-6")
            .props("rows=3")
        )

        async def submit_maintenance():
            # Validate inputs
            if not service_input.value or not service_input.value.strip():
                ui.notify("❌ Service type is required", type="negative")
                return

            if mileage_input.value is None or mileage_input.value < 0:
                ui.notify("❌ Valid mileage is required", type="negative")
                return

            if cost_input.value is None or cost_input.value < 0:
                ui.notify("❌ Valid cost is required", type="negative")
                return

            try:
                # Create maintenance entry
                entry_data = MaintenanceEntryCreate(
                    date=datetime.fromisoformat(date_input.value).date(),
                    service_type=service_input.value.strip(),
                    mileage=int(mileage_input.value),
                    cost=Decimal(str(cost_input.value)),
                    notes=notes_input.value or "",
                )

                create_maintenance_entry(entry_data)

                # Clear form
                date_input.set_value(date.today().isoformat())
                service_input.set_value("")
                mileage_input.set_value(None)
                cost_input.set_value(None)
                notes_input.set_value("")

                ui.notify("✅ Maintenance entry recorded successfully!", type="positive")
                refresh_callback()

            except Exception as e:
                ui.notify(f"❌ Error recording entry: {str(e)}", type="negative")

        ui.button("📝 Record Maintenance", on_click=submit_maintenance).classes(
            "bg-primary text-white px-6 py-2 rounded-lg"
        )


def create_reminder_form(refresh_callback):
    """Create form for adding service reminders"""
    with ui.card().classes("p-6 shadow-lg rounded-lg"):
        ui.label("⏰ Add Service Reminder").classes("text-xl font-bold mb-6")

        # Form fields
        ui.label("📅 Estimated Service Date").classes("text-sm font-medium text-gray-700 mb-1")
        date_input = ui.date(value=date.today().isoformat()).classes("w-full mb-4")
        service_input = ui.input(label="🛠️ Service Type", placeholder="Oil Change, Tire Rotation, etc.").classes(
            "w-full mb-4"
        )
        mileage_input = ui.number(label="🛣️ Estimated Mileage", format="%.0f", min=0).classes("w-full mb-4")
        notes_input = (
            ui.textarea(label="📝 Notes (optional)", placeholder="Any reminders or details...")
            .classes("w-full mb-6")
            .props("rows=3")
        )

        async def submit_reminder():
            # Validate inputs
            if not service_input.value or not service_input.value.strip():
                ui.notify("❌ Service type is required", type="negative")
                return

            if mileage_input.value is None or mileage_input.value < 0:
                ui.notify("❌ Valid estimated mileage is required", type="negative")
                return

            try:
                # Create service reminder
                reminder_data = ServiceReminderCreate(
                    estimated_date=datetime.fromisoformat(date_input.value).date(),
                    service_type=service_input.value.strip(),
                    estimated_mileage=int(mileage_input.value),
                    notes=notes_input.value or "",
                )

                create_service_reminder(reminder_data)

                # Clear form
                date_input.set_value(date.today().isoformat())
                service_input.set_value("")
                mileage_input.set_value(None)
                notes_input.set_value("")

                ui.notify("✅ Service reminder added successfully!", type="positive")
                refresh_callback()

            except Exception as e:
                ui.notify(f"❌ Error adding reminder: {str(e)}", type="negative")

        ui.button("⏰ Add Reminder", on_click=submit_reminder).classes("bg-accent text-white px-6 py-2 rounded-lg")


def create_maintenance_history(container):
    """Create maintenance history table"""
    container.clear()

    with container:
        ui.label("📋 Maintenance History").classes("text-xl font-bold mb-4")

        try:
            entries = get_all_maintenance_entries()

            if not entries:
                ui.label("📝 No maintenance entries recorded yet.").classes("text-gray-500 italic")
                return

            # Create table data
            columns = [
                {"name": "date", "label": "📅 Date", "field": "date", "align": "left"},
                {"name": "service_type", "label": "🛠️ Service Type", "field": "service_type", "align": "left"},
                {"name": "mileage", "label": "🛣️ Mileage", "field": "mileage", "align": "right"},
                {"name": "cost", "label": "💰 Cost", "field": "cost", "align": "right"},
                {"name": "notes", "label": "📝 Notes", "field": "notes", "align": "left"},
                {"name": "actions", "label": "⚙️ Actions", "field": "actions", "align": "center"},
            ]

            rows = []
            for entry in entries:
                rows.append(
                    {
                        "id": entry.id,
                        "date": entry.date.strftime("%Y-%m-%d"),
                        "service_type": entry.service_type,
                        "mileage": f"{entry.mileage:,}",
                        "cost": f"${entry.cost:.2f}",
                        "notes": entry.notes[:50] + ("..." if len(entry.notes) > 50 else ""),
                        "actions": entry.id,
                    }
                )

            async def handle_delete(e):
                entry_id = e.args
                if entry_id:
                    with ui.dialog() as dialog, ui.card():
                        ui.label("🗑️ Are you sure you want to delete this maintenance entry?")
                        with ui.row().classes("gap-2 justify-end mt-4"):
                            ui.button("❌ Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
                            ui.button("🗑️ Delete", on_click=lambda: dialog.submit("delete")).props("color=negative")

                    result = await dialog
                    if result == "delete":
                        if delete_maintenance_entry(entry_id):
                            ui.notify("🗑️ Maintenance entry deleted", type="warning")
                            create_maintenance_history(container)
                        else:
                            ui.notify("❌ Error deleting entry", type="negative")

            table = ui.table(columns=columns, rows=rows, row_key="id").classes("w-full")
            table.add_slot(
                "body-cell-actions",
                """
                <q-td key="actions" :props="props">
                    <q-btn flat dense round icon="delete" color="negative" 
                           @click="$parent.$emit('delete', props.value)" />
                </q-td>
            """,
            )
            table.on("delete", handle_delete)

        except Exception as e:
            ui.notify(f"❌ Error loading maintenance history: {str(e)}", type="negative")


def create_service_reminders(container):
    """Create service reminders table"""
    container.clear()

    with container:
        ui.label("⏰ Upcoming Service Reminders").classes("text-xl font-bold mb-4")

        try:
            reminders = get_all_service_reminders()

            if not reminders:
                ui.label("⏰ No upcoming service reminders.").classes("text-gray-500 italic")
                return

            # Create table data
            columns = [
                {"name": "estimated_date", "label": "📅 Estimated Date", "field": "estimated_date", "align": "left"},
                {"name": "service_type", "label": "🛠️ Service Type", "field": "service_type", "align": "left"},
                {
                    "name": "estimated_mileage",
                    "label": "🛣️ Est. Mileage",
                    "field": "estimated_mileage",
                    "align": "right",
                },
                {"name": "notes", "label": "📝 Notes", "field": "notes", "align": "left"},
                {"name": "status", "label": "🚦 Status", "field": "status", "align": "center"},
                {"name": "actions", "label": "⚙️ Actions", "field": "actions", "align": "center"},
            ]

            rows = []
            today = date.today()

            for reminder in reminders:
                days_until = (reminder.estimated_date - today).days
                if days_until < 0:
                    status = "🔴 Overdue"
                elif days_until <= 7:
                    status = "🟡 Due Soon"
                else:
                    status = "🟢 Upcoming"

                rows.append(
                    {
                        "id": reminder.id,
                        "estimated_date": reminder.estimated_date.strftime("%Y-%m-%d"),
                        "service_type": reminder.service_type,
                        "estimated_mileage": f"{reminder.estimated_mileage:,}",
                        "notes": reminder.notes[:50] + ("..." if len(reminder.notes) > 50 else ""),
                        "status": status,
                        "actions": reminder.id,
                    }
                )

            def handle_complete(e):
                reminder_id = e.args
                if reminder_id:
                    if complete_service_reminder(reminder_id):
                        ui.notify("✅ Service reminder marked as completed", type="positive")
                        create_service_reminders(container)
                    else:
                        ui.notify("❌ Error completing reminder", type="negative")

            async def handle_delete(e):
                reminder_id = e.args
                if reminder_id:
                    with ui.dialog() as dialog, ui.card():
                        ui.label("🗑️ Are you sure you want to delete this service reminder?")
                        with ui.row().classes("gap-2 justify-end mt-4"):
                            ui.button("❌ Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
                            ui.button("🗑️ Delete", on_click=lambda: dialog.submit("delete")).props("color=negative")

                    result = await dialog
                    if result == "delete":
                        if delete_service_reminder(reminder_id):
                            ui.notify("🗑️ Service reminder deleted", type="warning")
                            create_service_reminders(container)
                        else:
                            ui.notify("❌ Error deleting reminder", type="negative")

            table = ui.table(columns=columns, rows=rows, row_key="id").classes("w-full")
            table.add_slot(
                "body-cell-status",
                """
                <q-td key="status" :props="props">
                    <q-badge :color="props.value.includes('🔴') ? 'negative' : 
                                   props.value.includes('🟡') ? 'warning' : 'positive'">
                        {{ props.value }}
                    </q-badge>
                </q-td>
            """,
            )
            table.add_slot(
                "body-cell-actions",
                """
                <q-td key="actions" :props="props">
                    <q-btn flat dense round icon="check" color="positive" 
                           @click="$parent.$emit('complete', props.value)" title="Mark as completed" />
                    <q-btn flat dense round icon="delete" color="negative" 
                           @click="$parent.$emit('delete', props.value)" title="Delete reminder" />
                </q-td>
            """,
            )
            table.on("complete", handle_complete)
            table.on("delete", handle_delete)

        except Exception as e:
            ui.notify(f"❌ Error loading service reminders: {str(e)}", type="negative")


def create():
    """Create the car maintenance dashboard"""
    apply_modern_theme()

    @ui.page("/")
    async def dashboard():
        # Header
        with ui.row().classes("w-full items-center justify-between mb-8"):
            ui.label("🚗 Car Maintenance Dashboard").classes("text-3xl font-bold text-gray-800")
            ui.button("🔄 Refresh", on_click=lambda: refresh_data()).classes(
                "bg-secondary text-white px-4 py-2 rounded-lg"
            )

        # Metrics cards
        with ui.row().classes("gap-6 w-full mb-8"):
            total_entries = len(get_all_maintenance_entries())
            upcoming_reminders = len(get_all_service_reminders())

            create_metric_card("Total Maintenance", str(total_entries), "🔧")
            create_metric_card("Upcoming Services", str(upcoming_reminders), "⏰")

            # Calculate total cost
            entries = get_all_maintenance_entries()
            total_cost = sum(entry.cost for entry in entries)
            create_metric_card("Total Spent", f"${total_cost:.2f}", "💵")

        # Main content in tabs
        with ui.tabs().classes("w-full") as tabs:
            tab1 = ui.tab("🔧 Add Maintenance")
            tab2 = ui.tab("⏰ Add Reminder")
            tab3 = ui.tab("📋 History")
            tab4 = ui.tab("🔔 Reminders")

        with ui.tab_panels(tabs, value=tab1).classes("w-full"):
            # Add Maintenance tab
            with ui.tab_panel(tab1):

                def refresh_data():
                    create_maintenance_history(history_container)
                    create_service_reminders(reminders_container)
                    # Update metrics
                    ui.navigate.to("/", new_tab=False)

                create_maintenance_form(refresh_data)

            # Add Reminder tab
            with ui.tab_panel(tab2):

                def refresh_data():
                    create_maintenance_history(history_container)
                    create_service_reminders(reminders_container)
                    # Update metrics
                    ui.navigate.to("/", new_tab=False)

                create_reminder_form(refresh_data)

            # History tab
            with ui.tab_panel(tab3):
                history_container = ui.column().classes("w-full")
                create_maintenance_history(history_container)

            # Reminders tab
            with ui.tab_panel(tab4):
                reminders_container = ui.column().classes("w-full")
                create_service_reminders(reminders_container)

        def refresh_data():
            """Refresh all data on the page"""
            create_maintenance_history(history_container)
            create_service_reminders(reminders_container)
            ui.navigate.to("/", new_tab=False)
