from typing import List
from datetime import datetime
from sqlmodel import select, desc, asc
from app.database import get_session
from app.models import MaintenanceEntry, ServiceReminder, MaintenanceEntryCreate, ServiceReminderCreate


def create_maintenance_entry(entry_data: MaintenanceEntryCreate) -> MaintenanceEntry:
    """Create a new maintenance entry"""
    with get_session() as session:
        entry = MaintenanceEntry(
            date=entry_data.date,
            service_type=entry_data.service_type,
            mileage=entry_data.mileage,
            cost=entry_data.cost,
            notes=entry_data.notes,
            updated_at=datetime.utcnow(),
        )
        session.add(entry)
        session.commit()
        session.refresh(entry)
        return entry


def get_all_maintenance_entries() -> List[MaintenanceEntry]:
    """Get all maintenance entries ordered by date descending"""
    with get_session() as session:
        statement = select(MaintenanceEntry).order_by(desc(MaintenanceEntry.date))
        return list(session.exec(statement).all())


def delete_maintenance_entry(entry_id: int) -> bool:
    """Delete a maintenance entry by ID"""
    with get_session() as session:
        entry = session.get(MaintenanceEntry, entry_id)
        if entry is None:
            return False
        session.delete(entry)
        session.commit()
        return True


def create_service_reminder(reminder_data: ServiceReminderCreate) -> ServiceReminder:
    """Create a new service reminder"""
    with get_session() as session:
        reminder = ServiceReminder(
            estimated_date=reminder_data.estimated_date,
            service_type=reminder_data.service_type,
            estimated_mileage=reminder_data.estimated_mileage,
            notes=reminder_data.notes,
            updated_at=datetime.utcnow(),
        )
        session.add(reminder)
        session.commit()
        session.refresh(reminder)
        return reminder


def get_all_service_reminders() -> List[ServiceReminder]:
    """Get all service reminders ordered by estimated date"""
    with get_session() as session:
        statement = (
            select(ServiceReminder)
            .where(ServiceReminder.is_completed == False)
            .order_by(asc(ServiceReminder.estimated_date))
        )
        return list(session.exec(statement).all())


def complete_service_reminder(reminder_id: int) -> bool:
    """Mark a service reminder as completed"""
    with get_session() as session:
        reminder = session.get(ServiceReminder, reminder_id)
        if reminder is None:
            return False
        reminder.is_completed = True
        reminder.updated_at = datetime.utcnow()
        session.commit()
        return True


def delete_service_reminder(reminder_id: int) -> bool:
    """Delete a service reminder by ID"""
    with get_session() as session:
        reminder = session.get(ServiceReminder, reminder_id)
        if reminder is None:
            return False
        session.delete(reminder)
        session.commit()
        return True
