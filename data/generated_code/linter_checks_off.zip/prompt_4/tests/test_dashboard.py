"""
Dashboard smoke tests - minimal tests to verify basic functionality.
Due to NiceGUI's slot stack requirements, extensive UI testing is limited.
The main functionality is tested through the services layer.
"""

import pytest
from app.database import reset_db


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_dashboard_module_imports():
    """Test that dashboard module can be imported without errors"""
    try:
        import app.dashboard

        assert hasattr(app.dashboard, "create")
    except ImportError:
        pytest.fail("Dashboard module could not be imported")


def test_dashboard_services_integration(new_db):
    """Test that dashboard integrates with services correctly"""
    from app.services import get_all_maintenance_entries, get_all_service_reminders

    # These should work without UI components
    entries = get_all_maintenance_entries()
    reminders = get_all_service_reminders()

    assert isinstance(entries, list)
    assert isinstance(reminders, list)


def test_dashboard_theme_function():
    """Test that theme function exists and can be called"""
    from app.dashboard import apply_modern_theme

    # This should not raise an exception
    try:
        apply_modern_theme()
    except Exception as e:
        # In test environment, ui.colors might not be available, which is fine
        if "colors" not in str(e):
            pytest.fail(f"Unexpected error in apply_modern_theme: {e}")


class TestDashboardLogic:
    """Test dashboard helper functions and logic"""

    def test_metric_calculations(self, new_db):
        """Test that metric calculations work correctly"""
        from decimal import Decimal
        from datetime import date
        from app.services import create_maintenance_entry, get_all_maintenance_entries
        from app.models import MaintenanceEntryCreate

        # Create test data
        create_maintenance_entry(
            MaintenanceEntryCreate(date=date.today(), service_type="Oil Change", mileage=50000, cost=Decimal("45.99"))
        )
        create_maintenance_entry(
            MaintenanceEntryCreate(date=date.today(), service_type="Brake Check", mileage=50100, cost=Decimal("25.00"))
        )

        entries = get_all_maintenance_entries()
        total_cost = sum(entry.cost for entry in entries)

        assert len(entries) == 2
        assert total_cost == Decimal("70.99")

    def test_status_logic(self, new_db):
        """Test reminder status calculation logic"""
        from datetime import date, timedelta
        from app.services import create_service_reminder
        from app.models import ServiceReminderCreate

        today = date.today()

        # Create reminders with different dates
        overdue_reminder = create_service_reminder(
            ServiceReminderCreate(
                estimated_date=today - timedelta(days=1), service_type="Overdue Service", estimated_mileage=50000
            )
        )

        due_soon_reminder = create_service_reminder(
            ServiceReminderCreate(
                estimated_date=today + timedelta(days=3), service_type="Due Soon Service", estimated_mileage=51000
            )
        )

        future_reminder = create_service_reminder(
            ServiceReminderCreate(
                estimated_date=today + timedelta(days=30), service_type="Future Service", estimated_mileage=55000
            )
        )

        # Test status calculation logic
        def calculate_status(reminder_date: date) -> str:
            days_until = (reminder_date - today).days
            if days_until < 0:
                return "Overdue"
            elif days_until <= 7:
                return "Due Soon"
            else:
                return "Upcoming"

        assert calculate_status(overdue_reminder.estimated_date) == "Overdue"
        assert calculate_status(due_soon_reminder.estimated_date) == "Due Soon"
        assert calculate_status(future_reminder.estimated_date) == "Upcoming"
