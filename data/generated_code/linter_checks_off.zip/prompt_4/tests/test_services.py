import pytest
from datetime import date, timedelta
from decimal import Decimal
from app.database import reset_db
from app.services import (
    create_maintenance_entry,
    get_all_maintenance_entries,
    delete_maintenance_entry,
    create_service_reminder,
    get_all_service_reminders,
    complete_service_reminder,
    delete_service_reminder,
)
from app.models import MaintenanceEntryCreate, ServiceReminderCreate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


class TestMaintenanceEntryServices:
    """Test maintenance entry CRUD operations"""

    def test_create_maintenance_entry(self, new_db):
        """Test creating a new maintenance entry"""
        entry_data = MaintenanceEntryCreate(
            date=date.today(),
            service_type="Oil Change",
            mileage=50000,
            cost=Decimal("45.99"),
            notes="Full synthetic oil",
        )

        entry = create_maintenance_entry(entry_data)

        assert entry.id is not None
        assert entry.date == date.today()
        assert entry.service_type == "Oil Change"
        assert entry.mileage == 50000
        assert entry.cost == Decimal("45.99")
        assert entry.notes == "Full synthetic oil"
        assert entry.created_at is not None
        assert entry.updated_at is not None

    def test_create_maintenance_entry_minimal(self, new_db):
        """Test creating maintenance entry with minimal data"""
        entry_data = MaintenanceEntryCreate(
            date=date.today(), service_type="Brake Inspection", mileage=75000, cost=Decimal("0.00")
        )

        entry = create_maintenance_entry(entry_data)

        assert entry.id is not None
        assert entry.service_type == "Brake Inspection"
        assert entry.notes == ""

    def test_get_all_maintenance_entries_empty(self, new_db):
        """Test getting entries when database is empty"""
        entries = get_all_maintenance_entries()
        assert entries == []

    def test_get_all_maintenance_entries_ordered(self, new_db):
        """Test that entries are returned in date descending order"""
        # Create entries with different dates
        yesterday = date.today() - timedelta(days=1)
        today = date.today()
        tomorrow = date.today() + timedelta(days=1)

        entry1 = create_maintenance_entry(
            MaintenanceEntryCreate(date=yesterday, service_type="Service 1", mileage=1000, cost=Decimal("10.00"))
        )
        entry2 = create_maintenance_entry(
            MaintenanceEntryCreate(date=tomorrow, service_type="Service 2", mileage=2000, cost=Decimal("20.00"))
        )
        entry3 = create_maintenance_entry(
            MaintenanceEntryCreate(date=today, service_type="Service 3", mileage=1500, cost=Decimal("15.00"))
        )

        entries = get_all_maintenance_entries()

        assert len(entries) == 3
        # Should be ordered by date descending (tomorrow, today, yesterday)
        assert entries[0].id == entry2.id
        assert entries[1].id == entry3.id
        assert entries[2].id == entry1.id

    def test_delete_maintenance_entry_success(self, new_db):
        """Test successfully deleting a maintenance entry"""
        entry = create_maintenance_entry(
            MaintenanceEntryCreate(date=date.today(), service_type="Test Service", mileage=1000, cost=Decimal("10.00"))
        )

        assert entry.id is not None
        result = delete_maintenance_entry(entry.id)
        assert result is True

        entries = get_all_maintenance_entries()
        assert len(entries) == 0

    def test_delete_maintenance_entry_not_found(self, new_db):
        """Test deleting non-existent maintenance entry"""
        result = delete_maintenance_entry(999)
        assert result is False

    def test_decimal_precision(self, new_db):
        """Test that decimal precision is maintained"""
        entry = create_maintenance_entry(
            MaintenanceEntryCreate(
                date=date.today(), service_type="Precision Test", mileage=1000, cost=Decimal("123.45")
            )
        )

        retrieved_entries = get_all_maintenance_entries()
        assert len(retrieved_entries) == 1
        assert retrieved_entries[0].cost == Decimal("123.45")


class TestServiceReminderServices:
    """Test service reminder CRUD operations"""

    def test_create_service_reminder(self, new_db):
        """Test creating a new service reminder"""
        reminder_data = ServiceReminderCreate(
            estimated_date=date.today() + timedelta(days=30),
            service_type="Oil Change",
            estimated_mileage=55000,
            notes="Check air filter too",
        )

        reminder = create_service_reminder(reminder_data)

        assert reminder.id is not None
        assert reminder.estimated_date == date.today() + timedelta(days=30)
        assert reminder.service_type == "Oil Change"
        assert reminder.estimated_mileage == 55000
        assert reminder.notes == "Check air filter too"
        assert reminder.is_completed is False
        assert reminder.created_at is not None
        assert reminder.updated_at is not None

    def test_create_service_reminder_minimal(self, new_db):
        """Test creating service reminder with minimal data"""
        reminder_data = ServiceReminderCreate(
            estimated_date=date.today() + timedelta(days=7), service_type="Tire Rotation", estimated_mileage=60000
        )

        reminder = create_service_reminder(reminder_data)

        assert reminder.id is not None
        assert reminder.service_type == "Tire Rotation"
        assert reminder.notes == ""
        assert reminder.is_completed is False

    def test_get_all_service_reminders_empty(self, new_db):
        """Test getting reminders when database is empty"""
        reminders = get_all_service_reminders()
        assert reminders == []

    def test_get_all_service_reminders_ordered(self, new_db):
        """Test that reminders are returned in estimated date ascending order"""
        today = date.today()
        next_week = today + timedelta(days=7)
        next_month = today + timedelta(days=30)

        reminder1 = create_service_reminder(
            ServiceReminderCreate(estimated_date=next_month, service_type="Service 1", estimated_mileage=3000)
        )
        reminder2 = create_service_reminder(
            ServiceReminderCreate(estimated_date=today, service_type="Service 2", estimated_mileage=1000)
        )
        reminder3 = create_service_reminder(
            ServiceReminderCreate(estimated_date=next_week, service_type="Service 3", estimated_mileage=2000)
        )

        reminders = get_all_service_reminders()

        assert len(reminders) == 3
        # Should be ordered by estimated_date ascending (today, next_week, next_month)
        assert reminders[0].id == reminder2.id
        assert reminders[1].id == reminder3.id
        assert reminders[2].id == reminder1.id

    def test_get_all_service_reminders_excludes_completed(self, new_db):
        """Test that completed reminders are excluded from results"""
        reminder1 = create_service_reminder(
            ServiceReminderCreate(estimated_date=date.today(), service_type="Active Service", estimated_mileage=1000)
        )
        reminder2 = create_service_reminder(
            ServiceReminderCreate(estimated_date=date.today(), service_type="Completed Service", estimated_mileage=2000)
        )

        # Complete one reminder
        assert reminder2.id is not None
        complete_service_reminder(reminder2.id)

        reminders = get_all_service_reminders()

        assert len(reminders) == 1
        assert reminders[0].id == reminder1.id
        assert reminders[0].is_completed is False

    def test_complete_service_reminder_success(self, new_db):
        """Test successfully completing a service reminder"""
        reminder = create_service_reminder(
            ServiceReminderCreate(estimated_date=date.today(), service_type="Test Service", estimated_mileage=1000)
        )

        assert reminder.id is not None
        result = complete_service_reminder(reminder.id)
        assert result is True

        # Should no longer appear in active reminders
        reminders = get_all_service_reminders()
        assert len(reminders) == 0

    def test_complete_service_reminder_not_found(self, new_db):
        """Test completing non-existent service reminder"""
        result = complete_service_reminder(999)
        assert result is False

    def test_delete_service_reminder_success(self, new_db):
        """Test successfully deleting a service reminder"""
        reminder = create_service_reminder(
            ServiceReminderCreate(estimated_date=date.today(), service_type="Test Service", estimated_mileage=1000)
        )

        assert reminder.id is not None
        result = delete_service_reminder(reminder.id)
        assert result is True

        reminders = get_all_service_reminders()
        assert len(reminders) == 0

    def test_delete_service_reminder_not_found(self, new_db):
        """Test deleting non-existent service reminder"""
        result = delete_service_reminder(999)
        assert result is False


class TestIntegrationScenarios:
    """Test realistic usage scenarios"""

    def test_typical_maintenance_workflow(self, new_db):
        """Test a typical maintenance workflow"""
        # Create a service reminder
        reminder = create_service_reminder(
            ServiceReminderCreate(
                estimated_date=date.today(),
                service_type="Oil Change",
                estimated_mileage=50000,
                notes="5,000 miles overdue",
            )
        )

        # Verify reminder exists
        reminders = get_all_service_reminders()
        assert len(reminders) == 1

        # Complete the service and record maintenance entry
        entry = create_maintenance_entry(
            MaintenanceEntryCreate(
                date=date.today(),
                service_type="Oil Change",
                mileage=50100,
                cost=Decimal("45.99"),
                notes="Full synthetic oil - Mobil 1",
            )
        )

        # Mark reminder as completed
        assert reminder.id is not None
        complete_service_reminder(reminder.id)

        # Verify maintenance entry exists and reminder is gone from active list
        entries = get_all_maintenance_entries()
        reminders = get_all_service_reminders()

        assert len(entries) == 1
        assert len(reminders) == 0
        assert entries[0].service_type == "Oil Change"
        assert entries[0].cost == Decimal("45.99")

    def test_multiple_vehicles_simulation(self, new_db):
        """Test handling multiple vehicles' maintenance records"""
        # Create maintenance entries for different service types
        services = [
            ("Oil Change", 50000, Decimal("45.99")),
            ("Brake Inspection", 52000, Decimal("0.00")),
            ("Tire Rotation", 53000, Decimal("25.00")),
            ("Oil Change", 55000, Decimal("49.99")),
        ]

        for service_type, mileage, cost in services:
            create_maintenance_entry(
                MaintenanceEntryCreate(
                    date=date.today() - timedelta(days=30), service_type=service_type, mileage=mileage, cost=cost
                )
            )

        # Create future reminders
        future_services = [
            ("Oil Change", 60000, 30),
            ("Brake Pad Replacement", 65000, 90),
            ("Coolant Flush", 70000, 180),
        ]

        for service_type, mileage, days_ahead in future_services:
            create_service_reminder(
                ServiceReminderCreate(
                    estimated_date=date.today() + timedelta(days=days_ahead),
                    service_type=service_type,
                    estimated_mileage=mileage,
                )
            )

        entries = get_all_maintenance_entries()
        reminders = get_all_service_reminders()

        assert len(entries) == 4
        assert len(reminders) == 3

        # Calculate total cost
        total_cost = sum(entry.cost for entry in entries)
        assert total_cost == Decimal("120.98")

        # Verify reminders are ordered by date
        assert reminders[0].service_type == "Oil Change"  # 30 days ahead
        assert reminders[1].service_type == "Brake Pad Replacement"  # 90 days ahead
        assert reminders[2].service_type == "Coolant Flush"  # 180 days ahead
