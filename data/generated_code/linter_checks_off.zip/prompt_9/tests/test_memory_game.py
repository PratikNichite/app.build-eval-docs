import pytest
from nicegui.testing import User
from app.database import reset_db
from app.game_service import GameService
from app.models import GameStatus


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


async def test_memory_game_page_loads(user: User, new_db) -> None:
    """Test that the memory game page loads correctly."""
    await user.open("/memory-game")

    # Check main elements are present
    await user.should_see("Memory Card Game")
    await user.should_see("New Game")
    await user.should_see("Instructions")


async def test_index_page_navigation(user: User, new_db) -> None:
    """Test that the index page has proper navigation to the game."""
    await user.open("/")

    await user.should_see("Memory Card Game")
    await user.should_see("Test your memory by finding matching pairs of cards!")
    await user.should_see("Start Playing")


async def test_new_game_creates_game(user: User, new_db) -> None:
    """Test that the New Game button creates a game."""
    await user.open("/memory-game")

    # Click new game button
    user.find("New Game").click()

    # Should see some game elements
    await user.should_see("Memory Card Game")


async def test_instructions_dialog_opens(user: User, new_db) -> None:
    """Test that the instructions dialog can be opened."""
    await user.open("/memory-game")

    # Click instructions button
    user.find("Instructions").click()

    # Should see instructions dialog
    await user.should_see("How to Play")


async def test_game_service_integration(user: User, new_db) -> None:
    """Test integration between UI and game service."""
    await user.open("/memory-game")

    # Create a game through the service (simulating UI action)
    game = GameService.create_new_game(grid_size=2)

    # Verify game was created correctly
    assert game.id is not None
    assert game.grid_size == 2
    assert game.total_pairs == 2

    # Test game state retrieval
    game_state = GameService.get_game_state(game.id)
    assert game_state is not None
    assert len(game_state.cards) == 4


async def test_card_matching_service_logic(user: User, new_db) -> None:
    """Test card matching logic through service layer."""
    await user.open("/memory-game")

    # Create a small game for testing
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None

    # Find matching pair
    cards_by_pair = {}
    for card in game_with_cards.cards:
        if card.pair_id not in cards_by_pair:
            cards_by_pair[card.pair_id] = []
        cards_by_pair[card.pair_id].append(card)

    # Get first pair
    pair_cards = list(cards_by_pair.values())[0]
    card1, card2 = pair_cards[0], pair_cards[1]
    assert card1.id is not None and card2.id is not None

    # Test card flipping and matching
    success1, _ = GameService.flip_card(card1.id)
    success2, _ = GameService.flip_card(card2.id)
    assert success1 and success2

    is_match, game_won = GameService.check_match(card1.id, card2.id)
    assert is_match
    assert not game_won  # Only matched 1 of 2 pairs


async def test_game_completion_logic(user: User, new_db) -> None:
    """Test complete game win scenario."""
    await user.open("/memory-game")

    # Create and complete a small game
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None

    # Group cards by pair
    cards_by_pair = {}
    for card in game_with_cards.cards:
        if card.pair_id not in cards_by_pair:
            cards_by_pair[card.pair_id] = []
        cards_by_pair[card.pair_id].append(card)

    # Match all pairs
    for pair_cards in cards_by_pair.values():
        assert pair_cards[0].id is not None and pair_cards[1].id is not None
        GameService.flip_card(pair_cards[0].id)
        GameService.flip_card(pair_cards[1].id)
        is_match, game_won = GameService.check_match(pair_cards[0].id, pair_cards[1].id)
        assert is_match

    # Verify game is won
    final_game = GameService.get_game(game.id)
    assert final_game is not None
    assert final_game.status == GameStatus.WON


async def test_game_state_retrieval(user: User, new_db) -> None:
    """Test that game state can be retrieved correctly."""
    await user.open("/memory-game")

    # Create game
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None

    # Test game state
    game_state = GameService.get_game_state(game.id)
    assert game_state is not None
    assert game_state.game_id == game.id
    assert game_state.grid_size == 2
    assert game_state.attempts == 0
    assert game_state.matched_pairs == 0
    assert game_state.total_pairs == 2
    assert game_state.status == GameStatus.IN_PROGRESS
    assert len(game_state.cards) == 4
    assert game_state.elapsed_time is not None


async def test_multiple_games_creation(user: User, new_db) -> None:
    """Test creating multiple games in sequence."""
    await user.open("/memory-game")

    # Create first game
    game1 = GameService.create_new_game(grid_size=2)
    assert game1.id is not None

    # Create second game
    game2 = GameService.create_new_game(grid_size=2)
    assert game2.id is not None

    # Games should have different IDs
    assert game1.id != game2.id


async def test_page_elements_structure(user: User, new_db) -> None:
    """Test that essential page elements are present."""
    await user.open("/memory-game")

    # Check for essential buttons
    await user.should_see("New Game")
    await user.should_see("Instructions")

    # Check for game title
    await user.should_see("Memory Card Game")


async def test_index_page_features(user: User, new_db) -> None:
    """Test that index page shows game features."""
    await user.open("/")

    # Check game features are listed
    await user.should_see("6x6 grid with 18 pairs to match")
    await user.should_see("Shuffled cards every game")
    await user.should_see("Track attempts and time")


async def test_basic_navigation(user: User, new_db) -> None:
    """Test basic navigation functionality."""
    await user.open("/")

    # Test navigation to game page
    user.find("Start Playing").click()

    # Should be on game page now
    await user.should_see("New Game")


async def test_game_service_error_handling(user: User, new_db) -> None:
    """Test that game service handles errors appropriately."""
    await user.open("/memory-game")

    # Test with non-existent game
    game_state = GameService.get_game_state(999)
    assert game_state is None

    # Test with non-existent card
    success, card = GameService.flip_card(999)
    assert not success
    assert card is None


async def test_card_icon_variety(user: User, new_db) -> None:
    """Test that games use different icons from the available set."""
    await user.open("/memory-game")

    # Create a game and check that icons are from the available set
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None

    # Check that all card icons are from the available set
    for card in game_with_cards.cards:
        assert card.icon in GameService.CARD_ICONS


async def test_time_formatting_utility(user: User, new_db) -> None:
    """Test the time formatting utility function."""
    from app.memory_game import MemoryCardGame

    # Test time formatting
    assert MemoryCardGame.format_time(0) == "00:00"
    assert MemoryCardGame.format_time(65) == "01:05"
    assert MemoryCardGame.format_time(125) == "02:05"


async def test_game_attempt_tracking(user: User, new_db) -> None:
    """Test that game attempts are tracked correctly."""
    await user.open("/memory-game")

    # Create game and test attempt tracking
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None

    # Initially should have 0 attempts
    game_state = GameService.get_game_state(game.id)
    assert game_state is not None
    assert game_state.attempts == 0

    # Increment attempts
    success = GameService.increment_attempts(game.id)
    assert success

    # Check attempts increased
    game_state = GameService.get_game_state(game.id)
    assert game_state is not None
    assert game_state.attempts == 1
