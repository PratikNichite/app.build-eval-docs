import pytest
from app.database import reset_db
from app.game_service import GameService
from app.models import GameStatus, CardStatus


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_create_new_game(new_db):
    """Test creating a new memory card game."""
    game = GameService.create_new_game(grid_size=4)

    assert game.id is not None
    assert game.grid_size == 4
    assert game.total_pairs == 8  # 16 cards / 2 = 8 pairs
    assert game.attempts == 0
    assert game.matched_pairs == 0
    assert game.status == GameStatus.IN_PROGRESS
    assert game.start_time is not None
    assert game.end_time is None


def test_create_new_game_default_size(new_db):
    """Test creating a new game with default 6x6 grid."""
    game = GameService.create_new_game()

    assert game.grid_size == 6
    assert game.total_pairs == 18  # 36 cards / 2 = 18 pairs


def test_create_new_game_with_cards(new_db):
    """Test that new game creates proper cards."""
    game = GameService.create_new_game(grid_size=2)  # 2x2 = 4 cards, 2 pairs

    # Get the game with cards
    assert game.id is not None
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None
    assert len(game_with_cards.cards) == 4

    # Check card properties
    for card in game_with_cards.cards:
        assert card.game_id == game.id
        assert card.status == CardStatus.FACE_DOWN
        assert 0 <= card.position <= 3
        assert 0 <= card.row <= 1
        assert 0 <= card.col <= 1
        assert card.icon in GameService.CARD_ICONS
        assert card.pair_id >= 0

    # Check that we have exactly 2 pairs
    pair_counts = {}
    for card in game_with_cards.cards:
        pair_counts[card.pair_id] = pair_counts.get(card.pair_id, 0) + 1

    assert len(pair_counts) == 2  # 2 different pairs
    assert all(count == 2 for count in pair_counts.values())  # Each pair has 2 cards


def test_create_game_too_large(new_db):
    """Test creating a game that's too large for available icons."""
    with pytest.raises(ValueError, match="Not enough icons"):
        GameService.create_new_game(grid_size=10)  # 100 cards = 50 pairs, but we only have 24 icons


def test_get_game(new_db):
    """Test retrieving a game by ID."""
    game = GameService.create_new_game(grid_size=2)

    assert game.id is not None
    retrieved_game = GameService.get_game(game.id)
    assert retrieved_game is not None
    assert retrieved_game.id == game.id
    assert retrieved_game.grid_size == 2
    assert len(retrieved_game.cards) == 4


def test_get_nonexistent_game(new_db):
    """Test retrieving a non-existent game."""
    game = GameService.get_game(999)
    assert game is None


def test_flip_card(new_db):
    """Test flipping a card face up."""
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None
    card = game_with_cards.cards[0]
    assert card.id is not None

    success, flipped_card = GameService.flip_card(card.id)

    assert success
    assert flipped_card is not None
    assert flipped_card.status == CardStatus.FACE_UP
    assert flipped_card.revealed_at is not None


def test_flip_card_already_face_up(new_db):
    """Test flipping a card that's already face up."""
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None
    card = game_with_cards.cards[0]
    assert card.id is not None

    # Flip card first time
    GameService.flip_card(card.id)

    # Try to flip again
    success, flipped_card = GameService.flip_card(card.id)

    assert not success
    assert flipped_card is not None
    assert flipped_card.status == CardStatus.FACE_UP


def test_flip_nonexistent_card(new_db):
    """Test flipping a non-existent card."""
    success, card = GameService.flip_card(999)

    assert not success
    assert card is None


def test_flip_card_down(new_db):
    """Test flipping a card face down."""
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None
    card = game_with_cards.cards[0]
    assert card.id is not None

    # Flip up then down
    GameService.flip_card(card.id)
    success = GameService.flip_card_down(card.id)

    assert success

    # Verify card is face down
    updated_card = GameService.get_card(card.id)
    assert updated_card is not None
    assert updated_card.status == CardStatus.FACE_DOWN
    assert updated_card.revealed_at is None


def test_check_match_success(new_db):
    """Test checking a successful match."""
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None

    # Find two cards with the same pair_id
    cards_by_pair = {}
    for card in game_with_cards.cards:
        if card.pair_id not in cards_by_pair:
            cards_by_pair[card.pair_id] = []
        cards_by_pair[card.pair_id].append(card)

    # Get the first pair
    pair_cards = list(cards_by_pair.values())[0]
    card1, card2 = pair_cards[0], pair_cards[1]
    assert card1.id is not None and card2.id is not None

    # Flip both cards
    GameService.flip_card(card1.id)
    GameService.flip_card(card2.id)

    # Check match
    is_match, game_won = GameService.check_match(card1.id, card2.id)

    assert is_match
    assert not game_won  # Game should not be won yet (only 1 of 2 pairs matched)

    # Verify cards are marked as matched
    updated_card1 = GameService.get_card(card1.id)
    updated_card2 = GameService.get_card(card2.id)
    assert updated_card1 is not None and updated_card2 is not None
    assert updated_card1.status == CardStatus.MATCHED
    assert updated_card2.status == CardStatus.MATCHED
    assert updated_card1.matched_at is not None
    assert updated_card2.matched_at is not None


def test_check_match_failure(new_db):
    """Test checking a failed match."""
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None

    # Find two cards with different pair_ids
    cards_by_pair = {}
    for card in game_with_cards.cards:
        if card.pair_id not in cards_by_pair:
            cards_by_pair[card.pair_id] = []
        cards_by_pair[card.pair_id].append(card)

    # Get cards from different pairs
    pair_list = list(cards_by_pair.values())
    card1 = pair_list[0][0]
    card2 = pair_list[1][0]
    assert card1.id is not None and card2.id is not None

    # Flip both cards
    GameService.flip_card(card1.id)
    GameService.flip_card(card2.id)

    # Check match
    is_match, game_won = GameService.check_match(card1.id, card2.id)

    assert not is_match
    assert not game_won


def test_check_match_same_card(new_db):
    """Test checking match with the same card twice."""
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None
    card = game_with_cards.cards[0]
    assert card.id is not None

    # Flip card
    GameService.flip_card(card.id)

    # Try to match card with itself
    is_match, game_won = GameService.check_match(card.id, card.id)

    assert not is_match
    assert not game_won


def test_complete_game_win(new_db):
    """Test completing a full game and winning."""
    game = GameService.create_new_game(grid_size=2)  # 2x2 = 2 pairs
    assert game.id is not None
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None

    # Group cards by pair
    cards_by_pair = {}
    for card in game_with_cards.cards:
        if card.pair_id not in cards_by_pair:
            cards_by_pair[card.pair_id] = []
        cards_by_pair[card.pair_id].append(card)

    # Match first pair
    pair1_cards = list(cards_by_pair.values())[0]
    assert pair1_cards[0].id is not None and pair1_cards[1].id is not None
    GameService.flip_card(pair1_cards[0].id)
    GameService.flip_card(pair1_cards[1].id)
    is_match1, game_won1 = GameService.check_match(pair1_cards[0].id, pair1_cards[1].id)

    assert is_match1
    assert not game_won1

    # Match second pair (should win the game)
    pair2_cards = list(cards_by_pair.values())[1]
    assert pair2_cards[0].id is not None and pair2_cards[1].id is not None
    GameService.flip_card(pair2_cards[0].id)
    GameService.flip_card(pair2_cards[1].id)
    is_match2, game_won2 = GameService.check_match(pair2_cards[0].id, pair2_cards[1].id)

    assert is_match2
    assert game_won2

    # Verify game is marked as won
    final_game = GameService.get_game(game.id)
    assert final_game is not None
    assert final_game.status == GameStatus.WON
    assert final_game.matched_pairs == 2
    assert final_game.end_time is not None


def test_increment_attempts(new_db):
    """Test incrementing game attempts."""
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None

    success = GameService.increment_attempts(game.id)
    assert success

    updated_game = GameService.get_game(game.id)
    assert updated_game is not None
    assert updated_game.attempts == 1

    # Increment again
    GameService.increment_attempts(game.id)
    updated_game = GameService.get_game(game.id)
    assert updated_game is not None
    assert updated_game.attempts == 2


def test_increment_attempts_nonexistent_game(new_db):
    """Test incrementing attempts for non-existent game."""
    success = GameService.increment_attempts(999)
    assert not success


def test_get_face_up_cards(new_db):
    """Test getting face-up cards."""
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None

    # Initially no cards should be face up
    face_up_cards = GameService.get_face_up_cards(game.id)
    assert len(face_up_cards) == 0

    # Flip one card
    card1 = game_with_cards.cards[0]
    assert card1.id is not None
    GameService.flip_card(card1.id)

    face_up_cards = GameService.get_face_up_cards(game.id)
    assert len(face_up_cards) == 1
    assert face_up_cards[0].id == card1.id

    # Flip another card
    card2 = game_with_cards.cards[1]
    assert card2.id is not None
    GameService.flip_card(card2.id)

    face_up_cards = GameService.get_face_up_cards(game.id)
    assert len(face_up_cards) == 2


def test_get_game_state(new_db):
    """Test getting comprehensive game state."""
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None

    # Add some attempts
    GameService.increment_attempts(game.id)
    GameService.increment_attempts(game.id)

    game_state = GameService.get_game_state(game.id)

    assert game_state is not None
    assert game_state.game_id == game.id
    assert game_state.grid_size == 2
    assert game_state.attempts == 2
    assert game_state.matched_pairs == 0
    assert game_state.total_pairs == 2
    assert game_state.status == GameStatus.IN_PROGRESS
    assert len(game_state.cards) == 4
    assert game_state.elapsed_time is not None
    assert game_state.elapsed_time >= 0

    # Check card data structure
    card_data = game_state.cards[0]
    assert "id" in card_data
    assert "position" in card_data
    assert "row" in card_data
    assert "col" in card_data
    assert "icon" in card_data
    assert "status" in card_data
    assert "pair_id" in card_data

    # Face-down cards should show question mark
    assert card_data["icon"] == "❓"


def test_get_game_state_with_revealed_cards(new_db):
    """Test game state with some cards revealed."""
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None

    # Flip one card
    card = game_with_cards.cards[0]
    assert card.id is not None
    GameService.flip_card(card.id)

    game_state = GameService.get_game_state(game.id)
    assert game_state is not None

    # Find the flipped card in the state
    flipped_card_data = next((c for c in game_state.cards if c["id"] == card.id), None)

    assert flipped_card_data is not None
    assert flipped_card_data["icon"] != "❓"  # Should show actual icon
    assert flipped_card_data["icon"] in GameService.CARD_ICONS


def test_get_game_state_nonexistent(new_db):
    """Test getting state for non-existent game."""
    game_state = GameService.get_game_state(999)
    assert game_state is None


def test_card_shuffling(new_db):
    """Test that cards are properly shuffled in new games."""
    # Create multiple games and check that card positions vary
    games = []
    for _ in range(5):
        game = GameService.create_new_game(grid_size=2)
        assert game.id is not None
        game_with_cards = GameService.get_game(game.id)
        assert game_with_cards is not None
        games.append(game_with_cards)

    # Check that not all games have identical card arrangements
    first_game_arrangement = [(card.position, card.pair_id) for card in games[0].cards]

    different_arrangements = 0
    for game in games[1:]:
        game_arrangement = [(card.position, card.pair_id) for card in game.cards]
        if game_arrangement != first_game_arrangement:
            different_arrangements += 1

    # At least some games should have different arrangements
    # (With truly random shuffling, the probability of all games being identical is very low)
    assert different_arrangements > 0


def test_card_positions_valid(new_db):
    """Test that all card positions are valid and unique."""
    game = GameService.create_new_game(grid_size=4)  # 4x4 grid = 16 cards, 8 pairs
    assert game.id is not None
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None

    positions = [card.position for card in game_with_cards.cards]
    rows = [card.row for card in game_with_cards.cards]
    cols = [card.col for card in game_with_cards.cards]

    # Check positions are in valid range and unique
    assert all(0 <= pos <= 15 for pos in positions)
    assert len(set(positions)) == 16  # All positions should be unique

    # Check rows and columns are valid
    assert all(0 <= row <= 3 for row in rows)
    assert all(0 <= col <= 3 for col in cols)

    # Check position calculation matches row/col
    for card in game_with_cards.cards:
        expected_position = card.row * 4 + card.col
        assert card.position == expected_position


def test_game_time_tracking(new_db):
    """Test that game time is properly tracked."""
    # Create a game and immediately check state
    game = GameService.create_new_game(grid_size=2)
    assert game.id is not None

    game_state = GameService.get_game_state(game.id)
    assert game_state is not None
    assert game_state.elapsed_time is not None
    assert game_state.elapsed_time >= 0
    assert game_state.elapsed_time < 5  # Should be very quick

    # For a won game, end time should be set
    game_with_cards = GameService.get_game(game.id)
    assert game_with_cards is not None
    cards_by_pair = {}
    for card in game_with_cards.cards:
        if card.pair_id not in cards_by_pair:
            cards_by_pair[card.pair_id] = []
        cards_by_pair[card.pair_id].append(card)

    # Match all pairs to win
    for pair_cards in cards_by_pair.values():
        assert pair_cards[0].id is not None and pair_cards[1].id is not None
        GameService.flip_card(pair_cards[0].id)
        GameService.flip_card(pair_cards[1].id)
        GameService.check_match(pair_cards[0].id, pair_cards[1].id)

    # Check final state
    final_state = GameService.get_game_state(game.id)
    assert final_state is not None
    assert final_state.status == GameStatus.WON
    assert final_state.elapsed_time is not None
    assert final_state.elapsed_time >= 0
