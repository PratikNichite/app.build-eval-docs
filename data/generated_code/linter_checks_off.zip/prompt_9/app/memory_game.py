from nicegui import ui
from typing import Optional, List
import asyncio

from app.game_service import GameService
from app.models import CardStatus


class MemoryCardGame:
    """Memory Card Matching Game UI Component."""

    def __init__(self):
        self.current_game_id: Optional[int] = None
        self.selected_cards: List[int] = []
        self.is_checking_match = False
        self.grid_container: Optional[ui.element] = None
        self.stats_container: Optional[ui.element] = None
        self.card_elements: dict = {}

    def create_game_page(self):
        """Create the main game page."""
        with ui.column().classes("w-full max-w-4xl mx-auto p-6 bg-gray-50 min-h-screen"):
            # Header
            with ui.row().classes("w-full justify-between items-center mb-6"):
                ui.label("🧠 Memory Card Game").classes("text-3xl font-bold text-gray-800")

                with ui.row().classes("gap-2"):
                    ui.button("New Game", on_click=self.start_new_game).classes(
                        "bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold"
                    )
                    ui.button("Instructions", on_click=self.show_instructions).classes(
                        "bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg font-semibold"
                    )

            # Game stats
            self.stats_container = ui.row().classes("w-full gap-4 mb-6")

            # Game grid
            self.grid_container = ui.column().classes("w-full")

            # Start initial game
            self.start_new_game()

    def start_new_game(self):
        """Start a new memory card game."""
        try:
            # Create new game
            game = GameService.create_new_game(grid_size=6)
            self.current_game_id = game.id
            self.selected_cards = []
            self.is_checking_match = False
            self.card_elements = {}

            # Update UI
            self.update_stats()
            self.create_game_grid()

            ui.notify("New game started! 🎉 Find all matching pairs.", type="positive")

        except Exception as e:
            ui.notify(f"Error starting new game: {str(e)}", type="negative")

    def update_stats(self):
        """Update the game statistics display."""
        if self.current_game_id is None or self.stats_container is None:
            return

        self.stats_container.clear()

        game_state = GameService.get_game_state(self.current_game_id)
        if game_state is None:
            return

        if self.stats_container is not None:
            with self.stats_container:
                # Attempts
                with ui.card().classes("p-4 bg-white shadow-md rounded-lg"):
                    ui.label("Attempts").classes("text-sm text-gray-500 uppercase tracking-wider")
                    ui.label(str(game_state.attempts)).classes("text-2xl font-bold text-blue-600")

                # Matched Pairs
                with ui.card().classes("p-4 bg-white shadow-md rounded-lg"):
                    ui.label("Matched Pairs").classes("text-sm text-gray-500 uppercase tracking-wider")
                    ui.label(f"{game_state.matched_pairs}/{game_state.total_pairs}").classes(
                        "text-2xl font-bold text-green-600"
                    )

                # Elapsed Time
                with ui.card().classes("p-4 bg-white shadow-md rounded-lg"):
                    ui.label("Time").classes("text-sm text-gray-500 uppercase tracking-wider")
                    time_str = self.format_time(game_state.elapsed_time or 0)
                    ui.label(time_str).classes("text-2xl font-bold text-purple-600")

                # Progress
                progress = (game_state.matched_pairs / game_state.total_pairs) * 100
                with ui.card().classes("p-4 bg-white shadow-md rounded-lg"):
                    ui.label("Progress").classes("text-sm text-gray-500 uppercase tracking-wider")
                    ui.label(f"{progress:.1f}%").classes("text-2xl font-bold text-orange-600")

    def create_game_grid(self):
        """Create the 6x6 grid of memory cards."""
        if self.current_game_id is None or self.grid_container is None:
            return

        self.grid_container.clear()

        game_state = GameService.get_game_state(self.current_game_id)
        if game_state is None:
            return

        if self.grid_container is not None:
            with self.grid_container:
                with ui.card().classes("p-6 bg-white shadow-lg rounded-xl"):
                    # Create grid
                    with ui.column().classes("gap-2"):
                        for row in range(game_state.grid_size):
                            with ui.row().classes("gap-2 justify-center"):
                                for col in range(game_state.grid_size):
                                    position = row * game_state.grid_size + col
                                    card_data = next((c for c in game_state.cards if c["position"] == position), None)

                                    if card_data:
                                        self.create_card_button(card_data)

    def create_card_button(self, card_data: dict):
        """Create a single card button."""
        card_id = card_data["id"]
        status = card_data["status"]
        icon = card_data["icon"]

        # Determine card appearance
        if status == CardStatus.MATCHED.value:
            # Matched cards show icon with green background
            card_face = icon
            card_classes = "w-16 h-16 text-2xl bg-green-100 border-2 border-green-400 text-green-700 rounded-lg font-bold shadow-sm"
            disabled = True
        elif status == CardStatus.FACE_UP.value:
            # Face-up cards show icon
            card_face = icon
            card_classes = "w-16 h-16 text-2xl bg-blue-100 border-2 border-blue-400 text-blue-700 rounded-lg font-bold shadow-md transform scale-105"
            disabled = False
        else:
            # Face-down cards show question mark
            card_face = "❓"
            card_classes = "w-16 h-16 text-2xl bg-gray-100 border-2 border-gray-300 text-gray-600 rounded-lg font-bold shadow-sm hover:bg-gray-200 hover:shadow-md transition-all"
            disabled = False

        card_button = ui.button(card_face, on_click=lambda e, card_id=card_id: self.on_card_click(card_id)).classes(
            card_classes
        )

        if disabled:
            card_button.props("disable")

        self.card_elements[card_id] = card_button

    async def on_card_click(self, card_id: int):
        """Handle card click event."""
        if self.is_checking_match:
            return

        if card_id in self.selected_cards:
            return

        # Flip the card
        success, card = GameService.flip_card(card_id)
        if not success:
            return

        self.selected_cards.append(card_id)

        # Update the card display
        self.refresh_game_display()

        # Check if we have two cards selected
        if len(self.selected_cards) == 2:
            self.is_checking_match = True

            # Increment attempts
            if self.current_game_id is not None:
                GameService.increment_attempts(self.current_game_id)

            # Check for match after a short delay to show both cards
            await asyncio.sleep(1.0)

            card1_id, card2_id = self.selected_cards
            is_match, game_won = GameService.check_match(card1_id, card2_id)

            if not is_match:
                # No match - flip cards back down
                GameService.flip_card_down(card1_id)
                GameService.flip_card_down(card2_id)
                ui.notify("No match! 🤔 Try again.", type="warning")
            else:
                ui.notify("Match found! ✨ Pairs connected!", type="positive")

                if game_won:
                    await self.show_win_dialog()

            # Reset selection
            self.selected_cards = []
            self.is_checking_match = False

            # Refresh display
            self.refresh_game_display()

    def refresh_game_display(self):
        """Refresh the entire game display."""
        self.update_stats()
        self.create_game_grid()

    async def show_win_dialog(self):
        """Show the win dialog when game is completed."""
        if self.current_game_id is None:
            return

        game_state = GameService.get_game_state(self.current_game_id)
        if game_state is None:
            return

        time_str = self.format_time(game_state.elapsed_time or 0)

        with ui.dialog() as dialog, ui.card().classes("p-6 text-center"):
            ui.label("🏆 Congratulations! You Win! 🥳").classes("text-2xl font-bold text-green-600 mb-4")
            ui.label("You've successfully found all the matching pairs! ✨").classes("text-lg text-gray-700 mb-4")

            with ui.column().classes("gap-2 mb-6"):
                ui.label(f"Attempts: {game_state.attempts}").classes("text-base text-gray-600")
                ui.label(f"Time: {time_str}").classes("text-base text-gray-600")

            with ui.row().classes("gap-4 justify-center"):
                ui.button("Play Again", on_click=lambda: (dialog.close(), self.start_new_game())).classes(
                    "bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg font-semibold"
                )
                ui.button("Close", on_click=dialog.close).classes(
                    "bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded-lg font-semibold"
                )

        dialog.open()

    async def show_instructions(self):
        """Show game instructions dialog."""
        with ui.dialog() as dialog, ui.card().classes("p-6 max-w-md"):
            ui.label("🎮 How to Play").classes("text-xl font-bold text-blue-600 mb-4")

            instructions = [
                "1. Click on any face-down card to reveal it",
                "2. Click on a second card to reveal it",
                "3. If the icons match, both cards stay revealed",
                "4. If they don't match, both cards flip back over",
                "5. Find all matching pairs to win the game!",
                "",
                "💡 Tip: Try to remember where you saw each icon!",
            ]

            for instruction in instructions:
                if instruction == "":
                    ui.separator().classes("my-2")
                else:
                    ui.label(instruction).classes("text-sm text-gray-700 mb-1")

            ui.button("Got it!", on_click=dialog.close).classes(
                "bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold mt-4 w-full"
            )

        dialog.open()

    @staticmethod
    def format_time(seconds: int) -> str:
        """Format seconds into MM:SS format."""
        minutes = seconds // 60
        secs = seconds % 60
        return f"{minutes:02d}:{secs:02d}"


def create():
    """Create the memory game module."""
    game = MemoryCardGame()

    @ui.page("/memory-game")
    def memory_game_page():
        game.create_game_page()

    @ui.page("/")
    def index():
        with ui.column().classes("w-full max-w-2xl mx-auto p-8 text-center"):
            ui.label("🧠 Memory Card Game").classes("text-4xl font-bold text-gray-800 mb-4")
            ui.label("Test your memory by finding matching pairs of cards!").classes("text-lg text-gray-600 mb-8")

            with ui.card().classes("p-6 bg-white shadow-lg rounded-xl mb-6"):
                ui.label("Game Features:").classes("text-xl font-semibold text-gray-800 mb-4")
                features = [
                    "🎯 6x6 grid with 18 pairs to match",
                    "🔄 Shuffled cards every game",
                    "📊 Track attempts and time",
                    "🏆 Win dialog with statistics",
                    "🎨 Beautiful, responsive design",
                ]

                for feature in features:
                    ui.label(feature).classes("text-left text-gray-700 mb-2")

            ui.button("Start Playing", on_click=lambda: ui.navigate.to("/memory-game")).classes(
                "bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold shadow-md hover:shadow-lg transition-all"
            )
