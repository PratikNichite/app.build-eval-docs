from app.database import create_tables
import app.memory_game


def startup() -> None:
    # this function is called before the first request
    create_tables()
    app.memory_game.create()
