from sqlmodel import SQLModel, Field, Relationship, JSON, Column
from datetime import datetime
from typing import Optional, List, Dict, Any
from enum import Enum


class CardStatus(str, Enum):
    FACE_DOWN = "face_down"
    FACE_UP = "face_up"
    MATCHED = "matched"
    REMOVED = "removed"


class GameStatus(str, Enum):
    IN_PROGRESS = "in_progress"
    WON = "won"
    PAUSED = "paused"


# Persistent models (stored in database)
class Game(SQLModel, table=True):
    __tablename__ = "games"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    grid_size: int = Field(default=6)  # 6x6 grid
    total_pairs: int = Field(default=18)  # 36 cards / 2 = 18 pairs
    attempts: int = Field(default=0)
    matched_pairs: int = Field(default=0)
    status: GameStatus = Field(default=GameStatus.IN_PROGRESS)
    start_time: datetime = Field(default_factory=datetime.utcnow)
    end_time: Optional[datetime] = Field(default=None)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    cards: List["Card"] = Relationship(back_populates="game")


class Card(SQLModel, table=True):
    __tablename__ = "cards"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    game_id: int = Field(foreign_key="games.id")
    position: int = Field()  # 0-35 for 6x6 grid
    icon: str = Field(max_length=50)  # Icon identifier (e.g., "heart", "star", "diamond")
    pair_id: int = Field()  # Two cards with same pair_id form a matching pair
    status: CardStatus = Field(default=CardStatus.FACE_DOWN)
    row: int = Field()  # 0-5 for 6x6 grid
    col: int = Field()  # 0-5 for 6x6 grid
    revealed_at: Optional[datetime] = Field(default=None)
    matched_at: Optional[datetime] = Field(default=None)

    game: Game = Relationship(back_populates="cards")


class GameSession(SQLModel, table=True):
    __tablename__ = "game_sessions"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    player_name: Optional[str] = Field(default=None, max_length=100)
    total_games: int = Field(default=0)
    total_wins: int = Field(default=0)
    best_attempts: Optional[int] = Field(default=None)  # Fewest attempts to win
    best_time: Optional[int] = Field(default=None)  # Fastest win time in seconds
    session_data: Dict[str, Any] = Field(default={}, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_played: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class GameCreate(SQLModel, table=False):
    grid_size: int = Field(default=6, ge=2, le=8)  # Allow different grid sizes (2x2 to 8x8)
    player_name: Optional[str] = Field(default=None, max_length=100)


class GameUpdate(SQLModel, table=False):
    attempts: Optional[int] = Field(default=None, ge=0)
    matched_pairs: Optional[int] = Field(default=None, ge=0)
    status: Optional[GameStatus] = Field(default=None)
    end_time: Optional[datetime] = Field(default=None)


class CardFlip(SQLModel, table=False):
    card_id: int
    position: int


class CardMatch(SQLModel, table=False):
    card1_id: int
    card2_id: int
    is_match: bool


class GameStats(SQLModel, table=False):
    total_games: int
    total_wins: int
    win_rate: float
    best_attempts: Optional[int]
    best_time: Optional[int]
    average_attempts: Optional[float]


class CardReveal(SQLModel, table=False):
    card_id: int
    icon: str
    position: int
    pair_id: int


class GameState(SQLModel, table=False):
    game_id: int
    grid_size: int
    attempts: int
    matched_pairs: int
    total_pairs: int
    status: GameStatus
    cards: List[Dict[str, Any]]  # Card positions and states
    elapsed_time: Optional[int] = Field(default=None)  # Seconds since start
