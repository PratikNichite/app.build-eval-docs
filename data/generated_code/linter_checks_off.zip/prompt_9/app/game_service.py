from datetime import datetime
from typing import List, Optional, Tuple
import random
from sqlmodel import select
from app.database import get_session
from app.models import Game, Card, GameSession, GameStatus, CardStatus, GameState


class GameService:
    """Service class for managing memory card game logic."""

    # Available icons for the cards
    CARD_ICONS = [
        "❤️",
        "⭐",
        "💎",
        "🌟",
        "🎵",
        "🎨",
        "🎯",
        "🎪",
        "🌈",
        "🔥",
        "⚡",
        "💫",
        "🌙",
        "☀️",
        "🌍",
        "🎭",
        "🎸",
        "🎺",
        "🎪",
        "🎨",
        "🎯",
        "🎵",
        "⚽",
        "🏀",
    ]

    @staticmethod
    def create_new_game(grid_size: int = 6, player_name: Optional[str] = None) -> Game:
        """Create a new memory card game with shuffled cards."""
        total_cards = grid_size * grid_size
        total_pairs = total_cards // 2

        if total_pairs > len(GameService.CARD_ICONS):
            raise ValueError(f"Not enough icons for {grid_size}x{grid_size} grid")

        with get_session() as session:
            # Create the game
            game = Game(
                grid_size=grid_size,
                total_pairs=total_pairs,
                status=GameStatus.IN_PROGRESS,
                start_time=datetime.utcnow(),
            )
            session.add(game)
            session.commit()
            session.refresh(game)

            game_id = game.id
            if game_id is None:
                raise ValueError("Game ID cannot be None after creation")

            # Create cards with pairs
            cards = []
            icons = GameService.CARD_ICONS[:total_pairs]

            # Create pairs of cards
            card_data = []
            for pair_id, icon in enumerate(icons):
                card_data.extend([{"icon": icon, "pair_id": pair_id}, {"icon": icon, "pair_id": pair_id}])

            # Shuffle the cards
            random.shuffle(card_data)

            # Create card objects with positions
            for position, data in enumerate(card_data):
                row = position // grid_size
                col = position % grid_size

                card = Card(
                    game_id=game_id,
                    position=position,
                    icon=data["icon"],
                    pair_id=data["pair_id"],
                    row=row,
                    col=col,
                    status=CardStatus.FACE_DOWN,
                )
                cards.append(card)

            session.add_all(cards)
            session.commit()

            # Return a fresh copy from database
            return GameService._get_game_fresh(game_id)

    @staticmethod
    def _get_game_fresh(game_id: int) -> Game:
        """Get a fresh game instance from database."""
        with get_session() as session:
            game = session.get(Game, game_id)
            if game is None:
                raise ValueError(f"Game {game_id} not found")

            # Create a detached copy
            game_copy = Game(
                id=game.id,
                grid_size=game.grid_size,
                total_pairs=game.total_pairs,
                attempts=game.attempts,
                matched_pairs=game.matched_pairs,
                status=game.status,
                start_time=game.start_time,
                end_time=game.end_time,
                created_at=game.created_at,
                updated_at=game.updated_at,
            )

            return game_copy

    @staticmethod
    def get_game(game_id: int) -> Optional[Game]:
        """Get a game by ID with all its cards."""
        with get_session() as session:
            statement = select(Game).where(Game.id == game_id)
            game = session.exec(statement).first()
            if game is None:
                return None

            # Load cards
            cards_statement = select(Card).where(Card.game_id == game_id)
            cards = list(session.exec(cards_statement))
            # Sort by position
            cards.sort(key=lambda c: c.position)

            # Create detached copies
            card_copies = []
            for card in cards:
                card_copy = Card(
                    id=card.id,
                    game_id=card.game_id,
                    position=card.position,
                    icon=card.icon,
                    pair_id=card.pair_id,
                    status=card.status,
                    row=card.row,
                    col=card.col,
                    revealed_at=card.revealed_at,
                    matched_at=card.matched_at,
                )
                card_copies.append(card_copy)

            # Create detached game copy
            game_copy = Game(
                id=game.id,
                grid_size=game.grid_size,
                total_pairs=game.total_pairs,
                attempts=game.attempts,
                matched_pairs=game.matched_pairs,
                status=game.status,
                start_time=game.start_time,
                end_time=game.end_time,
                created_at=game.created_at,
                updated_at=game.updated_at,
            )
            game_copy.cards = card_copies

            return game_copy

    @staticmethod
    def get_card(card_id: int) -> Optional[Card]:
        """Get a card by ID."""
        with get_session() as session:
            card = session.get(Card, card_id)
            if card is None:
                return None

            # Create detached copy
            card_copy = Card(
                id=card.id,
                game_id=card.game_id,
                position=card.position,
                icon=card.icon,
                pair_id=card.pair_id,
                status=card.status,
                row=card.row,
                col=card.col,
                revealed_at=card.revealed_at,
                matched_at=card.matched_at,
            )

            return card_copy

    @staticmethod
    def flip_card(card_id: int) -> Tuple[bool, Optional[Card]]:
        """
        Flip a card face up.
        Returns (success, card) where success indicates if the flip was valid.
        """
        with get_session() as session:
            card = session.get(Card, card_id)
            if card is None:
                return False, None

            # Can only flip face-down cards
            if card.status != CardStatus.FACE_DOWN:
                return False, GameService.get_card(card_id)

            card.status = CardStatus.FACE_UP
            card.revealed_at = datetime.utcnow()
            session.add(card)
            session.commit()

            return True, GameService.get_card(card_id)

    @staticmethod
    def flip_card_down(card_id: int) -> bool:
        """Flip a card face down."""
        with get_session() as session:
            card = session.get(Card, card_id)
            if card is None:
                return False

            card.status = CardStatus.FACE_DOWN
            card.revealed_at = None
            session.add(card)
            session.commit()

            return True

    @staticmethod
    def check_match(card1_id: int, card2_id: int) -> Tuple[bool, bool]:
        """
        Check if two cards match.
        Returns (is_match, game_won) tuple.
        """
        with get_session() as session:
            card1 = session.get(Card, card1_id)
            card2 = session.get(Card, card2_id)

            if card1 is None or card2 is None:
                return False, False

            # Check if cards are from the same game and are a matching pair
            is_match = card1.game_id == card2.game_id and card1.pair_id == card2.pair_id and card1.id != card2.id

            if is_match:
                # Mark cards as matched
                card1.status = CardStatus.MATCHED
                card2.status = CardStatus.MATCHED
                card1.matched_at = datetime.utcnow()
                card2.matched_at = datetime.utcnow()
                session.add_all([card1, card2])

                # Update game progress
                game = session.get(Game, card1.game_id)
                if game is not None:
                    game.matched_pairs += 1
                    game.updated_at = datetime.utcnow()

                    # Check if game is won
                    if game.matched_pairs >= game.total_pairs:
                        game.status = GameStatus.WON
                        game.end_time = datetime.utcnow()
                        session.add(game)
                        session.commit()
                        return True, True

                    session.add(game)

                session.commit()
                return True, False

            return False, False

    @staticmethod
    def increment_attempts(game_id: int) -> bool:
        """Increment the number of attempts for a game."""
        with get_session() as session:
            game = session.get(Game, game_id)
            if game is None:
                return False

            game.attempts += 1
            game.updated_at = datetime.utcnow()
            session.add(game)
            session.commit()

            return True

    @staticmethod
    def get_face_up_cards(game_id: int) -> List[Card]:
        """Get all face-up cards for a game."""
        with get_session() as session:
            statement = select(Card).where(Card.game_id == game_id, Card.status == CardStatus.FACE_UP)
            cards = list(session.exec(statement))

            # Create detached copies
            card_copies = []
            for card in cards:
                card_copy = Card(
                    id=card.id,
                    game_id=card.game_id,
                    position=card.position,
                    icon=card.icon,
                    pair_id=card.pair_id,
                    status=card.status,
                    row=card.row,
                    col=card.col,
                    revealed_at=card.revealed_at,
                    matched_at=card.matched_at,
                )
                card_copies.append(card_copy)

            return card_copies

    @staticmethod
    def get_game_state(game_id: int) -> Optional[GameState]:
        """Get the current state of a game."""
        game = GameService.get_game(game_id)
        if game is None:
            return None

        # Calculate elapsed time if game is still in progress
        elapsed_time = None
        if game.status == GameStatus.IN_PROGRESS:
            elapsed_time = int((datetime.utcnow() - game.start_time).total_seconds())
        elif game.end_time is not None:
            elapsed_time = int((game.end_time - game.start_time).total_seconds())

        # Format cards data
        cards_data = []
        for card in game.cards:
            cards_data.append(
                {
                    "id": card.id,
                    "position": card.position,
                    "row": card.row,
                    "col": card.col,
                    "icon": card.icon if card.status in [CardStatus.FACE_UP, CardStatus.MATCHED] else "❓",
                    "status": card.status.value,
                    "pair_id": card.pair_id,
                }
            )

        if game.id is None:
            raise ValueError("Game ID cannot be None")

        return GameState(
            game_id=game.id,
            grid_size=game.grid_size,
            attempts=game.attempts,
            matched_pairs=game.matched_pairs,
            total_pairs=game.total_pairs,
            status=game.status,
            cards=cards_data,
            elapsed_time=elapsed_time,
        )

    @staticmethod
    def update_session_stats(player_name: str, game: Game) -> None:
        """Update session statistics for a player."""
        if player_name is None:
            return

        with get_session() as session:
            # Get or create session
            statement = select(GameSession).where(GameSession.player_name == player_name)
            game_session = session.exec(statement).first()

            if game_session is None:
                game_session = GameSession(player_name=player_name)

            # Update stats
            game_session.total_games += 1
            game_session.last_played = datetime.utcnow()

            if game.status == GameStatus.WON:
                game_session.total_wins += 1

                # Update best attempts
                if game_session.best_attempts is None or game.attempts < game_session.best_attempts:
                    game_session.best_attempts = game.attempts

                # Update best time
                if game.end_time is not None:
                    game_time = int((game.end_time - game.start_time).total_seconds())
                    if game_session.best_time is None or game_time < game_session.best_time:
                        game_session.best_time = game_time

            session.add(game_session)
            session.commit()
