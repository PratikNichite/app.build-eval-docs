"""Main dashboard for the Chore Wheel application."""

from nicegui import ui

from app.services import AssignmentService, WeeklyScheduleService
from app.models import ChoreStatus


def apply_modern_theme():
    """Apply modern color scheme."""
    ui.colors(
        primary="#2563eb",  # Professional blue
        secondary="#64748b",  # Subtle gray
        accent="#10b981",  # Success green
        positive="#10b981",
        negative="#ef4444",  # Error red
        warning="#f59e0b",  # Warning amber
        info="#3b82f6",  # Info blue
    )


class TextStyles:
    """Reusable text styles."""

    HEADING = "text-2xl font-bold text-gray-800 mb-4"
    SUBHEADING = "text-lg font-semibold text-gray-700 mb-2"
    BODY = "text-base text-gray-600 leading-relaxed"
    CAPTION = "text-sm text-gray-500"


def create_metric_card(title: str, value: str, change: str = "", positive: bool = True):
    """Create a modern metric card."""
    with ui.card().classes("p-6 bg-white shadow-lg rounded-xl hover:shadow-xl transition-shadow"):
        ui.label(title).classes("text-sm text-gray-500 uppercase tracking-wider")
        ui.label(value).classes("text-3xl font-bold text-gray-800 mt-2")
        if change:
            change_color = "text-green-500" if positive else "text-red-500"
            ui.label(change).classes(f"text-sm {change_color} mt-1")


def create_assignment_card(assignment, on_complete_callback=None):
    """Create a card for a single chore assignment."""
    with ui.card().classes("p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow"):
        # Chore name and status
        with ui.row().classes("w-full items-center justify-between mb-2"):
            ui.label(assignment.chore.name).classes("text-lg font-semibold text-gray-800")

            # Status badge
            status_colors = {
                ChoreStatus.PENDING: "bg-yellow-100 text-yellow-800",
                ChoreStatus.COMPLETED: "bg-green-100 text-green-800",
                ChoreStatus.OVERDUE: "bg-red-100 text-red-800",
            }
            status_color = status_colors.get(assignment.status, "bg-gray-100 text-gray-800")
            ui.label(assignment.status.value.title()).classes(f"px-2 py-1 rounded-full text-xs {status_color}")

        # Chore description
        if assignment.chore.description:
            ui.label(assignment.chore.description).classes("text-sm text-gray-600 mb-2")

        # Time estimate
        if assignment.chore.estimated_minutes:
            ui.label(f"⏱️ ~{assignment.chore.estimated_minutes} minutes").classes("text-xs text-gray-500 mb-3")

        # Completion info or action button
        if assignment.status == ChoreStatus.COMPLETED:
            completed_text = "✅ Completed"
            if assignment.completed_at:
                completed_text += f" on {assignment.completed_at.strftime('%m/%d at %I:%M %p')}"
            ui.label(completed_text).classes("text-sm text-green-600")

            if assignment.notes:
                ui.label(f"Note: {assignment.notes}").classes("text-xs text-gray-500 mt-1 italic")
        else:
            # Complete button
            if assignment.id is not None:

                def complete_chore(assignment_id=assignment.id):
                    if assignment_id is not None:
                        success = AssignmentService.complete_assignment(assignment_id)
                        if success:
                            ui.notify("Chore marked as completed!", type="positive")
                            if on_complete_callback:
                                on_complete_callback()
                        else:
                            ui.notify("Failed to mark chore as completed", type="negative")

                ui.button("Mark Complete", on_click=complete_chore).classes(
                    "bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
                )


def create_dashboard_content():
    """Create the main dashboard content."""
    # Get current week assignments
    current_week = WeeklyScheduleService.get_current_week()
    assignments = AssignmentService.get_current_week_assignments()

    if not assignments:
        # No assignments for current week - show generate button
        with ui.column().classes("items-center justify-center p-12"):
            ui.label("✨ Ready to spark a new week?").classes("text-2xl font-bold text-gray-700 mb-4")
            ui.label("Hit the button below to generate a fresh batch of assignments! 🚀").classes("text-gray-600 mb-6")

            def generate_assignments():
                try:
                    result = AssignmentService.generate_weekly_assignments()
                    if result:
                        ui.notify("🎉 Weekly assignments generated!", type="positive")
                        ui.run_javascript("window.location.reload()")
                    else:
                        ui.notify("Please add roommates and chores first", type="warning")
                except Exception as e:
                    ui.notify(f"Error generating assignments: {str(e)}", type="negative")

            ui.button("Generate This Week's Assignments", on_click=generate_assignments).classes(
                "bg-primary text-white px-8 py-3 text-lg rounded-lg shadow-md hover:shadow-lg"
            )
        return

    # Calculate metrics
    total_chores = len(assignments)
    completed_chores = len([a for a in assignments if a.status == ChoreStatus.COMPLETED])
    completion_rate = (completed_chores / total_chores * 100) if total_chores > 0 else 0

    # Header with week info
    week_text = "This Week"
    if current_week:
        week_text = f"Week of {current_week.week_start_date.strftime('%B %d, %Y')}"

    ui.label(f"🏠 Chore Wheel - {week_text}").classes(TextStyles.HEADING)

    # Metrics cards
    with ui.row().classes("gap-4 w-full mb-6"):
        create_metric_card("Total Chores", str(total_chores))
        create_metric_card("Completed", str(completed_chores), f"{completion_rate:.1f}%")
        create_metric_card("Remaining", str(total_chores - completed_chores))

    # Assignments by roommate
    roommate_assignments = AssignmentService.get_assignments_by_roommate(
        current_week.id if current_week and current_week.id else 0
    )

    if roommate_assignments:
        ui.label("📋 Assignments by Roommate").classes(TextStyles.SUBHEADING)

        # Refresh function for assignment updates
        def refresh_assignments():
            ui.run_javascript("window.location.reload()")

        for roommate_name, roommate_chores in roommate_assignments.items():
            with ui.expansion(roommate_name, icon="person").classes("w-full mb-4"):
                with ui.column().classes("gap-3 p-2"):
                    for assignment in roommate_chores:
                        create_assignment_card(assignment, on_complete_callback=refresh_assignments)

    # Generate new week button
    with ui.row().classes("mt-8 gap-4"):

        def generate_new_week():
            try:
                result = AssignmentService.generate_weekly_assignments()
                if result:
                    ui.notify("🎉 Weekly assignments generated!", type="positive")
                    ui.run_javascript("window.location.reload()")
                else:
                    ui.notify("Please add roommates and chores first", type="warning")
            except Exception as e:
                ui.notify(f"Error generating assignments: {str(e)}", type="negative")

        ui.button("Generate New Week", on_click=generate_new_week).classes(
            "bg-primary text-white px-4 py-2 rounded"
        ).props("outline")


def create():
    """Create the dashboard page."""
    apply_modern_theme()

    @ui.page("/")
    def dashboard():
        # Main layout with sidebar
        with ui.row().classes("w-full min-h-screen"):
            # Sidebar
            with ui.column().classes("w-64 bg-gray-800 text-white p-4 min-h-screen"):
                ui.label("🎯 Chore Wheel").classes("text-xl font-bold mb-6 text-white")

                # Navigation items
                nav_items = [
                    ("Dashboard", "/", "home"),
                    ("Roommates", "/roommates", "people"),
                    ("Chores", "/chores", "task_alt"),
                ]

                for item_name, item_path, icon in nav_items:

                    def create_nav_handler(path):
                        return lambda: ui.navigate.to(path)

                    ui.button(item_name, on_click=create_nav_handler(item_path), icon=icon).classes(
                        "w-full text-left px-4 py-2 hover:bg-gray-700 rounded mb-2"
                    ).props("flat text-color=white align=left")

            # Main content area
            with ui.column().classes("flex-1 bg-gray-50 p-6 overflow-auto"):
                create_dashboard_content()
