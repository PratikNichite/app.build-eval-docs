from sqlmodel import SQLModel, Field, Relationship
from datetime import datetime, date
from typing import Optional, List
from enum import Enum


class ChoreStatus(str, Enum):
    """Status of a chore assignment."""

    PENDING = "pending"
    COMPLETED = "completed"
    OVERDUE = "overdue"


# Persistent models (stored in database)
class Roommate(SQLModel, table=True):
    """Model for roommates in the chore wheel system."""

    __tablename__ = "roommates"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100, index=True)
    email: Optional[str] = Field(default=None, max_length=255)
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    assignments: List["Assignment"] = Relationship(back_populates="roommate")


class Chore(SQLModel, table=True):
    """Model for chores that can be assigned."""

    __tablename__ = "chores"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=200, index=True)
    description: Optional[str] = Field(default=None, max_length=1000)
    estimated_minutes: Optional[int] = Field(default=None, ge=1)
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    assignments: List["Assignment"] = Relationship(back_populates="chore")


class WeeklySchedule(SQLModel, table=True):
    """Model for weekly schedules that group assignments."""

    __tablename__ = "weekly_schedules"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    week_start_date: date = Field(index=True)
    week_end_date: date = Field(index=True)
    is_current: bool = Field(default=False, index=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    assignments: List["Assignment"] = Relationship(back_populates="weekly_schedule")


class Assignment(SQLModel, table=True):
    """Model for chore assignments linking roommates to chores for a specific week."""

    __tablename__ = "assignments"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    roommate_id: int = Field(foreign_key="roommates.id", index=True)
    chore_id: int = Field(foreign_key="chores.id", index=True)
    weekly_schedule_id: int = Field(foreign_key="weekly_schedules.id", index=True)
    status: ChoreStatus = Field(default=ChoreStatus.PENDING, index=True)
    completed_at: Optional[datetime] = Field(default=None)
    notes: Optional[str] = Field(default=None, max_length=500)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    roommate: Roommate = Relationship(back_populates="assignments")
    chore: Chore = Relationship(back_populates="assignments")
    weekly_schedule: WeeklySchedule = Relationship(back_populates="assignments")


# Non-persistent schemas (for validation, forms, API requests/responses)
class RoommateCreate(SQLModel, table=False):
    """Schema for creating a new roommate."""

    name: str = Field(max_length=100)
    email: Optional[str] = Field(default=None, max_length=255)


class RoommateUpdate(SQLModel, table=False):
    """Schema for updating an existing roommate."""

    name: Optional[str] = Field(default=None, max_length=100)
    email: Optional[str] = Field(default=None, max_length=255)
    is_active: Optional[bool] = Field(default=None)


class ChoreCreate(SQLModel, table=False):
    """Schema for creating a new chore."""

    name: str = Field(max_length=200)
    description: Optional[str] = Field(default=None, max_length=1000)
    estimated_minutes: Optional[int] = Field(default=None, ge=1)


class ChoreUpdate(SQLModel, table=False):
    """Schema for updating an existing chore."""

    name: Optional[str] = Field(default=None, max_length=200)
    description: Optional[str] = Field(default=None, max_length=1000)
    estimated_minutes: Optional[int] = Field(default=None, ge=1)
    is_active: Optional[bool] = Field(default=None)


class WeeklyScheduleCreate(SQLModel, table=False):
    """Schema for creating a new weekly schedule."""

    week_start_date: date
    week_end_date: date
    is_current: bool = Field(default=False)


class AssignmentCreate(SQLModel, table=False):
    """Schema for creating a new assignment."""

    roommate_id: int
    chore_id: int
    weekly_schedule_id: int


class AssignmentUpdate(SQLModel, table=False):
    """Schema for updating an existing assignment."""

    status: Optional[ChoreStatus] = Field(default=None)
    notes: Optional[str] = Field(default=None, max_length=500)


class AssignmentComplete(SQLModel, table=False):
    """Schema for marking an assignment as complete."""

    notes: Optional[str] = Field(default=None, max_length=500)
