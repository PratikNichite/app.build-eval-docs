"""Chore management module."""

from nicegui import ui

from app.services import ChoreService
from app.models import ChoreCreate, ChoreUpdate


class TextStyles:
    """Reusable text styles."""

    HEADING = "text-2xl font-bold text-gray-800 mb-4"
    SUBHEADING = "text-lg font-semibold text-gray-700 mb-2"
    BODY = "text-base text-gray-600 leading-relaxed"
    CAPTION = "text-sm text-gray-500"


def create_chore_form(chore=None, on_success=None):
    """Create a form for adding or editing chores."""
    is_edit = chore is not None
    title = "Edit Chore" if is_edit else "Add New Chore"

    with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
        ui.label(title).classes("text-xl font-bold mb-4")

        # Form fields
        name_input = ui.input("Chore Name", value=chore.name if is_edit else "").classes("w-full mb-4")

        description_input = (
            ui.textarea("Description (optional)", value=chore.description if is_edit and chore.description else "")
            .classes("w-full mb-4")
            .props("rows=3")
        )

        minutes_input = ui.number(
            "Estimated Minutes (optional)",
            value=chore.estimated_minutes if is_edit and chore.estimated_minutes else None,
            min=1,
            max=999,
        ).classes("w-full mb-4")

        active_checkbox = None
        if is_edit:
            active_checkbox = ui.checkbox("Active", value=chore.is_active).classes("mb-4")

        # Buttons
        with ui.row().classes("gap-2 justify-end w-full"):
            ui.button("Cancel", on_click=dialog.close).props("outline")

            def submit():
                name = name_input.value.strip()
                description = description_input.value.strip() if description_input.value else None
                minutes = int(minutes_input.value) if minutes_input.value else None

                if not name:
                    ui.notify("Chore name is required", type="negative")
                    return

                try:
                    if is_edit and chore and chore.id is not None:
                        # Update existing chore
                        update_data = ChoreUpdate(
                            name=name,
                            description=description,
                            estimated_minutes=minutes,
                            is_active=active_checkbox.value if active_checkbox else True,
                        )
                        result = ChoreService.update(chore.id, update_data)
                        if result:
                            ui.notify("Chore updated successfully! 📝", type="positive")
                            dialog.close()
                            if on_success:
                                on_success()
                        else:
                            ui.notify("Failed to update chore", type="negative")
                    else:
                        # Create new chore
                        create_data = ChoreCreate(name=name, description=description, estimated_minutes=minutes)
                        ChoreService.create(create_data)
                        ui.notify("Chore added successfully! ✅", type="positive")
                        dialog.close()
                        if on_success:
                            on_success()
                except Exception as e:
                    ui.notify(f"Error: {str(e)}", type="negative")

            ui.button("Save" if is_edit else "Add", on_click=submit).classes("bg-primary text-white")

    return dialog


def create_chore_card(chore, on_edit=None, on_delete=None):
    """Create a card for displaying chore information."""
    with ui.card().classes("p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow"):
        with ui.row().classes("w-full items-start justify-between"):
            with ui.column().classes("flex-1"):
                # Name and status
                with ui.row().classes("items-center gap-2 mb-2"):
                    ui.label(chore.name).classes("text-lg font-semibold text-gray-800")
                    if not chore.is_active:
                        ui.label("Inactive").classes("px-2 py-1 rounded-full text-xs bg-red-100 text-red-800")

                # Description
                if chore.description:
                    ui.label(chore.description).classes("text-sm text-gray-600 mb-2 leading-relaxed")

                # Time estimate
                if chore.estimated_minutes:
                    ui.label(f"⏱️ Estimated: {chore.estimated_minutes} minutes").classes("text-sm text-blue-600 mb-2")

                # Created date
                created_date = chore.created_at.strftime("%B %d, %Y")
                ui.label(f"Added: {created_date}").classes("text-xs text-gray-500")

            # Action buttons
            with ui.column().classes("gap-2 ml-4"):
                if chore.id is not None:
                    # Edit button
                    def edit_chore(chore_id=chore.id):
                        if chore_id is not None:
                            chore_data = ChoreService.get_by_id(chore_id)
                            if chore_data:
                                dialog = create_chore_form(chore_data, on_edit)
                                dialog.open()

                    ui.button("Edit", on_click=edit_chore, icon="edit").classes("text-sm").props("size=sm outline")

                    # Delete/Deactivate button
                    def delete_chore(chore_id=chore.id):
                        if chore_id is not None:
                            success = ChoreService.delete(chore_id)
                            if success:
                                ui.notify("Chore deactivated 🧹", type="positive")
                                if on_delete:
                                    on_delete()
                            else:
                                ui.notify("Failed to deactivate chore", type="negative")

                    if chore.is_active:
                        ui.button("Deactivate", on_click=delete_chore, icon="delete_outline").classes("text-sm").props(
                            "size=sm outline color=negative"
                        )


def create_chores_content():
    """Create the chores page content."""
    ui.label("📝 Manage Chores").classes(TextStyles.HEADING)

    # Load and display chores
    def refresh_chores():
        """Refresh the chores list."""
        ui.run_javascript("window.location.reload()")

    # Add chore button
    with ui.row().classes("mb-6"):

        def show_add_form():
            dialog = create_chore_form(on_success=refresh_chores)
            dialog.open()

        ui.button("Add Chore", on_click=show_add_form, icon="add_task").classes(
            "bg-primary text-white px-4 py-2 rounded"
        )

    # Get all chores (including inactive ones for management)
    try:
        # Get all chores, not just active ones, for management purposes
        all_chores = []
        active_chores = ChoreService.get_all_active()
        all_chores.extend(active_chores)

        # Also get any inactive chores by checking the database directly
        from app.database import get_session
        from sqlmodel import select
        from app.models import Chore

        with get_session() as session:
            statement = select(Chore).where(Chore.is_active == False)
            inactive_chores = list(session.exec(statement).all())
            all_chores.extend(inactive_chores)

        if not all_chores:
            # Empty state
            with ui.column().classes("items-center justify-center p-12"):
                ui.label("📋 No chores yet...").classes("text-xl font-bold text-gray-600 mb-2")
                ui.label("Time to list those tasks! ✍️").classes("text-gray-500")
                ui.label("Add your first chore to get started with the chore wheel!").classes("text-gray-400")
                ui.label("Examples: Vacuum living room, Take out trash, Clean bathroom, Do dishes").classes(
                    "text-sm text-gray-400 mt-2"
                )
        else:
            # Active chores
            active_count = len([c for c in all_chores if c.is_active])
            inactive_count = len([c for c in all_chores if not c.is_active])

            ui.label(f"Active Chores ({active_count})").classes(TextStyles.SUBHEADING)

            active_chores_list = [c for c in all_chores if c.is_active]
            if active_chores_list:
                with ui.grid(columns=2).classes("gap-4 w-full mb-6"):
                    for chore in active_chores_list:
                        create_chore_card(chore, on_edit=refresh_chores, on_delete=refresh_chores)
            else:
                ui.label("No active chores").classes("text-gray-500 mb-4")

            # Inactive chores (if any)
            if inactive_count > 0:
                ui.label(f"Inactive Chores ({inactive_count})").classes(TextStyles.SUBHEADING)
                inactive_chores_list = [c for c in all_chores if not c.is_active]

                with ui.grid(columns=2).classes("gap-4 w-full"):
                    for chore in inactive_chores_list:
                        create_chore_card(chore, on_edit=refresh_chores, on_delete=refresh_chores)

    except Exception as e:
        ui.label(f"Error loading chores: {str(e)}").classes("text-red-600")


def create():
    """Create the chores management page."""

    @ui.page("/chores")
    def chores():
        # Main layout with sidebar
        with ui.row().classes("w-full min-h-screen"):
            # Sidebar
            with ui.column().classes("w-64 bg-gray-800 text-white p-4 min-h-screen"):
                ui.label("🎯 Chore Wheel").classes("text-xl font-bold mb-6 text-white")

                # Navigation items
                nav_items = [
                    ("Dashboard", "/", "home"),
                    ("Roommates", "/roommates", "people"),
                    ("Chores", "/chores", "task_alt"),
                ]

                for item_name, item_path, icon in nav_items:
                    current_class = "bg-gray-700" if item_path == "/chores" else ""

                    def create_nav_handler(path):
                        return lambda: ui.navigate.to(path)

                    ui.button(item_name, on_click=create_nav_handler(item_path), icon=icon).classes(
                        f"w-full text-left px-4 py-2 hover:bg-gray-700 rounded mb-2 {current_class}"
                    ).props("flat text-color=white align=left")

            # Main content area
            with ui.column().classes("flex-1 bg-gray-50 p-6 overflow-auto"):
                create_chores_content()
