"""Service layer for chore wheel business logic."""

from typing import List, Optional
from datetime import date, datetime, timedelta
from sqlmodel import select, and_
import random

from app.database import get_session
from app.models import (
    Roommate,
    Chore,
    WeeklySchedule,
    Assignment,
    ChoreStatus,
    RoommateCreate,
    RoommateUpdate,
    ChoreCreate,
    ChoreUpdate,
    AssignmentUpdate,
)


class RoommateService:
    """Service for managing roommates."""

    @staticmethod
    def get_all_active() -> List[Roommate]:
        """Get all active roommates."""
        with get_session() as session:
            statement = select(Roommate).where(Roommate.is_active == True)
            return list(session.exec(statement).all())

    @staticmethod
    def get_by_id(roommate_id: int) -> Optional[Roommate]:
        """Get roommate by ID."""
        with get_session() as session:
            return session.get(Roommate, roommate_id)

    @staticmethod
    def create(roommate_data: RoommateCreate) -> Roommate:
        """Create a new roommate."""
        with get_session() as session:
            roommate = Roommate(**roommate_data.model_dump())
            session.add(roommate)
            session.commit()
            session.refresh(roommate)
            return roommate

    @staticmethod
    def update(roommate_id: int, roommate_data: RoommateUpdate) -> Optional[Roommate]:
        """Update an existing roommate."""
        with get_session() as session:
            roommate = session.get(Roommate, roommate_id)
            if roommate is None:
                return None

            update_data = roommate_data.model_dump(exclude_unset=True)
            for key, value in update_data.items():
                setattr(roommate, key, value)

            roommate.updated_at = datetime.utcnow()
            session.add(roommate)
            session.commit()
            session.refresh(roommate)
            return roommate

    @staticmethod
    def delete(roommate_id: int) -> bool:
        """Soft delete a roommate by setting is_active to False."""
        with get_session() as session:
            roommate = session.get(Roommate, roommate_id)
            if roommate is None:
                return False

            roommate.is_active = False
            roommate.updated_at = datetime.utcnow()
            session.add(roommate)
            session.commit()
            return True


class ChoreService:
    """Service for managing chores."""

    @staticmethod
    def get_all_active() -> List[Chore]:
        """Get all active chores."""
        with get_session() as session:
            statement = select(Chore).where(Chore.is_active == True)
            return list(session.exec(statement).all())

    @staticmethod
    def get_by_id(chore_id: int) -> Optional[Chore]:
        """Get chore by ID."""
        with get_session() as session:
            return session.get(Chore, chore_id)

    @staticmethod
    def create(chore_data: ChoreCreate) -> Chore:
        """Create a new chore."""
        with get_session() as session:
            chore = Chore(**chore_data.model_dump())
            session.add(chore)
            session.commit()
            session.refresh(chore)
            return chore

    @staticmethod
    def update(chore_id: int, chore_data: ChoreUpdate) -> Optional[Chore]:
        """Update an existing chore."""
        with get_session() as session:
            chore = session.get(Chore, chore_id)
            if chore is None:
                return None

            update_data = chore_data.model_dump(exclude_unset=True)
            for key, value in update_data.items():
                setattr(chore, key, value)

            chore.updated_at = datetime.utcnow()
            session.add(chore)
            session.commit()
            session.refresh(chore)
            return chore

    @staticmethod
    def delete(chore_id: int) -> bool:
        """Soft delete a chore by setting is_active to False."""
        with get_session() as session:
            chore = session.get(Chore, chore_id)
            if chore is None:
                return False

            chore.is_active = False
            chore.updated_at = datetime.utcnow()
            session.add(chore)
            session.commit()
            return True


class WeeklyScheduleService:
    """Service for managing weekly schedules."""

    @staticmethod
    def get_current_week() -> Optional[WeeklySchedule]:
        """Get the current active weekly schedule."""
        with get_session() as session:
            statement = select(WeeklySchedule).where(WeeklySchedule.is_current == True)
            return session.exec(statement).first()

    @staticmethod
    def get_week_by_date(target_date: date) -> Optional[WeeklySchedule]:
        """Get weekly schedule that contains the target date."""
        with get_session() as session:
            statement = select(WeeklySchedule).where(
                and_(WeeklySchedule.week_start_date <= target_date, WeeklySchedule.week_end_date >= target_date)
            )
            return session.exec(statement).first()

    @staticmethod
    def create_week(start_date: date) -> WeeklySchedule:
        """Create a new weekly schedule."""
        end_date = start_date + timedelta(days=6)

        with get_session() as session:
            # Set all existing schedules to not current
            statement = select(WeeklySchedule).where(WeeklySchedule.is_current == True)
            current_schedules = session.exec(statement).all()
            for schedule in current_schedules:
                schedule.is_current = False
                session.add(schedule)

            # Create new schedule
            new_schedule = WeeklySchedule(week_start_date=start_date, week_end_date=end_date, is_current=True)
            session.add(new_schedule)
            session.commit()
            session.refresh(new_schedule)
            return new_schedule

    @staticmethod
    def get_current_week_start() -> date:
        """Get the start of the current week (Monday)."""
        today = date.today()
        days_since_monday = today.weekday()
        return today - timedelta(days=days_since_monday)


class AssignmentService:
    """Service for managing chore assignments."""

    @staticmethod
    def get_assignments_for_week(weekly_schedule_id: int) -> List[Assignment]:
        """Get all assignments for a specific week."""
        with get_session() as session:
            statement = select(Assignment).where(Assignment.weekly_schedule_id == weekly_schedule_id)
            assignments = list(session.exec(statement).all())

            # Force load relationships while session is active
            for assignment in assignments:
                if assignment.roommate:
                    _ = assignment.roommate.name
                if assignment.chore:
                    _ = assignment.chore.name

            return assignments

    @staticmethod
    def get_current_week_assignments() -> List[Assignment]:
        """Get assignments for the current week."""
        current_week = WeeklyScheduleService.get_current_week()
        if current_week is None or current_week.id is None:
            return []
        return AssignmentService.get_assignments_for_week(current_week.id)

    @staticmethod
    def complete_assignment(assignment_id: int, notes: Optional[str] = None) -> bool:
        """Mark an assignment as completed."""
        with get_session() as session:
            assignment = session.get(Assignment, assignment_id)
            if assignment is None:
                return False

            assignment.status = ChoreStatus.COMPLETED
            assignment.completed_at = datetime.utcnow()
            assignment.updated_at = datetime.utcnow()
            if notes:
                assignment.notes = notes

            session.add(assignment)
            session.commit()
            return True

    @staticmethod
    def update_assignment(assignment_id: int, assignment_data: AssignmentUpdate) -> Optional[Assignment]:
        """Update an assignment."""
        with get_session() as session:
            assignment = session.get(Assignment, assignment_id)
            if assignment is None:
                return None

            update_data = assignment_data.model_dump(exclude_unset=True)
            for key, value in update_data.items():
                setattr(assignment, key, value)

            assignment.updated_at = datetime.utcnow()
            session.add(assignment)
            session.commit()
            session.refresh(assignment)
            return assignment

    @staticmethod
    def generate_weekly_assignments() -> Optional[WeeklySchedule]:
        """Generate random chore assignments for the current week."""
        # Get active roommates and chores
        roommates = RoommateService.get_all_active()
        chores = ChoreService.get_all_active()

        if not roommates or not chores:
            return None

        # Get or create current week schedule
        current_week = WeeklyScheduleService.get_current_week()
        if current_week is None:
            week_start = WeeklyScheduleService.get_current_week_start()
            current_week = WeeklyScheduleService.create_week(week_start)

        if current_week.id is None:
            return None

        # Check if assignments already exist for this week
        existing_assignments = AssignmentService.get_assignments_for_week(current_week.id)
        if existing_assignments:
            return current_week

        # Shuffle chores and assign them round-robin style to roommates
        random.shuffle(chores)

        with get_session() as session:
            for i, chore in enumerate(chores):
                roommate = roommates[i % len(roommates)]

                if chore.id is not None and roommate.id is not None:
                    assignment = Assignment(
                        roommate_id=roommate.id,
                        chore_id=chore.id,
                        weekly_schedule_id=current_week.id,
                        status=ChoreStatus.PENDING,
                    )
                    session.add(assignment)

            session.commit()

        return current_week

    @staticmethod
    def get_assignments_by_roommate(weekly_schedule_id: int) -> dict[str, List[Assignment]]:
        """Get assignments grouped by roommate for a specific week."""
        assignments = AssignmentService.get_assignments_for_week(weekly_schedule_id)

        roommate_assignments = {}
        for assignment in assignments:
            roommate_name = assignment.roommate.name
            if roommate_name not in roommate_assignments:
                roommate_assignments[roommate_name] = []
            roommate_assignments[roommate_name].append(assignment)

        return roommate_assignments
