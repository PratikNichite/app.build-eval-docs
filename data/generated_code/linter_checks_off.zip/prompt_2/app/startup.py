from app.database import create_tables
import app.dashboard
import app.roommates
import app.chores


def startup() -> None:
    # this function is called before the first request
    create_tables()

    # Create all modules
    app.dashboard.create()
    app.roommates.create()
    app.chores.create()
