"""Roommate management module."""

from nicegui import ui

from app.services import RoommateService
from app.models import RoommateCreate, RoommateUpdate


class TextStyles:
    """Reusable text styles."""

    HEADING = "text-2xl font-bold text-gray-800 mb-4"
    SUBHEADING = "text-lg font-semibold text-gray-700 mb-2"
    BODY = "text-base text-gray-600 leading-relaxed"
    CAPTION = "text-sm text-gray-500"


def create_roommate_form(roommate=None, on_success=None):
    """Create a form for adding or editing roommates."""
    is_edit = roommate is not None
    title = "Edit Roommate" if is_edit else "Add New Roommate"

    with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
        ui.label(title).classes("text-xl font-bold mb-4")

        # Form fields
        name_input = ui.input("Name", value=roommate.name if is_edit else "").classes("w-full mb-4")
        email_input = ui.input("Email (optional)", value=roommate.email if is_edit and roommate.email else "").classes(
            "w-full mb-4"
        )

        active_checkbox = None
        if is_edit:
            active_checkbox = ui.checkbox("Active", value=roommate.is_active).classes("mb-4")

        # Buttons
        with ui.row().classes("gap-2 justify-end w-full"):
            ui.button("Cancel", on_click=dialog.close).props("outline")

            def submit():
                name = name_input.value.strip()
                email = email_input.value.strip() if email_input.value else None

                if not name:
                    ui.notify("Name is required", type="negative")
                    return

                try:
                    if is_edit and roommate and roommate.id is not None:
                        # Update existing roommate
                        update_data = RoommateUpdate(
                            name=name, email=email, is_active=active_checkbox.value if active_checkbox else True
                        )
                        result = RoommateService.update(roommate.id, update_data)
                        if result:
                            ui.notify("Roommate updated successfully! 🔄", type="positive")
                            dialog.close()
                            if on_success:
                                on_success()
                        else:
                            ui.notify("Failed to update roommate", type="negative")
                    else:
                        # Create new roommate
                        create_data = RoommateCreate(name=name, email=email)
                        RoommateService.create(create_data)
                        ui.notify("Roommate added successfully! 👋", type="positive")
                        dialog.close()
                        if on_success:
                            on_success()
                except Exception as e:
                    ui.notify(f"Error: {str(e)}", type="negative")

            ui.button("Save" if is_edit else "Add", on_click=submit).classes("bg-primary text-white")

    return dialog


def create_roommate_card(roommate, on_edit=None, on_delete=None):
    """Create a card for displaying roommate information."""
    with ui.card().classes("p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow"):
        with ui.row().classes("w-full items-center justify-between"):
            with ui.column().classes("flex-1"):
                # Name and status
                with ui.row().classes("items-center gap-2 mb-1"):
                    ui.label(roommate.name).classes("text-lg font-semibold text-gray-800")
                    if not roommate.is_active:
                        ui.label("Inactive").classes("px-2 py-1 rounded-full text-xs bg-red-100 text-red-800")

                # Email
                if roommate.email:
                    ui.label(roommate.email).classes("text-sm text-gray-600")

                # Created date
                created_date = roommate.created_at.strftime("%B %d, %Y")
                ui.label(f"Added: {created_date}").classes("text-xs text-gray-500 mt-1")

            # Action buttons
            with ui.column().classes("gap-2"):
                if roommate.id is not None:
                    # Edit button
                    def edit_roommate(roommate_id=roommate.id):
                        if roommate_id is not None:
                            roommate_data = RoommateService.get_by_id(roommate_id)
                            if roommate_data:
                                dialog = create_roommate_form(roommate_data, on_edit)
                                dialog.open()

                    ui.button("Edit", on_click=edit_roommate, icon="edit").classes("text-sm").props("size=sm outline")

                    # Delete/Deactivate button
                    def delete_roommate(roommate_id=roommate.id):
                        if roommate_id is not None:
                            success = RoommateService.delete(roommate_id)
                            if success:
                                ui.notify("Roommate deactivated 🚶‍♂️", type="positive")
                                if on_delete:
                                    on_delete()
                            else:
                                ui.notify("Failed to deactivate roommate", type="negative")

                    if roommate.is_active:
                        ui.button("Deactivate", on_click=delete_roommate, icon="person_off").classes("text-sm").props(
                            "size=sm outline color=negative"
                        )


def create_roommates_content():
    """Create the roommates page content."""
    ui.label("👥 Manage Roommates").classes(TextStyles.HEADING)

    # Load and display roommates
    def refresh_roommates():
        """Refresh the roommates list."""
        ui.run_javascript("window.location.reload()")

    # Add roommate button
    with ui.row().classes("mb-6"):

        def show_add_form():
            dialog = create_roommate_form(on_success=refresh_roommates)
            dialog.open()

        ui.button("Add Roommate", on_click=show_add_form, icon="person_add").classes(
            "bg-primary text-white px-4 py-2 rounded"
        )

    # Get all roommates (including inactive ones for management)
    try:
        # Get all roommates, not just active ones, for management purposes
        all_roommates = []
        active_roommates = RoommateService.get_all_active()
        all_roommates.extend(active_roommates)

        # Also get any inactive roommates by checking the database directly
        from app.database import get_session
        from sqlmodel import select
        from app.models import Roommate

        with get_session() as session:
            statement = select(Roommate).where(Roommate.is_active == False)
            inactive_roommates = list(session.exec(statement).all())
            all_roommates.extend(inactive_roommates)

        if not all_roommates:
            # Empty state
            with ui.column().classes("items-center justify-center p-12"):
                ui.label("🏡 No roommates yet...").classes("text-xl font-bold text-gray-600 mb-2")
                ui.label("Let's add your housemates to the wheel! 🤝").classes("text-gray-500")
                ui.label("Add your first roommate to get started with the chore wheel!").classes("text-gray-400")
        else:
            # Active roommates
            active_count = len([r for r in all_roommates if r.is_active])
            inactive_count = len([r for r in all_roommates if not r.is_active])

            ui.label(f"Active Roommates ({active_count})").classes(TextStyles.SUBHEADING)

            active_roommates_list = [r for r in all_roommates if r.is_active]
            if active_roommates_list:
                with ui.grid(columns=2).classes("gap-4 w-full mb-6"):
                    for roommate in active_roommates_list:
                        create_roommate_card(roommate, on_edit=refresh_roommates, on_delete=refresh_roommates)
            else:
                ui.label("No active roommates").classes("text-gray-500 mb-4")

            # Inactive roommates (if any)
            if inactive_count > 0:
                ui.label(f"Inactive Roommates ({inactive_count})").classes(TextStyles.SUBHEADING)
                inactive_roommates_list = [r for r in all_roommates if not r.is_active]

                with ui.grid(columns=2).classes("gap-4 w-full"):
                    for roommate in inactive_roommates_list:
                        create_roommate_card(roommate, on_edit=refresh_roommates, on_delete=refresh_roommates)

    except Exception as e:
        ui.label(f"Error loading roommates: {str(e)}").classes("text-red-600")


def create():
    """Create the roommates management page."""

    @ui.page("/roommates")
    def roommates():
        # Main layout with sidebar
        with ui.row().classes("w-full min-h-screen"):
            # Sidebar
            with ui.column().classes("w-64 bg-gray-800 text-white p-4 min-h-screen"):
                ui.label("🎯 Chore Wheel").classes("text-xl font-bold mb-6 text-white")

                # Navigation items
                nav_items = [
                    ("Dashboard", "/", "home"),
                    ("Roommates", "/roommates", "people"),
                    ("Chores", "/chores", "task_alt"),
                ]

                for item_name, item_path, icon in nav_items:
                    current_class = "bg-gray-700" if item_path == "/roommates" else ""

                    def create_nav_handler(path):
                        return lambda: ui.navigate.to(path)

                    ui.button(item_name, on_click=create_nav_handler(item_path), icon=icon).classes(
                        f"w-full text-left px-4 py-2 hover:bg-gray-700 rounded mb-2 {current_class}"
                    ).props("flat text-color=white align=left")

            # Main content area
            with ui.column().classes("flex-1 bg-gray-50 p-6 overflow-auto"):
                create_roommates_content()
