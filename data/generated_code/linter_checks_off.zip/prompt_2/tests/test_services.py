"""Tests for service layer business logic."""

import pytest
from datetime import date, timedelta
from app.database import reset_db
from app.services import RoommateService, ChoreService, WeeklyScheduleService, AssignmentService
from app.models import RoommateCreate, RoommateUpdate, ChoreCreate, ChoreUpdate, ChoreStatus


@pytest.fixture()
def new_db():
    """Provide a fresh database for each test."""
    reset_db()
    yield
    reset_db()


class TestRoommateService:
    """Test roommate service logic."""

    def test_create_roommate(self, new_db):
        """Test creating a new roommate."""
        roommate_data = RoommateCreate(name="Alice", email="alice@example.com")
        roommate = RoommateService.create(roommate_data)

        assert roommate.id is not None
        assert roommate.name == "Alice"
        assert roommate.email == "alice@example.com"
        assert roommate.is_active

    def test_create_roommate_without_email(self, new_db):
        """Test creating a roommate without email."""
        roommate_data = RoommateCreate(name="Bob")
        roommate = RoommateService.create(roommate_data)

        assert roommate.id is not None
        assert roommate.name == "Bob"
        assert roommate.email is None
        assert roommate.is_active

    def test_get_all_active_roommates(self, new_db):
        """Test retrieving only active roommates."""
        # Create active roommate
        active_data = RoommateCreate(name="Alice")
        active_roommate = RoommateService.create(active_data)

        # Create and deactivate another roommate
        inactive_data = RoommateCreate(name="Bob")
        inactive_roommate = RoommateService.create(inactive_data)
        if inactive_roommate.id is not None:
            RoommateService.delete(inactive_roommate.id)

        # Should only return active roommate
        active_roommates = RoommateService.get_all_active()
        assert len(active_roommates) == 1
        assert active_roommates[0].name == "Alice"
        assert active_roommates[0].is_active

    def test_update_roommate(self, new_db):
        """Test updating a roommate."""
        # Create roommate
        roommate_data = RoommateCreate(name="Alice", email="alice@example.com")
        roommate = RoommateService.create(roommate_data)

        # Update roommate
        if roommate.id is not None:
            update_data = RoommateUpdate(name="Alice Smith", email="alice.smith@example.com")
            updated_roommate = RoommateService.update(roommate.id, update_data)

            assert updated_roommate is not None
            assert updated_roommate.name == "Alice Smith"
            assert updated_roommate.email == "alice.smith@example.com"

    def test_update_nonexistent_roommate(self, new_db):
        """Test updating a roommate that doesn't exist."""
        update_data = RoommateUpdate(name="Ghost")
        result = RoommateService.update(999, update_data)
        assert result is None

    def test_soft_delete_roommate(self, new_db):
        """Test soft deleting a roommate."""
        # Create roommate
        roommate_data = RoommateCreate(name="Alice")
        roommate = RoommateService.create(roommate_data)

        # Delete roommate
        if roommate.id is not None:
            success = RoommateService.delete(roommate.id)
            assert success

            # Verify it's no longer in active list
            active_roommates = RoommateService.get_all_active()
            assert len(active_roommates) == 0

            # Verify it still exists but is inactive
            retrieved_roommate = RoommateService.get_by_id(roommate.id)
            assert retrieved_roommate is not None
            assert not retrieved_roommate.is_active


class TestChoreService:
    """Test chore service logic."""

    def test_create_chore_basic(self, new_db):
        """Test creating a basic chore."""
        chore_data = ChoreCreate(name="Vacuum living room")
        chore = ChoreService.create(chore_data)

        assert chore.id is not None
        assert chore.name == "Vacuum living room"
        assert chore.description is None
        assert chore.estimated_minutes is None
        assert chore.is_active

    def test_create_chore_with_details(self, new_db):
        """Test creating a chore with full details."""
        chore_data = ChoreCreate(
            name="Clean bathroom", description="Scrub toilet, shower, and sink. Mop floor.", estimated_minutes=45
        )
        chore = ChoreService.create(chore_data)

        assert chore.id is not None
        assert chore.name == "Clean bathroom"
        assert chore.description == "Scrub toilet, shower, and sink. Mop floor."
        assert chore.estimated_minutes == 45
        assert chore.is_active

    def test_get_all_active_chores(self, new_db):
        """Test retrieving only active chores."""
        # Create active chore
        active_data = ChoreCreate(name="Dishes")
        active_chore = ChoreService.create(active_data)

        # Create and deactivate another chore
        inactive_data = ChoreCreate(name="Laundry")
        inactive_chore = ChoreService.create(inactive_data)
        if inactive_chore.id is not None:
            ChoreService.delete(inactive_chore.id)

        # Should only return active chore
        active_chores = ChoreService.get_all_active()
        assert len(active_chores) == 1
        assert active_chores[0].name == "Dishes"
        assert active_chores[0].is_active

    def test_update_chore(self, new_db):
        """Test updating a chore."""
        # Create chore
        chore_data = ChoreCreate(name="Clean kitchen")
        chore = ChoreService.create(chore_data)

        # Update chore
        if chore.id is not None:
            update_data = ChoreUpdate(
                name="Deep clean kitchen", description="Clean appliances, counters, and floor", estimated_minutes=60
            )
            updated_chore = ChoreService.update(chore.id, update_data)

            assert updated_chore is not None
            assert updated_chore.name == "Deep clean kitchen"
            assert updated_chore.description == "Clean appliances, counters, and floor"
            assert updated_chore.estimated_minutes == 60


class TestWeeklyScheduleService:
    """Test weekly schedule service logic."""

    def test_get_current_week_start(self, new_db):
        """Test getting the start of the current week."""
        week_start = WeeklyScheduleService.get_current_week_start()

        # Should be a Monday
        assert week_start.weekday() == 0  # Monday is 0

        # Should be within the last 7 days
        today = date.today()
        assert (today - week_start).days <= 6

    def test_create_week(self, new_db):
        """Test creating a weekly schedule."""
        start_date = date(2024, 1, 1)  # A Monday
        schedule = WeeklyScheduleService.create_week(start_date)

        assert schedule.id is not None
        assert schedule.week_start_date == start_date
        assert schedule.week_end_date == start_date + timedelta(days=6)
        assert schedule.is_current

    def test_create_week_sets_current(self, new_db):
        """Test that creating a new week sets it as current and unsets others."""
        # Create first week
        first_date = date(2024, 1, 1)
        first_schedule = WeeklyScheduleService.create_week(first_date)
        assert first_schedule.is_current

        # Create second week
        second_date = date(2024, 1, 8)
        second_schedule = WeeklyScheduleService.create_week(second_date)
        assert second_schedule.is_current

        # Check that first week is no longer current
        current_week = WeeklyScheduleService.get_current_week()
        assert current_week is not None
        assert current_week.id == second_schedule.id

    def test_get_week_by_date(self, new_db):
        """Test getting a week by a date within it."""
        start_date = date(2024, 1, 1)
        schedule = WeeklyScheduleService.create_week(start_date)

        # Test with various dates in the week
        for i in range(7):
            test_date = start_date + timedelta(days=i)
            found_schedule = WeeklyScheduleService.get_week_by_date(test_date)
            assert found_schedule is not None
            assert found_schedule.id == schedule.id


class TestAssignmentService:
    """Test assignment service logic."""

    def test_generate_weekly_assignments_empty_data(self, new_db):
        """Test generating assignments with no roommates or chores."""
        result = AssignmentService.generate_weekly_assignments()
        assert result is None

    def test_generate_weekly_assignments_no_roommates(self, new_db):
        """Test generating assignments with chores but no roommates."""
        ChoreService.create(ChoreCreate(name="Dishes"))
        result = AssignmentService.generate_weekly_assignments()
        assert result is None

    def test_generate_weekly_assignments_no_chores(self, new_db):
        """Test generating assignments with roommates but no chores."""
        RoommateService.create(RoommateCreate(name="Alice"))
        result = AssignmentService.generate_weekly_assignments()
        assert result is None

    def test_generate_weekly_assignments_success(self, new_db):
        """Test successfully generating weekly assignments."""
        # Create roommates
        alice = RoommateService.create(RoommateCreate(name="Alice"))
        bob = RoommateService.create(RoommateCreate(name="Bob"))

        # Create chores
        dishes = ChoreService.create(ChoreCreate(name="Dishes"))
        vacuum = ChoreService.create(ChoreCreate(name="Vacuum"))
        trash = ChoreService.create(ChoreCreate(name="Trash"))

        # Generate assignments
        result = AssignmentService.generate_weekly_assignments()

        assert result is not None
        assert result.is_current

        # Check that assignments were created
        if result.id is not None:
            assignments = AssignmentService.get_assignments_for_week(result.id)
            assert len(assignments) == 3  # One for each chore

            # All assignments should be pending
            for assignment in assignments:
                assert assignment.status == ChoreStatus.PENDING
                assert assignment.completed_at is None

    def test_assignment_distribution(self, new_db):
        """Test that chores are distributed fairly among roommates."""
        # Create 2 roommates and 5 chores
        alice = RoommateService.create(RoommateCreate(name="Alice"))
        bob = RoommateService.create(RoommateCreate(name="Bob"))

        for i in range(5):
            ChoreService.create(ChoreCreate(name=f"Chore {i + 1}"))

        # Generate assignments
        result = AssignmentService.generate_weekly_assignments()
        assert result is not None

        if result.id is not None:
            assignments_by_roommate = AssignmentService.get_assignments_by_roommate(result.id)

            # Should have 2 roommates in the result
            assert len(assignments_by_roommate) == 2
            assert "Alice" in assignments_by_roommate
            assert "Bob" in assignments_by_roommate

            # Total assignments should equal total chores
            total_assignments = sum(len(chores) for chores in assignments_by_roommate.values())
            assert total_assignments == 5

            # Distribution should be relatively fair (difference of at most 1)
            alice_count = len(assignments_by_roommate["Alice"])
            bob_count = len(assignments_by_roommate["Bob"])
            assert abs(alice_count - bob_count) <= 1

    def test_complete_assignment(self, new_db):
        """Test marking an assignment as completed."""
        # Set up data
        alice = RoommateService.create(RoommateCreate(name="Alice"))
        dishes = ChoreService.create(ChoreCreate(name="Dishes"))

        # Generate assignments
        result = AssignmentService.generate_weekly_assignments()
        assert result is not None

        if result.id is not None:
            assignments = AssignmentService.get_assignments_for_week(result.id)
            assert len(assignments) == 1

            assignment = assignments[0]
            if assignment.id is not None:
                # Complete the assignment
                success = AssignmentService.complete_assignment(assignment.id, "All clean!")
                assert success

                # Verify the assignment is marked as completed
                updated_assignments = AssignmentService.get_assignments_for_week(result.id)
                updated_assignment = updated_assignments[0]

                assert updated_assignment.status == ChoreStatus.COMPLETED
                assert updated_assignment.completed_at is not None
                assert updated_assignment.notes == "All clean!"

    def test_complete_nonexistent_assignment(self, new_db):
        """Test completing an assignment that doesn't exist."""
        success = AssignmentService.complete_assignment(999)
        assert not success

    def test_prevent_duplicate_weekly_assignments(self, new_db):
        """Test that generating assignments twice doesn't create duplicates."""
        # Set up data
        alice = RoommateService.create(RoommateCreate(name="Alice"))
        dishes = ChoreService.create(ChoreCreate(name="Dishes"))

        # Generate assignments twice
        first_result = AssignmentService.generate_weekly_assignments()
        second_result = AssignmentService.generate_weekly_assignments()

        assert first_result is not None
        assert second_result is not None
        assert first_result.id == second_result.id

        # Should still only have one assignment
        if first_result.id is not None:
            assignments = AssignmentService.get_assignments_for_week(first_result.id)
            assert len(assignments) == 1
