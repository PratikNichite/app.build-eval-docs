import pytest
from nicegui.testing import User
from nicegui import ui

from app.database import reset_db
from app.joke_service import JokeService
from app.models import JokeCreate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


class TestJokeCollectorUI:
    """Test suite for Joke Collector UI components."""

    async def test_main_page_loads(self, user: User, new_db) -> None:
        """Test that the main page loads correctly."""
        await user.open("/")

        # Check for main elements
        await user.should_see("🎭 Joke Collector")
        await user.should_see("Collect and manage your favorite jokes")
        await user.should_see("Get Random Joke")

    async def test_empty_state_display(self, user: User, new_db) -> None:
        """Test that empty state is displayed when no jokes exist."""
        await user.open("/")

        await user.should_see("No jokes yet!")
        await user.should_see('Click "Get Random Joke" to add your first joke.')

    async def test_jokes_display_with_data(self, user: User, new_db) -> None:
        """Test that jokes are displayed when they exist in database."""
        # Create test jokes
        JokeService.create_joke(
            JokeCreate(
                setup="Why don't scientists trust atoms?",
                punchline="Because they make up everything!",
                user_comment="Great chemistry joke!",
            )
        )

        JokeService.create_joke(
            JokeCreate(setup="What do you call a fake noodle?", punchline="An impasta!", user_comment="")
        )

        await user.open("/")

        # Check that both jokes are displayed
        await user.should_see("Why don't scientists trust atoms?")
        await user.should_see("Because they make up everything!")
        await user.should_see("Great chemistry joke!")

        await user.should_see("What do you call a fake noodle?")
        await user.should_see("An impasta!")

        # Should not see empty state
        await user.should_not_see("No jokes yet!")

    async def test_comment_update_functionality(self, user: User, new_db) -> None:
        """Test updating a joke's comment through the UI."""
        # Create a test joke
        joke = JokeService.create_joke(
            JokeCreate(setup="Test setup", punchline="Test punchline", user_comment="Original comment")
        )

        await user.open("/")

        # Find and update comment input
        comment_inputs = list(user.find(ui.input).elements)
        comment_input = None
        for inp in comment_inputs:
            if inp.value == "Original comment":
                comment_input = inp
                break

        assert comment_input is not None
        comment_input.set_value("Updated comment")

        # Click update button
        user.find("Update").click()

        # Check for success notification
        await user.should_see("Comment updated successfully!")

        # Verify comment was updated in database
        if joke.id is not None:
            updated_joke = JokeService.get_joke_by_id(joke.id)
            assert updated_joke is not None
            assert updated_joke.user_comment == "Updated comment"

    async def test_joke_deletion_cancellation(self, user: User, new_db) -> None:
        """Test cancelling joke deletion."""
        # Create a test joke
        joke = JokeService.create_joke(
            JokeCreate(setup="Joke to not delete", punchline="Don't delete me!", user_comment="Should remain")
        )

        await user.open("/")

        # Click delete button
        user.find("Delete").click()

        # Should see confirmation dialog
        await user.should_see("Are you sure you want to delete this joke?")

        # Cancel deletion
        user.find("Cancel").click()

        # Joke should still exist
        if joke.id is not None:
            remaining_joke = JokeService.get_joke_by_id(joke.id)
            assert remaining_joke is not None
            assert remaining_joke.setup == "Joke to not delete"

        # Should still see the joke on the page
        await user.should_see("Joke to not delete")

    async def test_fetch_random_joke_from_real_api(self, user: User, new_db) -> None:
        """Test fetching a random joke from real API."""
        await user.open("/")

        # Click the "Get Random Joke" button
        user.find("Get Random Joke").click()

        # Wait a moment for the API call to complete
        import asyncio

        await asyncio.sleep(2)

        # Check if we got a success or error message
        # We'll accept either since real API might be down
        try:
            await user.should_see("New joke added to your collection!")
            # If successful, should not see empty state anymore
            await user.should_not_see("No jokes yet!")
        except AssertionError:
            # If API failed, should see error message
            await user.should_see("Error: Could not fetch joke from API")

    async def test_joke_metadata_display(self, user: User, new_db) -> None:
        """Test that joke metadata (creation date) is displayed."""
        # Create a test joke
        JokeService.create_joke(JokeCreate(setup="Test setup", punchline="Test punchline", user_comment="Test comment"))

        await user.open("/")

        # Should see creation date (format: YYYY-MM-DD HH:MM)
        await user.should_see("Added:")
        # The actual date will vary, but the format should be consistent

    async def test_multiple_jokes_ordering(self, user: User, new_db) -> None:
        """Test that multiple jokes are displayed in correct order (newest first)."""
        import time

        # Create jokes with slight delays to ensure different timestamps
        joke1 = JokeService.create_joke(
            JokeCreate(setup="First joke setup", punchline="First punchline", user_comment="First comment")
        )

        time.sleep(0.01)

        joke2 = JokeService.create_joke(
            JokeCreate(setup="Second joke setup", punchline="Second punchline", user_comment="Second comment")
        )

        await user.open("/")

        # Both jokes should be visible
        await user.should_see("First joke setup")
        await user.should_see("Second joke setup")

        # Verify jokes exist in database in correct order
        jokes = JokeService.get_all_jokes()
        assert len(jokes) == 2
        assert jokes[0].setup == "Second joke setup"  # Newest first
        assert jokes[1].setup == "First joke setup"
