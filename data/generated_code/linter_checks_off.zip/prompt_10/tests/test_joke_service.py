import pytest

from app.database import reset_db
from app.joke_service import JokeService
from app.models import JokeCreate, JokeUpdate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


class TestJokeService:
    """Test suite for JokeService functionality."""

    def test_create_and_get_joke(self, new_db):
        """Test creating and retrieving a joke."""
        joke_data = JokeCreate(
            setup="Why don't scientists trust atoms?",
            punchline="Because they make up everything!",
            user_comment="Classic chemistry joke",
        )

        # Create joke
        created_joke = JokeService.create_joke(joke_data)

        assert created_joke.id is not None
        assert created_joke.setup == joke_data.setup
        assert created_joke.punchline == joke_data.punchline
        assert created_joke.user_comment == joke_data.user_comment
        assert created_joke.created_at is not None
        assert created_joke.updated_at is not None

        # Retrieve joke
        if created_joke.id is not None:
            retrieved_joke = JokeService.get_joke_by_id(created_joke.id)
            assert retrieved_joke is not None
            assert retrieved_joke.setup == joke_data.setup
            assert retrieved_joke.punchline == joke_data.punchline

    def test_get_all_jokes_empty(self, new_db):
        """Test getting all jokes when database is empty."""
        jokes = JokeService.get_all_jokes()
        assert jokes == []

    def test_get_all_jokes_multiple(self, new_db):
        """Test getting all jokes when multiple exist."""
        # Create multiple jokes
        joke1 = JokeService.create_joke(JokeCreate(setup="Setup 1", punchline="Punchline 1", user_comment="Comment 1"))
        joke2 = JokeService.create_joke(JokeCreate(setup="Setup 2", punchline="Punchline 2", user_comment="Comment 2"))

        jokes = JokeService.get_all_jokes()
        assert len(jokes) == 2

        # Should be ordered by creation date (newest first)
        assert jokes[0].id == joke2.id
        assert jokes[1].id == joke1.id

    def test_get_joke_by_id_not_found(self, new_db):
        """Test getting a joke that doesn't exist."""
        joke = JokeService.get_joke_by_id(999)
        assert joke is None

    def test_update_joke_comment(self, new_db):
        """Test updating a joke's user comment."""
        # Create initial joke
        joke = JokeService.create_joke(
            JokeCreate(
                setup="Why did the chicken cross the road?",
                punchline="To get to the other side!",
                user_comment="Original comment",
            )
        )

        original_updated_at = joke.updated_at

        # Update comment
        update_data = JokeUpdate(user_comment="Updated comment")
        if joke.id is not None:
            updated_joke = JokeService.update_joke_comment(joke.id, update_data)

            assert updated_joke is not None
            assert updated_joke.user_comment == "Updated comment"
            assert updated_joke.setup == joke.setup  # Unchanged
            assert updated_joke.punchline == joke.punchline  # Unchanged
            assert updated_joke.updated_at > original_updated_at

    def test_update_joke_comment_not_found(self, new_db):
        """Test updating comment for non-existent joke."""
        update_data = JokeUpdate(user_comment="New comment")
        result = JokeService.update_joke_comment(999, update_data)
        assert result is None

    def test_update_joke_comment_none_value(self, new_db):
        """Test updating joke with None comment value (should not change)."""
        joke = JokeService.create_joke(JokeCreate(setup="Setup", punchline="Punchline", user_comment="Original"))

        original_comment = joke.user_comment
        original_updated_at = joke.updated_at

        # Update with None should not change anything
        update_data = JokeUpdate(user_comment=None)
        if joke.id is not None:
            updated_joke = JokeService.update_joke_comment(joke.id, update_data)

            assert updated_joke is not None
            assert updated_joke.user_comment == original_comment
            assert updated_joke.updated_at == original_updated_at

    def test_delete_joke(self, new_db):
        """Test deleting a joke."""
        joke = JokeService.create_joke(JokeCreate(setup="Setup", punchline="Punchline", user_comment="Comment"))

        # Delete joke
        if joke.id is not None:
            success = JokeService.delete_joke(joke.id)
            assert success

            # Verify joke is gone
            retrieved_joke = JokeService.get_joke_by_id(joke.id)
            assert retrieved_joke is None

    def test_delete_joke_not_found(self, new_db):
        """Test deleting a non-existent joke."""
        success = JokeService.delete_joke(999)
        assert not success

    @pytest.mark.asyncio
    async def test_fetch_random_joke_success(self, new_db):
        """Test successfully fetching a random joke from real API."""
        # Fetch joke from real API
        joke = await JokeService.fetch_random_joke()

        # Verify joke was created (real API should work)
        if joke is not None:  # API might be down, so we test conditionally
            assert joke.setup != ""
            assert joke.punchline != ""
            assert joke.user_comment == ""
            assert joke.id is not None

            # Verify it's in database
            all_jokes = JokeService.get_all_jokes()
            assert len(all_jokes) == 1
            assert all_jokes[0].setup == joke.setup
        else:
            # If API is down, just check that no jokes were created
            all_jokes = JokeService.get_all_jokes()
            assert len(all_jokes) == 0

    def test_joke_ordering_by_creation_time(self, new_db):
        """Test that jokes are returned in correct order (newest first)."""
        # Create jokes with slight delay to ensure different timestamps
        import time

        joke1 = JokeService.create_joke(JokeCreate(setup="First joke", punchline="First punchline", user_comment=""))

        time.sleep(0.01)  # Small delay

        joke2 = JokeService.create_joke(JokeCreate(setup="Second joke", punchline="Second punchline", user_comment=""))

        time.sleep(0.01)  # Small delay

        joke3 = JokeService.create_joke(JokeCreate(setup="Third joke", punchline="Third punchline", user_comment=""))

        jokes = JokeService.get_all_jokes()

        # Should be in reverse chronological order (newest first)
        assert len(jokes) == 3
        assert jokes[0].id == joke3.id
        assert jokes[1].id == joke2.id
        assert jokes[2].id == joke1.id
