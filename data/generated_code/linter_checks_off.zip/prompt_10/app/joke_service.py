from datetime import datetime
from typing import Optional
import httpx
from sqlmodel import select, desc

from app.database import get_session
from app.models import Joke, JokeCreate, JokeUpdate, ExternalJokeAPI


class JokeService:
    """Service class for managing jokes in the database and fetching from external API."""

    @staticmethod
    def get_all_jokes() -> list[Joke]:
        """Retrieve all jokes from the database, ordered by creation date (newest first)."""
        with get_session() as session:
            statement = select(Joke).order_by(desc(Joke.created_at))
            return list(session.exec(statement))

    @staticmethod
    def get_joke_by_id(joke_id: int) -> Optional[Joke]:
        """Retrieve a specific joke by its ID."""
        with get_session() as session:
            return session.get(Joke, joke_id)

    @staticmethod
    def create_joke(joke_data: JokeCreate) -> Joke:
        """Create a new joke in the database."""
        with get_session() as session:
            joke = Joke(
                setup=joke_data.setup,
                punchline=joke_data.punchline,
                user_comment=joke_data.user_comment,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )
            session.add(joke)
            session.commit()
            session.refresh(joke)
            return joke

    @staticmethod
    def update_joke_comment(joke_id: int, comment_data: JokeUpdate) -> Optional[Joke]:
        """Update the user comment for a specific joke."""
        with get_session() as session:
            joke = session.get(Joke, joke_id)
            if joke is None:
                return None

            if comment_data.user_comment is not None:
                joke.user_comment = comment_data.user_comment
                joke.updated_at = datetime.utcnow()
                session.add(joke)
                session.commit()
                session.refresh(joke)

            return joke

    @staticmethod
    def delete_joke(joke_id: int) -> bool:
        """Delete a joke from the database. Returns True if successful, False if joke not found."""
        with get_session() as session:
            joke = session.get(Joke, joke_id)
            if joke is None:
                return False

            session.delete(joke)
            session.commit()
            return True

    @staticmethod
    async def fetch_random_joke() -> Optional[Joke]:
        """Fetch a random joke from the Official Joke API and save it to the database."""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get("https://official-joke-api.appspot.com/random_joke")
                response.raise_for_status()

                joke_data = response.json()
                external_joke = ExternalJokeAPI(**joke_data)

                # Create a new joke in the database
                joke_create = JokeCreate(setup=external_joke.setup, punchline=external_joke.punchline, user_comment="")

                return JokeService.create_joke(joke_create)

        except Exception as e:
            print(f"Error fetching random joke: {e}")
            return None
