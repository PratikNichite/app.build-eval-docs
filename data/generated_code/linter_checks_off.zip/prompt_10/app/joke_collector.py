from nicegui import ui
from typing import Optional

from app.joke_service import JokeService
from app.models import Joke, JokeUpdate


class JokeCollectorUI:
    """UI component for the Joke Collector application."""

    def __init__(self):
        self.jokes_container: Optional[ui.column] = None
        self.loading_indicator: Optional[ui.spinner] = None

    def create_joke_card(self, joke: Joke) -> None:
        """Create a card component for displaying a single joke."""
        with ui.card().classes(
            "w-full max-w-2xl p-6 mb-4 shadow-lg rounded-xl bg-white hover:shadow-xl transition-shadow"
        ):
            # Joke content
            ui.label(joke.setup).classes("text-lg font-semibold text-gray-800 mb-2")
            ui.label(joke.punchline).classes("text-base text-gray-700 mb-4 italic")

            # User comment section
            with ui.row().classes("w-full items-center gap-4 mb-4"):
                ui.label("Your comment:").classes("text-sm font-medium text-gray-600")
                comment_input = ui.input(
                    value=joke.user_comment, placeholder="Add your comment about this joke..."
                ).classes("flex-1")

                # Edit comment button
                ui.button(
                    "Update",
                    on_click=lambda _, j_id=joke.id, inp=comment_input: self.update_comment(j_id, inp.value)
                    if j_id is not None
                    else None,
                    color="primary",
                ).classes("px-4 py-2").props("outline")

            # Action buttons
            with ui.row().classes("justify-end gap-2"):
                ui.button(
                    "Delete",
                    on_click=lambda _, j_id=joke.id: self.delete_joke_with_confirmation(j_id)
                    if j_id is not None
                    else None,
                    color="negative",
                ).classes("px-4 py-2").props("outline")

            # Metadata
            ui.label(f"Added: {joke.created_at.strftime('%Y-%m-%d %H:%M')}").classes("text-xs text-gray-400")

    def render_jokes_list(self) -> None:
        """Render the list of all jokes."""
        if self.jokes_container is None:
            return

        self.jokes_container.clear()

        jokes = JokeService.get_all_jokes()

        if not jokes:
            with self.jokes_container:
                with ui.card().classes("w-full max-w-2xl p-8 text-center shadow-lg rounded-xl bg-gray-50"):
                    ui.icon("sentiment_very_satisfied").classes("text-6xl text-gray-400 mb-4")
                    ui.label("No jokes yet!").classes("text-xl font-semibold text-gray-600 mb-2")
                    ui.label('Click "Get Random Joke" to add your first joke.').classes("text-gray-500")
        else:
            with self.jokes_container:
                for joke in jokes:
                    self.create_joke_card(joke)

    def update_comment(self, joke_id: Optional[int], new_comment: str) -> None:
        """Update the user comment for a joke."""
        if joke_id is None:
            ui.notify("Error: Invalid joke ID ⚠️", type="negative")
            return

        comment_update = JokeUpdate(user_comment=new_comment)
        updated_joke = JokeService.update_joke_comment(joke_id, comment_update)

        if updated_joke:
            ui.notify("Comment updated successfully! ✨", type="positive")
            self.render_jokes_list()
        else:
            ui.notify("Error: Could not update comment ❌", type="negative")

    async def delete_joke_with_confirmation(self, joke_id: Optional[int]) -> None:
        """Delete a joke after user confirmation."""
        if joke_id is None:
            ui.notify("Error: Invalid joke ID ⚠️", type="negative")
            return

        with ui.dialog() as dialog, ui.card().classes("p-6"):
            ui.label("Are you sure you want to delete this joke?").classes("text-lg font-semibold mb-4")
            ui.label("This action cannot be undone.").classes("text-gray-600 mb-6")

            with ui.row().classes("justify-end gap-2"):
                ui.button("Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
                ui.button("Delete", on_click=lambda: dialog.submit("delete"), color="negative")

        result = await dialog

        if result == "delete":
            success = JokeService.delete_joke(joke_id)
            if success:
                ui.notify("Joke deleted successfully! ✅", type="positive")
                self.render_jokes_list()
            else:
                ui.notify("Error: Could not delete joke 🗑️", type="negative")

    async def fetch_random_joke(self) -> None:
        """Fetch a random joke from the API and add it to the collection."""
        # Show loading state
        if self.loading_indicator:
            self.loading_indicator.set_visibility(True)

        try:
            new_joke = await JokeService.fetch_random_joke()

            if new_joke:
                ui.notify("New joke added to your collection! 😂", type="positive")
                self.render_jokes_list()
            else:
                ui.notify("Error: Could not fetch joke from API 😅", type="negative")

        finally:
            # Hide loading state
            if self.loading_indicator:
                self.loading_indicator.set_visibility(False)

    def create_page(self) -> None:
        """Create the main page layout."""
        # Apply modern theme
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        # Header
        with ui.row().classes("w-full justify-center mb-8"):
            with ui.card().classes(
                "w-full max-w-4xl p-6 shadow-lg rounded-xl bg-gradient-to-r from-blue-500 to-purple-600"
            ):
                ui.label("🎭 Joke Collector").classes("text-3xl font-bold text-white text-center mb-2")
                ui.label("Collect and manage your favorite jokes").classes("text-blue-100 text-center")

        # Action button
        with ui.row().classes("w-full justify-center mb-6"):
            with ui.column().classes("items-center gap-4"):
                ui.button("Get Random Joke", on_click=self.fetch_random_joke, color="primary").classes(
                    "px-8 py-3 text-lg font-semibold shadow-lg hover:shadow-xl transition-shadow"
                ).props("size=lg")

                # Loading indicator (hidden by default)
                self.loading_indicator = ui.spinner(size="md").classes("text-primary")
                self.loading_indicator.set_visibility(False)

        # Jokes container
        with ui.column().classes("w-full items-center"):
            self.jokes_container = ui.column().classes("w-full max-w-4xl items-center")

        # Initial load of jokes
        self.render_jokes_list()


def create():
    """Create the joke collector page."""

    @ui.page("/")
    def index():
        joke_ui = JokeCollectorUI()
        joke_ui.create_page()
