from sqlmodel import SQLModel, Field
from datetime import datetime
from typing import Optional


# Persistent models (stored in database)
class Joke(SQLModel, table=True):
    __tablename__ = "jokes"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    setup: str = Field(max_length=500)
    punchline: str = Field(max_length=500)
    user_comment: str = Field(default="", max_length=1000)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class JokeCreate(SQLModel, table=False):
    setup: str = Field(max_length=500)
    punchline: str = Field(max_length=500)
    user_comment: str = Field(default="", max_length=1000)


class JokeUpdate(SQLModel, table=False):
    user_comment: Optional[str] = Field(default=None, max_length=1000)


class JokeResponse(SQLModel, table=False):
    id: int
    setup: str
    punchline: str
    user_comment: str
    created_at: str
    updated_at: str


# Schema for API response from Official Joke API
class ExternalJokeAPI(SQLModel, table=False):
    setup: str
    punchline: str
    type: str
    id: int
