import pytest
from app.database import reset_db
from app.models import MovieCreate, WatchStatus
from app.movie_service import create_movie


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_movie_watchlist_module_imports(new_db):
    """Test that the movie watchlist module can be imported without errors"""
    try:
        import app.movie_watchlist

        # If we can import it, the module structure is correct
        assert hasattr(app.movie_watchlist, "create")
        assert callable(app.movie_watchlist.create)
    except Exception as e:
        pytest.fail(f"Failed to import movie_watchlist module: {e}")


def test_movie_watchlist_create_function_exists(new_db):
    """Test that the create function exists and can be called"""
    import app.movie_watchlist

    # The create function should exist
    assert hasattr(app.movie_watchlist, "create")
    assert callable(app.movie_watchlist.create)


def test_integration_with_movie_service(new_db):
    """Test that movie service integration works correctly"""
    # Create test movies
    movies = [
        MovieCreate(title="Test Movie 1", director="Director 1", release_year=2020, watch_status=WatchStatus.PLANNED),
        MovieCreate(title="Test Movie 2", director="Director 2", release_year=2021, watch_status=WatchStatus.WATCHING),
        MovieCreate(title="Test Movie 3", director="Director 3", release_year=2022, watch_status=WatchStatus.COMPLETED),
    ]

    created_movies = []
    for movie_data in movies:
        created_movie = create_movie(movie_data)
        created_movies.append(created_movie)

    # Verify movies were created
    assert len(created_movies) == 3

    # Verify movie data
    assert created_movies[0].title == "Test Movie 1"
    assert created_movies[0].watch_status == WatchStatus.PLANNED

    assert created_movies[1].title == "Test Movie 2"
    assert created_movies[1].watch_status == WatchStatus.WATCHING

    assert created_movies[2].title == "Test Movie 3"
    assert created_movies[2].watch_status == WatchStatus.COMPLETED


def test_all_watch_statuses_available(new_db):
    """Test that all watch statuses from the enum are available"""
    from app.models import WatchStatus

    # Test that all expected statuses exist
    statuses = [WatchStatus.PLANNED, WatchStatus.WATCHING, WatchStatus.COMPLETED]

    for status in statuses:
        # Should be able to create a movie with each status
        movie_data = MovieCreate(
            title=f"Movie {status.value}", director="Test Director", release_year=2023, watch_status=status
        )

        created_movie = create_movie(movie_data)
        assert created_movie.watch_status == status


def test_helper_functions_exist(new_db):
    """Test that all helper functions are defined"""
    import app.movie_watchlist

    # Check that helper functions exist
    helper_functions = [
        "create_metric_card",
        "create_add_movie_form",
        "create_movies_table",
        "filter_movies",
        "show_edit_dialog",
        "show_delete_dialog",
    ]

    for func_name in helper_functions:
        assert hasattr(app.movie_watchlist, func_name), f"Missing function: {func_name}"
        assert callable(getattr(app.movie_watchlist, func_name)), f"Function {func_name} is not callable"


def test_database_operations_work_correctly(new_db):
    """Test that database operations work correctly with realistic data"""
    # Test creating a movie
    movie_data = MovieCreate(
        title="The Shawshank Redemption", director="Frank Darabont", release_year=1994, watch_status=WatchStatus.PLANNED
    )

    created_movie = create_movie(movie_data)
    assert created_movie.id is not None
    assert created_movie.title == "The Shawshank Redemption"
    assert created_movie.director == "Frank Darabont"
    assert created_movie.release_year == 1994
    assert created_movie.watch_status == WatchStatus.PLANNED

    # Test that we can fetch all movies
    from app.movie_service import get_all_movies

    all_movies = get_all_movies()
    assert len(all_movies) == 1
    assert all_movies[0].title == "The Shawshank Redemption"
