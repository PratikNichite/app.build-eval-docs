import pytest
from datetime import datetime

from app.database import reset_db
from app.models import MovieCreate, MovieUpdate, WatchStatus
from app.movie_service import (
    get_all_movies,
    create_movie,
    get_movie_by_id,
    update_movie,
    delete_movie,
    get_movies_by_status,
)


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_create_movie(new_db):
    """Test creating a new movie"""
    movie_data = MovieCreate(
        title="The Matrix", director="Lana Wachowski", release_year=1999, watch_status=WatchStatus.PLANNED
    )

    movie = create_movie(movie_data)

    assert movie.id is not None
    assert movie.title == "The Matrix"
    assert movie.director == "Lana Wachowski"
    assert movie.release_year == 1999
    assert movie.watch_status == WatchStatus.PLANNED
    assert isinstance(movie.created_at, datetime)
    assert isinstance(movie.updated_at, datetime)


def test_get_all_movies_empty(new_db):
    """Test getting all movies when database is empty"""
    movies = get_all_movies()
    assert movies == []


def test_get_all_movies_with_data(new_db):
    """Test getting all movies with data in database"""
    # Create test movies
    movie1_data = MovieCreate(title="Movie 1", director="Director 1", release_year=2020)
    movie2_data = MovieCreate(title="Movie 2", director="Director 2", release_year=2021)

    create_movie(movie1_data)
    create_movie(movie2_data)

    movies = get_all_movies()

    assert len(movies) == 2
    # Should be ordered by created_at desc (newest first)
    assert movies[0].title == "Movie 2"
    assert movies[1].title == "Movie 1"


def test_get_movie_by_id_existing(new_db):
    """Test getting a movie by valid ID"""
    movie_data = MovieCreate(title="Inception", director="Christopher Nolan", release_year=2010)

    created_movie = create_movie(movie_data)
    if created_movie.id is not None:
        retrieved_movie = get_movie_by_id(created_movie.id)

        assert retrieved_movie is not None
        assert retrieved_movie.id == created_movie.id
        assert retrieved_movie.title == "Inception"


def test_get_movie_by_id_nonexistent(new_db):
    """Test getting a movie by non-existent ID"""
    movie = get_movie_by_id(999)
    assert movie is None


def test_update_movie_success(new_db):
    """Test updating an existing movie"""
    # Create initial movie
    movie_data = MovieCreate(
        title="Original Title", director="Original Director", release_year=2020, watch_status=WatchStatus.PLANNED
    )
    created_movie = create_movie(movie_data)
    original_updated_at = created_movie.updated_at

    if created_movie.id is not None:
        # Update the movie
        update_data = MovieUpdate(title="Updated Title", watch_status=WatchStatus.COMPLETED)

        updated_movie = update_movie(created_movie.id, update_data)

        assert updated_movie is not None
        assert updated_movie.id == created_movie.id
        assert updated_movie.title == "Updated Title"
        assert updated_movie.director == "Original Director"  # Unchanged
        assert updated_movie.release_year == 2020  # Unchanged
        assert updated_movie.watch_status == WatchStatus.COMPLETED
        assert updated_movie.updated_at > original_updated_at


def test_update_movie_partial(new_db):
    """Test updating only some fields of a movie"""
    movie_data = MovieCreate(title="Test Movie", director="Test Director", release_year=2022)
    created_movie = create_movie(movie_data)

    if created_movie.id is not None:
        # Update only the status
        update_data = MovieUpdate(watch_status=WatchStatus.WATCHING)
        updated_movie = update_movie(created_movie.id, update_data)

        assert updated_movie is not None
        assert updated_movie.title == "Test Movie"  # Unchanged
        assert updated_movie.director == "Test Director"  # Unchanged
        assert updated_movie.release_year == 2022  # Unchanged
        assert updated_movie.watch_status == WatchStatus.WATCHING  # Changed


def test_update_movie_nonexistent(new_db):
    """Test updating a non-existent movie"""
    update_data = MovieUpdate(title="New Title")
    result = update_movie(999, update_data)
    assert result is None


def test_update_movie_no_changes(new_db):
    """Test updating a movie with no actual changes"""
    movie_data = MovieCreate(title="Test Movie", director="Test Director", release_year=2022)
    created_movie = create_movie(movie_data)

    if created_movie.id is not None:
        # Empty update
        update_data = MovieUpdate()
        updated_movie = update_movie(created_movie.id, update_data)

        assert updated_movie is not None
        assert updated_movie.title == created_movie.title
        assert updated_movie.updated_at == created_movie.updated_at  # Should not change


def test_delete_movie_success(new_db):
    """Test deleting an existing movie"""
    movie_data = MovieCreate(title="To Delete", director="Director", release_year=2020)
    created_movie = create_movie(movie_data)

    if created_movie.id is not None:
        # Confirm movie exists
        assert get_movie_by_id(created_movie.id) is not None

        # Delete the movie
        result = delete_movie(created_movie.id)
        assert result is True

        # Confirm movie is deleted
        assert get_movie_by_id(created_movie.id) is None


def test_delete_movie_nonexistent(new_db):
    """Test deleting a non-existent movie"""
    result = delete_movie(999)
    assert result is False


def test_get_movies_by_status(new_db):
    """Test filtering movies by watch status"""
    # Create movies with different statuses
    planned_movie = create_movie(
        MovieCreate(title="Planned Movie", director="Director 1", release_year=2020, watch_status=WatchStatus.PLANNED)
    )
    watching_movie = create_movie(
        MovieCreate(title="Watching Movie", director="Director 2", release_year=2021, watch_status=WatchStatus.WATCHING)
    )
    completed_movie = create_movie(
        MovieCreate(
            title="Completed Movie", director="Director 3", release_year=2022, watch_status=WatchStatus.COMPLETED
        )
    )

    # Test filtering by each status
    planned_movies = get_movies_by_status(WatchStatus.PLANNED)
    assert len(planned_movies) == 1
    assert planned_movies[0].title == "Planned Movie"

    watching_movies = get_movies_by_status(WatchStatus.WATCHING)
    assert len(watching_movies) == 1
    assert watching_movies[0].title == "Watching Movie"

    completed_movies = get_movies_by_status(WatchStatus.COMPLETED)
    assert len(completed_movies) == 1
    assert completed_movies[0].title == "Completed Movie"


def test_get_movies_by_status_empty(new_db):
    """Test filtering by status when no movies match"""
    movies = get_movies_by_status(WatchStatus.PLANNED)
    assert movies == []


def test_movie_create_validation():
    """Test MovieCreate schema validation"""
    # Valid data
    valid_data = MovieCreate(
        title="Valid Movie", director="Valid Director", release_year=2023, watch_status=WatchStatus.PLANNED
    )
    assert valid_data.title == "Valid Movie"

    # Test default status
    default_status = MovieCreate(title="Default Status Movie", director="Director", release_year=2023)
    assert default_status.watch_status == WatchStatus.PLANNED


def test_movie_update_validation():
    """Test MovieUpdate schema validation"""
    # All fields None by default
    empty_update = MovieUpdate()
    assert empty_update.title is None
    assert empty_update.director is None
    assert empty_update.release_year is None
    assert empty_update.watch_status is None

    # Partial update
    partial_update = MovieUpdate(title="New Title")
    assert partial_update.title == "New Title"
    assert partial_update.director is None


def test_watch_status_enum():
    """Test WatchStatus enum values"""
    assert WatchStatus.PLANNED == "Planned"
    assert WatchStatus.WATCHING == "Watching"
    assert WatchStatus.COMPLETED == "Completed"

    # Test all enum values are accessible
    all_statuses = [WatchStatus.PLANNED, WatchStatus.WATCHING, WatchStatus.COMPLETED]
    assert len(all_statuses) == 3
