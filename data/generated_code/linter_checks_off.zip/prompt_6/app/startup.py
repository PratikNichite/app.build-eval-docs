from app.database import create_tables
import app.movie_watchlist


def startup() -> None:
    # this function is called before the first request
    create_tables()
    app.movie_watchlist.create()
