from typing import Optional
from sqlmodel import select, desc
from datetime import datetime

from app.database import get_session
from app.models import Movie, MovieCreate, MovieUpdate, WatchStatus


def get_all_movies() -> list[Movie]:
    """Retrieve all movies from the database"""
    with get_session() as session:
        statement = select(Movie).order_by(desc(Movie.created_at))
        movies = session.exec(statement).all()
        return list(movies)


def create_movie(movie_data: MovieCreate) -> Movie:
    """Create a new movie entry"""
    with get_session() as session:
        movie = Movie(**movie_data.model_dump())
        session.add(movie)
        session.commit()
        session.refresh(movie)
        return movie


def get_movie_by_id(movie_id: int) -> Optional[Movie]:
    """Get a movie by its ID"""
    with get_session() as session:
        movie = session.get(Movie, movie_id)
        return movie


def update_movie(movie_id: int, movie_update: MovieUpdate) -> Optional[Movie]:
    """Update an existing movie"""
    with get_session() as session:
        movie = session.get(Movie, movie_id)
        if movie is None:
            return None

        update_data = movie_update.model_dump(exclude_unset=True)
        if update_data:
            for field, value in update_data.items():
                setattr(movie, field, value)
            movie.updated_at = datetime.utcnow()
            session.add(movie)
            session.commit()
            session.refresh(movie)

        return movie


def delete_movie(movie_id: int) -> bool:
    """Delete a movie by ID"""
    with get_session() as session:
        movie = session.get(Movie, movie_id)
        if movie is None:
            return False

        session.delete(movie)
        session.commit()
        return True


def get_movies_by_status(status: WatchStatus) -> list[Movie]:
    """Get movies filtered by watch status"""
    with get_session() as session:
        statement = select(Movie).where(Movie.watch_status == status).order_by(desc(Movie.created_at))
        movies = session.exec(statement).all()
        return list(movies)
