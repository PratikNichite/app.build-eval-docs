from nicegui import ui
from typing import Optional

from app.models import MovieCreate, MovieUpdate, WatchStatus
from app.movie_service import get_all_movies, create_movie, update_movie, delete_movie


def create():
    # Apply modern theme
    ui.colors(
        primary="#2563eb",
        secondary="#64748b",
        accent="#10b981",
        positive="#10b981",
        negative="#ef4444",
        warning="#f59e0b",
        info="#3b82f6",
    )

    # Define page function but don't execute UI creation logic yet
    @ui.page("/")
    def movie_watchlist_page():
        # Page header
        with ui.row().classes("w-full justify-between items-center mb-8"):
            ui.label("🎬 Movie Watchlist Manager").classes("text-3xl font-bold text-gray-800")
            ui.label("Track your movies to watch").classes("text-lg text-gray-600")
            ui.label("Your cinematic journey starts here! ✨🍿").classes("text-base text-gray-500 mt-2")

        # Statistics cards
        movies = get_all_movies()
        planned_count = len([m for m in movies if m.watch_status == WatchStatus.PLANNED])
        watching_count = len([m for m in movies if m.watch_status == WatchStatus.WATCHING])
        completed_count = len([m for m in movies if m.watch_status == WatchStatus.COMPLETED])

        with ui.row().classes("gap-4 w-full mb-8"):
            create_metric_card("Total Movies", str(len(movies)), "All entries")
            create_metric_card("Planned", str(planned_count), "To watch")
            create_metric_card("Watching", str(watching_count), "Currently")
            create_metric_card("Completed", str(completed_count), "Finished")

        # Main content area
        with ui.row().classes("w-full gap-8"):
            # Left column: Add movie form
            with ui.column().classes("w-96"):
                create_add_movie_form()

            # Right column: Movies table
            with ui.column().classes("flex-1"):
                create_movies_table()


def create_metric_card(title: str, value: str, subtitle: str):
    """Create a metrics display card"""
    with ui.card().classes("p-6 bg-white shadow-lg rounded-xl hover:shadow-xl transition-shadow"):
        ui.label(title).classes("text-sm text-gray-500 uppercase tracking-wider")
        ui.label(value).classes("text-3xl font-bold text-gray-800 mt-2")
        ui.label(subtitle).classes("text-sm text-gray-600 mt-1")


def create_add_movie_form():
    """Create the form for adding new movies"""
    with ui.card().classes("p-6 shadow-lg rounded-lg"):
        ui.label("Add New Movie").classes("text-xl font-bold mb-6")

        # Form inputs
        ui.label("Movie Title").classes("text-sm font-medium text-gray-700 mb-1")
        title_input = ui.input(placeholder="Enter movie title").classes("w-full mb-4")

        ui.label("Director").classes("text-sm font-medium text-gray-700 mb-1")
        director_input = ui.input(placeholder="Director name").classes("w-full mb-4")

        ui.label("Release Year").classes("text-sm font-medium text-gray-700 mb-1")
        year_input = ui.number(placeholder="e.g. 2023", min=1880, max=2030, precision=0).classes("w-full mb-4")

        ui.label("Watch Status").classes("text-sm font-medium text-gray-700 mb-1")
        status_select = ui.select(
            options={status.value: status.value for status in WatchStatus}, value=WatchStatus.PLANNED.value
        ).classes("w-full mb-6")

        # Add button
        def add_movie():
            if not title_input.value or not director_input.value or not year_input.value:
                ui.notify("Please fill in all required fields", type="negative")
                return

            try:
                movie_data = MovieCreate(
                    title=title_input.value.strip(),
                    director=director_input.value.strip(),
                    release_year=int(year_input.value),
                    watch_status=WatchStatus(status_select.value),
                )

                create_movie(movie_data)
                ui.notify(f'Added "{movie_data.title}" to watchlist!', type="positive")

                # Clear form
                title_input.set_value("")
                director_input.set_value("")
                year_input.set_value(None)
                status_select.set_value(WatchStatus.PLANNED.value)

                # Refresh the page to show the new movie
                ui.navigate.reload()

            except Exception as e:
                ui.notify(f"Error adding movie: {str(e)}", type="negative")

        ui.button("Add Movie", on_click=add_movie).classes(
            "w-full bg-primary text-white px-4 py-2 rounded hover:bg-blue-600"
        )


def create_movies_table():
    """Create the movies display table with inline editing"""
    ui.label("Your Movies").classes("text-xl font-bold mb-4")

    movies = get_all_movies()

    if not movies:
        with ui.card().classes("p-8 text-center"):
            ui.label("No movies in your watchlist yet").classes("text-gray-500 text-lg")
            ui.label("Add your first movie using the form on the left").classes("text-gray-400 mt-2")
        return

    # Status filter
    with ui.row().classes("gap-2 mb-4"):
        ui.button("All", on_click=lambda: filter_movies(None)).props("outline")
        ui.button("Planned", on_click=lambda: filter_movies(WatchStatus.PLANNED)).props("outline")
        ui.button("Watching", on_click=lambda: filter_movies(WatchStatus.WATCHING)).props("outline")
        ui.button("Completed", on_click=lambda: filter_movies(WatchStatus.COMPLETED)).props("outline")

    # Movies table
    columns = [
        {"name": "title", "label": "Title", "field": "title", "align": "left"},
        {"name": "director", "label": "Director", "field": "director", "align": "left"},
        {"name": "release_year", "label": "Year", "field": "release_year", "align": "center"},
        {"name": "watch_status", "label": "Status", "field": "watch_status", "align": "center"},
        {"name": "actions", "label": "Actions", "field": "actions", "align": "center"},
    ]

    # Prepare rows with action buttons
    rows = []
    for movie in movies:
        if movie.id is not None:
            rows.append(
                {
                    "id": movie.id,
                    "title": movie.title,
                    "director": movie.director,
                    "release_year": movie.release_year,
                    "watch_status": movie.watch_status.value,
                    "actions": movie.id,  # We'll use this for button creation
                }
            )

    table = ui.table(columns=columns, rows=rows).classes("w-full")

    # Add custom slot for action buttons
    table.add_slot(
        "body-cell-actions",
        """
        <q-td :props="props">
            <q-btn flat round dense icon="edit" color="primary" size="sm" 
                   @click="$parent.$emit('edit', props.row)" class="q-mr-xs" />
            <q-btn flat round dense icon="delete" color="negative" size="sm"
                   @click="$parent.$emit('delete', props.row)" />
        </q-td>
    """,
    )

    # Add status badge styling
    table.add_slot(
        "body-cell-watch_status",
        """
        <q-td :props="props">
            <q-badge :color="props.value === 'Completed' ? 'positive' : 
                            props.value === 'Watching' ? 'warning' : 'info'">
                {{ props.value }}
            </q-badge>
        </q-td>
    """,
    )

    # Handle edit action
    async def handle_edit(e):
        movie_id = e.args["id"]
        await show_edit_dialog(movie_id)

    # Handle delete action
    async def handle_delete(e):
        movie_id = e.args["id"]
        movie_title = e.args["title"]
        await show_delete_dialog(movie_id, movie_title)

    table.on("edit", handle_edit)
    table.on("delete", handle_delete)


def filter_movies(status: Optional[WatchStatus]):
    """Filter movies by status and refresh the page"""
    # For simplicity, we'll reload the page
    # In a more complex app, we'd update the table dynamically
    ui.navigate.reload()


async def show_edit_dialog(movie_id: int):
    """Show dialog for editing a movie"""
    from app.movie_service import get_movie_by_id

    movie = get_movie_by_id(movie_id)
    if movie is None:
        ui.notify("Movie not found", type="negative")
        return

    with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
        ui.label(f"Edit: {movie.title}").classes("text-xl font-bold mb-4")

        # Edit form
        title_input = ui.input("Title", value=movie.title).classes("w-full mb-4")
        director_input = ui.input("Director", value=movie.director).classes("w-full mb-4")
        year_input = ui.number("Release Year", value=movie.release_year, min=1880, max=2030, precision=0).classes(
            "w-full mb-4"
        )
        status_select = ui.select(
            options={status.value: status.value for status in WatchStatus},
            label="Watch Status",
            value=movie.watch_status.value,
        ).classes("w-full mb-6")

        # Action buttons
        with ui.row().classes("gap-2 justify-end w-full"):
            ui.button("Cancel", on_click=lambda: dialog.submit(False)).props("outline")
            ui.button("Save Changes", on_click=lambda: save_movie_changes()).classes("bg-primary text-white")

        def save_movie_changes():
            try:
                if not title_input.value or not director_input.value or not year_input.value:
                    ui.notify("Please fill in all required fields", type="negative")
                    return

                movie_update = MovieUpdate(
                    title=title_input.value.strip(),
                    director=director_input.value.strip(),
                    release_year=int(year_input.value),
                    watch_status=WatchStatus(status_select.value),
                )

                updated_movie = update_movie(movie_id, movie_update)
                if updated_movie:
                    ui.notify("Movie updated successfully!", type="positive")
                    dialog.submit(True)
                    ui.navigate.reload()
                else:
                    ui.notify("Failed to update movie", type="negative")

            except Exception as e:
                ui.notify(f"Error updating movie: {str(e)}", type="negative")

    await dialog


async def show_delete_dialog(movie_id: int, movie_title: str):
    """Show confirmation dialog for deleting a movie"""
    with ui.dialog() as dialog, ui.card().classes("w-80 p-6"):
        ui.label("Delete Movie").classes("text-xl font-bold mb-4")
        ui.label(f'Are you sure you want to delete "{movie_title}"?').classes("text-gray-600 mb-6")
        ui.label("This action cannot be undone.").classes("text-sm text-gray-500 mb-6")

        with ui.row().classes("gap-2 justify-end w-full"):
            ui.button("Cancel", on_click=lambda: dialog.submit(False)).props("outline")
            ui.button("Delete", on_click=lambda: confirm_delete()).classes("bg-red-500 text-white")

        def confirm_delete():
            if delete_movie(movie_id):
                ui.notify(f'Deleted "{movie_title}"', type="positive")
                dialog.submit(True)
                ui.navigate.reload()
            else:
                ui.notify("Failed to delete movie", type="negative")

    await dialog
