import pytest
from datetime import date, timedelta
from decimal import Decimal

from app.database import reset_db
from app.plant_service import PlantService
from app.models import PlantCreate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_end_to_end_plant_care_workflow(new_db):
    """Test the complete plant care workflow from setup to watering."""

    # 1. Ensure default data exists (users and plant types)
    PlantService.ensure_default_data()

    users = PlantService.get_all_users()
    plant_types = PlantService.get_all_plant_types()

    assert len(users) >= 1, "Should have at least one default user"
    assert len(plant_types) >= 5, "Should have at least 5 default plant types"

    # Find a pothos plant type for testing
    pothos_type = next(pt for pt in plant_types if "Pothos" in pt.name)
    user = users[0]

    user_id = user.id
    plant_type_id = pothos_type.id
    assert user_id is not None and plant_type_id is not None

    # 2. Add a new plant
    plant_data = PlantCreate(
        name="My Golden Pothos",
        nickname="Goldie",
        user_id=user_id,
        plant_type_id=plant_type_id,
        location="Living room windowsill",
        acquisition_date=date.today() - timedelta(days=30),
        last_watered=date.today() - timedelta(days=10),  # 10 days ago, should be thirsty
        notes="Beautiful trailing plant, loves bright indirect light",
    )

    plant_id = PlantService.create_plant(plant_data)
    assert plant_id is not None, "Plant creation should succeed"

    # 3. Check plant mood (should be thirsty after 10 days for a 7-day cycle plant)
    plant = PlantService.get_plant_by_id(plant_id)
    assert plant is not None
    assert plant.mood == "Thirsty", f"Expected Thirsty, got {plant.mood}"
    assert plant.days_since_watered == 10

    # 4. Water the plant
    watering_success = PlantService.water_plant(
        plant_id, amount_ml=Decimal("300"), notes="Soil was quite dry, leaves starting to droop"
    )
    assert watering_success, "Plant watering should succeed"

    # 5. Check plant mood after watering (should be happy)
    updated_plant = PlantService.get_plant_by_id(plant_id)
    assert updated_plant is not None
    assert updated_plant.mood == "Happy", f"After watering, expected Happy, got {updated_plant.mood}"
    assert updated_plant.last_watered == date.today().isoformat()
    assert updated_plant.days_since_watered == 0

    # 6. Verify we can get all plants and they include our new plant
    all_plants = PlantService.get_all_plants()
    plant_names = [p.name for p in all_plants]
    assert "My Golden Pothos" in plant_names

    # 7. Test filtering plants by user
    user_plants = PlantService.get_all_plants(user_id)
    assert len(user_plants) >= 1
    assert any(p.name == "My Golden Pothos" for p in user_plants)


def test_multiple_plants_with_different_moods(new_db):
    """Test that multiple plants can have different moods simultaneously."""

    PlantService.ensure_default_data()
    users = PlantService.get_all_users()
    plant_types = PlantService.get_all_plant_types()

    pothos_type = next(pt for pt in plant_types if "Pothos" in pt.name)
    snake_plant_type = next(pt for pt in plant_types if "Snake Plant" in pt.name)

    user_id = users[0].id
    assert user_id is not None
    pothos_type_id = pothos_type.id
    snake_type_id = snake_plant_type.id
    assert pothos_type_id is not None and snake_type_id is not None

    # Create happy pothos (recently watered)
    happy_pothos = PlantCreate(
        name="Happy Pothos",
        user_id=user_id,
        plant_type_id=pothos_type_id,
        location="Shelf",
        acquisition_date=date.today(),
        last_watered=date.today() - timedelta(days=3),  # Well within 7-day schedule
    )

    # Create thirsty pothos (overdue for watering)
    thirsty_pothos = PlantCreate(
        name="Thirsty Pothos",
        user_id=user_id,
        plant_type_id=pothos_type_id,
        location="Table",
        acquisition_date=date.today(),
        last_watered=date.today() - timedelta(days=12),  # 5 days overdue
    )

    # Create happy snake plant (14-day schedule, watered 10 days ago)
    happy_snake = PlantCreate(
        name="Happy Snake Plant",
        user_id=user_id,
        plant_type_id=snake_type_id,
        location="Corner",
        acquisition_date=date.today(),
        last_watered=date.today() - timedelta(days=10),  # Still good for 4 more days
    )

    # Create plants
    happy_pothos_id = PlantService.create_plant(happy_pothos)
    thirsty_pothos_id = PlantService.create_plant(thirsty_pothos)
    happy_snake_id = PlantService.create_plant(happy_snake)

    assert all(id is not None for id in [happy_pothos_id, thirsty_pothos_id, happy_snake_id])

    # Check moods
    assert happy_pothos_id is not None and thirsty_pothos_id is not None and happy_snake_id is not None
    happy_pothos_plant = PlantService.get_plant_by_id(happy_pothos_id)
    thirsty_pothos_plant = PlantService.get_plant_by_id(thirsty_pothos_id)
    happy_snake_plant = PlantService.get_plant_by_id(happy_snake_id)

    assert happy_pothos_plant is not None and happy_pothos_plant.mood == "Happy"
    assert thirsty_pothos_plant is not None and thirsty_pothos_plant.mood == "Thirsty"
    assert happy_snake_plant is not None and happy_snake_plant.mood == "Happy"

    # Get all plants and verify mood distribution
    all_plants = PlantService.get_all_plants()
    moods = [p.mood for p in all_plants]
    assert "Happy" in moods
    assert "Thirsty" in moods

    # Verify at least 2 happy plants and 1 thirsty plant
    happy_count = moods.count("Happy")
    thirsty_count = moods.count("Thirsty")
    assert happy_count >= 2
    assert thirsty_count >= 1


def test_plant_care_reminders_logic(new_db):
    """Test the logic that would drive care reminders in the UI."""

    PlantService.ensure_default_data()
    users = PlantService.get_all_users()
    plant_types = PlantService.get_all_plant_types()

    # Create plants with various watering states
    user_id = users[0].id
    assert user_id is not None

    plants_to_create = []

    for i, pt in enumerate(plant_types[:3]):  # Use first 3 plant types
        plant_type_id = pt.id
        assert plant_type_id is not None

        # Create one plant that needs urgent attention
        urgent_plant = PlantCreate(
            name=f"Stressed {pt.name}",
            user_id=user_id,
            plant_type_id=plant_type_id,
            location=f"Location {i}",
            acquisition_date=date.today(),
            last_watered=date.today() - timedelta(days=pt.watering_frequency_days + 7),  # Very overdue
        )
        plants_to_create.append(urgent_plant)

        # Create one plant that's doing well
        healthy_plant = PlantCreate(
            name=f"Happy {pt.name}",
            user_id=user_id,
            plant_type_id=plant_type_id,
            location=f"Location {i}b",
            acquisition_date=date.today(),
            last_watered=date.today() - timedelta(days=pt.watering_frequency_days // 2),  # Half the cycle
        )
        plants_to_create.append(healthy_plant)

    # Create all plants
    plant_ids = []
    for plant_data in plants_to_create:
        plant_id = PlantService.create_plant(plant_data)
        assert plant_id is not None
        plant_ids.append(plant_id)

    # Analyze plant care needs
    all_plants = PlantService.get_all_plants()

    care_summary = {"Happy": [], "Slightly Thirsty": [], "Thirsty": [], "Stressed": []}

    for plant in all_plants:
        care_summary[plant.mood].append(plant)

    # Should have both happy and stressed plants
    assert len(care_summary["Happy"]) >= 3, "Should have at least 3 happy plants"
    assert len(care_summary["Stressed"]) >= 3, "Should have at least 3 stressed plants"

    # Test priority logic (stressed plants need immediate attention)
    priority_plants = care_summary["Stressed"]
    assert all(p.days_since_watered > 10 for p in priority_plants), (
        "All stressed plants should be significantly overdue"
    )

    # Happy plants should have been watered recently relative to their schedule
    happy_plants = care_summary["Happy"]
    for plant in happy_plants:
        # Find the plant type to get watering frequency
        plant_type = next(pt for pt in plant_types if pt.name in plant.plant_type_name)
        assert plant.days_since_watered <= plant_type.watering_frequency_days, (
            f"Happy plant {plant.name} should be within schedule"
        )
