import pytest
from datetime import date, timedelta
from decimal import Decimal

from app.database import reset_db, get_session
from app.models import User, PlantType, Plant, PlantCreate
from app.plant_service import PlantService, PlantMoodCalculator


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


@pytest.fixture()
def sample_data():
    """Create sample users and plant types for testing."""
    with get_session() as session:
        # Create test user
        user = User(name="Test User", email="test@example.com")
        session.add(user)

        # Create test plant types
        pothos = PlantType(
            name="Test Pothos",
            description="Test plant",
            watering_frequency_days=7,
            sunlight_requirement="Medium",
            difficulty_level="Easy",
        )
        snake_plant = PlantType(
            name="Test Snake Plant",
            description="Test succulent",
            watering_frequency_days=14,
            sunlight_requirement="Low",
            difficulty_level="Easy",
        )

        session.add_all([pothos, snake_plant])
        session.commit()
        session.refresh(user)
        session.refresh(pothos)
        session.refresh(snake_plant)

        return {"user": user, "pothos_type": pothos, "snake_plant_type": snake_plant}


class TestPlantMoodCalculator:
    """Test plant mood calculation logic."""

    def test_calculate_mood_never_watered(self, new_db, sample_data):
        """Test mood calculation for never watered plant."""
        plant = Plant(
            name="Test Plant",
            user_id=sample_data["user"].id,
            plant_type_id=sample_data["pothos_type"].id,
            location="Test",
            acquisition_date=date.today(),
            last_watered=None,
        )

        mood = PlantMoodCalculator.calculate_mood(plant, sample_data["pothos_type"])
        assert mood == "Thirsty"

    def test_calculate_mood_happy_plant(self, new_db, sample_data):
        """Test mood calculation for recently watered plant."""
        plant = Plant(
            name="Test Plant",
            user_id=sample_data["user"].id,
            plant_type_id=sample_data["pothos_type"].id,
            location="Test",
            acquisition_date=date.today(),
            last_watered=date.today() - timedelta(days=3),  # Watered 3 days ago, needs water every 7
        )

        mood = PlantMoodCalculator.calculate_mood(plant, sample_data["pothos_type"])
        assert mood == "Happy"

    def test_calculate_mood_slightly_thirsty(self, new_db, sample_data):
        """Test mood calculation for slightly overdue watering."""
        plant = Plant(
            name="Test Plant",
            user_id=sample_data["user"].id,
            plant_type_id=sample_data["pothos_type"].id,
            location="Test",
            acquisition_date=date.today(),
            last_watered=date.today() - timedelta(days=8),  # 1 day overdue
        )

        mood = PlantMoodCalculator.calculate_mood(plant, sample_data["pothos_type"])
        assert mood == "Slightly Thirsty"

    def test_calculate_mood_thirsty(self, new_db, sample_data):
        """Test mood calculation for moderately overdue watering."""
        plant = Plant(
            name="Test Plant",
            user_id=sample_data["user"].id,
            plant_type_id=sample_data["pothos_type"].id,
            location="Test",
            acquisition_date=date.today(),
            last_watered=date.today() - timedelta(days=10),  # 3 days overdue
        )

        mood = PlantMoodCalculator.calculate_mood(plant, sample_data["pothos_type"])
        assert mood == "Thirsty"

    def test_calculate_mood_stressed(self, new_db, sample_data):
        """Test mood calculation for severely overdue watering."""
        plant = Plant(
            name="Test Plant",
            user_id=sample_data["user"].id,
            plant_type_id=sample_data["pothos_type"].id,
            location="Test",
            acquisition_date=date.today(),
            last_watered=date.today() - timedelta(days=15),  # 8 days overdue
        )

        mood = PlantMoodCalculator.calculate_mood(plant, sample_data["pothos_type"])
        assert mood == "Stressed"

    def test_different_watering_frequencies(self, new_db, sample_data):
        """Test mood calculation with different plant watering frequencies."""
        # Snake plant watered 10 days ago (needs water every 14 days)
        snake_plant = Plant(
            name="Test Snake Plant",
            user_id=sample_data["user"].id,
            plant_type_id=sample_data["snake_plant_type"].id,
            location="Test",
            acquisition_date=date.today(),
            last_watered=date.today() - timedelta(days=10),
        )

        # Pothos watered 10 days ago (needs water every 7 days)
        pothos = Plant(
            name="Test Pothos",
            user_id=sample_data["user"].id,
            plant_type_id=sample_data["pothos_type"].id,
            location="Test",
            acquisition_date=date.today(),
            last_watered=date.today() - timedelta(days=10),
        )

        snake_mood = PlantMoodCalculator.calculate_mood(snake_plant, sample_data["snake_plant_type"])
        pothos_mood = PlantMoodCalculator.calculate_mood(pothos, sample_data["pothos_type"])

        assert snake_mood == "Happy"  # 10 days is within 14 day schedule
        assert pothos_mood == "Thirsty"  # 10 days is way past 7 day schedule

    def test_get_mood_emoji(self):
        """Test emoji assignment for different moods."""
        assert PlantMoodCalculator.get_mood_emoji("Happy") == "😊"
        assert PlantMoodCalculator.get_mood_emoji("Slightly Thirsty") == "🙂"
        assert PlantMoodCalculator.get_mood_emoji("Thirsty") == "😐"
        assert PlantMoodCalculator.get_mood_emoji("Stressed") == "😟"
        assert PlantMoodCalculator.get_mood_emoji("Unknown") == "🤔"

    def test_get_mood_color(self):
        """Test color assignment for different moods."""
        assert PlantMoodCalculator.get_mood_color("Happy") == "text-green-500"
        assert PlantMoodCalculator.get_mood_color("Slightly Thirsty") == "text-yellow-500"
        assert PlantMoodCalculator.get_mood_color("Thirsty") == "text-orange-500"
        assert PlantMoodCalculator.get_mood_color("Stressed") == "text-red-500"
        assert PlantMoodCalculator.get_mood_color("Unknown") == "text-gray-500"


class TestPlantService:
    """Test plant service operations."""

    def test_create_plant_success(self, new_db, sample_data):
        """Test successful plant creation."""
        plant_data = PlantCreate(
            name="My Test Plant",
            nickname="Testy",
            user_id=sample_data["user"].id,
            plant_type_id=sample_data["pothos_type"].id,
            location="Living room",
            acquisition_date=date.today(),
            last_watered=date.today() - timedelta(days=2),
            notes="Beautiful plant",
        )

        plant_id = PlantService.create_plant(plant_data)
        assert plant_id is not None
        assert plant_id > 0

        # Verify plant was created
        created_plant = PlantService.get_plant_by_id(plant_id)
        assert created_plant is not None
        assert created_plant.name == "My Test Plant"
        assert created_plant.nickname == "Testy"
        assert created_plant.location == "Living room"
        assert created_plant.notes == "Beautiful plant"

    def test_create_plant_invalid_user(self, new_db, sample_data):
        """Test plant creation with invalid user ID."""
        plant_data = PlantCreate(
            name="Test Plant",
            user_id=99999,  # Non-existent user
            plant_type_id=sample_data["pothos_type"].id,
            location="Test",
            acquisition_date=date.today(),
        )

        plant_id = PlantService.create_plant(plant_data)
        assert plant_id is None

    def test_create_plant_invalid_type(self, new_db, sample_data):
        """Test plant creation with invalid plant type."""
        plant_data = PlantCreate(
            name="Test Plant",
            user_id=sample_data["user"].id,
            plant_type_id=99999,  # Non-existent type
            location="Test",
            acquisition_date=date.today(),
        )

        plant_id = PlantService.create_plant(plant_data)
        assert plant_id is None

    def test_water_plant_success(self, new_db, sample_data):
        """Test successful plant watering."""
        # Create a plant first
        plant_data = PlantCreate(
            name="Test Plant",
            user_id=sample_data["user"].id,
            plant_type_id=sample_data["pothos_type"].id,
            location="Test",
            acquisition_date=date.today(),
            last_watered=date.today() - timedelta(days=5),
        )

        plant_id = PlantService.create_plant(plant_data)
        assert plant_id is not None

        # Water the plant
        success = PlantService.water_plant(int(plant_id), amount_ml=Decimal("250"), notes="Looked thirsty")
        assert success

        # Verify watering was recorded
        plant = PlantService.get_plant_by_id(plant_id)
        assert plant is not None
        assert plant.last_watered == date.today().isoformat()

    def test_water_plant_invalid_id(self, new_db):
        """Test watering non-existent plant."""
        success = PlantService.water_plant(99999)
        assert not success

    def test_get_all_plants_empty(self, new_db):
        """Test getting plants when none exist."""
        plants = PlantService.get_all_plants()
        assert plants == []

    def test_get_all_plants_with_data(self, new_db, sample_data):
        """Test getting all plants with sample data."""
        # Create test plants
        plant_data1 = PlantCreate(
            name="Happy Plant",
            user_id=sample_data["user"].id,
            plant_type_id=sample_data["pothos_type"].id,
            location="Window",
            acquisition_date=date.today(),
            last_watered=date.today() - timedelta(days=2),
        )

        plant_data2 = PlantCreate(
            name="Thirsty Plant",
            user_id=sample_data["user"].id,
            plant_type_id=sample_data["pothos_type"].id,
            location="Shelf",
            acquisition_date=date.today(),
            last_watered=date.today() - timedelta(days=10),
        )

        PlantService.create_plant(plant_data1)
        PlantService.create_plant(plant_data2)

        plants = PlantService.get_all_plants()
        assert len(plants) == 2

        # Verify moods are calculated correctly
        moods = [p.mood for p in plants]
        assert "Happy" in moods
        assert "Thirsty" in moods

    def test_get_plants_by_user(self, new_db, sample_data):
        """Test filtering plants by user."""
        # Create second user
        with get_session() as session:
            user2 = User(name="User Two", email="user2@example.com")
            session.add(user2)
            session.commit()
            session.refresh(user2)
            user2_id = user2.id
            assert user2_id is not None

        # Create plants for both users
        plant_data1 = PlantCreate(
            name="User 1 Plant",
            user_id=sample_data["user"].id,
            plant_type_id=sample_data["pothos_type"].id,
            location="User 1 location",
            acquisition_date=date.today(),
        )

        plant_data2 = PlantCreate(
            name="User 2 Plant",
            user_id=user2_id,
            plant_type_id=sample_data["pothos_type"].id,
            location="User 2 location",
            acquisition_date=date.today(),
        )

        PlantService.create_plant(plant_data1)
        PlantService.create_plant(plant_data2)

        # Test filtering
        user1_plants = PlantService.get_all_plants(sample_data["user"].id)
        user2_plants = PlantService.get_all_plants(user2_id)

        assert len(user1_plants) == 1
        assert len(user2_plants) == 1
        assert user1_plants[0].name == "User 1 Plant"
        assert user2_plants[0].name == "User 2 Plant"

    def test_get_plant_by_id_not_found(self, new_db):
        """Test getting non-existent plant."""
        plant = PlantService.get_plant_by_id(99999)
        assert plant is None

    def test_ensure_default_data_creates_data(self, new_db):
        """Test that ensure_default_data creates users and plant types."""
        # Verify no data exists initially
        users = PlantService.get_all_users()
        plant_types = PlantService.get_all_plant_types()
        assert len(users) == 0
        assert len(plant_types) == 0

        # Run ensure_default_data
        PlantService.ensure_default_data()

        # Verify data was created
        users = PlantService.get_all_users()
        plant_types = PlantService.get_all_plant_types()
        assert len(users) >= 1
        assert len(plant_types) >= 5

        # Verify specific plant types exist
        plant_type_names = [pt.name for pt in plant_types]
        assert "Pothos" in plant_type_names
        assert "Snake Plant" in plant_type_names
        assert "Fiddle Leaf Fig" in plant_type_names

    def test_ensure_default_data_idempotent(self, new_db):
        """Test that ensure_default_data doesn't create duplicates."""
        # Run twice
        PlantService.ensure_default_data()
        users_count_1 = len(PlantService.get_all_users())
        types_count_1 = len(PlantService.get_all_plant_types())

        PlantService.ensure_default_data()
        users_count_2 = len(PlantService.get_all_users())
        types_count_2 = len(PlantService.get_all_plant_types())

        # Should not create duplicates
        assert users_count_1 == users_count_2
        assert types_count_1 == types_count_2

    def test_days_since_watered_calculation(self, new_db, sample_data):
        """Test days since watered calculation in plant response."""
        plant_data = PlantCreate(
            name="Test Plant",
            user_id=sample_data["user"].id,
            plant_type_id=sample_data["pothos_type"].id,
            location="Test",
            acquisition_date=date.today(),
            last_watered=date.today() - timedelta(days=3),
        )

        plant_id = PlantService.create_plant(plant_data)
        assert plant_id is not None
        plant = PlantService.get_plant_by_id(int(plant_id))

        assert plant is not None
        assert plant.days_since_watered == 3

    def test_plant_response_fields(self, new_db, sample_data):
        """Test all fields in PlantResponse are correctly populated."""
        plant_data = PlantCreate(
            name="Complete Test Plant",
            nickname="Testy",
            user_id=sample_data["user"].id,
            plant_type_id=sample_data["pothos_type"].id,
            location="Test Location",
            acquisition_date=date(2024, 1, 1),
            last_watered=date.today() - timedelta(days=5),
            notes="Test notes",
        )

        plant_id = PlantService.create_plant(plant_data)
        assert plant_id is not None
        plant = PlantService.get_plant_by_id(int(plant_id))

        assert plant is not None
        assert plant.name == "Complete Test Plant"
        assert plant.nickname == "Testy"
        assert plant.location == "Test Location"
        assert plant.acquisition_date == "2024-01-01"
        assert plant.notes == "Test notes"
        assert plant.plant_type_name == "Test Pothos"
        assert plant.user_name == "Test User"
        assert plant.mood in ["Happy", "Slightly Thirsty", "Thirsty", "Stressed"]
        assert plant.is_active
        assert plant.days_since_watered == 5
