import pytest
from datetime import date, timedelta

from app.database import reset_db
from app.plant_service import PlantService
from app.plant_tracker import PlantTrackerUI


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_plant_tracker_ui_init():
    """Test that PlantTrackerUI can be initialized."""
    tracker = PlantTrackerUI()
    assert tracker.plants_container is None
    assert tracker.selected_user_id is None


def test_plant_tracker_module_imports():
    """Test that the plant tracker module imports correctly."""
    import app.plant_tracker

    assert hasattr(app.plant_tracker, "create")
    assert hasattr(app.plant_tracker, "PlantTrackerUI")


def test_plant_service_integration_with_ui_data(new_db):
    """Test plant service with data suitable for UI display."""
    # Ensure we have default data
    PlantService.ensure_default_data()

    # Get users and types
    users = PlantService.get_all_users()
    plant_types = PlantService.get_all_plant_types()

    assert len(users) >= 1
    assert len(plant_types) >= 5

    # Create a plant for display
    from app.models import PlantCreate

    user_id = users[0].id
    plant_type_id = plant_types[0].id
    assert user_id is not None and plant_type_id is not None

    plant_data = PlantCreate(
        name="UI Test Plant",
        nickname="Display Test",
        user_id=user_id,
        plant_type_id=plant_type_id,
        location="UI Test Location",
        acquisition_date=date.today() - timedelta(days=10),
        last_watered=date.today() - timedelta(days=5),
        notes="Test plant for UI display",
    )

    plant_id = PlantService.create_plant(plant_data)
    assert plant_id is not None

    # Get plant for UI display
    plant = PlantService.get_plant_by_id(plant_id)
    assert plant is not None
    assert plant.name == "UI Test Plant"
    assert plant.nickname == "Display Test"
    assert plant.mood in ["Happy", "Slightly Thirsty", "Thirsty", "Stressed"]
    assert plant.days_since_watered == 5


def test_mood_calculator_ui_integration(new_db):
    """Test mood calculator provides data suitable for UI display."""
    from app.plant_service import PlantMoodCalculator

    # Test emoji and color mappings exist for all moods
    moods = ["Happy", "Slightly Thirsty", "Thirsty", "Stressed"]

    for mood in moods:
        emoji = PlantMoodCalculator.get_mood_emoji(mood)
        color = PlantMoodCalculator.get_mood_color(mood)

        assert emoji is not None and emoji != ""
        assert color is not None and "text-" in color

    # Test unknown mood handling
    assert PlantMoodCalculator.get_mood_emoji("Unknown") == "🤔"
    assert PlantMoodCalculator.get_mood_color("Unknown") == "text-gray-500"
