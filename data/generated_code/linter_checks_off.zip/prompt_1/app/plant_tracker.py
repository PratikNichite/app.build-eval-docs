from datetime import date
from typing import Optional, Any
from decimal import Decimal

from nicegui import ui
from app.plant_service import PlantService, PlantMoodCalculator
from app.models import PlantCreate


class PlantTrackerUI:
    """Main UI for the Plant Care Tracker application."""

    def __init__(self):
        self.plants_container: Optional[Any] = None
        self.selected_user_id: Optional[int] = None

    def create_plant_card(self, plant_response):
        """Create a card for displaying plant information."""
        mood_emoji = PlantMoodCalculator.get_mood_emoji(plant_response.mood)
        mood_color = PlantMoodCalculator.get_mood_color(plant_response.mood)

        with ui.card().classes("w-80 p-6 shadow-lg rounded-xl hover:shadow-xl transition-shadow bg-white"):
            # Plant name and mood
            with ui.row().classes("items-center justify-between w-full mb-4"):
                plant_name = plant_response.nickname or plant_response.name
                ui.label(plant_name).classes("text-xl font-bold text-gray-800")
                ui.label(f"{mood_emoji} {plant_response.mood}").classes(f"text-lg font-semibold {mood_color}")

            # Plant type and location
            ui.label(f"Type: {plant_response.plant_type_name}").classes("text-sm text-gray-600 mb-1")
            ui.label(f"Location: {plant_response.location}").classes("text-sm text-gray-600 mb-2")

            # Last watered info
            if plant_response.last_watered:
                days_text = f"{plant_response.days_since_watered} day{'s' if plant_response.days_since_watered != 1 else ''} ago"
                ui.label(f"Last watered: {days_text}").classes("text-sm text-gray-500 mb-4")
            else:
                ui.label("Never watered").classes("text-sm text-red-500 mb-4")

            # Notes (if any)
            if plant_response.notes.strip():
                ui.label(f"Notes: {plant_response.notes}").classes("text-xs text-gray-400 mb-4 italic")

            # Water button
            plant_id = plant_response.id

            def create_water_handler(pid: int):
                async def handler():
                    await self.water_plant_dialog(pid)

                return handler

            ui.button("💧 Water Now", on_click=create_water_handler(plant_id)).classes(
                "w-full bg-blue-500 hover:bg-blue-600 text-white py-2 rounded-lg font-semibold"
            )

    def refresh_plants_display(self):
        """Refresh the plants display."""
        if self.plants_container:
            self.plants_container.clear()
            with self.plants_container:
                plants = PlantService.get_all_plants(self.selected_user_id)

                if not plants:
                    with ui.card().classes("p-8 text-center bg-gray-50"):
                        ui.label("🌱 No plants found").classes("text-xl text-gray-500 mb-2")
                        ui.label("Add your first plant to get started!").classes("text-gray-400")

                    # Show welcome message for no plants
                    with ui.card().classes(
                        "p-6 text-center bg-gradient-to-br from-green-50 to-blue-50 border-2 border-dashed border-green-200 mt-4"
                    ):
                        ui.label("✨").classes("text-4xl mb-2")
                        ui.label("Welcome to your Plant Care Tracker! Add your first plant to see their mood!").classes(
                            "text-lg text-gray-600"
                        )
                else:
                    # Group plants by mood for better organization
                    mood_groups = {"Happy": [], "Slightly Thirsty": [], "Thirsty": [], "Stressed": []}

                    for plant in plants:
                        mood_groups[plant.mood].append(plant)

                    # Calculate mood counts
                    mood_counts = {mood: len(plants) for mood, plants in mood_groups.items() if plants}

                    # Create mood summary section
                    with ui.card().classes(
                        "p-6 bg-gradient-to-r from-green-50 to-blue-50 border-l-4 border-green-400 mb-6 shadow-md"
                    ):
                        # Summary line
                        summary_parts = []
                        for mood in ["Happy", "Slightly Thirsty", "Thirsty", "Stressed"]:
                            if mood_counts.get(mood, 0) > 0:
                                count = mood_counts[mood]
                                summary_parts.append(f"{count} {mood} plant{'s' if count != 1 else ''}")

                        if summary_parts:
                            summary_text = f"Currently, you have {', '.join(summary_parts[:-1])}"
                            if len(summary_parts) > 1:
                                summary_text += f", and {summary_parts[-1]}."
                            else:
                                summary_text += "."
                            ui.label(summary_text).classes("text-lg text-gray-700 mb-4")

                        # Overall mood message with emoji and color
                        if mood_counts.get("Stressed", 0) > 0:
                            ui.label(
                                "😰 Oh no! Some of your plant babies need urgent care! Let's get them watered!"
                            ).classes("text-xl font-bold text-red-500")
                        elif mood_counts.get("Thirsty", 0) > 0:
                            ui.label("💧 Your plants are getting a bit dry! Time for a drink!").classes(
                                "text-xl font-bold text-orange-500"
                            )
                        elif mood_counts.get("Slightly Thirsty", 0) > 0:
                            ui.label("🌱 Some plants are feeling a little parched. Give them some love soon!").classes(
                                "text-xl font-bold text-yellow-500"
                            )
                        else:  # All happy
                            ui.label("🥳 Your plant family is thriving! Keep up the great work!").classes(
                                "text-xl font-bold text-green-500"
                            )

                    # Display plants grouped by mood
                    for mood, mood_plants in mood_groups.items():
                        if mood_plants:
                            ui.label(
                                f"{PlantMoodCalculator.get_mood_emoji(mood)} {mood} Plants ({len(mood_plants)})"
                            ).classes("text-lg font-semibold text-gray-700 mt-6 mb-3")
                            with ui.row().classes("gap-4 flex-wrap"):
                                for plant in mood_plants:
                                    self.create_plant_card(plant)

    async def water_plant_dialog(self, plant_id: int):
        """Show dialog for watering a plant."""
        plant = PlantService.get_plant_by_id(plant_id)
        if plant is None:
            ui.notify("Plant not found", type="negative")
            return

        with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
            ui.label(f"💧 Water {plant.nickname or plant.name}").classes("text-xl font-bold mb-4")

            # Amount input
            ui.label("Amount (ml) - optional:").classes("text-sm font-medium text-gray-700 mb-1")
            amount_input = ui.number(placeholder="e.g. 250", precision=0, min=0, max=5000).classes("w-full mb-4")

            # Notes input
            ui.label("Notes - optional:").classes("text-sm font-medium text-gray-700 mb-1")
            notes_input = (
                ui.textarea(placeholder="Any observations about the plant...").classes("w-full mb-4").props("rows=3")
            )

            with ui.row().classes("gap-2 justify-end w-full"):
                ui.button("Cancel", on_click=lambda: dialog.submit(None)).props("outline")
                ui.button("💧 Water Plant", on_click=lambda: dialog.submit("water")).classes("bg-blue-500 text-white")

        result = await dialog

        if result == "water":
            amount = None
            if amount_input.value is not None and amount_input.value > 0:
                amount = Decimal(str(amount_input.value))

            success = PlantService.water_plant(plant_id, amount_ml=amount, notes=notes_input.value or "")

            if success:
                ui.notify(f"🌱 {plant.nickname or plant.name} has been watered!", type="positive")
                self.refresh_plants_display()
            else:
                ui.notify("Failed to water plant", type="negative")

    async def add_plant_dialog(self):
        """Show dialog for adding a new plant."""
        plant_types = PlantService.get_all_plant_types()
        users = PlantService.get_all_users()

        if not plant_types:
            ui.notify("No plant types available. Please contact administrator.", type="negative")
            return

        if not users:
            ui.notify("No users available. Please contact administrator.", type="negative")
            return

        with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
            ui.label("🌱 Add New Plant").classes("text-xl font-bold mb-4")

            # Plant name
            ui.label("Plant Name:").classes("text-sm font-medium text-gray-700 mb-1")
            name_input = ui.input(placeholder="e.g. My Golden Pothos").classes("w-full mb-3")

            # Nickname (optional)
            ui.label("Nickname (optional):").classes("text-sm font-medium text-gray-700 mb-1")
            nickname_input = ui.input(placeholder="e.g. Goldie").classes("w-full mb-3")

            # User selection
            ui.label("Owner:").classes("text-sm font-medium text-gray-700 mb-1")
            user_select = ui.select(
                {user.id: user.name for user in users}, value=users[0].id if users else None
            ).classes("w-full mb-3")

            # Plant type
            ui.label("Plant Type:").classes("text-sm font-medium text-gray-700 mb-1")
            type_select = ui.select(
                {pt.id: f"{pt.name} - {pt.difficulty_level}" for pt in plant_types},
                value=plant_types[0].id if plant_types else None,
            ).classes("w-full mb-3")

            # Location
            ui.label("Location:").classes("text-sm font-medium text-gray-700 mb-1")
            location_input = ui.input(placeholder="e.g. Living room windowsill").classes("w-full mb-3")

            # Acquisition date
            ui.label("Acquisition Date:").classes("text-sm font-medium text-gray-700 mb-1")
            date_input = ui.date(value=date.today().isoformat()).classes("w-full mb-3")

            # Last watered (optional)
            ui.label("Last Watered (optional):").classes("text-sm font-medium text-gray-700 mb-1")
            last_watered_input = ui.date().classes("w-full mb-3")

            # Notes
            ui.label("Notes (optional):").classes("text-sm font-medium text-gray-700 mb-1")
            notes_input = (
                ui.textarea(placeholder="Any special care instructions...").classes("w-full mb-4").props("rows=3")
            )

            with ui.row().classes("gap-2 justify-end w-full"):
                ui.button("Cancel", on_click=lambda: dialog.submit(None)).props("outline")
                ui.button("🌱 Add Plant", on_click=lambda: dialog.submit("add")).classes("bg-green-500 text-white")

        result = await dialog

        if result == "add":
            if not name_input.value or not location_input.value:
                ui.notify("Please fill in plant name and location", type="negative")
                return

            # Parse dates
            acquisition_date = date.fromisoformat(date_input.value) if date_input.value else date.today()
            last_watered = None
            if last_watered_input.value:
                last_watered = date.fromisoformat(last_watered_input.value)

            if user_select.value is None or type_select.value is None:
                ui.notify("Please select user and plant type", type="negative")
                return

            plant_data = PlantCreate(
                name=name_input.value,
                nickname=nickname_input.value or None,
                user_id=int(user_select.value),
                plant_type_id=int(type_select.value),
                location=location_input.value,
                acquisition_date=acquisition_date,
                last_watered=last_watered,
                notes=notes_input.value or "",
            )

            plant_id = PlantService.create_plant(plant_data)

            if plant_id:
                ui.notify(f"🌱 {name_input.value} has been added to your collection!", type="positive")
                self.refresh_plants_display()
            else:
                ui.notify("Failed to add plant", type="negative")


def create():
    """Create the Plant Care Tracker application."""

    # Apply modern theme
    ui.colors(
        primary="#10b981",  # Green for plants
        secondary="#64748b",  # Subtle gray
        accent="#3b82f6",  # Blue accent
        positive="#10b981",
        negative="#ef4444",
        warning="#f59e0b",
        info="#3b82f6",
    )

    # Ensure default data exists
    PlantService.ensure_default_data()

    @ui.page("/")
    def main_page():
        tracker = PlantTrackerUI()

        # Header
        with ui.row().classes("w-full justify-between items-center mb-6 p-4 bg-green-50 rounded-lg"):
            with ui.column():
                ui.label("🌱 Plant Care Tracker").classes("text-3xl font-bold text-green-800")
                ui.label("Keep your plants happy and healthy").classes("text-lg text-green-600")

            with ui.row().classes("gap-2"):

                async def add_plant_handler():
                    await tracker.add_plant_dialog()

                ui.button("+ Add Plant", on_click=add_plant_handler).classes(
                    "bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg font-semibold"
                )

                ui.button("🔄 Refresh", on_click=tracker.refresh_plants_display).classes(
                    "bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg"
                )

        # Main content container
        tracker.plants_container = ui.column().classes("w-full p-4")

        # Initial load
        tracker.refresh_plants_display()

    @ui.page("/plant-types")
    def plant_types_page():
        ui.label("🌿 Plant Types").classes("text-2xl font-bold text-green-800 mb-6")

        plant_types = PlantService.get_all_plant_types()

        with ui.row().classes("gap-4 flex-wrap"):
            for plant_type in plant_types:
                with ui.card().classes("w-80 p-6 shadow-md rounded-lg bg-white"):
                    ui.label(plant_type.name).classes("text-xl font-bold text-gray-800 mb-2")
                    ui.label(f"Difficulty: {plant_type.difficulty_level}").classes(
                        "text-sm font-medium text-green-600 mb-1"
                    )
                    ui.label(f"Sunlight: {plant_type.sunlight_requirement}").classes("text-sm text-gray-600 mb-1")
                    ui.label(f"Water every {plant_type.watering_frequency_days} days").classes(
                        "text-sm text-blue-600 mb-3"
                    )
                    ui.label(plant_type.description).classes("text-sm text-gray-500")

        ui.separator().classes("my-6")
        ui.link("← Back to Plant Tracker", "/").classes("text-green-600 hover:text-green-800")
