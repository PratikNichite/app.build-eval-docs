from sqlmodel import SQLModel, Field, Relationship
from datetime import datetime, date
from typing import Optional, List
from decimal import Decimal


# Persistent models (stored in database)
class User(SQLModel, table=True):
    __tablename__ = "users"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100)
    email: str = Field(unique=True, max_length=255)
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)

    plants: List["Plant"] = Relationship(back_populates="user")


class PlantType(SQLModel, table=True):
    __tablename__ = "plant_types"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100, unique=True)
    description: str = Field(default="", max_length=500)
    watering_frequency_days: int = Field(default=7, description="Recommended watering frequency in days")
    sunlight_requirement: str = Field(max_length=50, default="Medium", description="Low, Medium, High")
    difficulty_level: str = Field(max_length=20, default="Easy", description="Easy, Medium, Hard")
    created_at: datetime = Field(default_factory=datetime.utcnow)

    plants: List["Plant"] = Relationship(back_populates="plant_type")


class Plant(SQLModel, table=True):
    __tablename__ = "plants"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100)
    nickname: Optional[str] = Field(default=None, max_length=100)
    user_id: int = Field(foreign_key="users.id")
    plant_type_id: int = Field(foreign_key="plant_types.id")
    location: str = Field(max_length=100, description="Where the plant is located")
    acquisition_date: date = Field(description="When the plant was acquired")
    last_watered: Optional[date] = Field(default=None, description="Last watering date")
    notes: str = Field(default="", max_length=1000)
    is_active: bool = Field(default=True, description="Whether the plant is still being cared for")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    user: User = Relationship(back_populates="plants")
    plant_type: PlantType = Relationship(back_populates="plants")
    watering_records: List["WateringRecord"] = Relationship(back_populates="plant")


class WateringRecord(SQLModel, table=True):
    __tablename__ = "watering_records"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    plant_id: int = Field(foreign_key="plants.id")
    watered_date: date = Field(description="Date when plant was watered")
    amount_ml: Optional[Decimal] = Field(default=None, description="Amount of water in milliliters")
    notes: str = Field(default="", max_length=500)
    created_at: datetime = Field(default_factory=datetime.utcnow)

    plant: Plant = Relationship(back_populates="watering_records")


# Non-persistent schemas (for validation, forms, API requests/responses)
class UserCreate(SQLModel, table=False):
    name: str = Field(max_length=100)
    email: str = Field(max_length=255)


class UserUpdate(SQLModel, table=False):
    name: Optional[str] = Field(default=None, max_length=100)
    email: Optional[str] = Field(default=None, max_length=255)
    is_active: Optional[bool] = Field(default=None)


class PlantTypeCreate(SQLModel, table=False):
    name: str = Field(max_length=100)
    description: str = Field(default="", max_length=500)
    watering_frequency_days: int = Field(default=7)
    sunlight_requirement: str = Field(max_length=50, default="Medium")
    difficulty_level: str = Field(max_length=20, default="Easy")


class PlantTypeUpdate(SQLModel, table=False):
    name: Optional[str] = Field(default=None, max_length=100)
    description: Optional[str] = Field(default=None, max_length=500)
    watering_frequency_days: Optional[int] = Field(default=None)
    sunlight_requirement: Optional[str] = Field(default=None, max_length=50)
    difficulty_level: Optional[str] = Field(default=None, max_length=20)


class PlantCreate(SQLModel, table=False):
    name: str = Field(max_length=100)
    nickname: Optional[str] = Field(default=None, max_length=100)
    user_id: int
    plant_type_id: int
    location: str = Field(max_length=100)
    acquisition_date: date
    last_watered: Optional[date] = Field(default=None)
    notes: str = Field(default="", max_length=1000)


class PlantUpdate(SQLModel, table=False):
    name: Optional[str] = Field(default=None, max_length=100)
    nickname: Optional[str] = Field(default=None, max_length=100)
    plant_type_id: Optional[int] = Field(default=None)
    location: Optional[str] = Field(default=None, max_length=100)
    acquisition_date: Optional[date] = Field(default=None)
    last_watered: Optional[date] = Field(default=None)
    notes: Optional[str] = Field(default=None, max_length=1000)
    is_active: Optional[bool] = Field(default=None)


class WateringRecordCreate(SQLModel, table=False):
    plant_id: int
    watered_date: date
    amount_ml: Optional[Decimal] = Field(default=None)
    notes: str = Field(default="", max_length=500)


class WateringRecordUpdate(SQLModel, table=False):
    watered_date: Optional[date] = Field(default=None)
    amount_ml: Optional[Decimal] = Field(default=None)
    notes: Optional[str] = Field(default=None, max_length=500)


# Response schemas for API/UI with computed fields
class PlantResponse(SQLModel, table=False):
    id: int
    name: str
    nickname: Optional[str]
    location: str
    acquisition_date: str  # ISO format date string
    last_watered: Optional[str]  # ISO format date string
    notes: str
    is_active: bool
    created_at: str  # ISO format datetime string
    updated_at: str  # ISO format datetime string
    plant_type_name: str
    user_name: str
    days_since_watered: Optional[int]  # Computed field for mood logic
    mood: str  # Computed field: "Happy", "Thirsty", "Stressed", etc.


class UserResponse(SQLModel, table=False):
    id: int
    name: str
    email: str
    is_active: bool
    created_at: str  # ISO format datetime string
    plant_count: int  # Number of active plants
