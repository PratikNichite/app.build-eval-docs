from datetime import date, datetime
from typing import Optional, List
from sqlmodel import select
from decimal import Decimal

from app.database import get_session
from app.models import Plant, PlantType, User, WateringRecord, PlantCreate, PlantResponse


class PlantMoodCalculator:
    """Calculate plant mood based on watering schedule and care requirements."""

    @staticmethod
    def calculate_mood(plant: Plant, plant_type: PlantType) -> str:
        """Calculate plant mood based on watering history and requirements."""
        if plant.last_watered is None:
            return "Thirsty"

        days_since_watered = (date.today() - plant.last_watered).days
        recommended_frequency = plant_type.watering_frequency_days

        if days_since_watered <= recommended_frequency:
            return "Happy"
        elif days_since_watered <= recommended_frequency + 2:
            return "Slightly Thirsty"
        elif days_since_watered <= recommended_frequency + 5:
            return "Thirsty"
        else:
            return "Stressed"

    @staticmethod
    def get_mood_emoji(mood: str) -> str:
        """Get emoji representation of plant mood."""
        mood_emojis = {"Happy": "😊", "Slightly Thirsty": "🙂", "Thirsty": "😐", "Stressed": "😟"}
        return mood_emojis.get(mood, "🤔")

    @staticmethod
    def get_mood_color(mood: str) -> str:
        """Get color class for plant mood."""
        mood_colors = {
            "Happy": "text-green-500",
            "Slightly Thirsty": "text-yellow-500",
            "Thirsty": "text-orange-500",
            "Stressed": "text-red-500",
        }
        return mood_colors.get(mood, "text-gray-500")


class PlantService:
    """Service for plant-related operations."""

    @staticmethod
    def get_all_plants(user_id: Optional[int] = None) -> List[PlantResponse]:
        """Get all plants, optionally filtered by user."""
        with get_session() as session:
            query = select(Plant, PlantType, User).join(PlantType).join(User)
            if user_id is not None:
                query = query.where(Plant.user_id == user_id)

            results = session.exec(query).all()

            plant_responses = []
            for plant, plant_type, user in results:
                if not plant.is_active:
                    continue

                days_since_watered = None
                if plant.last_watered:
                    days_since_watered = (date.today() - plant.last_watered).days

                mood = PlantMoodCalculator.calculate_mood(plant, plant_type)

                plant_response = PlantResponse(
                    id=plant.id if plant.id is not None else 0,
                    name=plant.name,
                    nickname=plant.nickname,
                    location=plant.location,
                    acquisition_date=plant.acquisition_date.isoformat(),
                    last_watered=plant.last_watered.isoformat() if plant.last_watered else None,
                    notes=plant.notes,
                    is_active=plant.is_active,
                    created_at=plant.created_at.isoformat(),
                    updated_at=plant.updated_at.isoformat(),
                    plant_type_name=plant_type.name,
                    user_name=user.name,
                    days_since_watered=days_since_watered,
                    mood=mood,
                )
                plant_responses.append(plant_response)

            return plant_responses

    @staticmethod
    def get_plant_by_id(plant_id: int) -> Optional[PlantResponse]:
        """Get a specific plant by ID."""
        with get_session() as session:
            query = select(Plant, PlantType, User).join(PlantType).join(User).where(Plant.id == plant_id)
            result = session.exec(query).first()

            if not result:
                return None

            plant, plant_type, user = result

            days_since_watered = None
            if plant.last_watered:
                days_since_watered = (date.today() - plant.last_watered).days

            mood = PlantMoodCalculator.calculate_mood(plant, plant_type)

            return PlantResponse(
                id=plant.id if plant.id is not None else 0,
                name=plant.name,
                nickname=plant.nickname,
                location=plant.location,
                acquisition_date=plant.acquisition_date.isoformat(),
                last_watered=plant.last_watered.isoformat() if plant.last_watered else None,
                notes=plant.notes,
                is_active=plant.is_active,
                created_at=plant.created_at.isoformat(),
                updated_at=plant.updated_at.isoformat(),
                plant_type_name=plant_type.name,
                user_name=user.name,
                days_since_watered=days_since_watered,
                mood=mood,
            )

    @staticmethod
    def create_plant(plant_data: PlantCreate) -> Optional[int]:
        """Create a new plant and return its ID."""
        with get_session() as session:
            # Verify user exists
            user = session.get(User, plant_data.user_id)
            if user is None:
                return None

            # Verify plant type exists
            plant_type = session.get(PlantType, plant_data.plant_type_id)
            if plant_type is None:
                return None

            plant = Plant(
                name=plant_data.name,
                nickname=plant_data.nickname,
                user_id=plant_data.user_id,
                plant_type_id=plant_data.plant_type_id,
                location=plant_data.location,
                acquisition_date=plant_data.acquisition_date,
                last_watered=plant_data.last_watered,
                notes=plant_data.notes,
                updated_at=datetime.utcnow(),
            )

            session.add(plant)
            session.commit()
            session.refresh(plant)

            return plant.id

    @staticmethod
    def water_plant(plant_id: int, amount_ml: Optional[Decimal] = None, notes: str = "") -> bool:
        """Water a plant and record the watering."""
        with get_session() as session:
            plant = session.get(Plant, plant_id)
            if plant is None:
                return False

            # Update plant's last watered date
            plant.last_watered = date.today()
            plant.updated_at = datetime.utcnow()

            # Create watering record
            watering_record = WateringRecord(
                plant_id=plant_id, watered_date=date.today(), amount_ml=amount_ml, notes=notes
            )

            session.add(watering_record)
            session.commit()

            return True

    @staticmethod
    def get_all_plant_types() -> List[PlantType]:
        """Get all available plant types."""
        with get_session() as session:
            return list(session.exec(select(PlantType)).all())

    @staticmethod
    def get_all_users() -> List[User]:
        """Get all users."""
        with get_session() as session:
            return list(session.exec(select(User).where(User.is_active == True)).all())

    @staticmethod
    def ensure_default_data():
        """Ensure default users and plant types exist for demo purposes."""
        with get_session() as session:
            # Check if we have any users
            existing_users = session.exec(select(User)).all()
            if not existing_users:
                # Create default user
                default_user = User(name="Plant Lover", email="plantlover@example.com")
                session.add(default_user)

            # Check if we have any plant types
            existing_types = session.exec(select(PlantType)).all()
            if not existing_types:
                # Create default plant types
                default_types = [
                    PlantType(
                        name="Pothos",
                        description="Easy-care trailing plant perfect for beginners",
                        watering_frequency_days=7,
                        sunlight_requirement="Low to Medium",
                        difficulty_level="Easy",
                    ),
                    PlantType(
                        name="Snake Plant",
                        description="Low-maintenance succulent that tolerates neglect",
                        watering_frequency_days=14,
                        sunlight_requirement="Low",
                        difficulty_level="Easy",
                    ),
                    PlantType(
                        name="Fiddle Leaf Fig",
                        description="Popular but finicky tree with large leaves",
                        watering_frequency_days=7,
                        sunlight_requirement="High",
                        difficulty_level="Hard",
                    ),
                    PlantType(
                        name="Spider Plant",
                        description="Fast-growing plant that produces baby plants",
                        watering_frequency_days=5,
                        sunlight_requirement="Medium",
                        difficulty_level="Easy",
                    ),
                    PlantType(
                        name="Monstera Deliciosa",
                        description="Instagram-famous plant with fenestrated leaves",
                        watering_frequency_days=7,
                        sunlight_requirement="Medium to High",
                        difficulty_level="Medium",
                    ),
                ]

                for plant_type in default_types:
                    session.add(plant_type)

            session.commit()
