"""Main wellness tracking UI module."""

from datetime import date
from nicegui import ui, app

from app.wellness_service import WellnessService
from app.models import WellnessEntryCreate, WellnessEntryUpdate, WellnessEntry


def create():
    """Create the wellness tracking UI pages."""

    # Apply modern theme
    ui.colors(
        primary="#2563eb",  # Professional blue
        secondary="#64748b",  # Subtle gray
        accent="#10b981",  # Success green
        positive="#10b981",
        negative="#ef4444",  # Error red
        warning="#f59e0b",  # Warning amber
        info="#3b82f6",  # Info blue
    )

    @ui.page("/")
    def dashboard():
        """Main dashboard page."""
        ui.label("✨🌟 Daily Wellness Tracker 🌟✨").classes("text-3xl font-bold text-center text-gray-800 mb-8")

        # Navigation
        with ui.row().classes("gap-4 justify-center mb-8"):
            ui.button("📊 Dashboard", on_click=lambda: ui.navigate.to("/")).classes("px-6 py-3")
            ui.button("📝 Add Entry", on_click=lambda: ui.navigate.to("/entry")).classes("px-6 py-3")
            ui.button("📈 Insights", on_click=lambda: ui.navigate.to("/insights")).classes("px-6 py-3")

        # Today's entry status
        today = date.today()
        today_entry = WellnessService.get_entry_by_date(today)

        with ui.card().classes("w-full max-w-4xl mx-auto p-6 mb-6 shadow-lg"):
            ui.label(f"Today - {today.strftime('%B %d, %Y')}").classes("text-xl font-semibold text-gray-700 mb-4")

            if today_entry:
                _display_entry_summary(today_entry)
                with ui.row().classes("gap-2 mt-4"):

                    def edit_today():
                        app.storage.user["edit_date"] = today.isoformat()
                        ui.navigate.to("/entry")

                    ui.button("Edit Today's Entry", on_click=edit_today).classes("bg-blue-500 text-white px-4 py-2")
            else:
                ui.label("😢 No entry recorded for today. Let's fix that!").classes("text-gray-500 text-center py-8")
                ui.button("Add Today's Entry", on_click=lambda: ui.navigate.to("/entry")).classes(
                    "bg-green-500 text-white px-6 py-3 mx-auto"
                )

        # Recent entries
        recent_entries = WellnessService.get_recent_entries(7)
        if recent_entries:
            ui.label("📋 Recent Entries").classes("text-2xl font-bold text-gray-800 mb-4")

            for entry in recent_entries:
                if entry.entry_date == today:
                    continue  # Skip today as it's shown above

                with ui.card().classes("w-full max-w-4xl mx-auto p-4 mb-3 shadow-md hover:shadow-lg transition-shadow"):
                    with ui.row().classes("justify-between items-center"):
                        ui.label(entry.entry_date.strftime("%A, %B %d")).classes("text-lg font-semibold text-gray-700")

                        def edit_entry(date_iso=entry.entry_date.isoformat()):
                            app.storage.user["edit_date"] = date_iso
                            ui.navigate.to("/entry")

                        ui.button("View/Edit", on_click=edit_entry).classes("text-sm px-3 py-1").props("outline")

                    _display_entry_summary(entry, compact=True)

    @ui.page("/entry")
    def entry_form():
        """Entry form page for adding/editing wellness data."""
        # Default to today's date
        entry_date = date.today()

        # Try to get date from storage if navigated from edit button
        if "edit_date" in app.storage.user:
            try:
                entry_date = date.fromisoformat(app.storage.user["edit_date"])
                del app.storage.user["edit_date"]  # Clean up after use
            except (ValueError, KeyError):
                entry_date = date.today()

        # Check if entry exists
        existing_entry = WellnessService.get_entry_by_date(entry_date)
        is_editing = existing_entry is not None

        ui.label("✨🌟 Daily Wellness Tracker 🌟✨").classes("text-3xl font-bold text-center text-gray-800 mb-4")
        ui.button("⬅ Back to Dashboard", on_click=lambda: ui.navigate.to("/")).classes("mb-6")

        with ui.card().classes("w-full max-w-2xl mx-auto p-8 shadow-lg"):
            title = f"📝 {'Edit' if is_editing else 'Add'} Entry Details - {entry_date.strftime('%B %d, %Y')}"
            ui.label(title).classes("text-2xl font-bold text-gray-800 mb-6")

            # Form inputs
            with ui.column().classes("gap-4 w-full"):
                # Date picker
                ui.label("Date").classes("text-sm font-medium text-gray-700")
                date_input = ui.date(value=entry_date.isoformat()).classes("w-full")

                # Sleep hours
                ui.label("Hours of Sleep 😴").classes("text-sm font-medium text-gray-700 mt-4")
                sleep_input = ui.number(
                    value=existing_entry.sleep_hours if existing_entry else 8.0,
                    min=0,
                    max=24,
                    step=0.5,
                    placeholder="e.g., 7.5",
                ).classes("w-full")

                # Stress level
                ui.label("Stress Level (1-10) 😨").classes("text-sm font-medium text-gray-700 mt-4")
                stress_input = ui.slider(
                    min=1, max=10, step=1, value=existing_entry.stress_level if existing_entry else 5
                ).classes("w-full")
                stress_display = ui.label(f"Level: {stress_input.value}").classes("text-sm text-gray-600")
                stress_input.on("update:model-value", lambda e: stress_display.set_text(f"Level: {e.args[0]}"))

                # Caffeine intake
                ui.label("Caffeine Intake (mg) ☕").classes("text-sm font-medium text-gray-700 mt-4")
                caffeine_input = ui.number(
                    value=existing_entry.caffeine_intake if existing_entry else 0,
                    min=0,
                    step=25,
                    placeholder="e.g., 200",
                ).classes("w-full")

                # Alcohol intake
                ui.label("Alcohol Intake (standard drinks) 🍷").classes("text-sm font-medium text-gray-700 mt-4")
                alcohol_input = ui.number(
                    value=existing_entry.alcohol_intake if existing_entry else 0, min=0, step=1, placeholder="e.g., 2"
                ).classes("w-full")

                # Notes
                ui.label("Notes (optional) 📓").classes("text-sm font-medium text-gray-700 mt-4")
                notes_input = (
                    ui.textarea(
                        value=existing_entry.notes if existing_entry else "",
                        placeholder="How was your day? Any observations?",
                    )
                    .classes("w-full")
                    .props("rows=3")
                )

            # Action buttons
            with ui.row().classes("gap-4 justify-end mt-8"):
                if is_editing:
                    ui.button("Delete Entry", on_click=lambda: _delete_entry(entry_date)).classes(
                        "bg-red-500 text-white px-4 py-2"
                    )

                ui.button("Cancel", on_click=lambda: ui.navigate.to("/")).classes("px-6 py-2").props("outline")

                ui.button(
                    "Save Entry",
                    on_click=lambda: _save_entry(
                        date_input, sleep_input, stress_input, caffeine_input, alcohol_input, notes_input, is_editing
                    ),
                ).classes("bg-green-500 text-white px-6 py-2")

    @ui.page("/insights")
    def insights_page():
        """Wellness insights and analytics page."""
        ui.label("✨🌟 Daily Wellness Tracker 🌟✨").classes("text-3xl font-bold text-center text-gray-800 mb-4")
        ui.button("⬅ Back to Dashboard", on_click=lambda: ui.navigate.to("/")).classes("mb-6")

        # Get wellness summary
        summary = WellnessService.get_wellness_summary(30)

        if summary.total_entries == 0:
            with ui.card().classes("w-full max-w-4xl mx-auto p-8 text-center shadow-lg"):
                ui.label("😢 No data available yet").classes("text-xl text-gray-500 mb-4")
                ui.label("Start tracking your wellness to see insights here!").classes("text-gray-400")
                ui.button("Add Your First Entry", on_click=lambda: ui.navigate.to("/entry")).classes(
                    "bg-green-500 text-white px-6 py-3 mt-4"
                )
            return

        ui.label("📈 Wellness Insights 📈").classes("text-2xl font-bold text-gray-800 mb-6")

        # Summary cards
        with ui.row().classes("gap-6 w-full max-w-6xl mx-auto mb-8"):
            _create_metric_card("Total Entries", str(summary.total_entries), "📊")
            _create_metric_card("Avg Sleep", f"{summary.avg_sleep_hours or 0:.1f}h", "😴")
            _create_metric_card("Avg Stress", f"{summary.avg_stress_level or 0:.1f}/10", "😰")
            _create_metric_card("Avg Caffeine", f"{summary.avg_caffeine_intake or 0:.0f}mg", "☕")

        # Trends
        with ui.card().classes("w-full max-w-4xl mx-auto p-6 mb-6 shadow-lg"):
            ui.label("📈 Trends").classes("text-xl font-bold text-gray-800 mb-4")

            with ui.row().classes("gap-8 justify-around"):
                with ui.column().classes("text-center"):
                    ui.label("Sleep Trend").classes("text-lg font-semibold text-gray-700")
                    trend_color = _get_trend_color(summary.sleep_trend)
                    ui.label(summary.sleep_trend.title()).classes(f"text-2xl font-bold {trend_color}")
                    if summary.last_week_avg_sleep:
                        ui.label(f"Last week: {summary.last_week_avg_sleep:.1f}h").classes("text-sm text-gray-500")

                with ui.column().classes("text-center"):
                    ui.label("Stress Trend").classes("text-lg font-semibold text-gray-700")
                    trend_color = _get_trend_color(summary.stress_trend, reverse=True)  # Lower stress is better
                    ui.label(summary.stress_trend.title()).classes(f"text-2xl font-bold {trend_color}")
                    if summary.last_week_avg_stress:
                        ui.label(f"Last week: {summary.last_week_avg_stress:.1f}/10").classes("text-sm text-gray-500")

        # Recent entries list
        recent_entries = WellnessService.get_recent_entries(14)
        if recent_entries:
            ui.label("📋 Recent Entries (Last 2 Weeks)").classes("text-xl font-bold text-gray-800 mb-4")

            for entry in recent_entries:
                with ui.card().classes("w-full max-w-4xl mx-auto p-4 mb-3 shadow-md"):
                    with ui.row().classes("justify-between items-center"):
                        ui.label(entry.entry_date.strftime("%A, %B %d")).classes("text-lg font-semibold text-gray-700")

                        def edit_entry_insights(date_iso=entry.entry_date.isoformat()):
                            app.storage.user["edit_date"] = date_iso
                            ui.navigate.to("/entry")

                        ui.button("Edit", on_click=edit_entry_insights).classes("text-sm px-3 py-1").props("outline")

                    _display_entry_summary(entry, compact=True)


def _display_entry_summary(entry: WellnessEntry, compact: bool = False):
    """Display a summary of a wellness entry."""
    if compact:
        with ui.row().classes("gap-6 mt-2 text-sm"):
            ui.label(f"😴 {entry.sleep_hours}h").classes("text-gray-600")
            ui.label(f"😰 {entry.stress_level}/10").classes("text-gray-600")
            ui.label(f"☕ {entry.caffeine_intake}mg").classes("text-gray-600")
            ui.label(f"🍷 {entry.alcohol_intake} drinks").classes("text-gray-600")
    else:
        with ui.row().classes("gap-8 justify-around text-center"):
            with ui.column():
                ui.label("😴 Sleep").classes("text-sm text-gray-500")
                ui.label(f"{entry.sleep_hours}h").classes("text-2xl font-bold text-blue-600")

            with ui.column():
                ui.label("😰 Stress").classes("text-sm text-gray-500")
                stress_color = (
                    "text-green-600"
                    if entry.stress_level <= 3
                    else "text-yellow-600"
                    if entry.stress_level <= 6
                    else "text-red-600"
                )
                ui.label(f"{entry.stress_level}/10").classes(f"text-2xl font-bold {stress_color}")

            with ui.column():
                ui.label("☕ Caffeine").classes("text-sm text-gray-500")
                ui.label(f"{entry.caffeine_intake}mg").classes("text-2xl font-bold text-orange-600")

            with ui.column():
                ui.label("🍷 Alcohol").classes("text-sm text-gray-500")
                ui.label(f"{entry.alcohol_intake} drinks").classes("text-2xl font-bold text-purple-600")

        if entry.notes:
            ui.label("Notes:").classes("text-sm font-medium text-gray-700 mt-4")
            ui.label(entry.notes).classes("text-gray-600 italic p-3 bg-gray-50 rounded")


def _create_metric_card(title: str, value: str, icon: str):
    """Create a metric display card."""
    with ui.card().classes("p-6 text-center min-w-32 shadow-lg hover:shadow-xl transition-shadow"):
        ui.label(icon).classes("text-3xl mb-2")
        ui.label(title).classes("text-sm text-gray-500 uppercase tracking-wider")
        ui.label(value).classes("text-2xl font-bold text-gray-800 mt-1")


def _get_trend_color(trend: str, reverse: bool = False) -> str:
    """Get color class for trend display."""
    if trend == "improving":
        return "text-red-500" if reverse else "text-green-500"
    elif trend == "declining":
        return "text-green-500" if reverse else "text-red-500"
    else:
        return "text-gray-500"


def _save_entry(date_input, sleep_input, stress_input, caffeine_input, alcohol_input, notes_input, is_editing: bool):
    """Save wellness entry to database."""
    try:
        entry_date = date.fromisoformat(date_input.value)

        if is_editing:
            # Update existing entry
            update_data = WellnessEntryUpdate(
                sleep_hours=float(sleep_input.value),
                stress_level=int(stress_input.value),
                caffeine_intake=int(caffeine_input.value or 0),
                alcohol_intake=int(alcohol_input.value or 0),
                notes=notes_input.value or "",
            )
            result = WellnessService.update_entry(entry_date, update_data)
            if result:
                ui.notify("Entry updated successfully! 🎉", type="positive")
            else:
                ui.notify("Failed to update entry 😭", type="negative")
        else:
            # Create new entry
            entry_data = WellnessEntryCreate(
                entry_date=entry_date,
                sleep_hours=float(sleep_input.value),
                stress_level=int(stress_input.value),
                caffeine_intake=int(caffeine_input.value or 0),
                alcohol_intake=int(alcohol_input.value or 0),
                notes=notes_input.value or "",
            )
            WellnessService.create_entry(entry_data)
            ui.notify("Entry saved successfully! 🎉", type="positive")

        ui.navigate.to("/")

    except ValueError as e:
        if "already exists" in str(e):
            ui.notify("Entry already exists for this date", type="warning")
        else:
            ui.notify(f"Invalid input: {str(e)}", type="negative")
    except Exception as e:
        ui.notify(f"Error saving entry: 😭 {str(e)}", type="negative")


def _delete_entry(entry_date: date):
    """Delete wellness entry."""
    try:
        success = WellnessService.delete_entry(entry_date)
        if success:
            ui.notify("Entry deleted successfully! 🎉", type="positive")
            ui.navigate.to("/")
        else:
            ui.notify("Entry not found", type="warning")
    except Exception as e:
        ui.notify(f"Error deleting entry: 😭 {str(e)}", type="negative")
