from sqlmodel import SQLModel, Field
from datetime import datetime, date
from typing import Optional


# Persistent models (stored in database)
class WellnessEntry(SQLModel, table=True):
    """Daily wellness tracking entry for a single user."""

    __tablename__ = "wellness_entries"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    entry_date: date = Field(unique=True, description="Date of the wellness entry")
    sleep_hours: float = Field(ge=0.0, le=24.0, description="Hours of sleep")
    stress_level: int = Field(ge=1, le=10, description="Stress level on a scale of 1-10")
    caffeine_intake: int = Field(ge=0, default=0, description="Caffeine intake in mg")
    alcohol_intake: int = Field(ge=0, default=0, description="Alcohol intake in standard drinks")
    notes: str = Field(default="", max_length=500, description="Optional notes about the day")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class WellnessEntryCreate(SQLModel, table=False):
    """Schema for creating a new wellness entry."""

    entry_date: date
    sleep_hours: float = Field(ge=0.0, le=24.0)
    stress_level: int = Field(ge=1, le=10)
    caffeine_intake: int = Field(ge=0, default=0)
    alcohol_intake: int = Field(ge=0, default=0)
    notes: str = Field(default="", max_length=500)


class WellnessEntryUpdate(SQLModel, table=False):
    """Schema for updating an existing wellness entry."""

    sleep_hours: Optional[float] = Field(default=None, ge=0.0, le=24.0)
    stress_level: Optional[int] = Field(default=None, ge=1, le=10)
    caffeine_intake: Optional[int] = Field(default=None, ge=0)
    alcohol_intake: Optional[int] = Field(default=None, ge=0)
    notes: Optional[str] = Field(default=None, max_length=500)


class WellnessEntryResponse(SQLModel, table=False):
    """Schema for wellness entry API responses."""

    id: int
    entry_date: date
    sleep_hours: float
    stress_level: int
    caffeine_intake: int
    alcohol_intake: int
    notes: str
    created_at: datetime
    updated_at: datetime


class WellnessSummary(SQLModel, table=False):
    """Schema for wellness insights and summary data."""

    total_entries: int
    avg_sleep_hours: Optional[float]
    avg_stress_level: Optional[float]
    avg_caffeine_intake: Optional[float]
    avg_alcohol_intake: Optional[float]
    sleep_trend: str = Field(description="Trend analysis: improving, declining, or stable")
    stress_trend: str = Field(description="Trend analysis: improving, declining, or stable")
    last_week_avg_sleep: Optional[float]
    last_week_avg_stress: Optional[float]
