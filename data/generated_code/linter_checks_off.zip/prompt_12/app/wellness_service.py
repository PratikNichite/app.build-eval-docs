"""Service layer for wellness tracking operations."""

from datetime import date, datetime, timedelta
from typing import Optional
from decimal import Decimal
from sqlmodel import select, desc

from app.database import get_session
from app.models import WellnessEntry, WellnessEntryCreate, WellnessEntryUpdate, WellnessSummary


class WellnessService:
    """Service class for wellness tracking operations."""

    @staticmethod
    def create_entry(entry: WellnessEntryCreate) -> WellnessEntry:
        """Create a new wellness entry."""
        with get_session() as session:
            # Check if entry already exists for this date
            existing = session.exec(select(WellnessEntry).where(WellnessEntry.entry_date == entry.entry_date)).first()

            if existing:
                raise ValueError(f"Entry already exists for {entry.entry_date}")

            db_entry = WellnessEntry(**entry.model_dump())
            session.add(db_entry)
            session.commit()
            session.refresh(db_entry)
            return db_entry

    @staticmethod
    def get_entry_by_date(entry_date: date) -> Optional[WellnessEntry]:
        """Get wellness entry for a specific date."""
        with get_session() as session:
            return session.exec(select(WellnessEntry).where(WellnessEntry.entry_date == entry_date)).first()

    @staticmethod
    def update_entry(entry_date: date, update_data: WellnessEntryUpdate) -> Optional[WellnessEntry]:
        """Update an existing wellness entry."""
        with get_session() as session:
            entry = session.exec(select(WellnessEntry).where(WellnessEntry.entry_date == entry_date)).first()

            if entry is None:
                return None

            update_dict = update_data.model_dump(exclude_unset=True)
            for field, value in update_dict.items():
                if value is not None:
                    setattr(entry, field, value)

            entry.updated_at = datetime.utcnow()
            session.add(entry)
            session.commit()
            session.refresh(entry)
            return entry

    @staticmethod
    def get_recent_entries(days: int = 7) -> list[WellnessEntry]:
        """Get recent wellness entries, ordered by date descending."""
        with get_session() as session:
            cutoff_date = date.today() - timedelta(days=days)
            return list(
                session.exec(
                    select(WellnessEntry)
                    .where(WellnessEntry.entry_date >= cutoff_date)
                    .order_by(desc(WellnessEntry.entry_date))
                )
            )

    @staticmethod
    def get_wellness_summary(days: int = 30) -> WellnessSummary:
        """Generate wellness insights and summary data."""
        with get_session() as session:
            cutoff_date = date.today() - timedelta(days=days)
            entries = list(
                session.exec(
                    select(WellnessEntry)
                    .where(WellnessEntry.entry_date >= cutoff_date)
                    .order_by(desc(WellnessEntry.entry_date))
                )
            )

            if not entries:
                return WellnessSummary(
                    total_entries=0,
                    avg_sleep_hours=None,
                    avg_stress_level=None,
                    avg_caffeine_intake=None,
                    avg_alcohol_intake=None,
                    sleep_trend="stable",
                    stress_trend="stable",
                    last_week_avg_sleep=None,
                    last_week_avg_stress=None,
                )

            total_entries = len(entries)

            # Calculate averages
            avg_sleep = sum(e.sleep_hours for e in entries) / total_entries
            avg_stress = sum(e.stress_level for e in entries) / total_entries
            avg_caffeine = sum(e.caffeine_intake for e in entries) / total_entries
            avg_alcohol = sum(e.alcohol_intake for e in entries) / total_entries

            # Calculate trends (last week vs previous week)
            last_week_entries = [e for e in entries if e.entry_date >= date.today() - timedelta(days=7)]
            prev_week_entries = [
                e
                for e in entries
                if date.today() - timedelta(days=14) <= e.entry_date < date.today() - timedelta(days=7)
            ]

            sleep_trend = "stable"
            stress_trend = "stable"
            last_week_avg_sleep = None
            last_week_avg_stress = None

            if last_week_entries:
                last_week_avg_sleep = sum(e.sleep_hours for e in last_week_entries) / len(last_week_entries)
                last_week_avg_stress = sum(e.stress_level for e in last_week_entries) / len(last_week_entries)

                if prev_week_entries:
                    prev_week_avg_sleep = sum(e.sleep_hours for e in prev_week_entries) / len(prev_week_entries)
                    prev_week_avg_stress = sum(e.stress_level for e in prev_week_entries) / len(prev_week_entries)

                    sleep_diff = last_week_avg_sleep - prev_week_avg_sleep
                    stress_diff = last_week_avg_stress - prev_week_avg_stress

                    if sleep_diff > 0.5:
                        sleep_trend = "improving"
                    elif sleep_diff < -0.5:
                        sleep_trend = "declining"

                    if stress_diff < -0.5:
                        stress_trend = "improving"
                    elif stress_diff > 0.5:
                        stress_trend = "declining"

            return WellnessSummary(
                total_entries=total_entries,
                avg_sleep_hours=float(Decimal(str(avg_sleep)).quantize(Decimal("0.1"))),
                avg_stress_level=float(Decimal(str(avg_stress)).quantize(Decimal("0.1"))),
                avg_caffeine_intake=float(Decimal(str(avg_caffeine)).quantize(Decimal("0.1"))),
                avg_alcohol_intake=float(Decimal(str(avg_alcohol)).quantize(Decimal("0.1"))),
                sleep_trend=sleep_trend,
                stress_trend=stress_trend,
                last_week_avg_sleep=float(Decimal(str(last_week_avg_sleep)).quantize(Decimal("0.1")))
                if last_week_avg_sleep
                else None,
                last_week_avg_stress=float(Decimal(str(last_week_avg_stress)).quantize(Decimal("0.1")))
                if last_week_avg_stress
                else None,
            )

    @staticmethod
    def delete_entry(entry_date: date) -> bool:
        """Delete wellness entry for a specific date."""
        with get_session() as session:
            entry = session.exec(select(WellnessEntry).where(WellnessEntry.entry_date == entry_date)).first()

            if entry is None:
                return False

            session.delete(entry)
            session.commit()
            return True
