"""Tests for wellness service layer."""

import pytest
from datetime import date, timedelta

from app.database import reset_db
from app.wellness_service import WellnessService
from app.models import WellnessEntryCreate, WellnessEntryUpdate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_create_entry(new_db):
    """Test creating a new wellness entry."""
    entry_data = WellnessEntryCreate(
        entry_date=date.today(),
        sleep_hours=7.5,
        stress_level=4,
        caffeine_intake=150,
        alcohol_intake=1,
        notes="Good day overall",
    )

    result = WellnessService.create_entry(entry_data)

    assert result.id is not None
    assert result.entry_date == date.today()
    assert result.sleep_hours == 7.5
    assert result.stress_level == 4
    assert result.caffeine_intake == 150
    assert result.alcohol_intake == 1
    assert result.notes == "Good day overall"


def test_create_duplicate_entry_fails(new_db):
    """Test that creating duplicate entries for same date fails."""
    entry_data = WellnessEntryCreate(entry_date=date.today(), sleep_hours=7.5, stress_level=4)

    # Create first entry
    WellnessService.create_entry(entry_data)

    # Attempt to create duplicate should fail
    with pytest.raises(ValueError, match="Entry already exists"):
        WellnessService.create_entry(entry_data)


def test_get_entry_by_date(new_db):
    """Test retrieving entry by date."""
    today = date.today()
    entry_data = WellnessEntryCreate(entry_date=today, sleep_hours=8.0, stress_level=3)

    WellnessService.create_entry(entry_data)
    result = WellnessService.get_entry_by_date(today)

    assert result is not None
    assert result.entry_date == today
    assert result.sleep_hours == 8.0
    assert result.stress_level == 3


def test_get_entry_by_date_not_found(new_db):
    """Test retrieving non-existent entry returns None."""
    result = WellnessService.get_entry_by_date(date.today())
    assert result is None


def test_update_entry(new_db):
    """Test updating an existing entry."""
    today = date.today()
    entry_data = WellnessEntryCreate(entry_date=today, sleep_hours=7.0, stress_level=5, caffeine_intake=100)

    WellnessService.create_entry(entry_data)

    update_data = WellnessEntryUpdate(sleep_hours=8.5, stress_level=3, notes="Updated entry")

    result = WellnessService.update_entry(today, update_data)

    assert result is not None
    assert result.sleep_hours == 8.5
    assert result.stress_level == 3
    assert result.caffeine_intake == 100  # Unchanged
    assert result.notes == "Updated entry"


def test_update_nonexistent_entry(new_db):
    """Test updating non-existent entry returns None."""
    update_data = WellnessEntryUpdate(sleep_hours=8.0)
    result = WellnessService.update_entry(date.today(), update_data)
    assert result is None


def test_get_recent_entries(new_db):
    """Test retrieving recent entries."""
    today = date.today()
    yesterday = today - timedelta(days=1)
    week_ago = today - timedelta(days=7)

    # Create entries
    for entry_date in [today, yesterday, week_ago]:
        entry_data = WellnessEntryCreate(entry_date=entry_date, sleep_hours=7.0, stress_level=4)
        WellnessService.create_entry(entry_data)

    # Get recent entries (default 7 days)
    recent = WellnessService.get_recent_entries(7)

    assert len(recent) == 3
    # Should be ordered by date descending
    assert recent[0].entry_date == today
    assert recent[1].entry_date == yesterday
    assert recent[2].entry_date == week_ago


def test_get_recent_entries_limited_days(new_db):
    """Test retrieving recent entries with day limit."""
    today = date.today()
    yesterday = today - timedelta(days=1)
    week_ago = today - timedelta(days=7)

    # Create entries
    for entry_date in [today, yesterday, week_ago]:
        entry_data = WellnessEntryCreate(entry_date=entry_date, sleep_hours=7.0, stress_level=4)
        WellnessService.create_entry(entry_data)

    # Get only last 2 days
    recent = WellnessService.get_recent_entries(2)

    assert len(recent) == 2
    assert recent[0].entry_date == today
    assert recent[1].entry_date == yesterday


def test_wellness_summary_empty(new_db):
    """Test wellness summary with no entries."""
    summary = WellnessService.get_wellness_summary()

    assert summary.total_entries == 0
    assert summary.avg_sleep_hours is None
    assert summary.avg_stress_level is None
    assert summary.avg_caffeine_intake is None
    assert summary.avg_alcohol_intake is None
    assert summary.sleep_trend == "stable"
    assert summary.stress_trend == "stable"


def test_wellness_summary_with_data(new_db):
    """Test wellness summary with actual data."""
    today = date.today()

    # Create entries over several days
    entries_data = [
        (today - timedelta(days=0), 8.0, 3, 100, 0),
        (today - timedelta(days=1), 7.5, 4, 150, 1),
        (today - timedelta(days=2), 7.0, 5, 200, 2),
        (today - timedelta(days=3), 8.5, 2, 50, 0),
    ]

    for entry_date, sleep, stress, caffeine, alcohol in entries_data:
        entry_data = WellnessEntryCreate(
            entry_date=entry_date,
            sleep_hours=sleep,
            stress_level=stress,
            caffeine_intake=caffeine,
            alcohol_intake=alcohol,
        )
        WellnessService.create_entry(entry_data)

    summary = WellnessService.get_wellness_summary()

    assert summary.total_entries == 4
    # Average calculations: sleep=(8+7.5+7+8.5)/4=7.75, stress=(3+4+5+2)/4=3.5
    assert summary.avg_sleep_hours == 7.8  # Rounded to 1 decimal
    assert summary.avg_stress_level == 3.5
    assert summary.avg_caffeine_intake == 125.0  # (100+150+200+50)/4
    assert summary.avg_alcohol_intake == 0.8  # (0+1+2+0)/4


def test_wellness_summary_trends(new_db):
    """Test wellness summary trend calculations."""
    today = date.today()

    # Create entries with improving sleep and declining stress trends
    # Last week: better sleep (8h avg), lower stress (2.5 avg)
    # Previous week: worse sleep (6h avg), higher stress (6 avg)

    last_week_entries = [
        (today - timedelta(days=1), 8.0, 2),
        (today - timedelta(days=2), 8.0, 3),
    ]

    prev_week_entries = [
        (today - timedelta(days=8), 6.0, 6),
        (today - timedelta(days=9), 6.0, 6),
    ]

    for entry_date, sleep, stress in last_week_entries + prev_week_entries:
        entry_data = WellnessEntryCreate(entry_date=entry_date, sleep_hours=sleep, stress_level=stress)
        WellnessService.create_entry(entry_data)

    summary = WellnessService.get_wellness_summary()

    assert summary.sleep_trend == "improving"  # 8.0 vs 6.0 (diff > 0.5)
    assert summary.stress_trend == "improving"  # 2.5 vs 6.0 (diff < -0.5, lower is better)
    assert summary.last_week_avg_sleep == 8.0
    assert summary.last_week_avg_stress == 2.5


def test_delete_entry(new_db):
    """Test deleting an entry."""
    today = date.today()
    entry_data = WellnessEntryCreate(entry_date=today, sleep_hours=7.0, stress_level=4)

    WellnessService.create_entry(entry_data)

    # Verify entry exists
    assert WellnessService.get_entry_by_date(today) is not None

    # Delete entry
    success = WellnessService.delete_entry(today)
    assert success

    # Verify entry is gone
    assert WellnessService.get_entry_by_date(today) is None


def test_delete_nonexistent_entry(new_db):
    """Test deleting non-existent entry returns False."""
    success = WellnessService.delete_entry(date.today())
    assert not success


def test_entry_validation_constraints(new_db):
    """Test that model validation constraints work."""
    # Test invalid sleep hours
    with pytest.raises(Exception):  # ValidationError from pydantic
        entry_data = WellnessEntryCreate(
            entry_date=date.today(),
            sleep_hours=25.0,  # Invalid: > 24
            stress_level=5,
        )
        WellnessService.create_entry(entry_data)

    # Test invalid stress level
    with pytest.raises(Exception):
        entry_data = WellnessEntryCreate(
            entry_date=date.today(),
            sleep_hours=8.0,
            stress_level=11,  # Invalid: > 10
        )
        WellnessService.create_entry(entry_data)


def test_decimal_precision_in_summary(new_db):
    """Test that summary calculations maintain proper decimal precision."""
    today = date.today()

    # Create entries with values that would create floating point precision issues
    entry_data = WellnessEntryCreate(
        entry_date=today,
        sleep_hours=7.333333,  # Repeating decimal
        stress_level=3,
        caffeine_intake=133,
        alcohol_intake=1,
    )
    WellnessService.create_entry(entry_data)

    summary = WellnessService.get_wellness_summary()

    # Should be rounded to 1 decimal place
    assert isinstance(summary.avg_sleep_hours, float)
    assert len(str(summary.avg_sleep_hours).split(".")[-1]) <= 1
