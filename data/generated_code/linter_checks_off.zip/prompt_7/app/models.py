from sqlmodel import SQLModel, Field
from datetime import datetime
from typing import Optional, List, Dict
from decimal import Decimal


# Persistent models (stored in database)
class GameSession(SQLModel, table=True):
    """Represents a complete snake game session."""

    __tablename__ = "game_sessions"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    player_name: str = Field(max_length=100, default="Anonymous")
    score: int = Field(default=0)
    final_snake_length: int = Field(default=1)
    game_duration: Decimal = Field(default=Decimal("0"), decimal_places=2)  # Duration in seconds
    grid_width: int = Field(default=20)
    grid_height: int = Field(default=20)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    ended_at: Optional[datetime] = Field(default=None)
    game_over_reason: str = Field(max_length=50, default="wall_collision")  # wall_collision, self_collision


class HighScore(SQLModel, table=True):
    """Tracks high scores for the snake game."""

    __tablename__ = "high_scores"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    player_name: str = Field(max_length=100)
    score: int = Field(index=True)
    snake_length: int = Field(default=1)
    game_duration: Decimal = Field(decimal_places=2)
    achieved_at: datetime = Field(default_factory=datetime.utcnow)


class GameSettings(SQLModel, table=True):
    """Stores game configuration and settings."""

    __tablename__ = "game_settings"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    setting_name: str = Field(max_length=50, unique=True)
    setting_value: str = Field(max_length=200)
    data_type: str = Field(max_length=20, default="string")  # string, int, float, bool
    description: str = Field(max_length=500, default="")
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class GameState(SQLModel, table=False):
    """Current state of an active game (not persisted)."""

    snake_positions: List[Dict[str, int]] = Field(default=[], description="List of {x, y} coordinates")
    food_position: Dict[str, int] = Field(default={}, description="Current food {x, y} coordinates")
    direction: str = Field(default="right", max_length=10)  # up, down, left, right
    score: int = Field(default=0)
    is_game_over: bool = Field(default=False)
    game_started: bool = Field(default=False)
    grid_width: int = Field(default=20)
    grid_height: int = Field(default=20)
    game_over_reason: str = Field(default="", max_length=50)


class GameMove(SQLModel, table=False):
    """Represents a move command from the player."""

    direction: str = Field(max_length=10)  # up, down, left, right


class GameSessionCreate(SQLModel, table=False):
    """Schema for creating a new game session."""

    player_name: str = Field(max_length=100, default="Anonymous")
    grid_width: int = Field(default=20, ge=10, le=50)
    grid_height: int = Field(default=20, ge=10, le=50)


class GameSessionUpdate(SQLModel, table=False):
    """Schema for updating a game session."""

    score: Optional[int] = Field(default=None, ge=0)
    final_snake_length: Optional[int] = Field(default=None, ge=1)
    game_duration: Optional[Decimal] = Field(default=None, decimal_places=2)
    ended_at: Optional[datetime] = Field(default=None)
    game_over_reason: Optional[str] = Field(default=None, max_length=50)


class HighScoreCreate(SQLModel, table=False):
    """Schema for creating a high score entry."""

    player_name: str = Field(max_length=100)
    score: int = Field(ge=0)
    snake_length: int = Field(ge=1)
    game_duration: Decimal = Field(decimal_places=2)


class GameSettingsUpdate(SQLModel, table=False):
    """Schema for updating game settings."""

    setting_value: str = Field(max_length=200)
    description: Optional[str] = Field(default=None, max_length=500)


class LeaderboardEntry(SQLModel, table=False):
    """Schema for leaderboard display."""

    rank: int
    player_name: str
    score: int
    snake_length: int
    game_duration: Decimal
    achieved_at: str  # ISO format datetime string
