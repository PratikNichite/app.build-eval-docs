from nicegui import ui, events
from typing import Dict, List, Optional
import random
import asyncio
from datetime import datetime
from decimal import Decimal
from sqlmodel import Session, select, desc
from app.database import ENGINE
from app.models import GameSession, HighScore, GameState


class SnakeGame:
    """Snake game logic and state management."""

    def __init__(self, grid_width: int = 20, grid_height: int = 20):
        self.grid_width = grid_width
        self.grid_height = grid_height
        self.cell_size = 20  # pixels
        self.game_state = GameState(
            snake_positions=[{"x": 10, "y": 10}],
            food_position={"x": 15, "y": 15},
            direction="right",
            score=0,
            is_game_over=False,
            game_started=False,
            grid_width=grid_width,
            grid_height=grid_height,
        )
        self.start_time: Optional[datetime] = None
        self.game_session_id: Optional[int] = None

    def start_game(self) -> None:
        """Initialize and start a new game."""
        self.game_state = GameState(
            snake_positions=[{"x": 10, "y": 10}],
            food_position=self._generate_food_position(),
            direction="right",
            score=0,
            is_game_over=False,
            game_started=True,
            grid_width=self.grid_width,
            grid_height=self.grid_height,
        )
        self.start_time = datetime.utcnow()
        self._save_game_session()

    def _generate_food_position(self) -> Dict[str, int]:
        """Generate a random food position that doesn't overlap with snake."""
        while True:
            food_pos = {"x": random.randint(0, self.grid_width - 1), "y": random.randint(0, self.grid_height - 1)}
            if food_pos not in self.game_state.snake_positions:
                return food_pos

    def change_direction(self, new_direction: str) -> None:
        """Change snake direction, preventing immediate reversals."""
        if not self.game_state.game_started or self.game_state.is_game_over:
            return

        opposite_directions = {"up": "down", "down": "up", "left": "right", "right": "left"}

        if new_direction != opposite_directions.get(self.game_state.direction):
            self.game_state.direction = new_direction

    def move_snake(self) -> bool:
        """Move snake one step forward. Returns True if game continues, False if game over."""
        if not self.game_state.game_started or self.game_state.is_game_over:
            return False

        head = self.game_state.snake_positions[0].copy()

        # Calculate new head position
        direction_map = {
            "up": {"x": 0, "y": -1},
            "down": {"x": 0, "y": 1},
            "left": {"x": -1, "y": 0},
            "right": {"x": 1, "y": 0},
        }

        delta = direction_map[self.game_state.direction]
        new_head = {"x": head["x"] + delta["x"], "y": head["y"] + delta["y"]}

        # Check wall collision
        if (
            new_head["x"] < 0
            or new_head["x"] >= self.grid_width
            or new_head["y"] < 0
            or new_head["y"] >= self.grid_height
        ):
            self._end_game("wall_collision")
            return False

        # Check self collision
        if new_head in self.game_state.snake_positions:
            self._end_game("self_collision")
            return False

        # Add new head
        self.game_state.snake_positions.insert(0, new_head)

        # Check food collision
        if new_head == self.game_state.food_position:
            self.game_state.score += 10
            self.game_state.food_position = self._generate_food_position()
        else:
            # Remove tail if no food eaten
            self.game_state.snake_positions.pop()

        return True

    def _end_game(self, reason: str) -> None:
        """End the current game and save results."""
        self.game_state.is_game_over = True
        self.game_state.game_over_reason = reason
        end_time = datetime.utcnow()

        if self.start_time and self.game_session_id:
            duration = (end_time - self.start_time).total_seconds()
            self._update_game_session(end_time, Decimal(str(duration)), reason)
            self._check_and_save_high_score(Decimal(str(duration)))

    def _save_game_session(self) -> None:
        """Save initial game session to database."""
        with Session(ENGINE) as session:
            game_session = GameSession(
                player_name="Anonymous",
                score=0,
                final_snake_length=1,
                grid_width=self.grid_width,
                grid_height=self.grid_height,
                created_at=self.start_time or datetime.utcnow(),
            )
            session.add(game_session)
            session.commit()
            session.refresh(game_session)
            if game_session.id is not None:
                self.game_session_id = game_session.id

    def _update_game_session(self, end_time: datetime, duration: Decimal, reason: str) -> None:
        """Update game session with final results."""
        if self.game_session_id is None:
            return

        with Session(ENGINE) as session:
            game_session = session.get(GameSession, self.game_session_id)
            if game_session:
                game_session.score = self.game_state.score
                game_session.final_snake_length = len(self.game_state.snake_positions)
                game_session.game_duration = duration
                game_session.ended_at = end_time
                game_session.game_over_reason = reason
                session.add(game_session)
                session.commit()

    def _check_and_save_high_score(self, duration: Decimal) -> None:
        """Check if current score qualifies as high score and save it."""
        with Session(ENGINE) as session:
            # Check if this score qualifies for top 10
            top_scores = session.exec(select(HighScore).order_by(desc(HighScore.score)).limit(10)).all()

            qualifies = len(top_scores) < 10 or self.game_state.score > min(score.score for score in top_scores)

            if qualifies:
                high_score = HighScore(
                    player_name="Anonymous",
                    score=self.game_state.score,
                    snake_length=len(self.game_state.snake_positions),
                    game_duration=duration,
                )
                session.add(high_score)
                session.commit()

    def get_high_scores(self, limit: int = 10) -> List[HighScore]:
        """Get top high scores from database."""
        with Session(ENGINE) as session:
            return list(session.exec(select(HighScore).order_by(desc(HighScore.score)).limit(limit)).all())


class SnakeGameUI:
    """UI component for the Snake game."""

    def __init__(self):
        self.game = SnakeGame()
        self.canvas: Optional[ui.scene] = None
        self.score_label: Optional[ui.label] = None
        self.pause_button: Optional[ui.button] = None
        self.game_over_dialog: Optional[ui.dialog] = None
        self.timer: Optional[ui.timer] = None
        self.is_paused = False

    def create_ui(self) -> None:
        """Create the game UI elements."""
        # Apply modern theme
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        with ui.column().classes("w-full h-screen bg-gray-900 text-white p-4"):
            # Header
            with ui.row().classes("w-full justify-between items-center mb-4"):
                ui.label("🐍 Snake Game").classes("text-3xl font-bold text-green-400")

                with ui.row().classes("gap-4 items-center"):
                    self.score_label = ui.label("🏆 Score: 0").classes("text-xl font-semibold text-white")
                    self.pause_button = ui.button("⏸️ Pause", on_click=self._toggle_pause).classes(
                        "bg-yellow-600 hover:bg-yellow-700"
                    )
                    ui.button("🎮 New Game", on_click=self._start_new_game).classes("bg-green-600 hover:bg-green-700")

            # Game area
            with ui.row().classes("gap-6"):
                # Game canvas
                with ui.column().classes("bg-gray-800 p-4 rounded-lg shadow-lg"):
                    self.canvas = ui.scene(
                        width=self.game.grid_width * self.game.cell_size,
                        height=self.game.grid_height * self.game.cell_size,
                    ).classes("border-2 border-gray-600")

                # Side panel with controls and high scores
                with ui.column().classes("w-80 bg-gray-800 p-4 rounded-lg shadow-lg"):
                    ui.label("🎮 Controls").classes("text-xl font-bold mb-2 text-green-400")
                    ui.label("🠉 🠋 🠈 🠊 Arrow Keys: Move").classes("text-sm mb-1")
                    ui.label("🔄 R: Restart Game").classes("text-sm mb-1")
                    ui.label("⏸️ Space: Pause/Resume").classes("text-sm mb-4")

                    ui.separator().classes("my-4")

                    ui.label("🏆 High Scores").classes("text-xl font-bold mb-2 text-green-400")
                    self._create_high_scores_table()

            # Instructions
            ui.label(
                "🎯 Use arrow keys to control the snake. Eat the red food to grow and increase your score! 🐍🍎"
            ).classes("text-center text-gray-400 mt-4")

        self._setup_keyboard_controls()
        self._render_game()

    def _create_high_scores_table(self) -> None:
        """Create high scores display table."""
        high_scores = self.game.get_high_scores()

        if not high_scores:
            ui.label("🏅 No high scores yet!").classes("text-gray-400 text-center")
            return

        with ui.column().classes("w-full"):
            for i, score in enumerate(high_scores, 1):
                with ui.row().classes("justify-between items-center py-1 px-2 bg-gray-700 rounded mb-1"):
                    ui.label(f"{i}.").classes("text-sm font-bold text-yellow-400 w-6")
                    ui.label(f"{score.score}").classes("text-sm font-semibold text-white")
                    ui.label(f"L:{score.snake_length}").classes("text-xs text-gray-400")

    def _setup_keyboard_controls(self) -> None:
        """Setup keyboard event handlers."""

        async def handle_key(e: events.KeyEventArguments) -> None:
            if e.key == "ArrowUp":
                self.game.change_direction("up")
            elif e.key == "ArrowDown":
                self.game.change_direction("down")
            elif e.key == "ArrowLeft":
                self.game.change_direction("left")
            elif e.key == "ArrowRight":
                self.game.change_direction("right")
            elif e.key == "r" or e.key == "R":
                self._start_new_game()
            elif e.key == " ":  # Space key
                self._toggle_pause()

        ui.keyboard(on_key=handle_key)

    def _start_new_game(self) -> None:
        """Start a new game."""
        if self.timer:
            self.timer.cancel()

        self.game.start_game()
        self.is_paused = False
        if self.pause_button:
            self.pause_button.set_text("⏸️ Pause")
        self._render_game()
        self._update_score()

        # Start game loop
        self.timer = ui.timer(0.15, self._game_tick)

    def _toggle_pause(self) -> None:
        """Toggle game pause state."""
        if not self.game.game_state.game_started or self.game.game_state.is_game_over:
            return

        self.is_paused = not self.is_paused
        if self.timer:
            if self.is_paused:
                self.timer.deactivate()
                if self.pause_button:
                    self.pause_button.set_text("▶️ Resume")
            else:
                self.timer.activate()
                if self.pause_button:
                    self.pause_button.set_text("⏸️ Pause")

    def _game_tick(self) -> None:
        """Game loop tick - move snake and check game state."""
        if self.is_paused:
            return

        game_continues = self.game.move_snake()
        self._render_game()
        self._update_score()

        if not game_continues:
            if self.timer:
                self.timer.cancel()
            asyncio.create_task(self._show_game_over())

    def _render_game(self) -> None:
        """Render the current game state on canvas."""
        if not self.canvas:
            return

        self.canvas.clear()

        # Draw snake
        for i, segment in enumerate(self.game.game_state.snake_positions):
            color = "#22c55e" if i == 0 else "#16a34a"  # Head lighter, body darker
            with self.canvas:
                ui.scene.box().move(
                    segment["x"] * self.game.cell_size + self.game.cell_size / 2,
                    0,
                    -(segment["y"] * self.game.cell_size + self.game.cell_size / 2),
                ).scale(self.game.cell_size * 0.9, self.game.cell_size * 0.9, self.game.cell_size * 0.9).material(color)

        # Draw food
        food = self.game.game_state.food_position
        with self.canvas:
            ui.scene.sphere().move(
                food["x"] * self.game.cell_size + self.game.cell_size / 2,
                0,
                -(food["y"] * self.game.cell_size + self.game.cell_size / 2),
            ).scale(self.game.cell_size * 0.8, self.game.cell_size * 0.8, self.game.cell_size * 0.8).material("#ef4444")

    def _update_score(self) -> None:
        """Update score display."""
        if self.score_label:
            self.score_label.set_text(f"🏆 Score: {self.game.game_state.score}")

    async def _show_game_over(self) -> None:
        """Show game over dialog."""
        reason_text = {"wall_collision": "💥 You hit the wall!", "self_collision": "🪢 You hit yourself!"}.get(
            self.game.game_state.game_over_reason, "💀 Game Over!"
        )

        with ui.dialog() as dialog, ui.card().classes("bg-gray-800 text-white p-6"):
            ui.label("💀 Game Over! 💀").classes("text-2xl font-bold text-red-400 mb-2")
            ui.label(reason_text).classes("text-lg mb-2")
            ui.label(f"🏆 Final Score: {self.game.game_state.score}").classes(
                "text-xl font-semibold text-green-400 mb-2"
            )
            ui.label(f"🐍 Snake Length: {len(self.game.game_state.snake_positions)}").classes("text-lg mb-4")

            with ui.row().classes("gap-4 justify-center"):
                ui.button("🎮 Play Again (R)", on_click=lambda: (dialog.close(), self._start_new_game())).classes(
                    "bg-green-600 hover:bg-green-700 px-6 py-2"
                )
                ui.button("❌ Close", on_click=dialog.close).classes("bg-gray-600 hover:bg-gray-700 px-6 py-2")

        dialog.open()


def create() -> None:
    """Create and setup the Snake game page."""

    @ui.page("/snake")
    def snake_game_page():
        game_ui = SnakeGameUI()
        game_ui.create_ui()

        # Auto-start the game
        game_ui._start_new_game()

    @ui.page("/")
    def index():
        with ui.column().classes("w-full h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white p-8"):
            with ui.column().classes("max-w-4xl mx-auto text-center"):
                ui.label("🐍✨ Snake Game ✨🐍").classes("text-6xl font-bold text-green-400 mb-4")
                ui.label("🎮 Classic Snake Game built with NiceGUI 🚀").classes("text-xl text-gray-300 mb-8")

                with ui.row().classes("gap-4 justify-center"):
                    ui.link("🎮🐍 Play Snake 🐍🎮", "/snake").classes(
                        "bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-lg text-xl font-semibold no-underline"
                    )

                with ui.column().classes("mt-12 text-left max-w-2xl mx-auto"):
                    ui.label("📋 How to Play:").classes("text-2xl font-bold text-green-400 mb-4")

                    controls = [
                        "🠉 🠋 🠈 🠊 Use arrow keys to control the snake 🐍",
                        "🍎 Eat the red food to grow and score points 📈",
                        "⚡ Avoid hitting walls or your own tail 💥",
                        "🎯 Try to achieve the highest score possible 🏆",
                        "⏸️ Press Space to pause/resume the game ⏯️",
                        "🔄 Press R to restart anytime 🆕",
                    ]

                    for control in controls:
                        ui.label(control).classes("text-lg text-gray-300 mb-2 pl-4")
