import pytest
from decimal import Decimal
from sqlmodel import Session, select
from app.snake_game import SnakeGame
from app.models import GameSession, HighScore
from app.database import ENGINE, reset_db
from nicegui.testing import User


@pytest.fixture
def new_db():
    """Reset database to a clean state for testing."""
    reset_db()
    yield
    reset_db()


class TestSnakeGame:
    """Test the core Snake game logic."""

    def test_game_initialization(self, new_db):
        """Test that a new game initializes correctly."""
        game = SnakeGame(20, 20)

        assert game.grid_width == 20
        assert game.grid_height == 20
        assert game.cell_size == 20
        assert not game.game_state.game_started
        assert not game.game_state.is_game_over
        assert game.game_state.score == 0
        assert len(game.game_state.snake_positions) == 1
        assert game.game_state.direction == "right"

    def test_start_game(self, new_db):
        """Test starting a new game."""
        game = SnakeGame()
        game.start_game()

        assert game.game_state.game_started
        assert not game.game_state.is_game_over
        assert game.game_state.score == 0
        assert len(game.game_state.snake_positions) == 1
        assert game.start_time is not None
        assert game.game_session_id is not None

        # Check database record was created
        with Session(ENGINE) as session:
            game_session = session.get(GameSession, game.game_session_id)
            assert game_session is not None
            assert game_session.score == 0
            assert game_session.final_snake_length == 1

    def test_food_generation(self, new_db):
        """Test that food is generated in valid positions."""
        game = SnakeGame(5, 5)  # Small grid for easier testing
        game.start_game()

        # Food should be within grid bounds
        food = game.game_state.food_position
        assert 0 <= food["x"] < 5
        assert 0 <= food["y"] < 5

        # Food should not overlap with snake
        assert food not in game.game_state.snake_positions

    def test_direction_change_valid(self, new_db):
        """Test valid direction changes."""
        game = SnakeGame()
        game.start_game()

        # Should allow perpendicular direction changes
        game.change_direction("up")
        assert game.game_state.direction == "up"

        game.change_direction("left")
        assert game.game_state.direction == "left"

        game.change_direction("down")
        assert game.game_state.direction == "down"

        game.change_direction("right")
        assert game.game_state.direction == "right"

    def test_direction_change_invalid_reverse(self, new_db):
        """Test that snake cannot immediately reverse direction."""
        game = SnakeGame()
        game.start_game()
        game.game_state.direction = "right"

        # Should not allow direct reversal
        game.change_direction("left")
        assert game.game_state.direction == "right"  # Should remain unchanged

        # But should allow after changing to perpendicular direction
        game.change_direction("up")
        assert game.game_state.direction == "up"

        game.change_direction("left")
        assert game.game_state.direction == "left"

    def test_snake_movement_basic(self, new_db):
        """Test basic snake movement."""
        game = SnakeGame()
        game.start_game()

        initial_head = game.game_state.snake_positions[0].copy()
        game.game_state.direction = "right"

        result = game.move_snake()

        assert result  # Game should continue
        new_head = game.game_state.snake_positions[0]
        assert new_head["x"] == initial_head["x"] + 1
        assert new_head["y"] == initial_head["y"]

    def test_snake_movement_directions(self, new_db):
        """Test snake movement in all directions."""
        game = SnakeGame()
        game.start_game()

        initial_pos = {"x": 10, "y": 10}
        game.game_state.snake_positions = [initial_pos.copy()]

        # Test right movement
        game.game_state.direction = "right"
        game.move_snake()
        assert game.game_state.snake_positions[0] == {"x": 11, "y": 10}

        # Reset position
        game.game_state.snake_positions = [initial_pos.copy()]

        # Test left movement
        game.game_state.direction = "left"
        game.move_snake()
        assert game.game_state.snake_positions[0] == {"x": 9, "y": 10}

        # Reset position
        game.game_state.snake_positions = [initial_pos.copy()]

        # Test up movement
        game.game_state.direction = "up"
        game.move_snake()
        assert game.game_state.snake_positions[0] == {"x": 10, "y": 9}

        # Reset position
        game.game_state.snake_positions = [initial_pos.copy()]

        # Test down movement
        game.game_state.direction = "down"
        game.move_snake()
        assert game.game_state.snake_positions[0] == {"x": 10, "y": 11}

    def test_food_consumption(self, new_db):
        """Test that snake grows when eating food."""
        game = SnakeGame()
        game.start_game()

        # Position snake to eat food
        game.game_state.snake_positions = [{"x": 5, "y": 5}]
        game.game_state.food_position = {"x": 6, "y": 5}
        game.game_state.direction = "right"
        initial_length = len(game.game_state.snake_positions)
        initial_score = game.game_state.score

        game.move_snake()

        # Snake should grow by one segment
        assert len(game.game_state.snake_positions) == initial_length + 1

        # Score should increase
        assert game.game_state.score == initial_score + 10

        # New food should be generated
        assert game.game_state.food_position != {"x": 6, "y": 5}

    def test_wall_collision_detection(self, new_db):
        """Test wall collision detection."""
        game = SnakeGame(10, 10)
        game.start_game()

        # Test collision with right wall
        game.game_state.snake_positions = [{"x": 9, "y": 5}]
        game.game_state.direction = "right"

        result = game.move_snake()

        assert not result  # Game should end
        assert game.game_state.is_game_over

        # Test collision with left wall
        game = SnakeGame(10, 10)
        game.start_game()
        game.game_state.snake_positions = [{"x": 0, "y": 5}]
        game.game_state.direction = "left"

        result = game.move_snake()

        assert not result
        assert game.game_state.is_game_over

        # Test collision with top wall
        game = SnakeGame(10, 10)
        game.start_game()
        game.game_state.snake_positions = [{"x": 5, "y": 0}]
        game.game_state.direction = "up"

        result = game.move_snake()

        assert not result
        assert game.game_state.is_game_over

        # Test collision with bottom wall
        game = SnakeGame(10, 10)
        game.start_game()
        game.game_state.snake_positions = [{"x": 5, "y": 9}]
        game.game_state.direction = "down"

        result = game.move_snake()

        assert not result
        assert game.game_state.is_game_over

    def test_self_collision_detection(self, new_db):
        """Test self collision detection."""
        game = SnakeGame()
        game.start_game()

        # Create a snake that will collide with itself
        # Head at (5,5), move up to collide with body at (5,4)
        game.game_state.snake_positions = [
            {"x": 5, "y": 5},  # Head
            {"x": 5, "y": 6},  # Body
            {"x": 4, "y": 6},  # Body
            {"x": 4, "y": 5},  # Body
            {"x": 4, "y": 4},  # Body
            {"x": 5, "y": 4},  # Tail - collision target
        ]
        game.game_state.direction = "up"

        result = game.move_snake()

        assert not result
        assert game.game_state.is_game_over

    def test_game_session_persistence(self, new_db):
        """Test that game sessions are properly saved to database."""
        game = SnakeGame()
        game.start_game()

        # Simulate eating food and game ending
        game.game_state.score = 50
        game.game_state.snake_positions = [{"x": i, "y": 5} for i in range(5)]  # Length 5
        game._end_game("wall_collision")

        # Check database was updated
        with Session(ENGINE) as session:
            game_session = session.get(GameSession, game.game_session_id)
            assert game_session is not None
            assert game_session.score == 50
            assert game_session.final_snake_length == 5
            assert game_session.game_over_reason == "wall_collision"
            assert game_session.ended_at is not None
            assert game_session.game_duration > Decimal("0")

    def test_high_score_saving(self, new_db):
        """Test that high scores are saved correctly."""
        game = SnakeGame()
        game.start_game()

        # Set a high score
        game.game_state.score = 100
        game.game_state.snake_positions = [{"x": i, "y": 5} for i in range(10)]
        game._end_game("self_collision")

        # Check high score was saved
        with Session(ENGINE) as session:
            high_scores = list(session.exec(select(HighScore)).all())
            assert len(high_scores) == 1
            assert high_scores[0].score == 100
            assert high_scores[0].snake_length == 10

    def test_get_high_scores(self, new_db):
        """Test retrieving high scores."""
        # Create some high scores
        with Session(ENGINE) as session:
            scores = [
                HighScore(player_name="Player1", score=100, snake_length=10, game_duration=Decimal("30.5")),
                HighScore(player_name="Player2", score=80, snake_length=8, game_duration=Decimal("25.0")),
                HighScore(player_name="Player3", score=120, snake_length=12, game_duration=Decimal("45.0")),
            ]
            for score in scores:
                session.add(score)
            session.commit()

        game = SnakeGame()
        high_scores = game.get_high_scores()

        assert len(high_scores) == 3
        # Should be ordered by score descending
        assert high_scores[0].score == 120
        assert high_scores[1].score == 100
        assert high_scores[2].score == 80

    def test_paused_game_no_direction_change(self, new_db):
        """Test that direction cannot be changed when game is not started."""
        game = SnakeGame()
        # Don't start game

        game.change_direction("up")
        assert game.game_state.direction == "right"  # Should remain default

    def test_game_over_no_movement(self, new_db):
        """Test that snake cannot move when game is over."""
        game = SnakeGame()
        game.start_game()
        game.game_state.is_game_over = True

        initial_position = game.game_state.snake_positions[0].copy()
        result = game.move_snake()

        assert not result
        assert game.game_state.snake_positions[0] == initial_position


class TestSnakeGameUI:
    """Test the Snake game UI components."""

    async def test_snake_game_page_loads(self, user: User) -> None:
        """Test that the snake game page loads correctly."""
        await user.open("/snake")

        # Check for key UI elements
        await user.should_see("🐍 Snake Game")
        await user.should_see("🏆 Score: 0")
        await user.should_see("🎮 Controls")
        await user.should_see("🏆 High Scores")

    async def test_index_page_loads(self, user: User) -> None:
        """Test that the index page loads correctly."""
        await user.open("/")

        await user.should_see("🐍✨ Snake Game ✨🐍")
        await user.should_see("🎮 Classic Snake Game built with NiceGUI 🚀")
        await user.should_see("🎮🐍 Play Snake 🐍🎮")
        await user.should_see("📋 How to Play:")

    async def test_navigation_to_snake_game(self, user: User) -> None:
        """Test navigation from index to snake game."""
        await user.open("/")

        # Check that the play link exists
        await user.should_see("🎮🐍 Play Snake 🐍🎮")

        # Navigate to snake game directly
        await user.open("/snake")
        await user.should_see("🏆 Score: 0")
        await user.should_see("🎮 Controls")

    async def test_pause_button_exists(self, user: User) -> None:
        """Test that pause button is present and clickable."""
        await user.open("/snake")

        # Check that pause button exists
        await user.should_see("⏸️ Pause")

    async def test_new_game_button_exists(self, user: User) -> None:
        """Test that new game button is present and clickable."""
        await user.open("/snake")

        # Check that new game button exists
        await user.should_see("🎮 New Game")


class TestSnakeGameEdgeCases:
    """Test edge cases and error conditions."""

    def test_food_generation_full_grid(self, new_db):
        """Test food generation when grid is nearly full."""
        game = SnakeGame(3, 3)  # Very small grid
        game.start_game()

        # Fill most of the grid with snake
        game.game_state.snake_positions = [
            {"x": 0, "y": 0},
            {"x": 1, "y": 0},
            {"x": 2, "y": 0},
            {"x": 2, "y": 1},
            {"x": 1, "y": 1},
            {"x": 0, "y": 1},
            {"x": 0, "y": 2},
            {"x": 1, "y": 2},
        ]

        # Should still be able to generate food in remaining position
        food = game._generate_food_position()
        assert food == {"x": 2, "y": 2}
        assert food not in game.game_state.snake_positions

    def test_game_state_after_collision(self, new_db):
        """Test game state is properly set after collision."""
        game = SnakeGame(5, 5)
        game.start_game()

        # Position for wall collision
        game.game_state.snake_positions = [{"x": 4, "y": 2}]
        game.game_state.direction = "right"
        game.game_state.score = 30

        result = game.move_snake()

        assert not result
        assert game.game_state.is_game_over
        assert game.game_state.score == 30  # Score should remain
        assert len(game.game_state.snake_positions) == 1  # Snake should remain

    def test_multiple_food_consumption(self, new_db):
        """Test multiple consecutive food consumptions."""
        game = SnakeGame()
        game.start_game()

        initial_score = 0
        initial_length = 1

        # Simulate eating 3 pieces of food
        for i in range(3):
            # Position snake to eat food
            game.game_state.snake_positions[0] = {"x": 5 + i, "y": 5}
            game.game_state.food_position = {"x": 6 + i, "y": 5}
            game.game_state.direction = "right"

            game.move_snake()

            expected_score = initial_score + (i + 1) * 10
            expected_length = initial_length + i + 1

            assert game.game_state.score == expected_score
            assert len(game.game_state.snake_positions) == expected_length

    def test_direction_change_on_game_over(self, new_db):
        """Test that direction changes are ignored when game is over."""
        game = SnakeGame()
        game.start_game()
        game.game_state.is_game_over = True
        game.game_state.direction = "right"

        game.change_direction("up")

        assert game.game_state.direction == "right"  # Should not change


# Integration tests for database interactions
class TestSnakeGameDatabase:
    """Test database integration aspects."""

    def test_concurrent_games_different_sessions(self, new_db):
        """Test that multiple games create separate database sessions."""
        game1 = SnakeGame()
        game2 = SnakeGame()

        game1.start_game()
        game2.start_game()

        assert game1.game_session_id != game2.game_session_id

        # Both should be in database
        with Session(ENGINE) as session:
            session1 = session.get(GameSession, game1.game_session_id)
            session2 = session.get(GameSession, game2.game_session_id)

            assert session1 is not None
            assert session2 is not None
            assert session1.id != session2.id

    def test_high_score_limit(self, new_db):
        """Test that high scores are limited to top 10."""
        # Create 15 high scores
        with Session(ENGINE) as session:
            for i in range(15):
                score = HighScore(
                    player_name=f"Player{i}",
                    score=i * 10,  # Scores from 0 to 140
                    snake_length=i + 1,
                    game_duration=Decimal("30.0"),
                )
                session.add(score)
            session.commit()

        game = SnakeGame()
        high_scores = game.get_high_scores()

        # Should return only top 10
        assert len(high_scores) == 10

        # Should be in descending order
        for i in range(9):
            assert high_scores[i].score >= high_scores[i + 1].score

    def test_game_session_update_none_id(self, new_db):
        """Test graceful handling when game session ID is None."""
        game = SnakeGame()
        game.start_game()
        game.game_session_id = None  # Simulate missing ID

        # Should not crash when trying to update
        game._end_game("wall_collision")

        # Game state should still be updated locally
        assert game.game_state.is_game_over
