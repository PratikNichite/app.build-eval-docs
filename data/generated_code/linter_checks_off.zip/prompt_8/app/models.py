from sqlmodel import SQLModel, Field, Relationship, JSON, Column
from datetime import datetime
from typing import Optional, List, Dict, Any
from decimal import Decimal
from enum import Enum


class BrickType(str, Enum):
    NORMAL = "normal"
    STRONG = "strong"
    UNBREAKABLE = "unbreakable"


class GameStatus(str, Enum):
    WAITING = "waiting"
    PLAYING = "playing"
    PAUSED = "paused"
    GAME_OVER = "game_over"
    LEVEL_COMPLETE = "level_complete"


# Persistent models (stored in database)
class Player(SQLModel, table=True):
    __tablename__ = "players"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100)
    email: Optional[str] = Field(default=None, max_length=255)
    high_score: int = Field(default=0)
    levels_completed: int = Field(default=0)
    total_games_played: int = Field(default=0)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    game_sessions: List["GameSession"] = Relationship(back_populates="player")


class GameSession(SQLModel, table=True):
    __tablename__ = "game_sessions"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    player_id: int = Field(foreign_key="players.id")
    current_level: int = Field(default=1)
    current_score: int = Field(default=0)
    lives_remaining: int = Field(default=3)
    status: GameStatus = Field(default=GameStatus.WAITING)
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = Field(default=None)

    # Game state data stored as JSON
    paddle_position: Decimal = Field(default=Decimal("400"))  # X position of paddle center
    ball_position_x: Decimal = Field(default=Decimal("400"))
    ball_position_y: Decimal = Field(default=Decimal("300"))
    ball_velocity_x: Decimal = Field(default=Decimal("5"))
    ball_velocity_y: Decimal = Field(default=Decimal("-5"))

    player: Player = Relationship(back_populates="game_sessions")
    level_data: List["LevelData"] = Relationship(back_populates="game_session")
    bricks: List["Brick"] = Relationship(back_populates="game_session")


class LevelData(SQLModel, table=True):
    __tablename__ = "level_data"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    game_session_id: int = Field(foreign_key="game_sessions.id")
    level_number: int = Field(default=1)
    brick_layout: Dict[str, Any] = Field(default={}, sa_column=Column(JSON))  # Grid layout configuration
    completed: bool = Field(default=False)
    score_earned: int = Field(default=0)
    time_spent: Optional[int] = Field(default=None)  # Seconds
    created_at: datetime = Field(default_factory=datetime.utcnow)

    game_session: GameSession = Relationship(back_populates="level_data")


class Brick(SQLModel, table=True):
    __tablename__ = "bricks"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    game_session_id: int = Field(foreign_key="game_sessions.id")
    row: int = Field(ge=0)  # Grid row position
    col: int = Field(ge=0)  # Grid column position
    position_x: Decimal = Field(default=Decimal("0"))  # Pixel X coordinate
    position_y: Decimal = Field(default=Decimal("0"))  # Pixel Y coordinate
    width: Decimal = Field(default=Decimal("60"))
    height: Decimal = Field(default=Decimal("20"))
    brick_type: BrickType = Field(default=BrickType.NORMAL)
    color: str = Field(default="#FF0000", max_length=7)  # Hex color code
    hits_remaining: int = Field(default=1)  # How many hits to destroy
    points_value: int = Field(default=10)
    is_destroyed: bool = Field(default=False)
    destroyed_at: Optional[datetime] = Field(default=None)

    game_session: GameSession = Relationship(back_populates="bricks")


class GameConfiguration(SQLModel, table=True):
    __tablename__ = "game_configurations"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    config_name: str = Field(max_length=100, unique=True)

    # Game area dimensions
    game_width: int = Field(default=800)
    game_height: int = Field(default=600)

    # Paddle configuration
    paddle_width: int = Field(default=100)
    paddle_height: int = Field(default=10)
    paddle_speed: Decimal = Field(default=Decimal("8"))
    paddle_y_offset: int = Field(default=50)  # Distance from bottom

    # Ball configuration
    ball_radius: int = Field(default=8)
    ball_initial_speed: Decimal = Field(default=Decimal("5"))
    ball_max_speed: Decimal = Field(default=Decimal("12"))

    # Brick configuration
    brick_rows: int = Field(default=8)
    brick_cols: int = Field(default=12)
    brick_width: int = Field(default=60)
    brick_height: int = Field(default=20)
    brick_padding: int = Field(default=2)
    brick_top_margin: int = Field(default=50)

    # Game rules
    initial_lives: int = Field(default=3)
    points_per_brick: int = Field(default=10)
    bonus_points_per_level: int = Field(default=100)

    # Physics
    ball_paddle_bounce_factor: Decimal = Field(default=Decimal("1.1"))  # Speed increase on paddle hit
    wall_bounce_dampening: Decimal = Field(default=Decimal("0.98"))  # Slight speed reduction on wall hit

    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class PlayerCreate(SQLModel, table=False):
    name: str = Field(max_length=100)
    email: Optional[str] = Field(default=None, max_length=255)


class PlayerUpdate(SQLModel, table=False):
    name: Optional[str] = Field(default=None, max_length=100)
    email: Optional[str] = Field(default=None, max_length=255)


class GameSessionCreate(SQLModel, table=False):
    player_id: int
    current_level: int = Field(default=1)


class GameSessionUpdate(SQLModel, table=False):
    current_level: Optional[int] = Field(default=None)
    current_score: Optional[int] = Field(default=None)
    lives_remaining: Optional[int] = Field(default=None)
    status: Optional[GameStatus] = Field(default=None)
    paddle_position: Optional[Decimal] = Field(default=None)
    ball_position_x: Optional[Decimal] = Field(default=None)
    ball_position_y: Optional[Decimal] = Field(default=None)
    ball_velocity_x: Optional[Decimal] = Field(default=None)
    ball_velocity_y: Optional[Decimal] = Field(default=None)


class BrickCreate(SQLModel, table=False):
    game_session_id: int
    row: int = Field(ge=0)
    col: int = Field(ge=0)
    position_x: Decimal
    position_y: Decimal
    width: Decimal = Field(default=Decimal("60"))
    height: Decimal = Field(default=Decimal("20"))
    brick_type: BrickType = Field(default=BrickType.NORMAL)
    color: str = Field(default="#FF0000", max_length=7)
    hits_remaining: int = Field(default=1)
    points_value: int = Field(default=10)


class BrickUpdate(SQLModel, table=False):
    hits_remaining: Optional[int] = Field(default=None)
    is_destroyed: Optional[bool] = Field(default=None)


class LevelCreate(SQLModel, table=False):
    game_session_id: int
    level_number: int = Field(default=1)
    brick_layout: Dict[str, Any] = Field(default={})


class GameStats(SQLModel, table=False):
    """Statistics for displaying game progress and achievements"""

    player_name: str
    current_score: int
    high_score: int
    current_level: int
    lives_remaining: int
    total_bricks: int
    remaining_bricks: int
    level_progress: Decimal  # Percentage complete
    game_status: GameStatus


class CollisionInfo(SQLModel, table=False):
    """Information about ball-brick collisions"""

    brick_id: int
    collision_side: str  # "top", "bottom", "left", "right"
    new_ball_velocity_x: Decimal
    new_ball_velocity_y: Decimal
    points_earned: int
    brick_destroyed: bool
