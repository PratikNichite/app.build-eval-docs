"""
Brick Breaker Game Engine - Core game logic and physics
"""

from decimal import Decimal
from typing import List, Optional, Tuple
import math
from app.models import GameSession, Brick, GameConfiguration, BrickType, GameStatus, CollisionInfo
from app.database import get_session
from sqlmodel import select


class GameEngine:
    """Core game engine handling physics, collisions, and game state"""

    def __init__(self, game_session_id: int):
        self.game_session_id = game_session_id
        self.config = self._load_config()

    def _load_config(self) -> GameConfiguration:
        """Load active game configuration"""
        with get_session() as session:
            config = session.exec(select(GameConfiguration).where(GameConfiguration.is_active == True)).first()
            if config is None:
                # Create default configuration
                config = GameConfiguration(config_name="default")
                session.add(config)
                session.commit()
                session.refresh(config)
        return config

    def get_game_state(self) -> Optional[GameSession]:
        """Get current game session state"""
        with get_session() as session:
            return session.get(GameSession, self.game_session_id)

    def update_ball_position(self, dt: float) -> Tuple[Decimal, Decimal]:
        """Update ball position based on velocity and time delta"""
        with get_session() as session:
            game_session = session.get(GameSession, self.game_session_id)
            if game_session is None:
                return Decimal("0"), Decimal("0")

            # Calculate new position
            new_x = game_session.ball_position_x + (game_session.ball_velocity_x * Decimal(str(dt)))
            new_y = game_session.ball_position_y + (game_session.ball_velocity_y * Decimal(str(dt)))

            # Handle wall collisions
            ball_radius = Decimal(str(self.config.ball_radius))

            # Left/right walls
            if new_x <= ball_radius:
                new_x = ball_radius
                game_session.ball_velocity_x = -game_session.ball_velocity_x * self.config.wall_bounce_dampening
            elif new_x >= Decimal(str(self.config.game_width)) - ball_radius:
                new_x = Decimal(str(self.config.game_width)) - ball_radius
                game_session.ball_velocity_x = -game_session.ball_velocity_x * self.config.wall_bounce_dampening

            # Top wall
            if new_y <= ball_radius:
                new_y = ball_radius
                game_session.ball_velocity_y = -game_session.ball_velocity_y * self.config.wall_bounce_dampening

            # Bottom wall (lose life)
            elif new_y >= Decimal(str(self.config.game_height)) - ball_radius:
                return self._handle_life_lost(session, game_session)

            # Update position
            game_session.ball_position_x = new_x
            game_session.ball_position_y = new_y
            session.commit()

            return new_x, new_y

    def _handle_life_lost(self, session, game_session: GameSession) -> Tuple[Decimal, Decimal]:
        """Handle ball going past paddle - lose a life"""
        game_session.lives_remaining -= 1

        if game_session.lives_remaining <= 0:
            game_session.status = GameStatus.GAME_OVER
            # Reset ball to center
            game_session.ball_position_x = Decimal(str(self.config.game_width // 2))
            game_session.ball_position_y = Decimal(str(self.config.game_height // 2))
            game_session.ball_velocity_x = Decimal("0")
            game_session.ball_velocity_y = Decimal("0")
        else:
            # Reset ball and paddle for next life
            self._reset_ball_and_paddle(game_session)

        session.commit()
        return game_session.ball_position_x, game_session.ball_position_y

    def _reset_ball_and_paddle(self, game_session: GameSession):
        """Reset ball and paddle to starting positions"""
        game_session.paddle_position = Decimal(str(self.config.game_width // 2))
        game_session.ball_position_x = Decimal(str(self.config.game_width // 2))
        game_session.ball_position_y = Decimal(str(self.config.game_height - self.config.paddle_y_offset - 30))
        game_session.ball_velocity_x = self.config.ball_initial_speed
        game_session.ball_velocity_y = -self.config.ball_initial_speed

    def check_paddle_collision(self) -> bool:
        """Check and handle ball-paddle collision"""
        with get_session() as session:
            game_session = session.get(GameSession, self.game_session_id)
            if game_session is None:
                return False

            ball_radius = Decimal(str(self.config.ball_radius))
            paddle_y = Decimal(str(self.config.game_height - self.config.paddle_y_offset))
            paddle_half_width = Decimal(str(self.config.paddle_width // 2))

            # Check if ball is near paddle Y level (with some tolerance)
            ball_bottom = game_session.ball_position_y + ball_radius
            paddle_top = paddle_y

            # Ball must be at or below paddle level and moving downward
            if (
                ball_bottom >= paddle_top
                and ball_bottom <= paddle_top + Decimal(str(self.config.paddle_height))
                and game_session.ball_velocity_y > 0
            ):  # Ball moving down
                # Check X overlap
                paddle_left = game_session.paddle_position - paddle_half_width
                paddle_right = game_session.paddle_position + paddle_half_width

                if game_session.ball_position_x >= paddle_left and game_session.ball_position_x <= paddle_right:
                    # Calculate bounce angle based on hit position
                    hit_pos = (game_session.ball_position_x - game_session.paddle_position) / paddle_half_width
                    # Clamp hit position to prevent extreme angles
                    hit_pos = max(Decimal("-1"), min(Decimal("1"), hit_pos))
                    angle = hit_pos * Decimal(str(math.pi / 4))  # Max 45 degrees

                    speed = (game_session.ball_velocity_x**2 + game_session.ball_velocity_y**2) ** Decimal("0.5")
                    speed *= self.config.ball_paddle_bounce_factor

                    # Limit max speed
                    if speed > self.config.ball_max_speed:
                        speed = self.config.ball_max_speed

                    game_session.ball_velocity_x = speed * Decimal(str(math.sin(float(angle))))
                    game_session.ball_velocity_y = -abs(speed * Decimal(str(math.cos(float(angle)))))  # Ensure upward

                    # Move ball above paddle to prevent sticking
                    game_session.ball_position_y = paddle_y - ball_radius - Decimal("2")

                    session.commit()
                    return True

            return False

    def check_brick_collisions(self) -> List[CollisionInfo]:
        """Check and handle ball-brick collisions"""
        collisions = []

        with get_session() as session:
            game_session = session.get(GameSession, self.game_session_id)
            if game_session is None:
                return collisions

            # Get active bricks
            active_bricks = session.exec(
                select(Brick).where(Brick.game_session_id == self.game_session_id, Brick.is_destroyed == False)
            ).all()

            ball_radius = Decimal(str(self.config.ball_radius))

            for brick in active_bricks:
                collision_info = self._check_single_brick_collision(game_session, brick, ball_radius)
                if collision_info:
                    collisions.append(collision_info)

                    # Update brick
                    brick.hits_remaining -= 1
                    if brick.hits_remaining <= 0:
                        brick.is_destroyed = True
                        collision_info.brick_destroyed = True

                        # Update score
                        game_session.current_score += brick.points_value

                    # Update ball velocity
                    game_session.ball_velocity_x = collision_info.new_ball_velocity_x
                    game_session.ball_velocity_y = collision_info.new_ball_velocity_y

                    # Only handle one collision per frame to avoid complex multi-collision scenarios
                    break

            session.commit()

            # Check if level complete
            remaining_bricks = session.exec(
                select(Brick).where(
                    Brick.game_session_id == self.game_session_id,
                    Brick.is_destroyed == False,
                    Brick.brick_type != BrickType.UNBREAKABLE,
                )
            ).all()

            if not remaining_bricks:
                game_session.status = GameStatus.LEVEL_COMPLETE
                game_session.current_score += self.config.bonus_points_per_level
                session.commit()

        return collisions

    def _check_single_brick_collision(
        self, game_session: GameSession, brick: Brick, ball_radius: Decimal
    ) -> Optional[CollisionInfo]:
        """Check collision between ball and a single brick"""

        # Ball center and boundaries
        ball_x = game_session.ball_position_x
        ball_y = game_session.ball_position_y
        ball_left = ball_x - ball_radius
        ball_right = ball_x + ball_radius
        ball_top = ball_y - ball_radius
        ball_bottom = ball_y + ball_radius

        # Brick boundaries
        brick_left = brick.position_x
        brick_right = brick.position_x + brick.width
        brick_top = brick.position_y
        brick_bottom = brick.position_y + brick.height

        # Check for overlap using AABB collision detection
        if ball_right > brick_left and ball_left < brick_right and ball_bottom > brick_top and ball_top < brick_bottom:
            # Calculate overlap amounts
            left_overlap = ball_right - brick_left
            right_overlap = brick_right - ball_left
            top_overlap = ball_bottom - brick_top
            bottom_overlap = brick_bottom - ball_top

            # Find minimum overlap to determine collision side
            min_overlap = min(left_overlap, right_overlap, top_overlap, bottom_overlap)

            # Determine collision side and new velocity
            new_vx = game_session.ball_velocity_x
            new_vy = game_session.ball_velocity_y
            collision_side = "top"

            if min_overlap == left_overlap and game_session.ball_velocity_x > 0:
                collision_side = "left"
                new_vx = -abs(new_vx)
            elif min_overlap == right_overlap and game_session.ball_velocity_x < 0:
                collision_side = "right"
                new_vx = abs(new_vx)
            elif min_overlap == top_overlap and game_session.ball_velocity_y > 0:
                collision_side = "top"
                new_vy = -abs(new_vy)
            elif min_overlap == bottom_overlap and game_session.ball_velocity_y < 0:
                collision_side = "bottom"
                new_vy = abs(new_vy)

            return CollisionInfo(
                brick_id=brick.id or 0,
                collision_side=collision_side,
                new_ball_velocity_x=new_vx,
                new_ball_velocity_y=new_vy,
                points_earned=brick.points_value,
                brick_destroyed=False,  # Will be set later
            )

        return None

    def _determine_collision_side(self, game_session: GameSession, brick: Brick, ball_radius: Decimal) -> str:
        """Determine which side of the brick was hit"""

        # Calculate distances to each side
        ball_x = game_session.ball_position_x
        ball_y = game_session.ball_position_y

        brick_center_x = brick.position_x + brick.width / 2
        brick_center_y = brick.position_y + brick.height / 2

        # Calculate overlap on each axis
        x_overlap = min(
            ball_x + ball_radius - brick.position_x, brick.position_x + brick.width - (ball_x - ball_radius)
        )
        y_overlap = min(
            ball_y + ball_radius - brick.position_y, brick.position_y + brick.height - (ball_y - ball_radius)
        )

        # The side with smaller overlap is the collision side
        if x_overlap < y_overlap:
            return "left" if ball_x < brick_center_x else "right"
        else:
            return "top" if ball_y < brick_center_y else "bottom"

    def move_paddle(self, direction: str) -> Decimal:
        """Move paddle left or right"""
        with get_session() as session:
            game_session = session.get(GameSession, self.game_session_id)
            if game_session is None:
                return Decimal("0")

            paddle_half_width = Decimal(str(self.config.paddle_width // 2))

            if direction == "left":
                new_pos = game_session.paddle_position - self.config.paddle_speed
                new_pos = max(paddle_half_width, new_pos)
            else:  # right
                new_pos = game_session.paddle_position + self.config.paddle_speed
                new_pos = min(Decimal(str(self.config.game_width)) - paddle_half_width, new_pos)

            game_session.paddle_position = new_pos
            session.commit()

            return new_pos

    def initialize_level(self, level_number: int) -> None:
        """Initialize bricks for a new level"""
        with get_session() as session:
            # Clear existing bricks
            existing_bricks = session.exec(select(Brick).where(Brick.game_session_id == self.game_session_id)).all()
            for brick in existing_bricks:
                session.delete(brick)

            # Create new brick layout
            colors = ["#FF0000", "#FF8000", "#FFFF00", "#80FF00", "#00FF00", "#00FF80", "#00FFFF", "#0080FF"]

            brick_width = Decimal(str(self.config.brick_width))
            brick_height = Decimal(str(self.config.brick_height))
            padding = Decimal(str(self.config.brick_padding))

            for row in range(self.config.brick_rows):
                for col in range(self.config.brick_cols):
                    x = padding + col * (brick_width + padding)
                    y = Decimal(str(self.config.brick_top_margin)) + row * (brick_height + padding)

                    # Different brick types based on row
                    if row < 2:
                        brick_type = BrickType.STRONG
                        hits = 2
                        points = 20
                    else:
                        brick_type = BrickType.NORMAL
                        hits = 1
                        points = 10

                    brick = Brick(
                        game_session_id=self.game_session_id,
                        row=row,
                        col=col,
                        position_x=x,
                        position_y=y,
                        width=brick_width,
                        height=brick_height,
                        brick_type=brick_type,
                        color=colors[row % len(colors)],
                        hits_remaining=hits,
                        points_value=points,
                    )
                    session.add(brick)

            session.commit()

    def start_new_game(self, player_id: int) -> GameSession:
        """Start a new game session"""
        with get_session() as session:
            game_session = GameSession(
                player_id=player_id,
                current_level=1,
                current_score=0,
                lives_remaining=self.config.initial_lives,
                status=GameStatus.PLAYING,
                paddle_position=Decimal(str(self.config.game_width // 2)),
                ball_position_x=Decimal(str(self.config.game_width // 2)),
                ball_position_y=Decimal(str(self.config.game_height - self.config.paddle_y_offset - 30)),
                ball_velocity_x=self.config.ball_initial_speed,
                ball_velocity_y=-self.config.ball_initial_speed,
            )
            session.add(game_session)
            session.commit()
            session.refresh(game_session)

            # Initialize first level
            self.game_session_id = game_session.id or 0
            self.initialize_level(1)

            return game_session
