"""
Brick Breaker Game UI - Web-based game interface using NiceGUI
"""

from nicegui import ui
from typing import Optional, Dict
import asyncio
import time
from decimal import Decimal

from app.models import Player, GameSession, Brick, GameStatus
from app.game_engine import GameEngine
from app.database import get_session
from sqlmodel import select


class BrickBreakerGame:
    """Main game UI class"""

    def __init__(self):
        self.game_engine: Optional[GameEngine] = None
        self.game_session: Optional[GameSession] = None
        self.player: Optional[Player] = None

        # UI elements
        self.game_area: Optional[ui.element] = None
        self.score_label: Optional[ui.label] = None
        self.lives_label: Optional[ui.label] = None
        self.level_label: Optional[ui.label] = None
        self.status_label: Optional[ui.label] = None

        # Game state
        self.is_running = False
        self.keys_pressed: Dict[str, bool] = {}
        self.last_update_time = time.time()

        # Game configuration (will be loaded from database)
        self.game_width = 800
        self.game_height = 600

    async def create_game_ui(self):
        """Create the main game interface"""
        # Apply modern theme
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
        )

        # Main container
        with ui.column().classes("w-full h-screen bg-gray-900 text-white"):
            # Header
            with ui.row().classes("w-full bg-gray-800 p-4 justify-between items-center"):
                ui.label("🧱 Brick Breaker").classes("text-2xl font-bold text-white")

                # Game stats
                with ui.row().classes("gap-6 items-center"):
                    self.score_label = ui.label("Score: 0").classes("text-lg font-semibold text-yellow-400")
                    self.lives_label = ui.label("Lives: 3").classes("text-lg font-semibold text-red-400")
                    self.level_label = ui.label("Level: 1").classes("text-lg font-semibold text-blue-400")

                # Control buttons
                with ui.row().classes("gap-2"):
                    ui.button("New Game", on_click=self.start_new_game).classes("bg-green-600 hover:bg-green-700").mark(
                        "new-game"
                    )
                    ui.button("Pause/Resume", on_click=self.toggle_pause).classes(
                        "bg-yellow-600 hover:bg-yellow-700"
                    ).mark("pause-resume")

            # Game status
            self.status_label = (
                ui.label('Click "New Game" to start!')
                .classes("text-center text-xl py-2 bg-gray-700")
                .mark("game-status")
            )

            # Game area
            with ui.card().classes("flex-1 bg-black m-4 p-4 rounded-lg shadow-xl"):
                # Instructions
                with ui.row().classes("w-full justify-center mb-4"):
                    ui.label("Use ← → arrow keys to control the paddle").classes("text-gray-400 text-sm").mark(
                        "instructions"
                    )

                # Game area using HTML5 canvas via JavaScript
                with ui.row().classes("justify-center"):
                    self.game_area = ui.html(f'''
                        <canvas id="gameCanvas" width="{self.game_width}" height="{self.game_height}" 
                                style="border: 2px solid #4a5568; background: #000000; display: block;">
                            Your browser does not support the HTML5 canvas element.
                        </canvas>
                    ''').classes("mx-auto")

                # Add keyboard event handlers
                await self._setup_keyboard_controls()

    async def _setup_keyboard_controls(self):
        """Setup keyboard event handling"""
        # Add keyboard event listener
        ui.add_head_html("""
        <script>
        let keysPressed = {};
        
        document.addEventListener('keydown', function(e) {
            keysPressed[e.code] = true;
            if (e.code === 'ArrowLeft' || e.code === 'ArrowRight') {
                e.preventDefault();
            }
        });
        
        document.addEventListener('keyup', function(e) {
            keysPressed[e.code] = false;
        });
        
        // Function to get current key states
        window.getKeysPressed = function() {
            return keysPressed;
        };
        </script>
        """)

    async def start_new_game(self):
        """Start a new game"""
        try:
            # Stop current game if running
            if self.is_running:
                self.is_running = False
                await asyncio.sleep(0.1)  # Allow current game loop to finish

            # Get or create player
            await self._ensure_player()
            if self.player is None:
                return

            # Create new game session
            self.game_engine = GameEngine(0)  # Temporary, will be set after creation
            self.game_session = self.game_engine.start_new_game(self.player.id or 0)
            self.game_engine.game_session_id = self.game_session.id or 0

            # Update UI
            self.is_running = True
            self.last_update_time = time.time()
            await self._update_ui_elements()

            # Start game loop
            asyncio.create_task(self._game_loop())

            ui.notify("New game started! 🚀 Use arrow keys to control the paddle.", type="positive")

        except Exception as e:
            ui.notify(f"Error starting game: {str(e)}", type="negative")

    async def toggle_pause(self):
        """Toggle game pause state"""
        if self.game_session is None:
            return

        with get_session() as session:
            game_session = session.get(GameSession, self.game_session.id)
            if game_session is None:
                return

            if game_session.status == GameStatus.PLAYING:
                game_session.status = GameStatus.PAUSED
                self.is_running = False
                session.commit()
                session.refresh(game_session)
                self.game_session = game_session  # Update local reference
                await self._update_ui_elements()
                ui.notify("Game paused ⏸️", type="warning")

            elif game_session.status == GameStatus.PAUSED:
                game_session.status = GameStatus.PLAYING
                self.is_running = True
                self.last_update_time = time.time()
                session.commit()
                session.refresh(game_session)
                self.game_session = game_session  # Update local reference
                await self._update_ui_elements()
                asyncio.create_task(self._game_loop())
                ui.notify("Game resumed ▶️", type="positive")

    async def _ensure_player(self):
        """Ensure we have a player for the game"""
        if self.player is None:
            with get_session() as session:
                # Get or create default player
                player = session.exec(select(Player).where(Player.name == "Player 1")).first()
                if player is None:
                    player = Player(name="Player 1", email="player1@example.com")
                    session.add(player)
                    session.commit()
                    session.refresh(player)
                self.player = player

    async def _game_loop(self):
        """Main game loop"""
        while self.is_running and self.game_session is not None:
            try:
                current_time = time.time()
                dt = current_time - self.last_update_time
                self.last_update_time = current_time

                # Handle input
                await self._handle_input()

                # Update physics
                if self.game_engine:
                    # Update ball position
                    ball_x, ball_y = self.game_engine.update_ball_position(dt * 60)  # Scale for 60 FPS

                    # Check collisions
                    self.game_engine.check_paddle_collision()
                    collisions = self.game_engine.check_brick_collisions()

                    # Update game session state
                    self.game_session = self.game_engine.get_game_state()

                    # Check game status
                    if self.game_session and self.game_session.status != GameStatus.PLAYING:
                        self.is_running = False
                        await self._handle_game_end()

                # Render game
                await self._render_game()

                # Update UI elements
                await self._update_ui_elements()

                # Control frame rate (approximately 60 FPS)
                await asyncio.sleep(1 / 60)

            except Exception as e:
                print(f"Game loop error: {e}")
                self.is_running = False
                ui.notify(f"Game error: {str(e)}", type="negative")

    async def _handle_input(self):
        """Handle keyboard input for paddle movement"""
        if self.game_engine is None:
            return

        try:
            # Get key states from JavaScript
            keys_result = await ui.run_javascript("return window.getKeysPressed();")
            if keys_result:
                left_pressed = keys_result.get("ArrowLeft", False)
                right_pressed = keys_result.get("ArrowRight", False)

                if left_pressed:
                    self.game_engine.move_paddle("left")
                elif right_pressed:
                    self.game_engine.move_paddle("right")
        except:
            # Fallback - no input handling if JavaScript fails
            pass

    async def _render_game(self):
        """Render the game state on canvas using JavaScript"""
        if self.game_area is None or self.game_session is None:
            return

        try:
            # Get bricks data
            bricks_data = []
            with get_session() as session:
                bricks = session.exec(
                    select(Brick).where(Brick.game_session_id == self.game_session.id, Brick.is_destroyed == False)
                ).all()

                for brick in bricks:
                    bricks_data.append(
                        {
                            "x": float(brick.position_x),
                            "y": float(brick.position_y),
                            "width": float(brick.width),
                            "height": float(brick.height),
                            "color": brick.color,
                            "hits": brick.hits_remaining,
                        }
                    )

            # Paddle data
            if self.game_engine:
                config = self.game_engine.config
                paddle_data = {
                    "x": float(self.game_session.paddle_position) - config.paddle_width // 2,
                    "y": config.game_height - config.paddle_y_offset,
                    "width": config.paddle_width,
                    "height": config.paddle_height,
                }

                # Ball data
                ball_data = {
                    "x": float(self.game_session.ball_position_x),
                    "y": float(self.game_session.ball_position_y),
                    "radius": config.ball_radius,
                }

                # Render using JavaScript
                await ui.run_javascript(f"""
                    const canvas = document.getElementById('gameCanvas');
                    if (canvas) {{
                        const ctx = canvas.getContext('2d');
                        
                        // Clear canvas
                        ctx.fillStyle = '#111111';
                        ctx.fillRect(0, 0, {self.game_width}, {self.game_height});
                        
                        // Draw bricks
                        const bricks = {bricks_data};
                        bricks.forEach(brick => {{
                            ctx.fillStyle = brick.color;
                            ctx.globalAlpha = brick.hits === 1 ? 1.0 : 0.7;
                            ctx.fillRect(brick.x, brick.y, brick.width, brick.height);
                            ctx.strokeStyle = '#ffffff';
                            ctx.lineWidth = 1;
                            ctx.strokeRect(brick.x, brick.y, brick.width, brick.height);
                        }});
                        
                        // Draw paddle
                        ctx.globalAlpha = 1.0;
                        ctx.fillStyle = '#00ff00';
                        ctx.fillRect({paddle_data["x"]}, {paddle_data["y"]}, {paddle_data["width"]}, {paddle_data["height"]});
                        ctx.strokeStyle = '#ffffff';
                        ctx.lineWidth = 2;
                        ctx.strokeRect({paddle_data["x"]}, {paddle_data["y"]}, {paddle_data["width"]}, {paddle_data["height"]});
                        
                        // Draw ball
                        ctx.fillStyle = '#ffff00';
                        ctx.beginPath();
                        ctx.arc({ball_data["x"]}, {ball_data["y"]}, {ball_data["radius"]}, 0, 2 * Math.PI);
                        ctx.fill();
                        ctx.strokeStyle = '#ffffff';
                        ctx.lineWidth = 2;
                        ctx.stroke();
                    }}
                """)

        except Exception as e:
            print(f"Render error: {e}")

    async def _update_ui_elements(self):
        """Update score, lives, level displays"""
        if self.game_session is None:
            return

        if self.score_label:
            self.score_label.set_text(f"Score: {self.game_session.current_score}")

        if self.lives_label:
            self.lives_label.set_text(f"Lives: {self.game_session.lives_remaining}")

        if self.level_label:
            self.level_label.set_text(f"Level: {self.game_session.current_level}")

        if self.status_label:
            status_text = {
                GameStatus.WAITING: "Waiting to start... 😄",
                GameStatus.PLAYING: "Playing - Use arrow keys! 🎮",
                GameStatus.PAUSED: "Game Paused ⏸️",
                GameStatus.GAME_OVER: 'Game Over! 💀 Click "New Game" to play again.',
                GameStatus.LEVEL_COMPLETE: "Level Complete! 🎉 Starting next level...",
            }.get(self.game_session.status, "Unknown status")

            self.status_label.set_text(status_text)

    async def _handle_game_end(self):
        """Handle game over or level complete"""
        if self.game_session is None:
            return

        if self.game_session.status == GameStatus.GAME_OVER:
            # Update player high score
            with get_session() as session:
                if self.player:
                    player = session.get(Player, self.player.id)
                    if player and self.game_session.current_score > player.high_score:
                        player.high_score = self.game_session.current_score
                        session.commit()
                        ui.notify(f"New high score: {self.game_session.current_score}! 🏆", type="positive")
                    else:
                        ui.notify(f"Game Over! 💀 Final score: {self.game_session.current_score}", type="warning")

        elif self.game_session.status == GameStatus.LEVEL_COMPLETE:
            ui.notify(f"Level {self.game_session.current_level} complete! 🎉", type="positive")

            # Start next level after a short delay
            await asyncio.sleep(2)
            await self._start_next_level()

    async def _start_next_level(self):
        """Start the next level"""
        if self.game_session is None or self.game_engine is None:
            return

        with get_session() as session:
            game_session = session.get(GameSession, self.game_session.id)
            if game_session is None:
                return

            # Increment level
            game_session.current_level += 1
            game_session.status = GameStatus.PLAYING

            # Reset ball and paddle
            config = self.game_engine.config
            game_session.paddle_position = Decimal(str(config.game_width // 2))
            game_session.ball_position_x = Decimal(str(config.game_width // 2))
            game_session.ball_position_y = Decimal(str(config.game_height - config.paddle_y_offset - 30))
            game_session.ball_velocity_x = config.ball_initial_speed
            game_session.ball_velocity_y = -config.ball_initial_speed

            session.commit()

            # Initialize new level
            self.game_engine.initialize_level(game_session.current_level)

            # Resume game
            self.is_running = True
            self.last_update_time = time.time()
            asyncio.create_task(self._game_loop())


def create():
    """Create the Brick Breaker game module"""

    @ui.page("/brick-breaker")
    async def game_page():
        game = BrickBreakerGame()
        await game.create_game_ui()

    @ui.page("/")
    def index():
        with ui.column().classes("w-full h-screen bg-gradient-to-br from-blue-900 to-purple-900 text-white"):
            # Header
            with ui.row().classes("w-full justify-center p-8"):
                ui.label("🧱 Brick Breaker Game").classes("text-4xl font-bold text-center")

            # Game preview/description
            with ui.card().classes("max-w-2xl mx-auto p-8 bg-white/10 backdrop-blur-md border border-white/20"):
                ui.label("Classic Brick Breaker Game").classes("text-2xl font-semibold mb-4 text-center")

                with ui.column().classes("gap-4 text-lg"):
                    ui.label("🎮 Control the paddle with arrow keys")
                    ui.label("🧱 Break all the bricks to complete each level")
                    ui.label("❤️ You have 3 lives - don't let the ball fall!")
                    ui.label("🏆 Score points and beat your high score")

                # Play button
                with ui.row().classes("justify-center mt-8"):
                    ui.button("Play Game", on_click=lambda: ui.navigate.to("/brick-breaker")).classes(
                        "bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-bold py-4 px-8 rounded-lg text-xl shadow-lg transform hover:scale-105 transition-all duration-200"
                    ).mark("play-game")

            # Footer
            with ui.row().classes("w-full justify-center mt-8 text-white/60"):
                ui.label("Built with NiceGUI • Modern Web Gaming Experience").classes("text-sm")
