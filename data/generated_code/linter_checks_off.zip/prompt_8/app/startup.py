from app.database import create_tables
import app.brick_breaker


def startup() -> None:
    # this function is called before the first request
    create_tables()
    app.brick_breaker.create()
