"""
Tests for the Brick Breaker UI components
"""

import pytest
from nicegui.testing import User
from app.database import reset_db, get_session
from app.models import Player, GameSession, GameStatus
from app.brick_breaker import BrickBreakerGame
from sqlmodel import select


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


async def test_game_page_loads(user: User, new_db) -> None:
    """Test that the game page loads correctly"""
    await user.open("/brick-breaker")

    # Check that main UI elements are present
    await user.should_see("Brick Breaker")
    await user.should_see("Score: 0")
    await user.should_see("Lives: 3")
    await user.should_see("Level: 1")
    await user.should_see(marker="new-game")
    await user.should_see(marker="instructions")


async def test_home_page_navigation(user: User, new_db) -> None:
    """Test that the home page has proper navigation to the game"""
    await user.open("/")

    # Check home page content
    await user.should_see("Brick Breaker Game")
    await user.should_see("Classic Brick Breaker Game")
    await user.should_see("Control the paddle with arrow keys")
    await user.should_see("Break all the bricks")
    await user.should_see(marker="play-game")

    # Test navigation to game
    user.find(marker="play-game").click()
    await user.should_see(marker="instructions")


async def test_new_game_button_creates_session(user: User, new_db) -> None:
    """Test that clicking New Game creates a game session"""
    await user.open("/brick-breaker")

    # Initially no game sessions should exist
    with get_session() as session:
        game_sessions = session.exec(select(GameSession)).all()
        assert len(game_sessions) == 0

    # Click New Game button
    user.find(marker="new-game").click()

    # Wait a moment for async operations
    await user.should_see("Playing")

    # Check that game session was created
    with get_session() as session:
        game_sessions = session.exec(select(GameSession)).all()
        assert len(game_sessions) == 1

        game_session = game_sessions[0]
        assert game_session.status == GameStatus.PLAYING
        assert game_session.lives_remaining == 3
        assert game_session.current_level == 1
        assert game_session.current_score == 0


async def test_player_creation_on_game_start(user: User, new_db) -> None:
    """Test that a default player is created when starting a game"""
    await user.open("/brick-breaker")

    # Initially no players should exist
    with get_session() as session:
        players = session.exec(select(Player)).all()
        assert len(players) == 0

    # Start new game
    user.find(marker="new-game").click()
    await user.should_see("Playing")

    # Check that player was created
    with get_session() as session:
        players = session.exec(select(Player)).all()
        assert len(players) == 1

        player = players[0]
        assert player.name == "Player 1"
        assert player.email == "player1@example.com"


async def test_game_ui_updates_with_game_state(user: User, new_db) -> None:
    """Test that UI elements update to reflect game state"""
    await user.open("/brick-breaker")

    # Start game
    user.find(marker="new-game").click()
    await user.should_see("Playing")

    # UI should show initial game state
    await user.should_see("Score: 0")
    await user.should_see("Lives: 3")
    await user.should_see("Level: 1")


async def test_pause_resume_functionality(user: User, new_db) -> None:
    """Test pause and resume game functionality"""
    await user.open("/brick-breaker")

    # Start game first
    user.find(marker="new-game").click()
    await user.should_see("Playing")

    # Wait for game to be fully initialized
    import asyncio

    await asyncio.sleep(0.2)

    # Pause game
    user.find(marker="pause-resume").click()
    await user.should_see(marker="game-status")

    # Wait for pause to take effect
    await asyncio.sleep(0.1)

    # Check that game session is paused
    with get_session() as session:
        game_session = session.exec(select(GameSession)).first()
        assert game_session is not None
        session.refresh(game_session)
        assert game_session.status == GameStatus.PAUSED

    # Resume game
    user.find(marker="pause-resume").click()
    await user.should_see("Playing")

    # Wait for resume to take effect
    await asyncio.sleep(0.1)

    # Check that game session is playing again
    with get_session() as session:
        game_session = session.exec(select(GameSession)).first()
        assert game_session is not None
        session.refresh(game_session)
        assert game_session.status == GameStatus.PLAYING


async def test_game_area_element_present(user: User, new_db) -> None:
    """Test that the game area element is present"""
    await user.open("/brick-breaker")

    # Check for game area (HTML canvas)
    await user.should_see("gameCanvas")  # Canvas ID should be in HTML


def test_brick_breaker_game_initialization():
    """Test BrickBreakerGame class initialization"""
    game = BrickBreakerGame()

    # Check initial state
    assert game.game_engine is None
    assert game.game_session is None
    assert game.player is None
    assert not game.is_running
    assert game.keys_pressed == {}
    assert game.game_width == 800
    assert game.game_height == 600


async def test_game_handles_multiple_new_games(user: User, new_db) -> None:
    """Test that starting multiple new games works correctly"""
    await user.open("/brick-breaker")

    # Start first game
    user.find(marker="new-game").click()
    await user.should_see("Playing")

    # Wait a bit for game session to be created
    import asyncio

    await asyncio.sleep(0.2)

    # Check initial session count
    with get_session() as session:
        game_sessions = session.exec(select(GameSession)).all()
        assert len(game_sessions) >= 1
        first_session_count = len(game_sessions)

    # Start second game
    user.find(marker="new-game").click()
    await user.should_see("Playing")

    # Wait for second session
    await asyncio.sleep(0.2)

    # Should have created another session
    with get_session() as session:
        game_sessions = session.exec(select(GameSession)).all()
        assert len(game_sessions) >= first_session_count + 1


async def test_error_handling_in_ui(user: User, new_db) -> None:
    """Test that UI handles errors gracefully"""
    await user.open("/brick-breaker")

    # The game should load even if there are no database entries initially
    await user.should_see("Brick Breaker")
    await user.should_see(marker="new-game")

    # Should be able to start a game without errors
    user.find(marker="new-game").click()

    # Should not see any error messages in normal operation
    await user.should_not_see("Error")


def test_game_configuration_loading():
    """Test that game configuration is loaded properly"""
    from app.game_engine import GameEngine

    # Create engine (should create default config)
    engine = GameEngine(0)

    # Check that config was loaded/created
    assert engine.config is not None
    assert engine.config.game_width > 0
    assert engine.config.game_height > 0
    assert engine.config.paddle_width > 0
    assert engine.config.ball_radius > 0


async def test_responsive_ui_layout(user: User, new_db) -> None:
    """Test that UI layout is responsive and well-structured"""
    await user.open("/brick-breaker")

    # Check for proper header structure
    await user.should_see("Brick Breaker")
    await user.should_see("Score:")
    await user.should_see("Lives:")
    await user.should_see("Level:")

    # Check for game area
    await user.should_see("Use ← → arrow keys")

    # Game area should be present
    await user.should_see("gameCanvas")


async def test_game_status_messages(user: User, new_db) -> None:
    """Test that appropriate status messages are displayed"""
    await user.open("/brick-breaker")

    # Initial status
    await user.should_see('Click "New Game" to start!')

    # After starting game
    user.find(marker="new-game").click()
    await user.should_see("Playing - Use arrow keys!")

    # After pausing
    user.find(marker="pause-resume").click()
    await user.should_see(marker="game-status")


async def test_ui_styling_and_theming(user: User, new_db) -> None:
    """Test that UI has proper styling and theming applied"""
    await user.open("/")

    # Check that home page has gradient background and modern styling
    await user.should_see("Brick Breaker Game")
    await user.should_see("Play Game")

    # Navigate to game page
    user.find("Play Game").click()

    # Game page should have dark theme
    await user.should_see("Brick Breaker")
    await user.should_see("New Game")


def test_game_constants_and_configuration():
    """Test that game has reasonable default constants"""
    game = BrickBreakerGame()

    # Check game dimensions
    assert game.game_width == 800
    assert game.game_height == 600

    # Check that these are reasonable values for a web game
    assert 600 <= game.game_width <= 1200
    assert 400 <= game.game_height <= 800


async def test_navigation_between_pages(user: User, new_db) -> None:
    """Test navigation between home page and game page"""
    # Start at home
    await user.open("/")
    await user.should_see("Classic Brick Breaker Game")

    # Navigate to game
    user.find("Play Game").click()
    await user.should_see("Use ← → arrow keys to control the paddle")

    # Direct navigation to game page should also work
    await user.open("/brick-breaker")
    await user.should_see(marker="new-game")
    await user.should_see(marker="pause-resume")


async def test_ui_elements_are_accessible(user: User, new_db) -> None:
    """Test that UI elements are properly accessible"""
    await user.open("/brick-breaker")

    # All buttons should be findable and clickable
    new_game_button = user.find(marker="new-game").elements
    assert len(new_game_button) == 1

    pause_button = user.find(marker="pause-resume").elements
    assert len(pause_button) == 1

    # Labels should be present and accessible
    await user.should_see("Score:")
    await user.should_see("Lives:")
