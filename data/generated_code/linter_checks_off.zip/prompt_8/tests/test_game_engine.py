"""
Tests for the Brick Breaker game engine
"""

import pytest
from decimal import Decimal
from app.database import reset_db, get_session
from app.models import Player, GameSession, Brick, GameConfiguration, BrickType, GameStatus
from app.game_engine import GameEngine
from sqlmodel import select


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


@pytest.fixture()
def test_player(new_db):
    """Create a test player"""
    with get_session() as session:
        player = Player(name="Test Player", email="test@example.com")
        session.add(player)
        session.commit()
        session.refresh(player)
        return player


@pytest.fixture()
def game_config(new_db):
    """Create test game configuration"""
    with get_session() as session:
        config = GameConfiguration(
            config_name="test_config",
            game_width=800,
            game_height=600,
            paddle_width=100,
            paddle_height=10,
            ball_radius=8,
            ball_initial_speed=Decimal("5"),
            initial_lives=3,
            is_active=True,
        )
        session.add(config)
        session.commit()
        session.refresh(config)
        return config


def test_game_engine_initialization(test_player, game_config):
    """Test game engine initialization"""
    engine = GameEngine(0)  # Temporary ID
    assert engine.config.config_name == "test_config"
    assert engine.config.game_width == 800
    assert engine.config.game_height == 600


def test_start_new_game(test_player, game_config):
    """Test starting a new game session"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)

    assert game_session.player_id == test_player.id
    assert game_session.current_level == 1
    assert game_session.current_score == 0
    assert game_session.lives_remaining == 3
    assert game_session.status == GameStatus.PLAYING
    assert game_session.paddle_position == Decimal("400")  # Center of 800px width

    # Check that bricks were created
    with get_session() as session:
        bricks = session.exec(select(Brick).where(Brick.game_session_id == game_session.id)).all()
        # Default config creates 8 rows x 12 cols = 96 bricks
        assert len(bricks) == 96


def test_ball_position_update(test_player, game_config):
    """Test ball position updates with physics"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)
    engine.game_session_id = game_session.id or 0

    initial_x = game_session.ball_position_x
    initial_y = game_session.ball_position_y

    # Update ball position
    new_x, new_y = engine.update_ball_position(1.0)  # 1 second

    # Ball should have moved based on velocity
    assert new_x != initial_x
    assert new_y != initial_y

    # Check that position is updated in database
    updated_session = engine.get_game_state()
    assert updated_session is not None
    assert updated_session.ball_position_x == new_x
    assert updated_session.ball_position_y == new_y


def test_wall_collision_left(test_player, game_config):
    """Test ball collision with left wall"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)
    engine.game_session_id = game_session.id or 0

    # Set ball near left wall with leftward velocity
    with get_session() as session:
        session_obj = session.get(GameSession, game_session.id)
        if session_obj:
            session_obj.ball_position_x = Decimal("5")  # Near left wall
            session_obj.ball_velocity_x = Decimal("-10")  # Moving left
            session.commit()

    # Update position - should bounce off left wall
    new_x, new_y = engine.update_ball_position(1.0)

    updated_session = engine.get_game_state()
    assert updated_session is not None
    # Ball should bounce and velocity should reverse
    assert updated_session.ball_velocity_x > 0  # Now moving right


def test_wall_collision_right(test_player, game_config):
    """Test ball collision with right wall"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)
    engine.game_session_id = game_session.id or 0

    # Set ball near right wall with rightward velocity
    with get_session() as session:
        session_obj = session.get(GameSession, game_session.id)
        if session_obj:
            session_obj.ball_position_x = Decimal("795")  # Near right wall (800-5)
            session_obj.ball_velocity_x = Decimal("10")  # Moving right
            session.commit()

    # Update position - should bounce off right wall
    new_x, new_y = engine.update_ball_position(1.0)

    updated_session = engine.get_game_state()
    assert updated_session is not None
    # Ball should bounce and velocity should reverse
    assert updated_session.ball_velocity_x < 0  # Now moving left


def test_ball_fall_lose_life(test_player, game_config):
    """Test losing a life when ball falls past paddle"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)
    engine.game_session_id = game_session.id or 0

    initial_lives = game_session.lives_remaining

    # Set ball below bottom of screen
    with get_session() as session:
        session_obj = session.get(GameSession, game_session.id)
        if session_obj:
            session_obj.ball_position_y = Decimal("700")  # Below screen (height=600)
            session_obj.ball_velocity_y = Decimal("10")  # Moving down
            session.commit()

    # Update position - should lose a life
    new_x, new_y = engine.update_ball_position(1.0)

    updated_session = engine.get_game_state()
    assert updated_session is not None
    assert updated_session.lives_remaining == initial_lives - 1


def test_game_over_when_no_lives(test_player, game_config):
    """Test game over when all lives are lost"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)
    engine.game_session_id = game_session.id or 0

    # Set to last life
    with get_session() as session:
        session_obj = session.get(GameSession, game_session.id)
        if session_obj:
            session_obj.lives_remaining = 1
            session_obj.ball_position_y = Decimal("700")  # Below screen
            session_obj.ball_velocity_y = Decimal("10")  # Moving down
            session.commit()

    # Update position - should trigger game over
    new_x, new_y = engine.update_ball_position(1.0)

    updated_session = engine.get_game_state()
    assert updated_session is not None
    assert updated_session.lives_remaining == 0
    assert updated_session.status == GameStatus.GAME_OVER


def test_paddle_movement_left(test_player, game_config):
    """Test paddle movement to the left"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)
    engine.game_session_id = game_session.id or 0

    initial_position = game_session.paddle_position

    # Move paddle left
    new_position = engine.move_paddle("left")

    assert new_position < initial_position

    # Check database update
    updated_session = engine.get_game_state()
    assert updated_session is not None
    assert updated_session.paddle_position == new_position


def test_paddle_movement_right(test_player, game_config):
    """Test paddle movement to the right"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)
    engine.game_session_id = game_session.id or 0

    initial_position = game_session.paddle_position

    # Move paddle right
    new_position = engine.move_paddle("right")

    assert new_position > initial_position

    # Check database update
    updated_session = engine.get_game_state()
    assert updated_session is not None
    assert updated_session.paddle_position == new_position


def test_paddle_boundary_constraints(test_player, game_config):
    """Test paddle can't move outside screen boundaries"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)
    engine.game_session_id = game_session.id or 0

    # Move paddle far left
    for _ in range(100):
        engine.move_paddle("left")

    updated_session = engine.get_game_state()
    assert updated_session is not None
    # Paddle should be at minimum position (half width from left edge)
    assert updated_session.paddle_position >= Decimal("50")  # paddle_width/2

    # Move paddle far right
    for _ in range(200):
        engine.move_paddle("right")

    updated_session = engine.get_game_state()
    assert updated_session is not None
    # Paddle should be at maximum position (half width from right edge)
    assert updated_session.paddle_position <= Decimal("750")  # game_width - paddle_width/2


def test_paddle_collision(test_player, game_config):
    """Test ball collision with paddle"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)
    engine.game_session_id = game_session.id or 0

    # Position ball just above paddle, moving down
    with get_session() as session:
        session_obj = session.get(GameSession, game_session.id)
        if session_obj:
            # Calculate exact paddle position
            paddle_y = 600 - 50  # game_height - paddle_y_offset
            ball_radius = 8  # From config
            # Position ball so it will definitely hit paddle
            session_obj.ball_position_x = session_obj.paddle_position  # Same X as paddle
            session_obj.ball_position_y = Decimal(str(paddle_y + 1))  # Just at paddle level
            session_obj.ball_velocity_x = Decimal("0")  # No horizontal movement
            session_obj.ball_velocity_y = Decimal("5")  # Moving down
            session.commit()

    # Check collision
    collision_occurred = engine.check_paddle_collision()
    assert collision_occurred

    # Ball should now be moving up
    updated_session = engine.get_game_state()
    assert updated_session is not None
    assert updated_session.ball_velocity_y < 0  # Moving up after bounce


def test_brick_collision_and_destruction(test_player, game_config):
    """Test ball collision with bricks"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)
    engine.game_session_id = game_session.id or 0

    # Manually create a simple collision scenario
    with get_session() as session:
        # Create a test brick in a predictable position
        test_brick = Brick(
            game_session_id=game_session.id or 0,
            row=5,
            col=5,
            position_x=Decimal("300"),
            position_y=Decimal("200"),
            width=Decimal("60"),
            height=Decimal("20"),
            brick_type=BrickType.NORMAL,
            hits_remaining=1,
            points_value=10,
        )
        session.add(test_brick)
        session.commit()
        session.refresh(test_brick)

        # Position ball to overlap with this test brick
        session_obj = session.get(GameSession, game_session.id)
        if session_obj:
            # Position ball center inside the brick
            session_obj.ball_position_x = test_brick.position_x + test_brick.width / 2
            session_obj.ball_position_y = test_brick.position_y + test_brick.height / 2
            session_obj.ball_velocity_x = Decimal("0")
            session_obj.ball_velocity_y = Decimal("5")  # Moving down
            session.commit()

    initial_score = game_session.current_score

    # Check collision
    collisions = engine.check_brick_collisions()
    assert len(collisions) > 0

    collision = collisions[0]
    assert collision.points_earned > 0

    # Check that score increased
    updated_session = engine.get_game_state()
    assert updated_session is not None
    assert updated_session.current_score > initial_score

    # Check that brick is marked as destroyed
    with get_session() as session:
        updated_brick = session.get(Brick, collision.brick_id)
        assert updated_brick is not None
        assert updated_brick.is_destroyed


def test_level_completion(test_player, game_config):
    """Test level completion when all destructible bricks are destroyed"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)
    engine.game_session_id = game_session.id or 0

    # Destroy all bricks manually
    with get_session() as session:
        bricks = session.exec(
            select(Brick).where(Brick.game_session_id == game_session.id, Brick.brick_type != BrickType.UNBREAKABLE)
        ).all()

        for brick in bricks:
            brick.is_destroyed = True

        session.commit()

    # Check collisions (which triggers level complete check)
    collisions = engine.check_brick_collisions()

    # Game should be in level complete state
    updated_session = engine.get_game_state()
    assert updated_session is not None
    assert updated_session.status == GameStatus.LEVEL_COMPLETE


def test_strong_brick_requires_multiple_hits(test_player, game_config):
    """Test that strong bricks require multiple hits"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)
    engine.game_session_id = game_session.id or 0

    # Create a strong brick manually
    with get_session() as session:
        strong_brick = Brick(
            game_session_id=game_session.id or 0,
            row=0,
            col=0,
            position_x=Decimal("100"),
            position_y=Decimal("100"),
            width=Decimal("60"),
            height=Decimal("20"),
            brick_type=BrickType.STRONG,
            hits_remaining=2,
            points_value=20,
        )
        session.add(strong_brick)
        session.commit()
        session.refresh(strong_brick)

        # Position ball to hit the strong brick from above
        session_obj = session.get(GameSession, game_session.id)
        if session_obj:
            ball_radius = 8  # From config
            session_obj.ball_position_x = strong_brick.position_x + strong_brick.width / 2
            session_obj.ball_position_y = strong_brick.position_y - Decimal(str(ball_radius + 1))
            session_obj.ball_velocity_x = Decimal("0")
            session_obj.ball_velocity_y = Decimal("5")
            session.commit()

    # First hit - should not destroy brick
    collisions = engine.check_brick_collisions()
    if collisions:
        collision = collisions[0]
        assert not collision.brick_destroyed

        # Check brick still exists but has fewer hits remaining
        with get_session() as session:
            updated_brick = session.get(Brick, collision.brick_id)
            assert updated_brick is not None
            assert not updated_brick.is_destroyed
            assert updated_brick.hits_remaining == 1


def test_initialize_level_creates_bricks(test_player, game_config):
    """Test that initializing a level creates the correct brick layout"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)
    engine.game_session_id = game_session.id or 0

    # Clear existing bricks
    with get_session() as session:
        existing_bricks = session.exec(select(Brick).where(Brick.game_session_id == game_session.id)).all()
        for brick in existing_bricks:
            session.delete(brick)
        session.commit()

    # Initialize level
    engine.initialize_level(2)

    # Check that bricks were created
    with get_session() as session:
        bricks = session.exec(select(Brick).where(Brick.game_session_id == game_session.id)).all()

        # Should have created 8 rows x 12 cols = 96 bricks
        assert len(bricks) == 96

        # Check that top rows are strong bricks
        top_row_bricks = [b for b in bricks if b.row < 2]
        for brick in top_row_bricks:
            assert brick.brick_type == BrickType.STRONG
            assert brick.hits_remaining == 2
            assert brick.points_value == 20


def test_game_engine_handles_missing_session():
    """Test that game engine handles missing game session gracefully"""
    engine = GameEngine(999)  # Non-existent session ID

    # Should return None or default values without crashing
    game_state = engine.get_game_state()
    assert game_state is None

    ball_x, ball_y = engine.update_ball_position(1.0)
    assert ball_x == Decimal("0")
    assert ball_y == Decimal("0")

    collisions = engine.check_brick_collisions()
    assert collisions == []

    collision_occurred = engine.check_paddle_collision()
    assert not collision_occurred

    paddle_pos = engine.move_paddle("left")
    assert paddle_pos == Decimal("0")


def test_collision_side_detection_accuracy(test_player, game_config):
    """Test accurate collision side detection for ball-brick collisions"""
    engine = GameEngine(0)
    game_session = engine.start_new_game(test_player.id or 0)
    engine.game_session_id = game_session.id or 0

    # Create a test brick
    with get_session() as session:
        test_brick = Brick(
            game_session_id=game_session.id or 0,
            row=5,
            col=5,
            position_x=Decimal("300"),
            position_y=Decimal("200"),
            width=Decimal("60"),
            height=Decimal("20"),
            brick_type=BrickType.NORMAL,
            hits_remaining=1,
            points_value=10,
        )
        session.add(test_brick)
        session.commit()
        session.refresh(test_brick)

        # Test collision from top (ball moving down)
        session_obj = session.get(GameSession, game_session.id)
        if session_obj:
            ball_radius = 8  # From config
            session_obj.ball_position_x = test_brick.position_x + test_brick.width / 2  # Center X
            session_obj.ball_position_y = test_brick.position_y - Decimal(str(ball_radius + 1))  # Above brick
            session_obj.ball_velocity_x = Decimal("0")
            session_obj.ball_velocity_y = Decimal("5")  # Moving down
            session.commit()

    collisions = engine.check_brick_collisions()
    assert len(collisions) > 0

    collision = collisions[0]
    # When hitting from top, Y velocity should reverse but X should stay same
    assert collision.new_ball_velocity_y < 0  # Should bounce up
    assert collision.collision_side in ["top", "bottom"]
