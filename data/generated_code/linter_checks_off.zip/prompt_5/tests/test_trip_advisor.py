import pytest
from nicegui.testing import User
from nicegui import ui


@pytest.mark.asyncio
async def test_trip_advisor_page_loads(user: User) -> None:
    """Test that the trip advisor page loads correctly"""
    await user.open("/")

    # Check that main elements are present
    await user.should_see("Trip Weather Advisor")
    await user.should_see("Plan your perfect trip")
    await user.should_see("Enter City Name")
    await user.should_see("Check Weather")


@pytest.mark.asyncio
async def test_empty_city_input_validation(user: User) -> None:
    """Test validation when no city name is entered"""
    await user.open("/")

    # Try to search without entering a city
    user.find("Check Weather").click()

    # Should show a warning notification
    await user.should_see("Please enter a city name")


@pytest.mark.asyncio
async def test_input_field_functionality(user: User) -> None:
    """Test that the input field accepts text entry"""
    await user.open("/")

    # Find the input field and type in it
    city_input = user.find(ui.input)
    city_input.type("London")

    # Verify the text was entered
    input_elements = list(city_input.elements)
    if input_elements:
        assert input_elements[0].value == "London"


@pytest.mark.asyncio
async def test_ui_components_present(user: User) -> None:
    """Test that all required UI components are present"""
    await user.open("/")

    # Check for input field
    assert len(list(user.find(ui.input).elements)) == 1

    # Check for search button
    await user.should_see("Check Weather")

    # Check for main container elements
    await user.should_see("☀️ Trip Weather Advisor")
    await user.should_see("based on tomorrow's weather forecast")
    await user.should_see("Powered by Open-Meteo API")


@pytest.mark.asyncio
async def test_enter_key_functionality(user: User) -> None:
    """Test that pressing Enter triggers search functionality"""
    await user.open("/")

    # Type in input and press Enter (should trigger validation for empty input first)
    city_input = user.find(ui.input)
    city_input.trigger("keydown.enter")

    # Should show validation message
    await user.should_see("Please enter a city name")


@pytest.mark.asyncio
async def test_search_button_click_without_input(user: User) -> None:
    """Test search button behavior without input"""
    await user.open("/")

    # Click search button without entering city name
    search_button = user.find("Check Weather")
    search_button.click()

    # Should show validation message
    await user.should_see("Please enter a city name")


@pytest.mark.asyncio
async def test_page_styling_elements(user: User) -> None:
    """Test that key styling elements are present"""
    await user.open("/")

    # Check for main header elements
    await user.should_see("☀️")  # Weather emoji
    await user.should_see("Trip Weather Advisor")

    # Check for descriptive text
    await user.should_see("Plan your perfect trip")

    # Check for footer
    await user.should_see("Powered by Open-Meteo API")
