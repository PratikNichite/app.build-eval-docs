import pytest
from app.weather_service import WeatherService, TripRecommendationService
from decimal import Decimal


@pytest.mark.asyncio
async def test_real_city_search():
    """Test city search with real Open-Meteo API data"""
    # Test with a well-known city
    result = await WeatherService.search_city("London")

    if result is not None:
        # Verify the structure and types
        assert isinstance(result.name, str)
        assert isinstance(result.latitude, Decimal)
        assert isinstance(result.longitude, Decimal)
        assert isinstance(result.country, str)
        assert isinstance(result.timezone, str)

        # London coordinates should be approximately correct
        assert 51.0 < result.latitude < 52.0
        assert -1.0 < result.longitude < 0.0
        assert "Kingdom" in result.country or "England" in result.country
    else:
        # If API is not available, test should not fail
        # but we should note that API connectivity was not tested
        pytest.skip("Open-Meteo API not accessible during test run")


@pytest.mark.asyncio
async def test_real_weather_forecast():
    """Test weather forecast with real Open-Meteo API data"""
    # Use London coordinates
    london_lat = Decimal("51.5074")
    london_lon = Decimal("-0.1278")

    result = await WeatherService.get_tomorrow_forecast(london_lat, london_lon)

    if result is not None:
        # Verify the structure and reasonable values
        assert isinstance(result["temperature_min"], (int, float))
        assert isinstance(result["temperature_max"], (int, float))
        assert isinstance(result["precipitation_total"], (int, float))
        assert isinstance(result["wind_speed_max"], (int, float))
        assert isinstance(result["weather_code"], int)

        # Sanity checks for reasonable weather values
        assert -50 <= result["temperature_min"] <= 50  # Reasonable temp range
        assert -50 <= result["temperature_max"] <= 50
        assert result["temperature_min"] <= result["temperature_max"]  # Min <= Max
        assert result["precipitation_total"] >= 0  # Non-negative precipitation
        assert result["wind_speed_max"] >= 0  # Non-negative wind speed
        assert result["weather_code"] >= 0  # Valid weather code

        # Test that we can create a recommendation from real data
        recommendation = TripRecommendationService.evaluate_trip_conditions(
            temp_min=Decimal(str(result["temperature_min"])),
            temp_max=Decimal(str(result["temperature_max"])),
            precipitation=Decimal(str(result["precipitation_total"])),
            wind_speed=Decimal(str(result["wind_speed_max"])),
        )

        # Verify recommendation structure
        assert isinstance(recommendation["is_good_idea"], bool)
        assert isinstance(recommendation["message"], str)
        assert isinstance(recommendation["temperature_score"], bool)
        assert isinstance(recommendation["precipitation_score"], bool)
        assert isinstance(recommendation["wind_score"], bool)
        assert len(recommendation["message"]) > 0

    else:
        # If API is not available, test should not fail
        pytest.skip("Open-Meteo weather API not accessible during test run")


@pytest.mark.asyncio
async def test_real_nonexistent_city():
    """Test that searching for a truly nonexistent city returns None"""
    result = await WeatherService.search_city("Nonexistentcityname12345")
    assert result is None


@pytest.mark.asyncio
async def test_real_weather_description():
    """Test weather description with real weather codes"""
    # Test some common weather codes
    assert "clear" in TripRecommendationService.get_weather_description(0).lower()
    assert "rain" in TripRecommendationService.get_weather_description(61).lower()
    assert "snow" in TripRecommendationService.get_weather_description(71).lower()
    assert "thunderstorm" in TripRecommendationService.get_weather_description(95).lower()

    # Unknown code should return "Unknown conditions"
    assert "unknown" in TripRecommendationService.get_weather_description(9999).lower()
