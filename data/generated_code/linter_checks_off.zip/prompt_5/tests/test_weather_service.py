from decimal import Decimal
from app.weather_service import TripRecommendationService


class TestTripRecommendationService:
    """Tests for TripRecommendationService logic"""

    def test_perfect_conditions(self):
        """Test trip recommendation with perfect weather conditions"""
        result = TripRecommendationService.evaluate_trip_conditions(
            temp_min=Decimal("15"), temp_max=Decimal("22"), precipitation=Decimal("0"), wind_speed=Decimal("10")
        )

        assert result["is_good_idea"] is True
        assert result["temperature_score"] is True
        assert result["precipitation_score"] is True
        assert result["wind_score"] is True
        assert "☀️ Good Idea!" in result["message"]

    def test_too_cold_conditions(self):
        """Test trip recommendation when temperature is too cold"""
        result = TripRecommendationService.evaluate_trip_conditions(
            temp_min=Decimal("2"), temp_max=Decimal("8"), precipitation=Decimal("0"), wind_speed=Decimal("10")
        )

        assert result["is_good_idea"] is False
        assert result["temperature_score"] is False
        assert result["precipitation_score"] is True
        assert result["wind_score"] is True
        assert "⚠️ Maybe Reschedule" in result["message"]
        assert "cold ❄️" in result["message"]

    def test_too_hot_conditions(self):
        """Test trip recommendation when temperature is too hot"""
        result = TripRecommendationService.evaluate_trip_conditions(
            temp_min=Decimal("20"), temp_max=Decimal("35"), precipitation=Decimal("0"), wind_speed=Decimal("10")
        )

        assert result["is_good_idea"] is False
        assert result["temperature_score"] is False
        assert result["precipitation_score"] is True
        assert result["wind_score"] is True
        assert "⚠️ Maybe Reschedule" in result["message"]
        assert "hot 🔥" in result["message"]

    def test_rainy_conditions(self):
        """Test trip recommendation with significant precipitation"""
        result = TripRecommendationService.evaluate_trip_conditions(
            temp_min=Decimal("15"), temp_max=Decimal("20"), precipitation=Decimal("5.5"), wind_speed=Decimal("10")
        )

        assert result["is_good_idea"] is False
        assert result["temperature_score"] is True
        assert result["precipitation_score"] is False
        assert result["wind_score"] is True
        assert "⚠️ Maybe Reschedule" in result["message"]
        assert "rain is expected 🌧️" in result["message"]

    def test_windy_conditions(self):
        """Test trip recommendation with strong winds"""
        result = TripRecommendationService.evaluate_trip_conditions(
            temp_min=Decimal("15"), temp_max=Decimal("20"), precipitation=Decimal("0"), wind_speed=Decimal("25")
        )

        assert result["is_good_idea"] is False
        assert result["temperature_score"] is True
        assert result["precipitation_score"] is True
        assert result["wind_score"] is False
        assert "⚠️ Maybe Reschedule" in result["message"]
        assert "winds are forecast 🌬️" in result["message"]

    def test_multiple_bad_conditions(self):
        """Test trip recommendation with multiple poor conditions"""
        result = TripRecommendationService.evaluate_trip_conditions(
            temp_min=Decimal("5"), temp_max=Decimal("8"), precipitation=Decimal("3.2"), wind_speed=Decimal("30")
        )

        assert result["is_good_idea"] is False
        assert result["temperature_score"] is False
        assert result["precipitation_score"] is False
        assert result["wind_score"] is False
        assert "⚠️ Maybe Reschedule" in result["message"]

    def test_borderline_conditions(self):
        """Test trip recommendation with borderline weather conditions"""
        # Exactly at temperature limits
        result = TripRecommendationService.evaluate_trip_conditions(
            temp_min=Decimal("10"), temp_max=Decimal("25"), precipitation=Decimal("0.9"), wind_speed=Decimal("19.9")
        )

        assert result["is_good_idea"] is True
        assert result["temperature_score"] is True
        assert result["precipitation_score"] is True
        assert result["wind_score"] is True

    def test_just_over_limits(self):
        """Test trip recommendation just over the limits"""
        result = TripRecommendationService.evaluate_trip_conditions(
            temp_min=Decimal("10"), temp_max=Decimal("25.1"), precipitation=Decimal("1.1"), wind_speed=Decimal("20.1")
        )

        assert result["is_good_idea"] is False
        assert result["temperature_score"] is False
        assert result["precipitation_score"] is False
        assert result["wind_score"] is False

    def test_weather_description_codes(self):
        """Test weather code to description conversion"""
        assert TripRecommendationService.get_weather_description(0) == "Clear sky"
        assert TripRecommendationService.get_weather_description(1) == "Mainly clear"
        assert TripRecommendationService.get_weather_description(61) == "Slight rain"
        assert TripRecommendationService.get_weather_description(95) == "Thunderstorm"
        assert TripRecommendationService.get_weather_description(999) == "Unknown conditions"

    def test_details_formatting(self):
        """Test that details are properly formatted"""
        result = TripRecommendationService.evaluate_trip_conditions(
            temp_min=Decimal("12.5"), temp_max=Decimal("18.7"), precipitation=Decimal("0.3"), wind_speed=Decimal("8.2")
        )

        details = result["details"]
        assert details["temperature_range"] == "12.5°C - 18.7°C"
        assert details["precipitation"] == "0.3mm"
        assert details["wind_speed"] == "8.2km/h"

    def test_cold_morning_temperature(self):
        """Test trip recommendation when morning temperature is very cold"""
        result = TripRecommendationService.evaluate_trip_conditions(
            temp_min=Decimal("2"), temp_max=Decimal("15"), precipitation=Decimal("0"), wind_speed=Decimal("10")
        )

        assert result["is_good_idea"] is False
        assert result["temperature_score"] is False
        assert "cold ❄️" in result["message"]

    def test_empty_conditions_handling(self):
        """Test handling of zero/minimal values"""
        result = TripRecommendationService.evaluate_trip_conditions(
            temp_min=Decimal("0"), temp_max=Decimal("0"), precipitation=Decimal("0"), wind_speed=Decimal("0")
        )

        # Should fail temperature score due to being too cold
        assert result["is_good_idea"] is False
        assert result["temperature_score"] is False
        assert result["precipitation_score"] is True  # 0mm is good
        assert result["wind_score"] is True  # 0 km/h is good
