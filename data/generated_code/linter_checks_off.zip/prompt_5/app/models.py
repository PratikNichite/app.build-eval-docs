from sqlmodel import SQLModel, Field, Relationship, JSON, Column
from datetime import datetime, date
from typing import Optional, List, Dict, Any
from decimal import Decimal


# Persistent models (stored in database)
class City(SQLModel, table=True):
    __tablename__ = "cities"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100, index=True)
    latitude: Decimal = Field(decimal_places=6)
    longitude: Decimal = Field(decimal_places=6)
    country: str = Field(max_length=100)
    timezone: str = Field(max_length=50)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    weather_forecasts: List["WeatherForecast"] = Relationship(back_populates="city")
    trip_recommendations: List["TripRecommendation"] = Relationship(back_populates="city")


class WeatherForecast(SQLModel, table=True):
    __tablename__ = "weather_forecasts"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    city_id: int = Field(foreign_key="cities.id")
    forecast_date: date = Field(index=True)
    temperature_min: Decimal = Field(decimal_places=2)  # Celsius
    temperature_max: Decimal = Field(decimal_places=2)  # Celsius
    precipitation_total: Decimal = Field(decimal_places=2, default=Decimal("0"))  # mm
    wind_speed_max: Decimal = Field(decimal_places=2, default=Decimal("0"))  # km/h
    weather_code: int = Field(default=0)  # WMO weather interpretation codes
    raw_api_data: Dict[str, Any] = Field(default={}, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    city: City = Relationship(back_populates="weather_forecasts")
    trip_recommendations: List["TripRecommendation"] = Relationship(back_populates="weather_forecast")


class TripRecommendation(SQLModel, table=True):
    __tablename__ = "trip_recommendations"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    city_id: int = Field(foreign_key="cities.id")
    weather_forecast_id: int = Field(foreign_key="weather_forecasts.id")
    recommendation_date: date = Field(index=True)
    is_good_idea: bool = Field(default=False)
    temperature_score: bool = Field(default=False)  # 10-25°C range
    precipitation_score: bool = Field(default=False)  # < 1mm
    wind_score: bool = Field(default=False)  # < 20 km/h
    overall_message: str = Field(max_length=500)
    details: Dict[str, Any] = Field(default={}, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=datetime.utcnow)

    city: City = Relationship(back_populates="trip_recommendations")
    weather_forecast: WeatherForecast = Relationship(back_populates="trip_recommendations")


# Non-persistent schemas (for validation, forms, API requests/responses)
class CityCreate(SQLModel, table=False):
    name: str = Field(max_length=100)
    latitude: Decimal = Field(decimal_places=6)
    longitude: Decimal = Field(decimal_places=6)
    country: str = Field(max_length=100)
    timezone: str = Field(max_length=50)


class CitySearch(SQLModel, table=False):
    query: str = Field(max_length=100, min_length=1)


class WeatherForecastCreate(SQLModel, table=False):
    city_id: int
    forecast_date: date
    temperature_min: Decimal = Field(decimal_places=2)
    temperature_max: Decimal = Field(decimal_places=2)
    precipitation_total: Decimal = Field(decimal_places=2, default=Decimal("0"))
    wind_speed_max: Decimal = Field(decimal_places=2, default=Decimal("0"))
    weather_code: int = Field(default=0)
    raw_api_data: Dict[str, Any] = Field(default={})


class WeatherForecastUpdate(SQLModel, table=False):
    temperature_min: Optional[Decimal] = Field(default=None, decimal_places=2)
    temperature_max: Optional[Decimal] = Field(default=None, decimal_places=2)
    precipitation_total: Optional[Decimal] = Field(default=None, decimal_places=2)
    wind_speed_max: Optional[Decimal] = Field(default=None, decimal_places=2)
    weather_code: Optional[int] = Field(default=None)
    raw_api_data: Optional[Dict[str, Any]] = Field(default=None)


class TripRecommendationCreate(SQLModel, table=False):
    city_id: int
    weather_forecast_id: int
    recommendation_date: date
    is_good_idea: bool = Field(default=False)
    temperature_score: bool = Field(default=False)
    precipitation_score: bool = Field(default=False)
    wind_score: bool = Field(default=False)
    overall_message: str = Field(max_length=500)
    details: Dict[str, Any] = Field(default={})


class TripRecommendationResponse(SQLModel, table=False):
    city_name: str
    recommendation_date: str  # ISO format date string
    is_good_idea: bool
    overall_message: str
    temperature_min: Decimal
    temperature_max: Decimal
    precipitation_total: Decimal
    wind_speed_max: Decimal
    temperature_score: bool
    precipitation_score: bool
    wind_score: bool
    weather_code: int


class WeatherApiError(SQLModel, table=False):
    error_type: str = Field(max_length=50)
    message: str = Field(max_length=500)
    city_name: str = Field(max_length=100)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class GeocodingResult(SQLModel, table=False):
    name: str = Field(max_length=100)
    latitude: Decimal = Field(decimal_places=6)
    longitude: Decimal = Field(decimal_places=6)
    country: str = Field(max_length=100)
    timezone: str = Field(max_length=50)
    admin1: Optional[str] = Field(default=None, max_length=100)  # State/Province
    admin2: Optional[str] = Field(default=None, max_length=100)  # County/District
