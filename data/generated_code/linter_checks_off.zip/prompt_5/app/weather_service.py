import httpx
from datetime import date, timedelta
from decimal import Decimal
from typing import Optional, Dict, Any
from app.models import GeocodingResult


class WeatherService:
    """Service for fetching weather data from Open-Meteo API"""

    BASE_GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
    BASE_WEATHER_URL = "https://api.open-meteo.com/v1/forecast"

    @staticmethod
    async def search_city(city_name: str) -> Optional[GeocodingResult]:
        """Search for a city using Open-Meteo Geocoding API"""
        if not city_name or not city_name.strip():
            return None

        params = {"name": city_name.strip(), "count": 1, "language": "en", "format": "json"}

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(WeatherService.BASE_GEOCODING_URL, params=params)
                response.raise_for_status()
                data = response.json()

                if not data.get("results"):
                    return None

                result = data["results"][0]
                return GeocodingResult(
                    name=result["name"],
                    latitude=Decimal(str(result["latitude"])),
                    longitude=Decimal(str(result["longitude"])),
                    country=result.get("country", ""),
                    timezone=result.get("timezone", "UTC"),
                    admin1=result.get("admin1"),
                    admin2=result.get("admin2"),
                )
        except (httpx.RequestError, httpx.HTTPStatusError, KeyError, ValueError) as e:
            print(f"Error searching for city {city_name}: {e}")
            return None

    @staticmethod
    async def get_tomorrow_forecast(latitude: Decimal, longitude: Decimal) -> Optional[Dict[str, Any]]:
        """Get tomorrow's weather forecast from Open-Meteo API"""
        tomorrow = date.today() + timedelta(days=1)
        tomorrow_str = tomorrow.isoformat()

        params = {
            "latitude": float(latitude),
            "longitude": float(longitude),
            "daily": "temperature_2m_min,temperature_2m_max,precipitation_sum,wind_speed_10m_max,weather_code",
            "start_date": tomorrow_str,
            "end_date": tomorrow_str,
            "timezone": "auto",
        }

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(WeatherService.BASE_WEATHER_URL, params=params)
                response.raise_for_status()
                data = response.json()

                daily = data.get("daily", {})
                if not daily or not daily.get("time"):
                    return None

                # Extract tomorrow's data (should be first and only element)
                forecast_data = {
                    "date": daily["time"][0],
                    "temperature_min": daily["temperature_2m_min"][0],
                    "temperature_max": daily["temperature_2m_max"][0],
                    "precipitation_total": daily["precipitation_sum"][0] or 0,
                    "wind_speed_max": daily["wind_speed_10m_max"][0] or 0,
                    "weather_code": daily["weather_code"][0] or 0,
                    "raw_data": data,
                }

                return forecast_data

        except (httpx.RequestError, httpx.HTTPStatusError, KeyError, ValueError, IndexError) as e:
            print(f"Error fetching weather forecast for {latitude}, {longitude}: {e}")
            return None


class TripRecommendationService:
    """Service for generating trip recommendations based on weather data"""

    @staticmethod
    def evaluate_trip_conditions(
        temp_min: Decimal, temp_max: Decimal, precipitation: Decimal, wind_speed: Decimal
    ) -> Dict[str, Any]:
        """
        Evaluate if weather conditions are good for a trip based on criteria:
        - Temperature: between 10°C and 25°C
        - Precipitation: less than 1mm
        - Wind speed: less than 20 km/h
        """

        # Individual criteria scores
        temp_score = Decimal("10") <= temp_max <= Decimal("25") and temp_min >= Decimal("5")
        precipitation_score = precipitation < Decimal("1")
        wind_score = wind_speed < Decimal("20")

        # Overall recommendation
        is_good_idea = temp_score and precipitation_score and wind_score

        # Generate message
        if is_good_idea:
            message = "☀️ Good Idea! The weather looks perfect for your trip tomorrow."
        else:
            issues = []
            if not temp_score:
                if temp_max < Decimal("10"):
                    issues.append("it will be quite cold ❄️")
                elif temp_max > Decimal("25"):
                    issues.append("it will be quite hot 🔥")
                elif temp_min < Decimal("5"):
                    issues.append("morning temperatures will be very cold ❄️")

            if not precipitation_score:
                issues.append("rain is expected 🌧️")

            if not wind_score:
                issues.append("strong winds are forecast 🌬️")

            if issues:
                message = f"⚠️ Maybe Reschedule - Tomorrow {', '.join(issues)}."
            else:
                message = "⚠️ Maybe Reschedule - Weather conditions might not be ideal."

        return {
            "is_good_idea": is_good_idea,
            "message": message,
            "temperature_score": temp_score,
            "precipitation_score": precipitation_score,
            "wind_score": wind_score,
            "details": {
                "temperature_range": f"{temp_min}°C - {temp_max}°C",
                "precipitation": f"{precipitation}mm",
                "wind_speed": f"{wind_speed}km/h",
            },
        }

    @staticmethod
    def get_weather_description(weather_code: int) -> str:
        """Convert WMO weather code to human-readable description"""
        weather_codes = {
            0: "Clear sky",
            1: "Mainly clear",
            2: "Partly cloudy",
            3: "Overcast",
            45: "Fog",
            48: "Depositing rime fog",
            51: "Light drizzle",
            53: "Moderate drizzle",
            55: "Dense drizzle",
            56: "Light freezing drizzle",
            57: "Dense freezing drizzle",
            61: "Slight rain",
            63: "Moderate rain",
            65: "Heavy rain",
            66: "Light freezing rain",
            67: "Heavy freezing rain",
            71: "Slight snow fall",
            73: "Moderate snow fall",
            75: "Heavy snow fall",
            77: "Snow grains",
            80: "Slight rain showers",
            81: "Moderate rain showers",
            82: "Violent rain showers",
            85: "Slight snow showers",
            86: "Heavy snow showers",
            95: "Thunderstorm",
            96: "Thunderstorm with slight hail",
            99: "Thunderstorm with heavy hail",
        }

        return weather_codes.get(weather_code, "Unknown conditions")
