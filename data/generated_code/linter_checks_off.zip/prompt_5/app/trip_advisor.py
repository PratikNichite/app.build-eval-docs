from nicegui import ui
from decimal import Decimal
from datetime import date, timedelta

from app.weather_service import WeatherService, TripRecommendationService
from app.models import GeocodingResult


def create():
    """Create the trip advisor application"""

    @ui.page("/")
    async def trip_advisor_page():
        """Main trip advisor page"""

        # Apply modern theme
        ui.colors(
            primary="#2563eb",  # Professional blue
            secondary="#64748b",  # Subtle gray
            accent="#10b981",  # Success green
            positive="#10b981",
            negative="#ef4444",  # Error red
            warning="#f59e0b",  # Warning amber
            info="#3b82f6",  # Info blue
        )

        # Main container
        with ui.column().classes("min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6"):
            # Header
            with ui.row().classes("w-full justify-center mb-8"):
                with ui.card().classes("p-8 shadow-xl rounded-2xl bg-white/80 backdrop-blur-sm"):
                    ui.label("☀️ Trip Weather Advisor").classes("text-4xl font-bold text-gray-800 text-center")
                    ui.label("Plan your perfect trip based on tomorrow's weather forecast").classes(
                        "text-lg text-gray-600 text-center mt-2"
                    )

            # Main content area
            with ui.row().classes("w-full justify-center"):
                with ui.card().classes("w-full max-w-2xl p-8 shadow-lg rounded-xl bg-white"):
                    # Input section
                    ui.label("Enter City Name").classes("text-lg font-semibold text-gray-700 mb-3")

                    with ui.row().classes("w-full gap-4 items-end"):
                        city_input = (
                            ui.input(placeholder="e.g., London, Paris, Tokyo...").classes("flex-1").props("outlined")
                        )

                        search_button = ui.button("Check Weather", icon="search").classes(
                            "bg-primary text-white px-6 py-3"
                        )

                    # Loading state
                    loading_container = ui.row().classes("w-full justify-center mt-6 hidden")
                    with loading_container:
                        ui.spinner(size="lg", color="primary")
                        ui.label("Fetching weather forecast...").classes("ml-4 text-gray-600")

                    # Results container
                    results_container = ui.column().classes("w-full mt-8")

                    async def search_weather():
                        """Search for weather and provide recommendation"""
                        city_name = city_input.value

                        if not city_name or not city_name.strip():
                            ui.notify("Please enter a city name", type="warning")
                            return

                        # Clear previous results and show loading
                        results_container.clear()
                        loading_container.classes(remove="hidden")
                        search_button.set_enabled(False)

                        try:
                            # Search for city coordinates
                            city_data = await WeatherService.search_city(city_name.strip())

                            if city_data is None:
                                show_error_result(
                                    "❓ City not found",
                                    f"Sorry, we couldn't find '{city_name}'. Please check the spelling and try again.",
                                )
                                return

                            # Get tomorrow's weather forecast
                            weather_data = await WeatherService.get_tomorrow_forecast(
                                city_data.latitude, city_data.longitude
                            )

                            if weather_data is None:
                                show_error_result(
                                    "🚫 Weather data unavailable",
                                    "Sorry, we couldn't fetch the weather forecast. Please try again later.",
                                )
                                return

                            # Generate recommendation
                            recommendation = TripRecommendationService.evaluate_trip_conditions(
                                temp_min=Decimal(str(weather_data["temperature_min"])),
                                temp_max=Decimal(str(weather_data["temperature_max"])),
                                precipitation=Decimal(str(weather_data["precipitation_total"])),
                                wind_speed=Decimal(str(weather_data["wind_speed_max"])),
                            )

                            # Show results
                            show_recommendation_result(city_data, weather_data, recommendation)

                        except Exception as e:
                            print(f"Unexpected error: {e}")
                            show_error_result(
                                "❌ Something went wrong", "An unexpected error occurred. Please try again."
                            )

                        finally:
                            # Hide loading and re-enable button
                            loading_container.classes(add="hidden")
                            search_button.set_enabled(True)

                    def show_recommendation_result(
                        city_data: GeocodingResult, weather_data: dict, recommendation: dict
                    ):
                        """Display the trip recommendation results"""
                        results_container.clear()

                        with results_container:
                            # City info header
                            with ui.row().classes("w-full items-center mb-4"):
                                ui.label(f"📍 {city_data.name}, {city_data.country}").classes(
                                    "text-xl font-semibold text-gray-800"
                                )
                                ui.label(
                                    f"Tomorrow • {(date.today() + timedelta(days=1)).strftime('%B %d, %Y')}"
                                ).classes("text-gray-500 ml-auto")

                            # Main recommendation card
                            recommendation_color = (
                                "bg-green-50 border-green-200"
                                if recommendation["is_good_idea"]
                                else "bg-orange-50 border-orange-200"
                            )

                            with ui.card().classes(f"w-full p-6 {recommendation_color} border-2 mb-6"):
                                ui.label(recommendation["message"]).classes("text-2xl font-bold text-center mb-4")

                                # Weather details grid
                                with ui.grid(columns=3).classes("w-full gap-4"):
                                    # Temperature
                                    temp_color = (
                                        "text-green-600" if recommendation["temperature_score"] else "text-red-600"
                                    )
                                    temp_icon = "✅" if recommendation["temperature_score"] else "❌"
                                    with ui.card().classes("p-4 text-center bg-white/70"):
                                        ui.label(f"{temp_icon} Temperature").classes(f"font-semibold {temp_color}")
                                        ui.label(
                                            f"{weather_data['temperature_min']}° - {weather_data['temperature_max']}°C"
                                        ).classes("text-lg font-bold text-gray-800 mt-1")
                                        ui.label("Ideal: 10-25°C").classes("text-xs text-gray-500 mt-1")

                                    # Precipitation
                                    precip_color = (
                                        "text-green-600" if recommendation["precipitation_score"] else "text-red-600"
                                    )
                                    precip_icon = "✅" if recommendation["precipitation_score"] else "❌"
                                    with ui.card().classes("p-4 text-center bg-white/70"):
                                        ui.label(f"{precip_icon} Precipitation").classes(
                                            f"font-semibold {precip_color}"
                                        )
                                        ui.label(f"{weather_data['precipitation_total']}mm").classes(
                                            "text-lg font-bold text-gray-800 mt-1"
                                        )
                                        ui.label("Ideal: < 1mm").classes("text-xs text-gray-500 mt-1")

                                    # Wind Speed
                                    wind_color = "text-green-600" if recommendation["wind_score"] else "text-red-600"
                                    wind_icon = "✅" if recommendation["wind_score"] else "❌"
                                    with ui.card().classes("p-4 text-center bg-white/70"):
                                        ui.label(f"{wind_icon} Wind Speed").classes(f"font-semibold {wind_color}")
                                        ui.label(f"{weather_data['wind_speed_max']}km/h").classes(
                                            "text-lg font-bold text-gray-800 mt-1"
                                        )
                                        ui.label("Ideal: < 20km/h").classes("text-xs text-gray-500 mt-1")

                            # Additional weather info
                            weather_desc = TripRecommendationService.get_weather_description(
                                weather_data["weather_code"]
                            )
                            with ui.card().classes("w-full p-4 bg-gray-50"):
                                ui.label("Additional Weather Information").classes("font-semibold text-gray-700 mb-2")
                                ui.label(f"Sky Conditions: {weather_desc}").classes("text-gray-600")

                            # Search again button
                            with ui.row().classes("w-full justify-center mt-6"):
                                ui.button(
                                    "Search Another City",
                                    icon="refresh",
                                    on_click=lambda: (city_input.set_value(""), results_container.clear()),
                                ).classes("bg-secondary text-white px-6 py-2").props("outline")

                    def show_error_result(title: str, message: str):
                        """Display error message to user"""
                        results_container.clear()

                        with results_container:
                            with ui.card().classes("w-full p-6 bg-red-50 border-2 border-red-200"):
                                ui.label(title).classes("text-xl font-bold text-red-800 mb-2")
                                ui.label(message).classes("text-red-700")

                                with ui.row().classes("w-full justify-center mt-4"):
                                    ui.button(
                                        "Try Again", icon="refresh", on_click=lambda: results_container.clear()
                                    ).classes("bg-red-500 text-white px-4 py-2")

                    # Set up event handlers
                    search_button.on_click(search_weather)
                    city_input.on("keydown.enter", search_weather)

            # Footer
            with ui.row().classes("w-full justify-center mt-12"):
                ui.label("Powered by Open-Meteo API").classes("text-sm text-gray-500")
