"""Currency conversion service using Frankfurter API."""

from decimal import Decimal
from typing import Optional
import httpx


class CurrencyService:
    """Service for currency conversion using Frankfurter API."""

    BASE_URL = "https://api.frankfurter.app"

    @classmethod
    async def get_currencies(cls) -> dict[str, str]:
        """Fetch available currencies from the API.

        Returns:
            Dictionary mapping currency codes to currency names.
        """
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{cls.BASE_URL}/currencies")
            response.raise_for_status()
            return response.json()

    @classmethod
    async def convert_currency(cls, amount: Decimal, from_currency: str, to_currency: str) -> Optional[Decimal]:
        """Convert amount from one currency to another.

        Args:
            amount: Amount to convert
            from_currency: Source currency code (e.g., 'USD')
            to_currency: Target currency code (e.g., 'EUR')

        Returns:
            Converted amount or None if conversion fails
        """
        if from_currency == to_currency:
            return amount

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{cls.BASE_URL}/latest", params={"amount": str(amount), "from": from_currency, "to": to_currency}
                )
                response.raise_for_status()
                data = response.json()

                if "rates" in data and to_currency in data["rates"]:
                    return Decimal(str(data["rates"][to_currency]))

                return None
        except (httpx.HTTPError, ValueError, KeyError):
            return None

    @classmethod
    async def get_exchange_rate(cls, from_currency: str, to_currency: str) -> Optional[Decimal]:
        """Get exchange rate between two currencies.

        Args:
            from_currency: Source currency code
            to_currency: Target currency code

        Returns:
            Exchange rate or None if not available
        """
        if from_currency == to_currency:
            return Decimal("1")

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(f"{cls.BASE_URL}/latest", params={"from": from_currency, "to": to_currency})
                response.raise_for_status()
                data = response.json()

                if "rates" in data and to_currency in data["rates"]:
                    return Decimal(str(data["rates"][to_currency]))

                return None
        except (httpx.HTTPError, ValueError, KeyError):
            return None
