"""Currency converter UI component."""

from decimal import Decimal, InvalidOperation
from typing import Optional
from nicegui import ui
from app.currency_service import CurrencyService


class CurrencyConverter:
    """Currency converter UI component."""

    def __init__(self):
        self.currencies: dict[str, str] = {}
        self.amount_input: Optional[ui.number] = None
        self.from_currency_select: Optional[ui.select] = None
        self.to_currency_select: Optional[ui.select] = None
        self.result_label: Optional[ui.label] = None
        self.rate_label: Optional[ui.label] = None
        self.loading_spinner: Optional[ui.spinner] = None
        self.convert_button: Optional[ui.button] = None

    async def load_currencies(self) -> None:
        """Load available currencies from the API."""
        try:
            self.currencies = await CurrencyService.get_currencies()
            if self.from_currency_select is not None and self.to_currency_select is not None:
                currency_options = list(self.currencies.keys())
                self.from_currency_select.set_options(currency_options)
                self.to_currency_select.set_options(currency_options)

                # Set default values
                if "USD" in currency_options:
                    self.from_currency_select.set_value("USD")
                if "EUR" in currency_options:
                    self.to_currency_select.set_value("EUR")

        except Exception as e:
            ui.notify(f"⚠️ Failed to load currencies: {str(e)}", type="negative")

    def _get_currency_display_name(self, code: str) -> str:
        """Get display name for currency code."""
        if code in self.currencies:
            return f"{code} - {self.currencies[code]}"
        return code

    async def convert_currency(self) -> None:
        """Perform currency conversion and update UI."""
        if not all(
            [
                self.amount_input,
                self.from_currency_select,
                self.to_currency_select,
                self.result_label,
                self.rate_label,
                self.loading_spinner,
            ]
        ):
            return

        # Validate inputs
        if self.amount_input is None or not self.amount_input.value:
            ui.notify("⚠️ Please enter an amount", type="warning")
            return

        if self.from_currency_select is None or not self.from_currency_select.value:
            ui.notify("⚠️ Please select source currency", type="warning")
            return

        if self.to_currency_select is None or not self.to_currency_select.value:
            ui.notify("⚠️ Please select target currency", type="warning")
            return

        try:
            amount = Decimal(str(self.amount_input.value))
            if amount <= 0:
                ui.notify("⚠️ Please enter a positive amount", type="warning")
                return
        except (InvalidOperation, ValueError):
            ui.notify("⚠️ Please enter a valid amount", type="warning")
            return

        # Show loading state
        if self.loading_spinner is not None:
            self.loading_spinner.set_visibility(True)
        if self.convert_button is not None:
            self.convert_button.disable()

        try:
            from_currency = str(self.from_currency_select.value)
            to_currency = str(self.to_currency_select.value)

            # Get conversion result and exchange rate
            converted_amount = await CurrencyService.convert_currency(amount, from_currency, to_currency)

            if converted_amount is not None and self.result_label is not None and self.rate_label is not None:
                # Update result display
                self.result_label.set_text(f"💸 {amount:,.2f} {from_currency} = {converted_amount:,.2f} {to_currency}")
                self.result_label.classes("text-2xl font-bold text-green-600 bg-green-50 p-4 rounded-lg")

                # Show exchange rate
                if amount != 0:
                    rate = converted_amount / amount
                    self.rate_label.set_text(f"📊 Exchange rate: 1 {from_currency} = {rate:.4f} {to_currency}")
                    self.rate_label.classes("text-sm text-gray-600 mt-2")
                    self.rate_label.set_visibility(True)

                ui.notify("✨ Conversion successful!", type="positive")
            else:
                ui.notify("❌ Conversion failed. Please try again.", type="negative")
                if self.result_label is not None:
                    self.result_label.set_text("")
                if self.rate_label is not None:
                    self.rate_label.set_visibility(False)

        except Exception as e:
            ui.notify(f"❌ Error during conversion: {str(e)}", type="negative")
            if self.result_label is not None:
                self.result_label.set_text("")
            if self.rate_label is not None:
                self.rate_label.set_visibility(False)
        finally:
            # Hide loading state
            if self.loading_spinner is not None:
                self.loading_spinner.set_visibility(False)
            if self.convert_button is not None:
                self.convert_button.enable()

    async def swap_currencies(self) -> None:
        """Swap source and target currencies."""
        if not all([self.from_currency_select, self.to_currency_select]):
            return

        if self.from_currency_select is None or self.to_currency_select is None:
            return

        from_value = self.from_currency_select.value
        to_value = self.to_currency_select.value

        if from_value and to_value:
            self.from_currency_select.set_value(to_value)
            self.to_currency_select.set_value(from_value)

            # Auto-convert if amount is entered
            if self.amount_input is not None and self.amount_input.value:
                await self.convert_currency()

    def create_ui(self) -> None:
        """Create the currency converter UI."""
        # Apply modern theme colors
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        # Main container
        with ui.column().classes("w-full max-w-2xl mx-auto p-6"):
            # Header
            ui.label("💰 Currency Converter 💱").classes("text-3xl font-bold text-center text-gray-800 mb-8")

            # Main conversion card
            with ui.card().classes("w-full p-8 shadow-xl rounded-2xl bg-white"):
                # Amount input
                ui.label("💵 Amount").classes("text-lg font-semibold text-gray-700 mb-2")
                self.amount_input = ui.number(placeholder="Enter amount to convert", min=0.01, step=0.01).classes(
                    "w-full mb-6 text-lg"
                )

                # Currency selection row
                with ui.row().classes("w-full gap-4 mb-6 items-end"):
                    # From currency
                    with ui.column().classes("flex-1"):
                        ui.label("📤 From Currency").classes("text-lg font-semibold text-gray-700 mb-2")
                        self.from_currency_select = ui.select(options=[], with_input=True, clearable=False).classes(
                            "w-full"
                        )

                    # Swap button
                    ui.button("🔀", on_click=self.swap_currencies).classes(
                        "bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-full w-12 h-12 text-xl"
                    ).props("round")

                    # To currency
                    with ui.column().classes("flex-1"):
                        ui.label("📥 To Currency").classes("text-lg font-semibold text-gray-700 mb-2")
                        self.to_currency_select = ui.select(options=[], with_input=True, clearable=False).classes(
                            "w-full"
                        )

                # Convert button with loading spinner
                with ui.row().classes("w-full justify-center items-center gap-4 mb-6"):
                    self.convert_button = ui.button("🔄 Convert Currency", on_click=self.convert_currency).classes(
                        "bg-primary text-white px-8 py-3 text-lg font-semibold rounded-lg hover:bg-blue-600 shadow-md"
                    )

                    self.loading_spinner = ui.spinner(size="lg").classes("text-primary")
                    self.loading_spinner.set_visibility(False)

                # Results area
                with ui.column().classes("w-full items-center"):
                    self.result_label = ui.label("").classes("text-center")
                    self.rate_label = ui.label("").classes("text-center")
                    self.rate_label.set_visibility(False)

            # Information card
            with ui.card().classes("w-full p-6 mt-6 bg-blue-50 border-l-4 border-blue-500"):
                ui.label("ℹ️ About This Tool").classes("text-lg font-semibold text-blue-800 mb-2")
                ui.label(
                    "🌍 Exchange rates are provided by Frankfurter API and updated daily. 📈 Rates are for informational purposes only."
                ).classes("text-blue-700")


def create():
    """Create the currency converter page."""

    @ui.page("/")
    async def currency_converter_page():
        converter = CurrencyConverter()
        converter.create_ui()
        await converter.load_currencies()
