from sqlmodel import SQLModel, Field, Relationship, JSON, Column
from datetime import datetime
from typing import Optional, List, Dict, Any
from decimal import Decimal

# Persistent models (stored in database)


class Currency(SQLModel, table=True):
    """Currency definitions with metadata."""

    __tablename__ = "currencies"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    code: str = Field(unique=True, max_length=3, description="ISO 4217 currency code (e.g., USD, EUR)")
    name: str = Field(max_length=100, description="Full currency name")
    symbol: str = Field(max_length=10, description="Currency symbol (e.g., $, €)")
    is_active: bool = Field(default=True, description="Whether currency is available for conversion")
    created_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    source_conversions: List["ConversionHistory"] = Relationship(
        back_populates="source_currency",
        sa_relationship_kwargs={"foreign_keys": "ConversionHistory.source_currency_id"},
    )
    target_conversions: List["ConversionHistory"] = Relationship(
        back_populates="target_currency",
        sa_relationship_kwargs={"foreign_keys": "ConversionHistory.target_currency_id"},
    )
    exchange_rates: List["ExchangeRate"] = Relationship(back_populates="currency")


class ExchangeRate(SQLModel, table=True):
    """Historical exchange rates from Frankfurter API."""

    __tablename__ = "exchange_rates"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    currency_id: int = Field(foreign_key="currencies.id")
    base_currency: str = Field(max_length=3, description="Base currency (usually EUR for Frankfurter)")
    rate: Decimal = Field(decimal_places=6, description="Exchange rate value")
    date: datetime = Field(description="Date of the exchange rate")
    created_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationship
    currency: Currency = Relationship(back_populates="exchange_rates")


class ConversionHistory(SQLModel, table=True):
    """History of currency conversions performed by users."""

    __tablename__ = "conversion_history"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    source_currency_id: int = Field(foreign_key="currencies.id")
    target_currency_id: int = Field(foreign_key="currencies.id")
    source_amount: Decimal = Field(decimal_places=2, description="Original amount to convert")
    target_amount: Decimal = Field(decimal_places=2, description="Converted amount")
    exchange_rate: Decimal = Field(decimal_places=6, description="Exchange rate used for conversion")
    conversion_date: datetime = Field(default_factory=datetime.utcnow)
    api_response: Dict[str, Any] = Field(default={}, sa_column=Column(JSON), description="Raw API response")

    # Relationships
    source_currency: Currency = Relationship(
        back_populates="source_conversions",
        sa_relationship_kwargs={"foreign_keys": "ConversionHistory.source_currency_id"},
    )
    target_currency: Currency = Relationship(
        back_populates="target_conversions",
        sa_relationship_kwargs={"foreign_keys": "ConversionHistory.target_currency_id"},
    )


# Non-persistent schemas (for validation, forms, API requests/responses)


class CurrencyBase(SQLModel, table=False):
    code: str = Field(max_length=3, description="ISO 4217 currency code")
    name: str = Field(max_length=100, description="Full currency name")
    symbol: str = Field(max_length=10, description="Currency symbol")


class CurrencyCreate(CurrencyBase):
    """Schema for creating new currencies."""

    is_active: bool = Field(default=True)


class CurrencyRead(CurrencyBase):
    """Schema for reading currency data."""

    id: int
    is_active: bool
    created_at: datetime


class ConversionRequest(SQLModel, table=False):
    """Schema for currency conversion requests."""

    source_currency_code: str = Field(max_length=3, description="Source currency code")
    target_currency_code: str = Field(max_length=3, description="Target currency code")
    amount: Decimal = Field(gt=0, decimal_places=2, description="Amount to convert")


class ConversionResponse(SQLModel, table=False):
    """Schema for currency conversion responses."""

    source_currency_code: str
    target_currency_code: str
    source_amount: Decimal
    target_amount: Decimal
    exchange_rate: Decimal
    conversion_date: datetime
    success: bool = Field(default=True)
    error_message: Optional[str] = Field(default=None)


class ExchangeRateCreate(SQLModel, table=False):
    """Schema for creating exchange rate records."""

    currency_code: str = Field(max_length=3)
    base_currency: str = Field(max_length=3)
    rate: Decimal = Field(decimal_places=6)
    date: datetime


class ExchangeRateRead(SQLModel, table=False):
    """Schema for reading exchange rate data."""

    id: int
    currency_code: str
    base_currency: str
    rate: Decimal
    date: datetime
    created_at: datetime


class ConversionHistoryRead(SQLModel, table=False):
    """Schema for reading conversion history."""

    id: int
    source_currency_code: str
    target_currency_code: str
    source_amount: Decimal
    target_amount: Decimal
    exchange_rate: Decimal
    conversion_date: datetime


class FrankfurterApiResponse(SQLModel, table=False):
    """Schema for Frankfurter API response structure."""

    amount: Decimal
    base: str
    date: str
    rates: Dict[str, Decimal]
