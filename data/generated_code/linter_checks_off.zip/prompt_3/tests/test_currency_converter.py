"""Tests for currency converter UI component."""

import pytest
from nicegui.testing import User
from nicegui import ui
from app.currency_converter import CurrencyConverter


class TestCurrencyConverter:
    """Test cases for CurrencyConverter UI component."""

    def test_currency_converter_initialization(self):
        """Test that CurrencyConverter initializes correctly."""
        converter = CurrencyConverter()

        assert converter.currencies == {}
        assert converter.amount_input is None
        assert converter.from_currency_select is None
        assert converter.to_currency_select is None
        assert converter.result_label is None
        assert converter.rate_label is None
        assert converter.loading_spinner is None
        assert converter.convert_button is None

    def test_get_currency_display_name(self):
        """Test currency display name formatting."""
        converter = CurrencyConverter()
        converter.currencies = {"USD": "US Dollar", "EUR": "Euro"}

        assert converter._get_currency_display_name("USD") == "USD - US Dollar"
        assert converter._get_currency_display_name("EUR") == "EUR - Euro"
        assert converter._get_currency_display_name("GBP") == "GBP"  # Not in currencies dict

    @pytest.mark.asyncio
    async def test_load_currencies_success(self):
        """Test that load_currencies fetches currencies successfully."""
        converter = CurrencyConverter()

        await converter.load_currencies()

        # Should have populated currencies
        assert len(converter.currencies) > 0
        assert "USD" in converter.currencies
        assert "EUR" in converter.currencies


async def test_currency_converter_page_loads(user: User) -> None:
    """Test that the currency converter page loads correctly."""
    await user.open("/")

    # Check that main elements are present
    await user.should_see("Currency Converter")
    await user.should_see("Amount")
    await user.should_see("From Currency")
    await user.should_see("To Currency")
    await user.should_see("Convert Currency")


async def test_currency_converter_basic_interaction(user: User) -> None:
    """Test basic currency converter interactions."""
    await user.open("/")

    # Wait for currencies to load
    import asyncio

    await asyncio.sleep(2)

    # Find amount input and enter value
    amount_inputs = list(user.find(ui.number).elements)
    if amount_inputs:
        amount_inputs[0].value = 100

    # Check that convert button is present
    convert_button = user.find("Convert Currency")
    assert len(convert_button.elements) > 0


async def test_currency_converter_validation_messages(user: User) -> None:
    """Test that validation messages appear correctly."""
    await user.open("/")

    # Wait for page to load
    import asyncio

    await asyncio.sleep(1)

    # Try to convert without entering amount
    user.find("Convert Currency").click()

    # Should show validation message (this will be in notifications)
    # Note: In a real test, we might check for specific notification text


async def test_currency_converter_swap_functionality(user: User) -> None:
    """Test currency swap functionality."""
    await user.open("/")

    # Wait for currencies to load
    import asyncio

    await asyncio.sleep(2)

    # Check that swap button exists
    swap_buttons = [elem for elem in user.find(ui.button).elements if "🔀" in getattr(elem, "text", "")]
    assert len(swap_buttons) > 0


async def test_currency_converter_results_display(user: User) -> None:
    """Test that conversion results are displayed properly."""
    await user.open("/")

    # Wait for currencies to load
    import asyncio

    await asyncio.sleep(2)

    # Enter amount
    amount_inputs = list(user.find(ui.number).elements)
    if amount_inputs:
        amount_inputs[0].value = 100

    # Click convert button
    user.find("Convert Currency").click()

    # Wait for conversion to complete
    await asyncio.sleep(3)

    # Check that some result is shown (exact content depends on API response)
    # We just verify the UI structure is there
    result_labels = list(user.find(ui.label).elements)
    assert len(result_labels) > 0


async def test_currency_converter_loading_state(user: User) -> None:
    """Test that loading spinner appears during conversion."""
    await user.open("/")

    # Wait for page to load
    import asyncio

    await asyncio.sleep(1)

    # The spinner should be present in the DOM, even if hidden
    # We just check that the page loads without errors for now
    await user.should_see("Convert Currency")


async def test_currency_converter_about_section(user: User) -> None:
    """Test that the about section is displayed."""
    await user.open("/")

    await user.should_see("About This Tool")
    await user.should_see("Exchange rates are provided by Frankfurter API")
