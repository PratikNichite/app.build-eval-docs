"""Tests for currency service."""

import pytest
from decimal import Decimal
from app.currency_service import CurrencyService


class TestCurrencyService:
    """Test cases for CurrencyService."""

    @pytest.mark.asyncio
    async def test_get_currencies_returns_valid_data(self):
        """Test that get_currencies returns valid currency data."""
        currencies = await CurrencyService.get_currencies()

        # Should return a dictionary
        assert isinstance(currencies, dict)

        # Should contain common currencies
        assert "USD" in currencies
        assert "EUR" in currencies
        assert "GBP" in currencies

        # Currency names should be strings
        for code, name in currencies.items():
            assert isinstance(code, str)
            assert isinstance(name, str)
            assert len(code) == 3  # Currency codes are 3 letters
            assert len(name) > 0  # Currency names should not be empty

    @pytest.mark.asyncio
    async def test_convert_currency_same_currency(self):
        """Test conversion between same currencies returns original amount."""
        amount = Decimal("100.00")
        result = await CurrencyService.convert_currency(amount, "USD", "USD")

        assert result == amount

    @pytest.mark.asyncio
    async def test_convert_currency_valid_conversion(self):
        """Test valid currency conversion with real API data."""
        amount = Decimal("100.00")
        result = await CurrencyService.convert_currency(amount, "USD", "EUR")

        # Should return a valid decimal
        assert result is not None
        assert isinstance(result, Decimal)
        assert result > 0

        # Result should be different from input (unless by coincidence rate is exactly 1)
        # This is a reasonable assumption for USD to EUR
        assert result != amount

    @pytest.mark.asyncio
    async def test_convert_currency_with_small_amount(self):
        """Test conversion with small decimal amounts."""
        amount = Decimal("0.01")
        result = await CurrencyService.convert_currency(amount, "USD", "EUR")

        assert result is not None
        assert isinstance(result, Decimal)
        assert result > 0

    @pytest.mark.asyncio
    async def test_convert_currency_with_large_amount(self):
        """Test conversion with large amounts."""
        amount = Decimal("1000000.00")
        result = await CurrencyService.convert_currency(amount, "USD", "EUR")

        assert result is not None
        assert isinstance(result, Decimal)
        assert result > 0

    @pytest.mark.asyncio
    async def test_get_exchange_rate_same_currency(self):
        """Test exchange rate for same currency is 1."""
        rate = await CurrencyService.get_exchange_rate("USD", "USD")

        assert rate == Decimal("1")

    @pytest.mark.asyncio
    async def test_get_exchange_rate_valid_currencies(self):
        """Test getting exchange rate between valid currencies."""
        rate = await CurrencyService.get_exchange_rate("USD", "EUR")

        assert rate is not None
        assert isinstance(rate, Decimal)
        assert rate > 0

        # Exchange rates should be reasonable (between 0.1 and 10 for major currencies)
        assert Decimal("0.1") <= rate <= Decimal("10")

    @pytest.mark.asyncio
    async def test_convert_currency_precision(self):
        """Test that conversion maintains proper decimal precision."""
        amount = Decimal("123.45")
        result = await CurrencyService.convert_currency(amount, "USD", "EUR")

        assert result is not None
        # Result should have reasonable precision (not more than 10 decimal places)
        assert len(str(result).split(".")[-1]) <= 10

    @pytest.mark.asyncio
    async def test_api_error_handling(self):
        """Test behavior with invalid currency codes."""
        # Using invalid currency codes should return None
        result = await CurrencyService.convert_currency(Decimal("100"), "INVALID", "ALSOINVALID")

        # Should handle error gracefully by returning None
        assert result is None

    @pytest.mark.asyncio
    async def test_reverse_conversion_consistency(self):
        """Test that converting back gives approximately original amount."""
        original_amount = Decimal("100.00")

        # Convert USD to EUR
        eur_amount = await CurrencyService.convert_currency(original_amount, "USD", "EUR")
        assert eur_amount is not None

        # Convert back EUR to USD
        usd_amount = await CurrencyService.convert_currency(eur_amount, "EUR", "USD")
        assert usd_amount is not None

        # Should be approximately equal (within 1% due to rounding and rate precision)
        difference = abs(original_amount - usd_amount)
        tolerance = original_amount * Decimal("0.01")  # 1% tolerance
        assert difference <= tolerance

    @pytest.mark.asyncio
    async def test_multiple_currencies_available(self):
        """Test that multiple currencies are available."""
        currencies = await CurrencyService.get_currencies()

        # Should have a reasonable number of currencies (at least 30)
        assert len(currencies) >= 30

        # Should include major world currencies
        major_currencies = ["USD", "EUR", "GBP", "JPY", "CAD", "AUD", "CHF"]
        for currency in major_currencies:
            assert currency in currencies
