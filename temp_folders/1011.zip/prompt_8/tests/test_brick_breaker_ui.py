import pytest
from nicegui.testing import User
from nicegui import ui
from app.database import reset_db


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


async def test_brick_breaker_main_page_loads(user: User, new_db) -> None:
    """Test that the main page loads correctly"""
    await user.open("/")

    # Check main page elements
    await user.should_see("🧱 BRICK BREAKER 🧱")
    await user.should_see("Classic arcade game built with NiceGUI")
    await user.should_see("PLAY NOW")
    await user.should_see("🏆 LEADERBOARD")


async def test_brick_breaker_game_page_loads(user: User, new_db) -> None:
    """Test that the game page loads correctly"""
    await user.open("/brick_breaker")

    # Check game page elements
    await user.should_see("🧱 BRICK BREAKER 🧱")
    await user.should_see("Use ← → arrow keys to move the paddle")
    await user.should_see("Player Name:")
    await user.should_see("Start Game")
    await user.should_see("Pause/Resume")
    await user.should_see("Reset")
    await user.should_see("Score: 0")
    await user.should_see("Lives: 3")
    await user.should_see("Ready to Play")
    await user.should_see("Game Instructions:")


async def test_start_game_without_name(user: User, new_db) -> None:
    """Test starting game without entering player name"""
    await user.open("/brick_breaker")

    # Try to start game without name
    user.find("Start Game").click()

    # Should show warning message
    await user.should_see("Please enter your name first!")


async def test_start_game_with_name(user: User, new_db) -> None:
    """Test starting game with player name"""
    await user.open("/brick_breaker")

    # Enter player name
    player_input = user.find(ui.input)
    player_input.type("TestPlayer")

    # Start game
    user.find("Start Game").click()

    # Should show success message and game should start
    await user.should_see("Game started! Good luck!")
    await user.should_see("Status: Playing")


async def test_game_ui_elements_present(user: User, new_db) -> None:
    """Test that all game UI elements are present"""
    await user.open("/brick_breaker")

    # Check input field
    inputs = list(user.find(ui.input).elements)
    assert len(inputs) >= 1

    # Check buttons
    buttons = list(user.find(ui.button).elements)
    button_texts = [btn.text for btn in buttons]
    assert "Start Game" in button_texts
    assert "Pause/Resume" in button_texts
    assert "Reset" in button_texts

    # Check canvas
    canvas_elements = list(user.find(ui.interactive_image).elements)
    assert len(canvas_elements) == 1

    # Check labels
    labels = list(user.find(ui.label).elements)
    label_texts = [label.text for label in labels]

    # Should have score, lives, and status labels
    score_labels = [text for text in label_texts if "Score:" in text]
    lives_labels = [text for text in label_texts if "Lives:" in text]
    status_labels = [text for text in label_texts if "Status:" in text or "Ready to Play" in text]

    assert len(score_labels) >= 1
    assert len(lives_labels) >= 1
    assert len(status_labels) >= 1


async def test_reset_game_functionality(user: User, new_db) -> None:
    """Test reset game functionality"""
    await user.open("/brick_breaker")

    # Start a game first
    player_input = user.find(ui.input)
    player_input.type("TestPlayer")
    user.find("Start Game").click()

    await user.should_see("Game started! Good luck!")

    # Reset game
    user.find("Reset").click()

    # Should show reset message
    await user.should_see("Game reset")
    await user.should_see("Ready to Play")


async def test_navigation_from_main_to_game(user: User, new_db) -> None:
    """Test navigation from main page to game page"""
    await user.open("/")

    # Click play now link
    play_link = user.find(ui.link)
    play_link.click()

    # Should navigate to game page
    await user.should_see("Use ← → arrow keys to move the paddle")
    await user.should_see("Start Game")


async def test_game_instructions_visible(user: User, new_db) -> None:
    """Test that game instructions are visible"""
    await user.open("/brick_breaker")

    # Check instructions
    await user.should_see("Game Instructions:")
    await user.should_see("Use LEFT and RIGHT arrow keys to move the paddle")
    await user.should_see("Bounce the ball to destroy all bricks")
    await user.should_see("Different colored bricks have different point values")
    await user.should_see("Don't let the ball fall off the bottom!")


async def test_leaderboard_display_empty(user: User, new_db) -> None:
    """Test leaderboard display when empty"""
    await user.open("/")

    # Should show empty leaderboard message
    await user.should_see("No high scores yet. Be the first!")


async def test_pause_without_active_game(user: User, new_db) -> None:
    """Test pausing without an active game"""
    await user.open("/brick_breaker")

    # Try to pause without starting game
    user.find("Pause/Resume").click()

    # Should show warning
    await user.should_see("No active game to pause!")


async def test_game_styling_classes(user: User, new_db) -> None:
    """Test that proper CSS classes are applied"""
    await user.open("/brick_breaker")

    # Check for presence of styled elements (basic smoke test)
    # The actual styling is handled by CSS, we just verify elements exist

    # Game container should be present
    containers = user.find(ui.column).elements
    assert len(list(containers)) > 0

    # Cards should be present
    cards = user.find(ui.card).elements
    assert len(list(cards)) > 0

    # Rows should be present
    rows = user.find(ui.row).elements
    assert len(list(rows)) > 0


async def test_canvas_initialization(user: User, new_db) -> None:
    """Test that the game canvas is properly initialized"""
    await user.open("/brick_breaker")

    # Check canvas element exists
    canvas_elements = list(user.find(ui.interactive_image).elements)
    assert len(canvas_elements) == 1

    canvas = canvas_elements[0]
    # Canvas should have appropriate size (this is set in the game code)
    # We can't easily test the exact dimensions without diving into internal properties
    # but we can verify the element exists and is configured
    assert canvas is not None
