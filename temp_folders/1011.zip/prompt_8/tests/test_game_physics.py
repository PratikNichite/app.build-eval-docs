from decimal import Decimal
from app.game_physics import GamePhysics, Ball, Paddle, Brick, Rectangle


class TestRectangle:
    """Test suite for Rectangle class"""

    def test_contains_point_inside(self):
        """Test point inside rectangle"""
        rect = Rectangle(Decimal("10"), Decimal("20"), Decimal("30"), Decimal("40"))
        assert rect.contains_point(Decimal("25"), Decimal("35"))

    def test_contains_point_outside(self):
        """Test point outside rectangle"""
        rect = Rectangle(Decimal("10"), Decimal("20"), Decimal("30"), Decimal("40"))
        assert not rect.contains_point(Decimal("5"), Decimal("35"))
        assert not rect.contains_point(Decimal("45"), Decimal("35"))
        assert not rect.contains_point(Decimal("25"), Decimal("15"))
        assert not rect.contains_point(Decimal("25"), Decimal("65"))

    def test_contains_point_on_edge(self):
        """Test point on rectangle edge"""
        rect = Rectangle(Decimal("10"), Decimal("20"), Decimal("30"), Decimal("40"))
        assert rect.contains_point(Decimal("10"), Decimal("30"))  # Left edge
        assert rect.contains_point(Decimal("40"), Decimal("30"))  # Right edge
        assert rect.contains_point(Decimal("25"), Decimal("20"))  # Top edge
        assert rect.contains_point(Decimal("25"), Decimal("60"))  # Bottom edge

    def test_intersects_circle_overlapping(self):
        """Test circle intersecting rectangle"""
        rect = Rectangle(Decimal("10"), Decimal("10"), Decimal("20"), Decimal("20"))
        # Circle center at (15, 15) with radius 5 should intersect
        assert rect.intersects_circle(Decimal("15"), Decimal("15"), Decimal("5"))

    def test_intersects_circle_not_overlapping(self):
        """Test circle not intersecting rectangle"""
        rect = Rectangle(Decimal("10"), Decimal("10"), Decimal("20"), Decimal("20"))
        # Circle center at (50, 50) with radius 5 should not intersect
        assert not rect.intersects_circle(Decimal("50"), Decimal("50"), Decimal("5"))

    def test_intersects_circle_touching(self):
        """Test circle just touching rectangle"""
        rect = Rectangle(Decimal("10"), Decimal("10"), Decimal("20"), Decimal("20"))
        # Circle center at (35, 20) with radius 5 should just touch right edge
        assert rect.intersects_circle(Decimal("35"), Decimal("20"), Decimal("5"))


class TestBall:
    """Test suite for Ball class"""

    def test_ball_creation(self):
        """Test ball creation with proper attributes"""
        ball = Ball(x=Decimal("100"), y=Decimal("200"), vx=Decimal("5"), vy=Decimal("-3"), radius=Decimal("8"))

        assert ball.x == Decimal("100")
        assert ball.y == Decimal("200")
        assert ball.vx == Decimal("5")
        assert ball.vy == Decimal("-3")
        assert ball.radius == Decimal("8")

    def test_update_position(self):
        """Test ball position update"""
        ball = Ball(x=Decimal("100"), y=Decimal("200"), vx=Decimal("5"), vy=Decimal("-3"), radius=Decimal("8"))

        ball.update_position()

        assert ball.x == Decimal("105")
        assert ball.y == Decimal("197")

    def test_update_position_with_dt(self):
        """Test ball position update with custom time delta"""
        ball = Ball(x=Decimal("100"), y=Decimal("200"), vx=Decimal("5"), vy=Decimal("-3"), radius=Decimal("8"))

        ball.update_position(Decimal("2"))

        assert ball.x == Decimal("110")
        assert ball.y == Decimal("194")

    def test_get_bounds(self):
        """Test ball bounding rectangle"""
        ball = Ball(x=Decimal("100"), y=Decimal("200"), vx=Decimal("5"), vy=Decimal("-3"), radius=Decimal("8"))

        bounds = ball.get_bounds()

        assert bounds.x == Decimal("92")  # 100 - 8
        assert bounds.y == Decimal("192")  # 200 - 8
        assert bounds.width == Decimal("16")  # 8 * 2
        assert bounds.height == Decimal("16")  # 8 * 2


class TestPaddle:
    """Test suite for Paddle class"""

    def test_paddle_creation(self):
        """Test paddle creation"""
        paddle = Paddle(x=Decimal("300"), y=Decimal("550"), width=Decimal("80"), height=Decimal("15"))

        assert paddle.x == Decimal("300")
        assert paddle.y == Decimal("550")
        assert paddle.width == Decimal("80")
        assert paddle.height == Decimal("15")

    def test_get_bounds(self):
        """Test paddle bounding rectangle"""
        paddle = Paddle(x=Decimal("300"), y=Decimal("550"), width=Decimal("80"), height=Decimal("15"))

        bounds = paddle.get_bounds()

        assert bounds.x == Decimal("300")
        assert bounds.y == Decimal("550")
        assert bounds.width == Decimal("80")
        assert bounds.height == Decimal("15")

    def test_get_center_x(self):
        """Test paddle center X calculation"""
        paddle = Paddle(x=Decimal("300"), y=Decimal("550"), width=Decimal("80"), height=Decimal("15"))

        center_x = paddle.get_center_x()
        assert center_x == Decimal("340")  # 300 + 80/2


class TestGamePhysics:
    """Test suite for GamePhysics class"""

    def test_physics_creation(self):
        """Test physics engine creation"""
        physics = GamePhysics(800, 600)

        assert physics.play_area_width == Decimal("800")
        assert physics.play_area_height == Decimal("600")
        assert physics.wall_bounce_factor == Decimal("1.0")
        assert physics.paddle_bounce_factor == Decimal("0.8")

    def test_update_ball_no_collision(self):
        """Test ball update with no collisions"""
        physics = GamePhysics(800, 600)
        ball = Ball(x=Decimal("400"), y=Decimal("300"), vx=Decimal("5"), vy=Decimal("-3"), radius=Decimal("8"))

        updated_ball, events = physics.update_ball(ball)

        assert updated_ball.x == Decimal("405")
        assert updated_ball.y == Decimal("297")
        assert len(events) == 0

    def test_update_ball_left_wall_collision(self):
        """Test ball collision with left wall"""
        physics = GamePhysics(800, 600)
        ball = Ball(x=Decimal("5"), y=Decimal("300"), vx=Decimal("-10"), vy=Decimal("0"), radius=Decimal("8"))

        updated_ball, events = physics.update_ball(ball)

        assert updated_ball.x == Decimal("8")  # Ball radius
        assert updated_ball.vx > 0  # Velocity reversed
        assert "wall_left" in events

    def test_update_ball_right_wall_collision(self):
        """Test ball collision with right wall"""
        physics = GamePhysics(800, 600)
        ball = Ball(x=Decimal("795"), y=Decimal("300"), vx=Decimal("10"), vy=Decimal("0"), radius=Decimal("8"))

        updated_ball, events = physics.update_ball(ball)

        assert updated_ball.x == Decimal("792")  # 800 - 8
        assert updated_ball.vx < 0  # Velocity reversed
        assert "wall_right" in events

    def test_update_ball_top_wall_collision(self):
        """Test ball collision with top wall"""
        physics = GamePhysics(800, 600)
        ball = Ball(x=Decimal("400"), y=Decimal("5"), vx=Decimal("0"), vy=Decimal("-10"), radius=Decimal("8"))

        updated_ball, events = physics.update_ball(ball)

        assert updated_ball.y == Decimal("8")  # Ball radius
        assert updated_ball.vy > 0  # Velocity reversed
        assert "wall_top" in events

    def test_update_ball_bottom_collision(self):
        """Test ball going off bottom (lose life)"""
        physics = GamePhysics(800, 600)
        ball = Ball(x=Decimal("400"), y=Decimal("595"), vx=Decimal("0"), vy=Decimal("10"), radius=Decimal("8"))

        updated_ball, events = physics.update_ball(ball)

        assert "ball_lost" in events

    def test_check_paddle_collision_no_hit(self):
        """Test paddle collision detection - no collision"""
        physics = GamePhysics(800, 600)
        ball = Ball(x=Decimal("100"), y=Decimal("100"), vx=Decimal("5"), vy=Decimal("3"), radius=Decimal("8"))
        paddle = Paddle(x=Decimal("300"), y=Decimal("550"), width=Decimal("80"), height=Decimal("15"))

        hit, updated_ball = physics.check_paddle_collision(ball, paddle)

        assert not hit
        assert updated_ball is None

    def test_check_paddle_collision_hit_center(self):
        """Test paddle collision - ball hits center of paddle"""
        physics = GamePhysics(800, 600)
        ball = Ball(
            x=Decimal("340"),  # Center of 80-wide paddle at x=300
            y=Decimal("545"),  # Just above paddle at y=550
            vx=Decimal("0"),
            vy=Decimal("5"),
            radius=Decimal("8"),
        )
        paddle = Paddle(x=Decimal("300"), y=Decimal("550"), width=Decimal("80"), height=Decimal("15"))

        hit, updated_ball = physics.check_paddle_collision(ball, paddle)

        assert hit
        assert updated_ball is not None
        assert updated_ball.vy < 0  # Ball should bounce up

    def test_check_paddle_collision_hit_edge(self):
        """Test paddle collision - ball hits edge of paddle"""
        physics = GamePhysics(800, 600)
        ball = Ball(
            x=Decimal("310"),  # Near left edge of paddle
            y=Decimal("545"),
            vx=Decimal("0"),
            vy=Decimal("5"),
            radius=Decimal("8"),
        )
        paddle = Paddle(x=Decimal("300"), y=Decimal("550"), width=Decimal("80"), height=Decimal("15"))

        hit, updated_ball = physics.check_paddle_collision(ball, paddle)

        assert hit
        assert updated_ball is not None
        assert updated_ball.vy < 0  # Ball should bounce up
        assert updated_ball.vx < 0  # Ball should angle left

    def test_check_brick_collisions_no_hit(self):
        """Test brick collision detection - no collisions"""
        physics = GamePhysics(800, 600)
        ball = Ball(x=Decimal("100"), y=Decimal("100"), vx=Decimal("5"), vy=Decimal("3"), radius=Decimal("8"))
        brick = Brick(
            x=Decimal("200"), y=Decimal("200"), width=Decimal("75"), height=Decimal("20"), id=1, hits_remaining=1
        )

        updated_ball, hit_bricks = physics.check_brick_collisions(ball, [brick])

        assert len(hit_bricks) == 0

    def test_check_brick_collisions_hit(self):
        """Test brick collision detection - hit brick"""
        physics = GamePhysics(800, 600)
        ball = Ball(
            x=Decimal("195"),  # Ball center closer to brick
            y=Decimal("210"),
            vx=Decimal("5"),
            vy=Decimal("0"),
            radius=Decimal("8"),
        )
        brick = Brick(
            x=Decimal("200"), y=Decimal("200"), width=Decimal("75"), height=Decimal("20"), id=1, hits_remaining=1
        )

        # Check if ball would intersect brick
        brick_rect = brick.get_bounds()
        ball_intersects = brick_rect.intersects_circle(ball.x, ball.y, ball.radius)

        if ball_intersects:
            updated_ball, hit_bricks = physics.check_brick_collisions(ball, [brick])
            assert len(hit_bricks) == 1
            assert hit_bricks[0] == 1
        else:
            # Adjust ball position to definitely intersect
            ball.x = Decimal("205")  # Right in the middle of brick
            updated_ball, hit_bricks = physics.check_brick_collisions(ball, [brick])
            assert len(hit_bricks) == 1
            assert hit_bricks[0] == 1

    def test_normalize_velocity(self):
        """Test velocity normalization"""
        physics = GamePhysics(800, 600)
        ball = Ball(x=Decimal("400"), y=Decimal("300"), vx=Decimal("10"), vy=Decimal("0"), radius=Decimal("8"))

        normalized_ball = physics.normalize_velocity(ball, Decimal("5"))

        # Ball should have speed of 5
        speed = (normalized_ball.vx**2 + normalized_ball.vy**2) ** Decimal("0.5")
        assert abs(speed - Decimal("5")) < Decimal("0.1")

    def test_normalize_velocity_zero_speed(self):
        """Test velocity normalization with zero speed"""
        physics = GamePhysics(800, 600)
        ball = Ball(x=Decimal("400"), y=Decimal("300"), vx=Decimal("0"), vy=Decimal("0"), radius=Decimal("8"))

        normalized_ball = physics.normalize_velocity(ball, Decimal("5"))

        # Ball should still have zero velocity
        assert normalized_ball.vx == Decimal("0")
        assert normalized_ball.vy == Decimal("0")

    def test_calculate_brick_position(self):
        """Test brick position calculation"""
        physics = GamePhysics(800, 600)

        # Test brick at row 0, col 0
        x, y = physics.calculate_brick_position(0, 0, 75, 20, 5)
        assert x == Decimal("5")  # spacing
        assert y == Decimal("55")  # spacing + 50 (offset from top)

        # Test brick at row 1, col 2
        x, y = physics.calculate_brick_position(1, 2, 75, 20, 5)
        expected_x = Decimal("165")  # 2 * (75 + 5) + 5
        expected_y = Decimal("80")  # 1 * (20 + 5) + 5 + 50
        assert x == expected_x
        assert y == expected_y
