import pytest
from decimal import Decimal
from app.database import reset_db
from app.game_service import GameService
from app.models import GameStatus, BrickType


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


class TestGameService:
    """Test suite for GameService"""

    def test_get_or_create_player_new(self, new_db):
        """Test creating a new player"""
        player = GameService.get_or_create_player("TestPlayer", "test@example.com")

        assert player.name == "TestPlayer"
        assert player.email == "test@example.com"
        assert player.total_score == 0
        assert player.games_played == 0
        assert player.highest_level == 1
        assert player.id is not None

    def test_get_or_create_player_existing(self, new_db):
        """Test retrieving existing player"""
        # Create first player
        player1 = GameService.get_or_create_player("TestPlayer", "test@example.com")
        player1_id = player1.id

        # Try to create same player again
        player2 = GameService.get_or_create_player("TestPlayer", "test@example.com")

        assert player2.id == player1_id
        assert player2.name == "TestPlayer"
        assert player2.email == "test@example.com"

    def test_get_or_create_default_level(self, new_db):
        """Test creating default level"""
        level = GameService.get_or_create_default_level()

        assert level.level_number == 1
        assert level.name == "Level 1"
        assert level.rows == 5
        assert level.cols == 10
        assert len(level.brick_layout) == 5
        assert all(len(row) == 10 for row in level.brick_layout)
        assert level.ball_speed == Decimal("5.0")
        assert level.paddle_speed == Decimal("8.0")
        assert level.lives == 3
        assert level.bonus_points == 1000

    def test_create_game_session(self, new_db):
        """Test creating a new game session"""
        player = GameService.get_or_create_player("TestPlayer")
        level = GameService.get_or_create_default_level()

        session = GameService.create_game_session(player.id, level.id)

        assert session.player_id == player.id
        assert session.level_id == level.id
        assert session.score == 0
        assert session.lives_remaining == 3
        assert session.current_level == 1
        assert session.status == GameStatus.ACTIVE
        assert session.ball_position_x == Decimal("400")
        assert session.ball_position_y == Decimal("300")
        assert session.ball_velocity_x == Decimal("5")
        assert session.ball_velocity_y == Decimal("-5")
        assert session.paddle_position_x == Decimal("360")
        assert session.paddle_width == Decimal("80")
        assert session.active_powerups == []
        assert session.powerup_timers == {}

    def test_create_bricks_for_session(self, new_db):
        """Test creating bricks for a game session"""
        player = GameService.get_or_create_player("TestPlayer")
        level = GameService.get_or_create_default_level()
        session = GameService.create_game_session(player.id, level.id)

        bricks = GameService.get_active_bricks(session.id)

        # Should create 5 rows × 10 columns = 50 bricks
        assert len(bricks) == 50

        # Check first brick properties
        first_brick = bricks[0]
        assert first_brick.game_session_id == session.id
        assert first_brick.row == 0
        assert first_brick.col == 0
        assert first_brick.brick_type == BrickType.NORMAL
        assert first_brick.hits_remaining == 1
        assert first_brick.points_value == 10
        assert first_brick.color.startswith("#")
        assert not first_brick.is_destroyed

    def test_update_game_session(self, new_db):
        """Test updating game session state"""
        player = GameService.get_or_create_player("TestPlayer")
        level = GameService.get_or_create_default_level()
        session = GameService.create_game_session(player.id, level.id)

        updated_session = GameService.update_game_session(
            session.id,
            ball_x=Decimal("100"),
            ball_y=Decimal("200"),
            ball_vx=Decimal("3"),
            ball_vy=Decimal("-4"),
            paddle_x=Decimal("150"),
            score=500,
            lives=2,
            status=GameStatus.PAUSED,
        )

        assert updated_session is not None
        assert updated_session.ball_position_x == Decimal("100")
        assert updated_session.ball_position_y == Decimal("200")
        assert updated_session.ball_velocity_x == Decimal("3")
        assert updated_session.ball_velocity_y == Decimal("-4")
        assert updated_session.paddle_position_x == Decimal("150")
        assert updated_session.score == 500
        assert updated_session.lives_remaining == 2
        assert updated_session.status == GameStatus.PAUSED

    def test_update_nonexistent_session(self, new_db):
        """Test updating nonexistent game session"""
        result = GameService.update_game_session(999, score=100)
        assert result is None

    def test_hit_brick_normal(self, new_db):
        """Test hitting a normal brick"""
        player = GameService.get_or_create_player("TestPlayer")
        level = GameService.get_or_create_default_level()
        session = GameService.create_game_session(player.id, level.id)

        bricks = GameService.get_active_bricks(session.id)
        brick = bricks[0]

        destroyed, points = GameService.hit_brick(brick.id)

        assert destroyed
        assert points == 10

        # Verify brick is marked as destroyed
        bricks_after = GameService.get_active_bricks(session.id)
        assert len(bricks_after) == 49  # One less active brick

    def test_hit_brick_nonexistent(self, new_db):
        """Test hitting nonexistent brick"""
        destroyed, points = GameService.hit_brick(999)

        assert not destroyed
        assert points == 0

    def test_is_level_complete_false(self, new_db):
        """Test level completion check with remaining bricks"""
        player = GameService.get_or_create_player("TestPlayer")
        level = GameService.get_or_create_default_level()
        session = GameService.create_game_session(player.id, level.id)

        assert not GameService.is_level_complete(session.id)

    def test_is_level_complete_true(self, new_db):
        """Test level completion check with all bricks destroyed"""
        player = GameService.get_or_create_player("TestPlayer")
        level = GameService.get_or_create_default_level()
        session = GameService.create_game_session(player.id, level.id)

        # Destroy all bricks
        bricks = GameService.get_active_bricks(session.id)
        for brick in bricks:
            GameService.hit_brick(brick.id)

        assert GameService.is_level_complete(session.id)

    def test_save_high_score(self, new_db):
        """Test saving a high score"""
        player = GameService.get_or_create_player("TestPlayer")

        high_score = GameService.save_high_score(
            player.id, score=5000, level_reached=3, total_time_seconds=300, bricks_destroyed=150
        )

        assert high_score.player_id == player.id
        assert high_score.score == 5000
        assert high_score.level_reached == 3
        assert high_score.total_time_seconds == 300
        assert high_score.bricks_destroyed == 150
        assert high_score.id is not None

    def test_get_leaderboard_empty(self, new_db):
        """Test getting leaderboard with no scores"""
        leaderboard = GameService.get_leaderboard()
        assert leaderboard == []

    def test_get_leaderboard_with_scores(self, new_db):
        """Test getting leaderboard with scores"""
        # Create players and high scores
        player1 = GameService.get_or_create_player("Player1")
        player2 = GameService.get_or_create_player("Player2")

        GameService.save_high_score(player1.id, 1000, 1, 120, 30)
        GameService.save_high_score(player2.id, 2000, 2, 240, 60)
        GameService.save_high_score(player1.id, 1500, 1, 180, 45)

        leaderboard = GameService.get_leaderboard()

        assert len(leaderboard) == 3

        # Should be ordered by score descending
        assert leaderboard[0]["score"] == 2000
        assert leaderboard[0]["player_name"] == "Player2"
        assert leaderboard[0]["rank"] == 1

        assert leaderboard[1]["score"] == 1500
        assert leaderboard[1]["player_name"] == "Player1"
        assert leaderboard[1]["rank"] == 2

        assert leaderboard[2]["score"] == 1000
        assert leaderboard[2]["player_name"] == "Player1"
        assert leaderboard[2]["rank"] == 3

    def test_get_leaderboard_limit(self, new_db):
        """Test getting leaderboard with limit"""
        player = GameService.get_or_create_player("TestPlayer")

        # Create multiple high scores
        for i in range(15):
            GameService.save_high_score(player.id, i * 100, 1, 60, 10)

        leaderboard = GameService.get_leaderboard(5)
        assert len(leaderboard) == 5

        # Should get top 5 scores
        assert leaderboard[0]["score"] == 1400  # Highest score
        assert leaderboard[-1]["score"] == 1000  # 5th highest

    def test_get_game_config(self, new_db):
        """Test getting game configuration"""
        config = GameService.get_game_config()

        assert config.config_name == "default"
        assert config.play_area_width == 800
        assert config.play_area_height == 600
        assert config.paddle_height == 15
        assert config.ball_radius == 8
        assert config.brick_width == 75
        assert config.brick_height == 20
        assert config.brick_spacing == 5
        assert "ball_speed_multiplier" in config.physics_settings
        assert "paddle_bounce_factor" in config.physics_settings
        assert "wall_bounce_factor" in config.physics_settings
