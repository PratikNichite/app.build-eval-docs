from nicegui import ui, events
from typing import Optional, List
from decimal import Decimal
from datetime import datetime

from app.game_service import GameService
from app.game_physics import GamePhysics, Ball, Paddle, Brick as PhysicsBrick
from app.models import GameSession, GameStatus


class BrickBreakerGame:
    """Main Brick Breaker game component"""

    def __init__(self):
        self.game_service = GameService()
        self.physics: Optional[GamePhysics] = None
        self.game_session: Optional[GameSession] = None
        self.player_name: str = ""

        # Game state
        self.ball: Optional[Ball] = None
        self.paddle: Optional[Paddle] = None
        self.bricks: List[PhysicsBrick] = []
        self.game_running = False
        self.keys_pressed = set()

        # UI elements
        self.canvas: Optional[ui.interactive_image] = None
        self.score_label: Optional[ui.label] = None
        self.lives_label: Optional[ui.label] = None
        self.status_label: Optional[ui.label] = None

        # Game configuration
        self.config = self.game_service.get_game_config()
        self.width = self.config.play_area_width
        self.height = self.config.play_area_height
        self.ball_radius = self.config.ball_radius
        self.paddle_width = 80
        self.paddle_height = self.config.paddle_height
        self.brick_width = self.config.brick_width
        self.brick_height = self.config.brick_height
        self.brick_spacing = self.config.brick_spacing

        # Initialize physics
        self.physics = GamePhysics(self.width, self.height)

        # Game loop timer
        self.game_timer: Optional[ui.timer] = None

    def create_ui(self) -> None:
        """Create the game UI"""
        ui.add_head_html("""
        <style>
        .game-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .game-header {
            color: white;
            text-align: center;
            margin-bottom: 20px;
        }
        .game-controls {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            backdrop-filter: blur(10px);
        }
        .game-canvas {
            border: 3px solid #ffffff;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        .game-stats {
            display: flex;
            gap: 20px;
            margin-top: 15px;
            color: white;
            font-size: 18px;
            font-weight: bold;
        }
        </style>
        """)

        with ui.column().classes("game-container w-full"):
            # Header
            with ui.column().classes("game-header"):
                ui.label("🧱 BRICK BREAKER 🧱").classes("text-4xl font-bold mb-2")
                ui.label("Use ← → arrow keys to move the paddle").classes("text-lg opacity-80")

            # Player input and controls
            with ui.card().classes("game-controls"):
                with ui.row().classes("gap-4 items-center"):
                    ui.label("Player Name:").classes("text-white font-semibold")
                    ui.input(placeholder="Enter your name").classes("w-48").bind_value(self, "player_name")

                    ui.button("Start Game", on_click=self.start_game).classes(
                        "bg-green-500 text-white px-6 py-2 font-bold"
                    )

                    ui.button("Pause/Resume", on_click=self.toggle_pause).classes("bg-yellow-500 text-white px-4 py-2")

                    ui.button("Reset", on_click=self.reset_game).classes("bg-red-500 text-white px-4 py-2")

            # Game canvas
            self.canvas = (
                ui.interactive_image()
                .classes("game-canvas")
                .style(f"width: {self.width}px; height: {self.height}px; background-color: #001122;")
            )

            # Game statistics
            with ui.row().classes("game-stats"):
                self.score_label = ui.label("Score: 0")
                self.lives_label = ui.label("Lives: 3")
                self.status_label = ui.label("Ready to Play")

            # Instructions
            with ui.card().classes("mt-4 p-4 bg-white bg-opacity-10"):
                ui.label("Game Instructions:").classes("text-white font-bold mb-2")
                with ui.column().classes("text-white text-sm gap-1"):
                    ui.label("• Use LEFT and RIGHT arrow keys to move the paddle")
                    ui.label("• Bounce the ball to destroy all bricks")
                    ui.label("• Different colored bricks have different point values")
                    ui.label("• Don't let the ball fall off the bottom!")

        # Set up keyboard event handlers
        self.setup_keyboard_handlers()

    def setup_keyboard_handlers(self) -> None:
        """Set up keyboard event handling"""
        ui.keyboard(on_key=self.handle_key_event, active=True)

    def handle_key_event(self, event: events.KeyEventArguments) -> None:
        """Handle keyboard events"""
        if event.action.keydown:
            self.keys_pressed.add(event.key)
        elif event.action.keyup:
            self.keys_pressed.discard(event.key)

    async def start_game(self) -> None:
        """Start a new game"""
        if not self.player_name.strip():
            ui.notify("Please enter your name first!", type="warning")
            return

        try:
            # Get or create player
            player = self.game_service.get_or_create_player(self.player_name.strip())
            level = self.game_service.get_or_create_default_level()

            # Create new game session
            self.game_session = self.game_service.create_game_session(player.id, level.id)

            # Initialize game objects
            self.initialize_game_objects()

            # Start game loop
            self.game_running = True
            if self.game_timer:
                self.game_timer.cancel()
            self.game_timer = ui.timer(1 / 60, self.game_loop)  # 60 FPS

            self.update_ui()
            ui.notify("Game started! Good luck! 🎉🚀", type="positive")

        except Exception as e:
            ui.notify(f"Error starting game: {str(e)}", type="negative")

    def initialize_game_objects(self) -> None:
        """Initialize ball, paddle, and bricks"""
        if not self.game_session:
            return

        # Initialize ball
        self.ball = Ball(
            x=Decimal(str(self.width // 2)),
            y=Decimal(str(self.height - 100)),
            vx=Decimal("5"),
            vy=Decimal("-5"),
            radius=Decimal(str(self.ball_radius)),
        )

        # Initialize paddle
        self.paddle = Paddle(
            x=Decimal(str((self.width - self.paddle_width) // 2)),
            y=Decimal(str(self.height - 30)),
            width=Decimal(str(self.paddle_width)),
            height=Decimal(str(self.paddle_height)),
        )

        # Initialize bricks
        self.bricks = []
        db_bricks = self.game_service.get_active_bricks(self.game_session.id)

        for db_brick in db_bricks:
            if db_brick.id is not None:
                brick_x, brick_y = self.physics.calculate_brick_position(
                    db_brick.row, db_brick.col, self.brick_width, self.brick_height, self.brick_spacing
                )

                physics_brick = PhysicsBrick(
                    x=brick_x,
                    y=brick_y,
                    width=Decimal(str(self.brick_width)),
                    height=Decimal(str(self.brick_height)),
                    id=db_brick.id,
                    hits_remaining=db_brick.hits_remaining,
                )
                self.bricks.append(physics_brick)

    async def game_loop(self) -> None:
        """Main game loop"""
        if not self.game_running or not self.ball or not self.paddle or not self.physics:
            return

        # Handle paddle movement
        self.handle_paddle_movement()

        # Update ball physics
        self.ball, events = self.physics.update_ball(self.ball)

        # Handle wall collision events
        for event in events:
            if event == "ball_lost":
                await self.handle_ball_lost()
                return

        # Check paddle collision
        hit_paddle, updated_ball = self.physics.check_paddle_collision(self.ball, self.paddle)
        if hit_paddle and updated_ball:
            self.ball = updated_ball

        # Check brick collisions
        self.ball, hit_brick_ids = self.physics.check_brick_collisions(self.ball, self.bricks)

        # Handle brick hits
        if hit_brick_ids and self.game_session:
            for brick_id in hit_brick_ids:
                destroyed, points = self.game_service.hit_brick(brick_id)
                if destroyed:
                    # Remove brick from physics simulation
                    self.bricks = [b for b in self.bricks if b.id != brick_id]
                    # Update score
                    new_score = self.game_session.score + points
                    self.game_session = self.game_service.update_game_session(self.game_session.id, score=new_score)

        # Check for level completion
        if not self.bricks:
            await self.handle_level_complete()
            return

        # Normalize ball speed
        if self.ball:
            self.ball = self.physics.normalize_velocity(self.ball, Decimal("6"))

        # Update game session in database
        if self.game_session and self.ball and self.paddle:
            self.game_service.update_game_session(
                self.game_session.id,
                ball_x=self.ball.x,
                ball_y=self.ball.y,
                ball_vx=self.ball.vx,
                ball_vy=self.ball.vy,
                paddle_x=self.paddle.x,
            )

        # Render game
        self.render_game()
        self.update_ui()

    def handle_paddle_movement(self) -> None:
        """Handle paddle movement based on key presses"""
        if not self.paddle:
            return

        paddle_speed = Decimal("8")

        if "ArrowLeft" in self.keys_pressed:
            self.paddle.x = max(Decimal("0"), self.paddle.x - paddle_speed)
        if "ArrowRight" in self.keys_pressed:
            max_x = Decimal(str(self.width)) - self.paddle.width
            self.paddle.x = min(max_x, self.paddle.x + paddle_speed)

    async def handle_ball_lost(self) -> None:
        """Handle when ball goes off screen"""
        if not self.game_session:
            return

        lives = self.game_session.lives_remaining - 1

        if lives <= 0:
            # Game over
            self.game_session = self.game_service.update_game_session(
                self.game_session.id, lives=0, status=GameStatus.GAME_OVER
            )
            await self.handle_game_over()
        else:
            # Reset ball position
            self.game_session = self.game_service.update_game_session(self.game_session.id, lives=lives)

            # Reset ball and paddle positions
            if self.ball:
                self.ball.x = Decimal(str(self.width // 2))
                self.ball.y = Decimal(str(self.height - 100))
                self.ball.vx = Decimal("5")
                self.ball.vy = Decimal("-5")

            ui.notify(f"Oops! Life lost! 💔 {lives} lives remaining", type="warning")

    async def handle_level_complete(self) -> None:
        """Handle level completion"""
        if not self.game_session:
            return

        # Award bonus points
        bonus_points = 1000
        new_score = self.game_session.score + bonus_points

        self.game_session = self.game_service.update_game_session(
            self.game_session.id, score=new_score, status=GameStatus.LEVEL_COMPLETE
        )

        self.game_running = False
        if self.game_timer:
            self.game_timer.cancel()

        ui.notify("Level Complete! 🥳✨", type="positive")
        ui.notify(f"Bonus: {bonus_points} points! 🌟", type="info")

        # Save high score
        if self.game_session.player_id:
            duration = int((datetime.utcnow() - self.game_session.started_at).total_seconds())
            self.game_service.save_high_score(
                self.game_session.player_id,
                new_score,
                1,  # Level reached
                duration,
                50 - len(self.bricks),  # Bricks destroyed
            )

    async def handle_game_over(self) -> None:
        """Handle game over"""
        self.game_running = False
        if self.game_timer:
            self.game_timer.cancel()

        ui.notify("Game Over! 💀 Better luck next time!", type="negative")

        # Save high score
        if self.game_session and self.game_session.player_id:
            duration = int((datetime.utcnow() - self.game_session.started_at).total_seconds())
            self.game_service.save_high_score(
                self.game_session.player_id,
                self.game_session.score,
                1,  # Level reached
                duration,
                50 - len(self.bricks),  # Bricks destroyed
            )

    def toggle_pause(self) -> None:
        """Toggle game pause state"""
        if not self.game_session:
            ui.notify("No active game to pause!", type="warning")
            return

        if self.game_running:
            self.game_running = False
            if self.game_timer:
                self.game_timer.cancel()
            ui.notify("Game paused", type="info")
        else:
            self.game_running = True
            if self.game_timer:
                self.game_timer.cancel()
            self.game_timer = ui.timer(1 / 60, self.game_loop)
            ui.notify("Game resumed", type="info")

    async def reset_game(self) -> None:
        """Reset the game"""
        self.game_running = False
        if self.game_timer:
            self.game_timer.cancel()

        self.game_session = None
        self.ball = None
        self.paddle = None
        self.bricks = []
        self.keys_pressed.clear()

        # Clear canvas
        if self.canvas:
            self.canvas.set_content("")

        self.update_ui()
        ui.notify("Game reset", type="info")

    def render_game(self) -> None:
        """Render the current game state"""
        if not self.canvas:
            return

        # Create SVG content
        svg_content = f'''
        <svg width="{self.width}" height="{self.height}" style="background-color: #001122;">
        '''

        # Render bricks
        for brick in self.bricks:
            color = "#FF0000" if brick.hits_remaining == 1 else "#FF8800"
            svg_content += f'''
            <rect x="{brick.x}" y="{brick.y}" width="{brick.width}" height="{brick.height}" 
                  fill="{color}" stroke="#FFFFFF" stroke-width="1" rx="3"/>
            '''

        # Render paddle
        if self.paddle:
            svg_content += f'''
            <rect x="{self.paddle.x}" y="{self.paddle.y}" width="{self.paddle.width}" height="{self.paddle.height}" 
                  fill="#FFFFFF" rx="5"/>
            '''

        # Render ball
        if self.ball:
            svg_content += f'''
            <circle cx="{self.ball.x}" cy="{self.ball.y}" r="{self.ball.radius}" 
                    fill="#FFFFFF" stroke="#FFFF00" stroke-width="2"/>
            '''

        svg_content += "</svg>"
        self.canvas.set_content(svg_content)

    def update_ui(self) -> None:
        """Update UI labels"""
        if self.game_session:
            if self.score_label:
                self.score_label.set_text(f"Score: {self.game_session.score}")
            if self.lives_label:
                self.lives_label.set_text(f"Lives: {self.game_session.lives_remaining}")
            if self.status_label:
                status_text = {
                    GameStatus.ACTIVE: "Playing",
                    GameStatus.PAUSED: "Paused",
                    GameStatus.GAME_OVER: "Game Over",
                    GameStatus.LEVEL_COMPLETE: "Level Complete!",
                }.get(self.game_session.status, "Unknown")
                self.status_label.set_text(f"Status: {status_text}")
        else:
            if self.score_label:
                self.score_label.set_text("Score: 0")
            if self.lives_label:
                self.lives_label.set_text("Lives: 3")
            if self.status_label:
                self.status_label.set_text("Ready to Play")


def create() -> None:
    """Create the Brick Breaker game page"""

    @ui.page("/brick_breaker")
    def brick_breaker_page():
        game = BrickBreakerGame()
        game.create_ui()

    @ui.page("/")
    def index():
        with ui.column().classes(
            "w-full h-screen bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center"
        ):
            with ui.card().classes("p-8 text-center bg-white bg-opacity-10 backdrop-blur-lg"):
                ui.label("🧱 BRICK BREAKER 🧱").classes("text-5xl font-bold text-white mb-4")
                ui.label("Classic arcade game built with NiceGUI").classes("text-xl text-white mb-6")

                ui.link("PLAY NOW", "/brick_breaker").classes(
                    "bg-green-500 hover:bg-green-600 text-white px-8 py-4 text-xl font-bold rounded-lg transition-colors no-underline"
                )

                # Leaderboard preview
                with ui.card().classes("mt-6 p-4 bg-black bg-opacity-20"):
                    ui.label("🏆 LEADERBOARD").classes("text-lg font-bold text-white mb-2")

                    try:
                        game_service = GameService()
                        leaderboard = game_service.get_leaderboard(5)

                        if leaderboard:
                            for entry in leaderboard:
                                ui.label(f"{entry['rank']}. {entry['player_name']} - {entry['score']} pts").classes(
                                    "text-white text-sm"
                                )
                        else:
                            ui.label("No high scores yet. Be the first!").classes("text-white text-sm italic")
                    except Exception:
                        ui.label("Leaderboard unavailable").classes("text-white text-sm italic")
