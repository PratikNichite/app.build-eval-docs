from decimal import Decimal
from datetime import datetime
from typing import Optional, List, Dict, Tuple
from sqlmodel import select
from app.database import get_session
from app.models import Player, GameLevel, GameSession, Brick, HighScore, GameConfig, PlayerCreate, GameStatus, BrickType


class GameService:
    """Service class for handling game logic and database operations"""

    @staticmethod
    def get_or_create_player(name: str, email: Optional[str] = None) -> Player:
        """Get existing player or create new one"""
        with get_session() as session:
            # Try to find existing player by name or email
            query = select(Player).where(Player.name == name)
            if email:
                query = query.where(Player.email == email)

            player = session.exec(query).first()

            if not player:
                player_data = PlayerCreate(name=name, email=email)
                player = Player(**player_data.model_dump())
                session.add(player)
                session.commit()
                session.refresh(player)

            return player

    @staticmethod
    def get_or_create_default_level() -> GameLevel:
        """Get or create the default level 1"""
        with get_session() as session:
            level = session.exec(select(GameLevel).where(GameLevel.level_number == 1)).first()

            if not level:
                # Create default level with standard brick layout
                brick_layout = []
                for row in range(5):
                    brick_row = []
                    for col in range(10):
                        brick_row.append(BrickType.NORMAL.value)
                    brick_layout.append(brick_row)

                level = GameLevel(
                    level_number=1,
                    name="Level 1",
                    rows=5,
                    cols=10,
                    brick_layout=brick_layout,
                    ball_speed=Decimal("5.0"),
                    paddle_speed=Decimal("8.0"),
                    lives=3,
                    bonus_points=1000,
                )
                session.add(level)
                session.commit()
                session.refresh(level)

            return level

    @staticmethod
    def create_game_session(player_id: int, level_id: int) -> GameSession:
        """Create a new game session"""
        with get_session() as session:
            game_session = GameSession(
                player_id=player_id,
                level_id=level_id,
                score=0,
                lives_remaining=3,
                current_level=1,
                status=GameStatus.ACTIVE,
                ball_position_x=Decimal("400"),
                ball_position_y=Decimal("300"),
                ball_velocity_x=Decimal("5"),
                ball_velocity_y=Decimal("-5"),
                paddle_position_x=Decimal("360"),
                paddle_width=Decimal("80"),
                active_powerups=[],
                powerup_timers={},
            )
            session.add(game_session)
            session.commit()
            session.refresh(game_session)

            # Create bricks for this session
            GameService.create_bricks_for_session(game_session.id, level_id)

            return game_session

    @staticmethod
    def create_bricks_for_session(session_id: int, level_id: int) -> None:
        """Create brick instances for a game session based on level layout"""
        with get_session() as session:
            level = session.get(GameLevel, level_id)
            if not level:
                return

            colors = ["#FF0000", "#FF8000", "#FFFF00", "#00FF00", "#0000FF"]  # Red, Orange, Yellow, Green, Blue

            for row in range(level.rows):
                for col in range(level.cols):
                    if row < len(level.brick_layout) and col < len(level.brick_layout[row]):
                        brick_type_str = level.brick_layout[row][col]
                        brick_type = BrickType(brick_type_str)

                        points_value = 10
                        hits_remaining = 1
                        if brick_type == BrickType.STRONG:
                            points_value = 20
                            hits_remaining = 2
                        elif brick_type == BrickType.POWERUP:
                            points_value = 50

                        color = colors[row % len(colors)]

                        brick = Brick(
                            game_session_id=session_id,
                            row=row,
                            col=col,
                            brick_type=brick_type,
                            hits_remaining=hits_remaining,
                            points_value=points_value,
                            color=color,
                        )
                        session.add(brick)

            session.commit()

    @staticmethod
    def get_game_session(session_id: int) -> Optional[GameSession]:
        """Get a game session by ID"""
        with get_session() as session:
            return session.get(GameSession, session_id)

    @staticmethod
    def update_game_session(
        session_id: int,
        ball_x: Optional[Decimal] = None,
        ball_y: Optional[Decimal] = None,
        ball_vx: Optional[Decimal] = None,
        ball_vy: Optional[Decimal] = None,
        paddle_x: Optional[Decimal] = None,
        score: Optional[int] = None,
        lives: Optional[int] = None,
        status: Optional[GameStatus] = None,
    ) -> Optional[GameSession]:
        """Update game session state"""
        with get_session() as session:
            game_session = session.get(GameSession, session_id)
            if not game_session:
                return None

            if ball_x is not None:
                game_session.ball_position_x = ball_x
            if ball_y is not None:
                game_session.ball_position_y = ball_y
            if ball_vx is not None:
                game_session.ball_velocity_x = ball_vx
            if ball_vy is not None:
                game_session.ball_velocity_y = ball_vy
            if paddle_x is not None:
                game_session.paddle_position_x = paddle_x
            if score is not None:
                game_session.score = score
            if lives is not None:
                game_session.lives_remaining = lives
            if status is not None:
                game_session.status = status

            game_session.updated_at = datetime.utcnow()
            session.add(game_session)
            session.commit()
            session.refresh(game_session)

            return game_session

    @staticmethod
    def get_active_bricks(session_id: int) -> List[Brick]:
        """Get all non-destroyed bricks for a game session"""
        with get_session() as session:
            return session.exec(select(Brick).where(Brick.game_session_id == session_id, ~Brick.is_destroyed)).all()

    @staticmethod
    def hit_brick(brick_id: int) -> Tuple[bool, int]:
        """Hit a brick, return (destroyed, points_awarded)"""
        with get_session() as session:
            brick = session.get(Brick, brick_id)
            if not brick or brick.is_destroyed:
                return False, 0

            brick.hits_remaining -= 1
            points_awarded = 0

            if brick.hits_remaining <= 0:
                brick.is_destroyed = True
                brick.destroyed_at = datetime.utcnow()
                points_awarded = brick.points_value

            session.add(brick)
            session.commit()

            return brick.is_destroyed, points_awarded

    @staticmethod
    def get_game_config() -> GameConfig:
        """Get or create default game configuration"""
        with get_session() as session:
            config = session.exec(select(GameConfig).where(GameConfig.config_name == "default")).first()

            if not config:
                config = GameConfig(
                    config_name="default",
                    play_area_width=800,
                    play_area_height=600,
                    paddle_height=15,
                    ball_radius=8,
                    brick_width=75,
                    brick_height=20,
                    brick_spacing=5,
                    physics_settings={
                        "ball_speed_multiplier": 1.0,
                        "paddle_bounce_factor": 0.8,
                        "wall_bounce_factor": 1.0,
                    },
                )
                session.add(config)
                session.commit()
                session.refresh(config)

            return config

    @staticmethod
    def save_high_score(
        player_id: int, score: int, level_reached: int, total_time_seconds: int, bricks_destroyed: int
    ) -> HighScore:
        """Save a high score entry"""
        with get_session() as session:
            high_score = HighScore(
                player_id=player_id,
                score=score,
                level_reached=level_reached,
                total_time_seconds=total_time_seconds,
                bricks_destroyed=bricks_destroyed,
            )
            session.add(high_score)
            session.commit()
            session.refresh(high_score)

            return high_score

    @staticmethod
    def get_leaderboard(limit: int = 10) -> List[Dict]:
        """Get top high scores"""
        with get_session() as session:
            query = select(HighScore, Player.name).join(Player).order_by(HighScore.score.desc()).limit(limit)

            results = session.exec(query).all()

            leaderboard = []
            for rank, (high_score, player_name) in enumerate(results, 1):
                leaderboard.append(
                    {
                        "rank": rank,
                        "player_name": player_name,
                        "score": high_score.score,
                        "level_reached": high_score.level_reached,
                        "achieved_at": high_score.achieved_at.strftime("%Y-%m-%d %H:%M"),
                    }
                )

            return leaderboard

    @staticmethod
    def is_level_complete(session_id: int) -> bool:
        """Check if all bricks are destroyed"""
        with get_session() as session:
            remaining_bricks = session.exec(
                select(Brick).where(Brick.game_session_id == session_id, ~Brick.is_destroyed)
            ).first()

            return remaining_bricks is None
