from decimal import Decimal
from typing import Tuple, Optional, List
from dataclasses import dataclass
import math


@dataclass
class Position:
    x: Decimal
    y: Decimal


@dataclass
class Velocity:
    x: Decimal
    y: Decimal


@dataclass
class Rectangle:
    x: Decimal
    y: Decimal
    width: Decimal
    height: Decimal

    def contains_point(self, px: Decimal, py: Decimal) -> bool:
        """Check if a point is inside this rectangle"""
        return self.x <= px <= self.x + self.width and self.y <= py <= self.y + self.height

    def intersects_circle(self, cx: Decimal, cy: Decimal, radius: Decimal) -> bool:
        """Check if this rectangle intersects with a circle"""
        # Find the closest point on the rectangle to the circle center
        closest_x = max(self.x, min(cx, self.x + self.width))
        closest_y = max(self.y, min(cy, self.y + self.height))

        # Calculate distance from circle center to closest point
        distance_x = cx - closest_x
        distance_y = cy - closest_y
        distance_squared = distance_x * distance_x + distance_y * distance_y

        return distance_squared <= (radius * radius)


@dataclass
class Ball:
    x: Decimal
    y: Decimal
    vx: Decimal
    vy: Decimal
    radius: Decimal

    def update_position(self, dt: Decimal = Decimal("1")) -> None:
        """Update ball position based on velocity"""
        self.x += self.vx * dt
        self.y += self.vy * dt

    def get_bounds(self) -> Rectangle:
        """Get bounding rectangle of the ball"""
        return Rectangle(self.x - self.radius, self.y - self.radius, self.radius * 2, self.radius * 2)


@dataclass
class Paddle:
    x: Decimal
    y: Decimal
    width: Decimal
    height: Decimal

    def get_bounds(self) -> Rectangle:
        """Get bounding rectangle of the paddle"""
        return Rectangle(self.x, self.y, self.width, self.height)

    def get_center_x(self) -> Decimal:
        """Get center X coordinate of paddle"""
        return self.x + self.width / 2


@dataclass
class Brick:
    x: Decimal
    y: Decimal
    width: Decimal
    height: Decimal
    id: int
    hits_remaining: int

    def get_bounds(self) -> Rectangle:
        """Get bounding rectangle of the brick"""
        return Rectangle(self.x, self.y, self.width, self.height)


class GamePhysics:
    """Physics engine for Brick Breaker game"""

    def __init__(self, play_area_width: int, play_area_height: int):
        self.play_area_width = Decimal(str(play_area_width))
        self.play_area_height = Decimal(str(play_area_height))
        self.wall_bounce_factor = Decimal("1.0")
        self.paddle_bounce_factor = Decimal("0.8")

    def update_ball(self, ball: Ball) -> Tuple[Ball, List[str]]:
        """Update ball position and handle wall collisions"""
        events = []

        # Update position
        ball.update_position()

        # Check wall collisions
        if ball.x - ball.radius <= 0:
            ball.x = ball.radius
            ball.vx = -ball.vx * self.wall_bounce_factor
            events.append("wall_left")
        elif ball.x + ball.radius >= self.play_area_width:
            ball.x = self.play_area_width - ball.radius
            ball.vx = -ball.vx * self.wall_bounce_factor
            events.append("wall_right")

        if ball.y - ball.radius <= 0:
            ball.y = ball.radius
            ball.vy = -ball.vy * self.wall_bounce_factor
            events.append("wall_top")
        elif ball.y + ball.radius >= self.play_area_height:
            # Ball went off bottom - lose life
            events.append("ball_lost")

        return ball, events

    def check_paddle_collision(self, ball: Ball, paddle: Paddle) -> Tuple[bool, Optional[Ball]]:
        """Check and handle collision between ball and paddle"""
        paddle_rect = paddle.get_bounds()

        if not paddle_rect.intersects_circle(ball.x, ball.y, ball.radius):
            return False, None

        # Calculate collision response
        # Determine which side of paddle was hit
        ball_center_y = ball.y
        paddle_top = paddle.y

        # If ball is above paddle, it hit the top
        if ball_center_y < paddle_top + paddle.height / 2:
            # Hit top of paddle
            ball.y = paddle_top - ball.radius

            # Calculate angle based on where ball hit paddle
            paddle_center_x = paddle.get_center_x()
            hit_pos = (ball.x - paddle_center_x) / (paddle.width / 2)  # -1 to 1
            hit_pos = max(Decimal("-1"), min(Decimal("1"), hit_pos))  # Clamp

            # Calculate new velocity with angle
            speed = (ball.vx**2 + ball.vy**2) ** Decimal("0.5")
            angle = hit_pos * Decimal("60")  # Max 60 degrees from vertical
            angle_rad = angle * Decimal(str(math.pi)) / Decimal("180")

            ball.vx = speed * Decimal(str(math.sin(float(angle_rad))))
            ball.vy = -abs(speed * Decimal(str(math.cos(float(angle_rad)))))  # Always up

        else:
            # Hit side of paddle
            if ball.x < paddle.get_center_x():
                ball.x = paddle.x - ball.radius
                ball.vx = -abs(ball.vx)
            else:
                ball.x = paddle.x + paddle.width + ball.radius
                ball.vx = abs(ball.vx)

        return True, ball

    def check_brick_collisions(self, ball: Ball, bricks: List[Brick]) -> Tuple[Ball, List[int]]:
        """Check and handle collisions between ball and bricks"""
        hit_bricks = []

        for brick in bricks:
            brick_rect = brick.get_bounds()

            if brick_rect.intersects_circle(ball.x, ball.y, ball.radius):
                hit_bricks.append(brick.id)

                # Determine collision side and reflect ball
                ball_prev_x = ball.x - ball.vx
                ball_prev_y = ball.y - ball.vy

                # Check which side was hit
                if ball_prev_x < brick.x and ball.x >= brick.x:
                    # Hit left side
                    ball.x = brick.x - ball.radius
                    ball.vx = -abs(ball.vx)
                elif ball_prev_x > brick.x + brick.width and ball.x <= brick.x + brick.width:
                    # Hit right side
                    ball.x = brick.x + brick.width + ball.radius
                    ball.vx = abs(ball.vx)
                elif ball_prev_y < brick.y and ball.y >= brick.y:
                    # Hit top side
                    ball.y = brick.y - ball.radius
                    ball.vy = -abs(ball.vy)
                elif ball_prev_y > brick.y + brick.height and ball.y <= brick.y + brick.height:
                    # Hit bottom side
                    ball.y = brick.y + brick.height + ball.radius
                    ball.vy = abs(ball.vy)
                else:
                    # Corner collision - reverse both velocities
                    ball.vx = -ball.vx
                    ball.vy = -ball.vy

                # Only process first collision per frame
                break

        return ball, hit_bricks

    def normalize_velocity(self, ball: Ball, target_speed: Decimal) -> Ball:
        """Normalize ball velocity to maintain consistent speed"""
        current_speed = (ball.vx**2 + ball.vy**2) ** Decimal("0.5")

        if current_speed > 0:
            scale = target_speed / current_speed
            ball.vx *= scale
            ball.vy *= scale

        return ball

    def calculate_brick_position(
        self, row: int, col: int, brick_width: int, brick_height: int, spacing: int
    ) -> Tuple[Decimal, Decimal]:
        """Calculate screen position for a brick based on grid position"""
        x = Decimal(str(col * (brick_width + spacing) + spacing))
        y = Decimal(str(row * (brick_height + spacing) + spacing + 50))  # 50px from top
        return x, y
