from sqlmodel import SQLModel, Field, Relationship, JSON, Column
from datetime import datetime
from typing import Optional, List, Dict, Any
from decimal import Decimal
from enum import Enum


class BrickType(str, Enum):
    NORMAL = "normal"
    STRONG = "strong"  # Takes 2 hits to destroy
    POWERUP = "powerup"  # Drops power-up when destroyed


class GameStatus(str, Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    GAME_OVER = "game_over"
    LEVEL_COMPLETE = "level_complete"
    WON = "won"


class PowerUpType(str, Enum):
    EXTRA_LIFE = "extra_life"
    LARGER_PADDLE = "larger_paddle"
    MULTI_BALL = "multi_ball"
    SLOWER_BALL = "slower_ball"


# Persistent models (stored in database)
class Player(SQLModel, table=True):
    __tablename__ = "players"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=50)
    email: Optional[str] = Field(default=None, max_length=255, unique=True)
    total_score: int = Field(default=0)
    games_played: int = Field(default=0)
    highest_level: int = Field(default=1)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    game_sessions: List["GameSession"] = Relationship(back_populates="player")
    high_scores: List["HighScore"] = Relationship(back_populates="player")


class GameLevel(SQLModel, table=True):
    __tablename__ = "game_levels"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    level_number: int = Field(unique=True)
    name: str = Field(max_length=100)
    rows: int = Field(default=5)  # Number of brick rows
    cols: int = Field(default=10)  # Number of brick columns
    brick_layout: List[List[str]] = Field(default=[], sa_column=Column(JSON))  # 2D array of brick types
    ball_speed: Decimal = Field(default=Decimal("5.0"))
    paddle_speed: Decimal = Field(default=Decimal("8.0"))
    lives: int = Field(default=3)
    bonus_points: int = Field(default=1000)  # Bonus for completing level
    created_at: datetime = Field(default_factory=datetime.utcnow)

    game_sessions: List["GameSession"] = Relationship(back_populates="level")


class GameSession(SQLModel, table=True):
    __tablename__ = "game_sessions"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    player_id: int = Field(foreign_key="players.id")
    level_id: int = Field(foreign_key="game_levels.id")
    score: int = Field(default=0)
    lives_remaining: int = Field(default=3)
    current_level: int = Field(default=1)
    status: GameStatus = Field(default=GameStatus.ACTIVE)
    ball_position_x: Decimal = Field(default=Decimal("400"))  # Ball X coordinate
    ball_position_y: Decimal = Field(default=Decimal("300"))  # Ball Y coordinate
    ball_velocity_x: Decimal = Field(default=Decimal("5"))  # Ball X velocity
    ball_velocity_y: Decimal = Field(default=Decimal("-5"))  # Ball Y velocity
    paddle_position_x: Decimal = Field(default=Decimal("360"))  # Paddle X coordinate
    paddle_width: Decimal = Field(default=Decimal("80"))  # Current paddle width
    active_powerups: List[str] = Field(default=[], sa_column=Column(JSON))  # Active power-ups
    powerup_timers: Dict[str, int] = Field(default={}, sa_column=Column(JSON))  # Power-up timers
    started_at: datetime = Field(default_factory=datetime.utcnow)
    ended_at: Optional[datetime] = Field(default=None)
    duration_seconds: Optional[int] = Field(default=None)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    player: Player = Relationship(back_populates="game_sessions")
    level: GameLevel = Relationship(back_populates="game_sessions")
    bricks: List["Brick"] = Relationship(back_populates="game_session")


class Brick(SQLModel, table=True):
    __tablename__ = "bricks"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    game_session_id: int = Field(foreign_key="game_sessions.id")
    row: int  # Row position in grid
    col: int  # Column position in grid
    brick_type: BrickType = Field(default=BrickType.NORMAL)
    hits_remaining: int = Field(default=1)  # How many hits needed to destroy
    points_value: int = Field(default=10)  # Points awarded when destroyed
    color: str = Field(default="#FF0000", max_length=7)  # Hex color code
    is_destroyed: bool = Field(default=False)
    destroyed_at: Optional[datetime] = Field(default=None)

    game_session: GameSession = Relationship(back_populates="bricks")


class HighScore(SQLModel, table=True):
    __tablename__ = "high_scores"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    player_id: int = Field(foreign_key="players.id")
    score: int
    level_reached: int
    total_time_seconds: int  # Total game duration
    bricks_destroyed: int
    achieved_at: datetime = Field(default_factory=datetime.utcnow)

    player: Player = Relationship(back_populates="high_scores")


class GameConfig(SQLModel, table=True):
    __tablename__ = "game_configs"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    config_name: str = Field(unique=True, max_length=50)
    play_area_width: int = Field(default=800)
    play_area_height: int = Field(default=600)
    paddle_height: int = Field(default=15)
    ball_radius: int = Field(default=8)
    brick_width: int = Field(default=75)
    brick_height: int = Field(default=20)
    brick_spacing: int = Field(default=5)
    physics_settings: Dict[str, Any] = Field(default={}, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class PlayerCreate(SQLModel, table=False):
    name: str = Field(max_length=50)
    email: Optional[str] = Field(default=None, max_length=255)


class PlayerUpdate(SQLModel, table=False):
    name: Optional[str] = Field(default=None, max_length=50)
    email: Optional[str] = Field(default=None, max_length=255)


class GameSessionCreate(SQLModel, table=False):
    player_id: int
    level_id: int
    lives_remaining: int = Field(default=3)


class GameSessionUpdate(SQLModel, table=False):
    score: Optional[int] = Field(default=None)
    lives_remaining: Optional[int] = Field(default=None)
    status: Optional[GameStatus] = Field(default=None)
    ball_position_x: Optional[Decimal] = Field(default=None)
    ball_position_y: Optional[Decimal] = Field(default=None)
    ball_velocity_x: Optional[Decimal] = Field(default=None)
    ball_velocity_y: Optional[Decimal] = Field(default=None)
    paddle_position_x: Optional[Decimal] = Field(default=None)
    paddle_width: Optional[Decimal] = Field(default=None)
    active_powerups: Optional[List[str]] = Field(default=None)
    powerup_timers: Optional[Dict[str, int]] = Field(default=None)


class LevelCreate(SQLModel, table=False):
    level_number: int
    name: str = Field(max_length=100)
    rows: int = Field(default=5)
    cols: int = Field(default=10)
    brick_layout: List[List[str]] = Field(default=[])
    ball_speed: Decimal = Field(default=Decimal("5.0"))
    paddle_speed: Decimal = Field(default=Decimal("8.0"))
    lives: int = Field(default=3)
    bonus_points: int = Field(default=1000)


class BrickCreate(SQLModel, table=False):
    game_session_id: int
    row: int
    col: int
    brick_type: BrickType = Field(default=BrickType.NORMAL)
    hits_remaining: int = Field(default=1)
    points_value: int = Field(default=10)
    color: str = Field(default="#FF0000", max_length=7)


class BrickUpdate(SQLModel, table=False):
    hits_remaining: Optional[int] = Field(default=None)
    is_destroyed: Optional[bool] = Field(default=None)


class HighScoreCreate(SQLModel, table=False):
    player_id: int
    score: int
    level_reached: int
    total_time_seconds: int
    bricks_destroyed: int


class GameStateResponse(SQLModel, table=False):
    """Response schema for current game state"""

    session_id: int
    player_name: str
    score: int
    lives_remaining: int
    current_level: int
    status: GameStatus
    ball_position: Dict[str, Decimal]
    ball_velocity: Dict[str, Decimal]
    paddle_position_x: Decimal
    paddle_width: Decimal
    active_powerups: List[str]
    remaining_bricks: int
    level_complete: bool


class LeaderboardEntry(SQLModel, table=False):
    """Schema for leaderboard entries"""

    rank: int
    player_name: str
    score: int
    level_reached: int
    achieved_at: str  # ISO format datetime string
