"""Plant care service layer for business logic."""

from sqlmodel import select
from typing import List, Optional
from datetime import date, datetime

from app.database import get_session
from app.models import Plant, PlantCreate, PlantUpdate, PlantResponse


class PlantService:
    """Service class for plant management operations."""

    @staticmethod
    def create_plant(plant_data: PlantCreate) -> PlantResponse:
        """Create a new plant in the database."""
        with get_session() as session:
            plant = Plant(
                name=plant_data.name,
                last_watered_date=plant_data.last_watered_date,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )
            session.add(plant)
            session.commit()
            session.refresh(plant)
            return PlantResponse.from_plant(plant)

    @staticmethod
    def get_all_plants() -> List[PlantResponse]:
        """Retrieve all plants from the database."""
        with get_session() as session:
            statement = select(Plant).order_by(Plant.name)
            plants = session.exec(statement).all()
            return [PlantResponse.from_plant(plant) for plant in plants]

    @staticmethod
    def get_plant_by_id(plant_id: int) -> Optional[PlantResponse]:
        """Retrieve a specific plant by ID."""
        with get_session() as session:
            plant = session.get(Plant, plant_id)
            if plant is None:
                return None
            return PlantResponse.from_plant(plant)

    @staticmethod
    def update_plant(plant_id: int, plant_data: PlantUpdate) -> Optional[PlantResponse]:
        """Update an existing plant."""
        with get_session() as session:
            plant = session.get(Plant, plant_id)
            if plant is None:
                return None

            if plant_data.name is not None:
                plant.name = plant_data.name
            if plant_data.last_watered_date is not None:
                plant.last_watered_date = plant_data.last_watered_date

            plant.updated_at = datetime.utcnow()
            session.add(plant)
            session.commit()
            session.refresh(plant)
            return PlantResponse.from_plant(plant)

    @staticmethod
    def delete_plant(plant_id: int) -> bool:
        """Delete a plant from the database."""
        with get_session() as session:
            plant = session.get(Plant, plant_id)
            if plant is None:
                return False

            session.delete(plant)
            session.commit()
            return True

    @staticmethod
    def water_plant(plant_id: int, watered_date: Optional[date] = None) -> Optional[PlantResponse]:
        """Update the last watered date for a plant (defaults to today)."""
        if watered_date is None:
            watered_date = date.today()

        plant_data = PlantUpdate(last_watered_date=watered_date)
        return PlantService.update_plant(plant_id, plant_data)
