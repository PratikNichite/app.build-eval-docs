"""Plant Care Tracker UI module."""

from nicegui import ui
from datetime import date, datetime

from app.plant_service import PlantService
from app.models import PlantCreate, PlantMood


def create():
    """Create the plant tracker UI routes."""

    # Apply modern theme
    ui.colors(
        primary="#10b981",  # Green for plants
        secondary="#64748b",  # Subtle gray
        accent="#059669",  # Darker green
        positive="#10b981",
        negative="#ef4444",
        warning="#f59e0b",
        info="#3b82f6",
    )

    @ui.page("/")
    def index():
        """Main plant tracker page."""
        ui.add_head_html("<title>Plant Care Tracker</title>")

        # Header
        with ui.row().classes("w-full justify-between items-center mb-6 p-4 bg-green-50 rounded-lg"):
            ui.label("🌱 Plant Care Tracker").classes("text-3xl font-bold text-green-700")
            ui.button("Add New Plant", on_click=lambda: ui.navigate.to("/add"), icon="add").classes(
                "bg-green-500 text-white"
            )

        # Plants container
        plants_container = ui.column().classes("w-full gap-4")

        def refresh_plants():
            """Refresh the plants display."""
            plants_container.clear()
            plants = PlantService.get_all_plants()

            if not plants:
                with plants_container:
                    with (
                        ui.card()
                        .classes(
                            "p-8 text-center bg-gradient-to-br from-green-50 to-blue-50 border-2 border-dashed border-green-200"
                        )
                        .style("min-height: 250px")
                    ):
                        ui.label("🌿🌱🌺").classes("text-6xl mb-4")
                        ui.label("Your garden is waiting! 🌸").classes("text-2xl font-bold text-green-700 mb-2")
                        ui.label("Add your first green friend to start this amazing journey! ✨").classes(
                            "text-lg text-green-600 mb-4"
                        )
                        ui.label("Every plant parent starts somewhere... 🌱➡️🌳").classes("text-sm text-gray-500")
                return

            with plants_container:
                for plant in plants:
                    create_plant_card(plant, refresh_plants)

        # Initial load
        refresh_plants()

    def create_plant_card(plant, refresh_callback):
        """Create a card display for a single plant."""
        mood_colors = {
            PlantMood.HAPPY: "bg-green-100 border-green-300",
            PlantMood.NORMAL: "bg-blue-100 border-blue-300",
            PlantMood.THIRSTY: "bg-red-100 border-red-300",
        }

        mood_icons = {PlantMood.HAPPY: "🌱✨", PlantMood.NORMAL: "🌿💚", PlantMood.THIRSTY: "🥵💧"}

        mood_messages = {
            PlantMood.HAPPY: "Happy and thriving! 🎉",
            PlantMood.NORMAL: "Feeling pretty good! 👍",
            PlantMood.THIRSTY: "Getting thirsty... help! 🆘",
        }

        card_class = f"p-4 border-2 rounded-lg shadow-md hover:shadow-lg transition-shadow {mood_colors[plant.mood]}"

        with ui.card().classes(card_class):
            with ui.row().classes("w-full justify-between items-start"):
                # Plant info
                with ui.column().classes("flex-1"):
                    ui.label(plant.name).classes("text-xl font-bold text-gray-800")
                    ui.label(f"Last watered: {plant.last_watered_date}").classes("text-gray-600")
                    ui.label(f"{plant.days_since_watered} days ago").classes("text-sm text-gray-500")

                # Mood indicator
                with ui.column().classes("items-center"):
                    ui.label(mood_icons[plant.mood]).classes("text-3xl")
                    ui.label(plant.mood.value.title()).classes("font-semibold text-gray-700")
                    ui.label(mood_messages[plant.mood]).classes("text-xs text-gray-600")

            # Action buttons
            with ui.row().classes("gap-2 mt-4"):
                ui.button(
                    "💧 Water Now",
                    on_click=lambda p_id=plant.id: water_plant_now(p_id, refresh_callback),
                    color="primary",
                ).classes("text-sm")
                ui.button(
                    "✏️ Edit", on_click=lambda p_id=plant.id: ui.navigate.to(f"/edit/{p_id}"), color="secondary"
                ).props("outline").classes("text-sm")
                ui.button(
                    "🗑️ Delete",
                    on_click=lambda p_id=plant.id: delete_plant_confirm(p_id, refresh_callback),
                    color="negative",
                ).props("outline").classes("text-sm")

    async def water_plant_now(plant_id: int, refresh_callback):
        """Water a plant immediately."""
        result = PlantService.water_plant(plant_id)
        if result:
            ui.notify("🎉 Plant watered successfully! Your green buddy is happy! 💧✨", type="positive")
            refresh_callback()
        else:
            ui.notify("❌ Oops! Something went wrong while watering your plant 😢", type="negative")

    async def delete_plant_confirm(plant_id: int, refresh_callback):
        """Show confirmation dialog before deleting a plant."""
        plant = PlantService.get_plant_by_id(plant_id)
        if plant is None:
            ui.notify("🔍 Hmm, we can't find that plant! It might have wandered off... 🌿", type="negative")
            return

        with ui.dialog() as dialog, ui.card():
            ui.label(f'Delete "{plant.name}"?').classes("text-lg font-bold mb-4")
            ui.label("This action cannot be undone.").classes("text-gray-600 mb-4")

            with ui.row().classes("gap-2"):
                ui.button("Cancel", on_click=lambda: dialog.submit(False)).props("outline")
                ui.button("Delete", on_click=lambda: dialog.submit(True), color="negative")

        result = await dialog
        if result:
            success = PlantService.delete_plant(plant_id)
            if success:
                ui.notify(f'🌿 Farewell "{plant.name}"! Thanks for the memories 💚', type="warning")
                refresh_callback()
            else:
                ui.notify("❌ Couldn't remove the plant - maybe it's too attached! 🌱💔", type="negative")

    @ui.page("/add")
    def add_plant():
        """Add new plant page."""
        ui.add_head_html("<title>Add Plant - Plant Care Tracker</title>")

        # Header with back button
        with ui.row().classes("w-full items-center mb-6"):
            ui.button("← Back", on_click=lambda: ui.navigate.to("/"), icon="arrow_back").props("flat")
            ui.label("🌱 Add New Plant").classes("text-2xl font-bold text-green-700 ml-4")

        # Form
        with ui.card().classes("max-w-md mx-auto p-6"):
            ui.label("Plant Details").classes("text-lg font-semibold mb-4")

            name_input = ui.input("Plant Name", placeholder="e.g., My Fiddle Leaf Fig").classes("w-full mb-4")

            ui.label("Last Watered Date").classes("text-sm font-medium text-gray-700 mb-1")
            date_input = ui.date(value=date.today().isoformat()).classes("w-full mb-6")

            with ui.row().classes("gap-4 justify-end"):
                ui.button("Cancel", on_click=lambda: ui.navigate.to("/"), color="secondary").props("outline")
                ui.button(
                    "Add Plant", on_click=lambda: save_new_plant(name_input, date_input), color="primary", icon="add"
                )

    def save_new_plant(name_input: ui.input, date_input: ui.date):
        """Save a new plant to the database."""
        name = name_input.value.strip() if name_input.value else ""
        if not name:
            ui.notify("🌿 Oops! Your plant needs a name to join the family! ✏️", type="negative")
            return

        try:
            # Parse the date value
            if isinstance(date_input.value, str):
                watered_date = datetime.fromisoformat(date_input.value).date()
            else:
                watered_date = date_input.value

            plant_data = PlantCreate(name=name, last_watered_date=watered_date)
            result = PlantService.create_plant(plant_data)

            ui.notify(f'🎉 Welcome "{result.name}" to your green family! 🌱💚', type="positive")
            ui.navigate.to("/")

        except Exception as e:
            ui.notify(f"🚨 Uh oh! Something went wrong adding your plant: {str(e)} 😞", type="negative")

    @ui.page("/edit/{plant_id}")
    def edit_plant(plant_id: int):
        """Edit existing plant page."""
        ui.add_head_html("<title>Edit Plant - Plant Care Tracker</title>")

        plant = PlantService.get_plant_by_id(plant_id)
        if plant is None:
            ui.notify("🔍 Hmm, that plant seems to have disappeared! 🌿✨", type="negative")
            ui.navigate.to("/")
            return

        # Header with back button
        with ui.row().classes("w-full items-center mb-6"):
            ui.button("← Back", on_click=lambda: ui.navigate.to("/"), icon="arrow_back").props("flat")
            ui.label(f"🍃 Edit {plant.name}").classes("text-2xl font-bold text-green-700 ml-4")

        # Form
        with ui.card().classes("max-w-md mx-auto p-6"):
            ui.label("Plant Details").classes("text-lg font-semibold mb-4")

            name_input = ui.input("Plant Name", value=plant.name).classes("w-full mb-4")

            ui.label("Last Watered Date").classes("text-sm font-medium text-gray-700 mb-1")
            date_input = ui.date(value=plant.last_watered_date.isoformat()).classes("w-full mb-6")

            with ui.row().classes("gap-4 justify-end"):
                ui.button("Cancel", on_click=lambda: ui.navigate.to("/"), color="secondary").props("outline")
                ui.button(
                    "Save Changes",
                    on_click=lambda: save_plant_changes(plant_id, name_input, date_input),
                    color="primary",
                    icon="save",
                )

    def save_plant_changes(plant_id: int, name_input: ui.input, date_input: ui.date):
        """Save changes to an existing plant."""
        name = name_input.value.strip() if name_input.value else ""
        if not name:
            ui.notify("🌿 Your plant still needs a name! Don't leave it nameless! 📝", type="negative")
            return

        try:
            # Parse the date value
            if isinstance(date_input.value, str):
                watered_date = datetime.fromisoformat(date_input.value).date()
            else:
                watered_date = date_input.value

            from app.models import PlantUpdate

            plant_data = PlantUpdate(name=name, last_watered_date=watered_date)
            result = PlantService.update_plant(plant_id, plant_data)

            if result:
                ui.notify(f'🎊 "{result.name}" has been updated! Looking fresh! ✨🌿', type="positive")
                ui.navigate.to("/")
            else:
                ui.notify("🔍 Whoops! That plant vanished while we weren't looking! 👻🌱", type="negative")

        except Exception as e:
            ui.notify(f"🚨 Oops! Something went wonky while updating: {str(e)} 🤔", type="negative")
