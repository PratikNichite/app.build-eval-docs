from sqlmodel import SQLModel, Field
from datetime import datetime, date
from typing import Optional
from enum import Enum


class PlantMood(str, Enum):
    """Enum for plant mood states based on watering schedule."""

    HAPPY = "happy"
    NORMAL = "normal"
    THIRSTY = "thirsty"


class Plant(SQLModel, table=True):
    """Model for tracking plants and their care status."""

    __tablename__ = "plants"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=200, description="Name of the plant")
    last_watered_date: date = Field(description="Date when the plant was last watered")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="When the plant was added to tracker")
    updated_at: datetime = Field(default_factory=datetime.utcnow, description="When plant info was last updated")

    def get_mood(self) -> PlantMood:
        """Calculate plant mood based on last watered date."""
        today = date.today()
        days_since_watered = (today - self.last_watered_date).days

        if days_since_watered > 7:
            return PlantMood.THIRSTY
        elif days_since_watered <= 3:
            return PlantMood.HAPPY
        else:
            return PlantMood.NORMAL

    def days_since_watered(self) -> int:
        """Get number of days since plant was last watered."""
        today = date.today()
        return (today - self.last_watered_date).days


# Non-persistent schemas for validation and data transfer


class PlantCreate(SQLModel, table=False):
    """Schema for creating a new plant."""

    name: str = Field(max_length=200, description="Name of the plant")
    last_watered_date: date = Field(description="Date when the plant was last watered")


class PlantUpdate(SQLModel, table=False):
    """Schema for updating plant information."""

    name: Optional[str] = Field(default=None, max_length=200, description="Name of the plant")
    last_watered_date: Optional[date] = Field(default=None, description="Date when the plant was last watered")


class PlantResponse(SQLModel, table=False):
    """Schema for plant API responses including computed fields."""

    id: int
    name: str
    last_watered_date: date
    mood: PlantMood
    days_since_watered: int
    created_at: datetime
    updated_at: datetime

    @classmethod
    def from_plant(cls, plant: Plant) -> "PlantResponse":
        """Create response model from Plant instance."""
        if plant.id is None:
            raise ValueError("Plant ID cannot be None")

        return cls(
            id=plant.id,
            name=plant.name,
            last_watered_date=plant.last_watered_date,
            mood=plant.get_mood(),
            days_since_watered=plant.days_since_watered(),
            created_at=plant.created_at,
            updated_at=plant.updated_at,
        )
