"""Tests for plant models and their logic."""

import pytest
from datetime import date, datetime, timedelta
from app.models import Plant, PlantMood, PlantResponse, PlantCreate, PlantUpdate


def test_plant_mood_happy():
    """Test plant mood calculation for happy plants (watered within 3 days)."""
    # Watered today
    plant = Plant(name="Happy Plant", last_watered_date=date.today())
    assert plant.get_mood() == PlantMood.HAPPY

    # Watered 1 day ago
    plant = Plant(name="Happy Plant", last_watered_date=date.today() - timedelta(days=1))
    assert plant.get_mood() == PlantMood.HAPPY

    # Watered 3 days ago (boundary case)
    plant = Plant(name="Happy Plant", last_watered_date=date.today() - timedelta(days=3))
    assert plant.get_mood() == PlantMood.HAPPY


def test_plant_mood_normal():
    """Test plant mood calculation for normal plants (watered 4-7 days ago)."""
    # Watered 4 days ago
    plant = Plant(name="Normal Plant", last_watered_date=date.today() - timedelta(days=4))
    assert plant.get_mood() == PlantMood.NORMAL

    # Watered 5 days ago
    plant = Plant(name="Normal Plant", last_watered_date=date.today() - timedelta(days=5))
    assert plant.get_mood() == PlantMood.NORMAL

    # Watered 7 days ago (boundary case)
    plant = Plant(name="Normal Plant", last_watered_date=date.today() - timedelta(days=7))
    assert plant.get_mood() == PlantMood.NORMAL


def test_plant_mood_thirsty():
    """Test plant mood calculation for thirsty plants (watered more than 7 days ago)."""
    # Watered 8 days ago
    plant = Plant(name="Thirsty Plant", last_watered_date=date.today() - timedelta(days=8))
    assert plant.get_mood() == PlantMood.THIRSTY

    # Watered 10 days ago
    plant = Plant(name="Thirsty Plant", last_watered_date=date.today() - timedelta(days=10))
    assert plant.get_mood() == PlantMood.THIRSTY

    # Watered 30 days ago
    plant = Plant(name="Thirsty Plant", last_watered_date=date.today() - timedelta(days=30))
    assert plant.get_mood() == PlantMood.THIRSTY


def test_days_since_watered():
    """Test days since watered calculation."""
    # Watered today
    plant = Plant(name="Test Plant", last_watered_date=date.today())
    assert plant.days_since_watered() == 0

    # Watered 5 days ago
    plant = Plant(name="Test Plant", last_watered_date=date.today() - timedelta(days=5))
    assert plant.days_since_watered() == 5

    # Watered 15 days ago
    plant = Plant(name="Test Plant", last_watered_date=date.today() - timedelta(days=15))
    assert plant.days_since_watered() == 15


def test_days_since_watered_future_date():
    """Test days since watered with future date (negative days)."""
    # Watered tomorrow (future date)
    plant = Plant(name="Future Plant", last_watered_date=date.today() + timedelta(days=1))
    assert plant.days_since_watered() == -1

    # Future watering should still result in happy mood
    assert plant.get_mood() == PlantMood.HAPPY


def test_plant_response_from_plant():
    """Test PlantResponse creation from Plant instance."""
    now = datetime.utcnow()
    plant = Plant(
        id=1, name="Test Plant", last_watered_date=date.today() - timedelta(days=5), created_at=now, updated_at=now
    )

    response = PlantResponse.from_plant(plant)

    assert response.id == 1
    assert response.name == "Test Plant"
    assert response.last_watered_date == plant.last_watered_date
    assert response.mood == PlantMood.NORMAL  # 5 days ago = normal
    assert response.days_since_watered == 5
    assert response.created_at == now
    assert response.updated_at == now


def test_plant_response_from_plant_none_id():
    """Test PlantResponse creation fails with None ID."""
    plant = Plant(
        id=None,
        name="Test Plant",
        last_watered_date=date.today(),
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )

    with pytest.raises(ValueError, match="Plant ID cannot be None"):
        PlantResponse.from_plant(plant)


def test_plant_create_schema():
    """Test PlantCreate schema."""
    plant_data = PlantCreate(name="New Plant", last_watered_date=date.today())

    assert plant_data.name == "New Plant"
    assert plant_data.last_watered_date == date.today()


def test_plant_update_schema():
    """Test PlantUpdate schema with optional fields."""
    # Update with both fields
    update_data = PlantUpdate(name="Updated Name", last_watered_date=date.today() - timedelta(days=2))

    assert update_data.name == "Updated Name"
    assert update_data.last_watered_date == date.today() - timedelta(days=2)

    # Update with only name
    update_data = PlantUpdate(name="Only Name")
    assert update_data.name == "Only Name"
    assert update_data.last_watered_date is None

    # Update with only date
    test_date = date.today() - timedelta(days=1)
    update_data = PlantUpdate(last_watered_date=test_date)
    assert update_data.name is None
    assert update_data.last_watered_date == test_date

    # Update with no fields (all None)
    update_data = PlantUpdate()
    assert update_data.name is None
    assert update_data.last_watered_date is None


def test_plant_mood_enum_values():
    """Test PlantMood enum values."""
    assert PlantMood.HAPPY == "happy"
    assert PlantMood.NORMAL == "normal"
    assert PlantMood.THIRSTY == "thirsty"


def test_plant_model_defaults():
    """Test Plant model default values."""
    plant = Plant(name="Test Plant", last_watered_date=date.today())

    # ID should default to None
    assert plant.id is None

    # Timestamps should be set automatically
    assert isinstance(plant.created_at, datetime)
    assert isinstance(plant.updated_at, datetime)

    # Both timestamps should be very close to now
    now = datetime.utcnow()
    assert abs((plant.created_at - now).total_seconds()) < 1
    assert abs((plant.updated_at - now).total_seconds()) < 1


def test_boundary_conditions():
    """Test boundary conditions for mood calculation."""
    # Exactly 3 days (should be happy)
    plant = Plant(name="Boundary Plant", last_watered_date=date.today() - timedelta(days=3))
    assert plant.get_mood() == PlantMood.HAPPY

    # Exactly 4 days (should be normal)
    plant = Plant(name="Boundary Plant", last_watered_date=date.today() - timedelta(days=4))
    assert plant.get_mood() == PlantMood.NORMAL

    # Exactly 7 days (should be normal)
    plant = Plant(name="Boundary Plant", last_watered_date=date.today() - timedelta(days=7))
    assert plant.get_mood() == PlantMood.NORMAL

    # Exactly 8 days (should be thirsty)
    plant = Plant(name="Boundary Plant", last_watered_date=date.today() - timedelta(days=8))
    assert plant.get_mood() == PlantMood.THIRSTY
