"""Tests for the plant service layer."""

import pytest
from datetime import date, datetime, timedelta
from app.plant_service import PlantService
from app.models import PlantCreate, PlantUpdate, PlantMood
from app.database import reset_db


@pytest.fixture
def new_db():
    """Reset database before each test."""
    reset_db()
    yield
    reset_db()


def test_create_plant(new_db):
    """Test creating a new plant."""
    plant_data = PlantCreate(name="Test Fern", last_watered_date=date.today())

    result = PlantService.create_plant(plant_data)

    assert result.name == "Test Fern"
    assert result.last_watered_date == date.today()
    assert result.id is not None
    assert isinstance(result.created_at, datetime)
    assert isinstance(result.updated_at, datetime)


def test_get_all_plants_empty(new_db):
    """Test getting all plants when database is empty."""
    plants = PlantService.get_all_plants()
    assert plants == []


def test_get_all_plants_with_data(new_db):
    """Test getting all plants with data."""
    # Create test plants
    PlantService.create_plant(PlantCreate(name="Plant 1", last_watered_date=date.today()))
    PlantService.create_plant(PlantCreate(name="Plant 2", last_watered_date=date.today() - timedelta(days=5)))

    plants = PlantService.get_all_plants()

    assert len(plants) == 2
    # Should be ordered by name
    assert plants[0].name == "Plant 1"
    assert plants[1].name == "Plant 2"


def test_get_plant_by_id(new_db):
    """Test getting a specific plant by ID."""
    created_plant = PlantService.create_plant(PlantCreate(name="Test Plant", last_watered_date=date.today()))

    retrieved_plant = PlantService.get_plant_by_id(created_plant.id)

    assert retrieved_plant is not None
    assert retrieved_plant.id == created_plant.id
    assert retrieved_plant.name == "Test Plant"


def test_get_plant_by_nonexistent_id(new_db):
    """Test getting a plant with non-existent ID."""
    result = PlantService.get_plant_by_id(999)
    assert result is None


def test_update_plant(new_db):
    """Test updating an existing plant."""
    # Create a plant
    created_plant = PlantService.create_plant(
        PlantCreate(name="Original Name", last_watered_date=date.today() - timedelta(days=5))
    )

    # Update it
    update_data = PlantUpdate(name="Updated Name", last_watered_date=date.today())
    updated_plant = PlantService.update_plant(created_plant.id, update_data)

    assert updated_plant is not None
    assert updated_plant.name == "Updated Name"
    assert updated_plant.last_watered_date == date.today()
    assert updated_plant.updated_at > created_plant.updated_at


def test_update_plant_partial(new_db):
    """Test partial update of a plant."""
    # Create a plant
    original_date = date.today() - timedelta(days=3)
    created_plant = PlantService.create_plant(PlantCreate(name="Original Name", last_watered_date=original_date))

    # Update only the name
    update_data = PlantUpdate(name="Updated Name")
    updated_plant = PlantService.update_plant(created_plant.id, update_data)

    assert updated_plant is not None
    assert updated_plant.name == "Updated Name"
    assert updated_plant.last_watered_date == original_date  # Should remain unchanged


def test_update_nonexistent_plant(new_db):
    """Test updating a plant that doesn't exist."""
    update_data = PlantUpdate(name="Test")
    result = PlantService.update_plant(999, update_data)
    assert result is None


def test_delete_plant(new_db):
    """Test deleting a plant."""
    # Create a plant
    created_plant = PlantService.create_plant(PlantCreate(name="To Delete", last_watered_date=date.today()))

    # Delete it
    success = PlantService.delete_plant(created_plant.id)
    assert success

    # Verify it's gone
    retrieved_plant = PlantService.get_plant_by_id(created_plant.id)
    assert retrieved_plant is None


def test_delete_nonexistent_plant(new_db):
    """Test deleting a plant that doesn't exist."""
    success = PlantService.delete_plant(999)
    assert not success


def test_water_plant_default_date(new_db):
    """Test watering a plant with default date (today)."""
    # Create a plant watered 5 days ago
    old_date = date.today() - timedelta(days=5)
    created_plant = PlantService.create_plant(PlantCreate(name="Thirsty Plant", last_watered_date=old_date))

    # Water it (should use today's date)
    watered_plant = PlantService.water_plant(created_plant.id)

    assert watered_plant is not None
    assert watered_plant.last_watered_date == date.today()


def test_water_plant_specific_date(new_db):
    """Test watering a plant with a specific date."""
    # Create a plant
    created_plant = PlantService.create_plant(
        PlantCreate(name="Test Plant", last_watered_date=date.today() - timedelta(days=10))
    )

    # Water it with a specific date
    water_date = date.today() - timedelta(days=2)
    watered_plant = PlantService.water_plant(created_plant.id, water_date)

    assert watered_plant is not None
    assert watered_plant.last_watered_date == water_date


def test_water_nonexistent_plant(new_db):
    """Test watering a plant that doesn't exist."""
    result = PlantService.water_plant(999)
    assert result is None


def test_plant_mood_calculation(new_db):
    """Test that plant mood is calculated correctly."""
    # Happy plant (watered today)
    happy_plant = PlantService.create_plant(PlantCreate(name="Happy Plant", last_watered_date=date.today()))
    assert happy_plant.mood == PlantMood.HAPPY

    # Normal plant (watered 5 days ago)
    normal_plant = PlantService.create_plant(
        PlantCreate(name="Normal Plant", last_watered_date=date.today() - timedelta(days=5))
    )
    assert normal_plant.mood == PlantMood.NORMAL

    # Thirsty plant (watered 10 days ago)
    thirsty_plant = PlantService.create_plant(
        PlantCreate(name="Thirsty Plant", last_watered_date=date.today() - timedelta(days=10))
    )
    assert thirsty_plant.mood == PlantMood.THIRSTY


def test_days_since_watered_calculation(new_db):
    """Test that days since watered is calculated correctly."""
    # Plant watered 7 days ago
    test_date = date.today() - timedelta(days=7)
    plant = PlantService.create_plant(PlantCreate(name="Test Plant", last_watered_date=test_date))

    assert plant.days_since_watered == 7


def test_create_plant_with_empty_name(new_db):
    """Test creating a plant with empty name should work (validation handled in UI)."""
    plant_data = PlantCreate(name="", last_watered_date=date.today())
    result = PlantService.create_plant(plant_data)
    assert result.name == ""


def test_create_plant_with_future_date(new_db):
    """Test creating a plant with future watered date."""
    future_date = date.today() + timedelta(days=1)
    plant_data = PlantCreate(name="Future Plant", last_watered_date=future_date)
    result = PlantService.create_plant(plant_data)

    assert result.last_watered_date == future_date
    # Future date should result in negative days since watered, making plant happy
    assert result.mood == PlantMood.HAPPY


def test_multiple_plants_ordering(new_db):
    """Test that multiple plants are returned in alphabetical order."""
    # Create plants in non-alphabetical order
    PlantService.create_plant(PlantCreate(name="Zebra Plant", last_watered_date=date.today()))
    PlantService.create_plant(PlantCreate(name="Apple Tree", last_watered_date=date.today()))
    PlantService.create_plant(PlantCreate(name="Basil", last_watered_date=date.today()))

    plants = PlantService.get_all_plants()

    assert len(plants) == 3
    assert plants[0].name == "Apple Tree"
    assert plants[1].name == "Basil"
    assert plants[2].name == "Zebra Plant"
