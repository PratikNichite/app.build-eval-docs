def test_dummy():
    # This is a dummy test to ensure that the testing framework collects the tests correctly.
    assert True
