import pytest
from app.database import reset_db
from app.book_service import create_book, get_book, get_all_books, update_book, delete_book, get_stats
from app.models import BookCreate, BookUpdate, Genre, ReadingStatus


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_create_book(new_db):
    """Test creating a new book."""
    book_data = BookCreate(
        title="The Great Gatsby", author="F. Scott Fitzgerald", genre=Genre.FICTION, reading_status=ReadingStatus.UNREAD
    )

    book = create_book(book_data)

    assert book.id is not None
    assert book.title == "The Great Gatsby"
    assert book.author == "F. Scott Fitzgerald"
    assert book.genre == Genre.FICTION
    assert book.reading_status == ReadingStatus.UNREAD
    assert book.created_at is not None
    assert book.updated_at is not None


def test_create_book_with_default_status(new_db):
    """Test creating a book with default reading status."""
    book_data = BookCreate(title="1984", author="George Orwell", genre=Genre.SCIENCE_FICTION)

    book = create_book(book_data)

    assert book.reading_status == ReadingStatus.UNREAD


def test_get_book_existing(new_db):
    """Test getting an existing book."""
    book_data = BookCreate(
        title="To Kill a Mockingbird", author="Harper Lee", genre=Genre.FICTION, reading_status=ReadingStatus.READ
    )

    created_book = create_book(book_data)
    retrieved_book = get_book(created_book.id)

    assert retrieved_book is not None
    assert retrieved_book.id == created_book.id
    assert retrieved_book.title == "To Kill a Mockingbird"
    assert retrieved_book.author == "Harper Lee"


def test_get_book_nonexistent(new_db):
    """Test getting a non-existent book."""
    book = get_book(999)
    assert book is None


def test_get_all_books_empty(new_db):
    """Test getting all books when database is empty."""
    books = get_all_books()
    assert books == []


def test_get_all_books_multiple(new_db):
    """Test getting all books with multiple entries."""
    # Create test books
    books_data = [
        BookCreate(title="Book 1", author="Author 1", genre=Genre.FICTION),
        BookCreate(title="Book 2", author="Author 2", genre=Genre.MYSTERY),
        BookCreate(title="Book 3", author="Author 3", genre=Genre.FICTION, reading_status=ReadingStatus.READ),
    ]

    for book_data in books_data:
        create_book(book_data)

    all_books = get_all_books()

    assert len(all_books) == 3
    # Should be ordered by creation date (newest first)
    assert all_books[0].title == "Book 3"  # Last created, first in list


def test_search_books_by_title(new_db):
    """Test searching books by title."""
    books_data = [
        BookCreate(title="Python Programming", author="John Doe", genre=Genre.NON_FICTION),
        BookCreate(title="Java Basics", author="Jane Smith", genre=Genre.NON_FICTION),
        BookCreate(title="Advanced Python", author="Bob Wilson", genre=Genre.NON_FICTION),
    ]

    for book_data in books_data:
        create_book(book_data)

    # Search for "Python"
    python_books = get_all_books(search_query="Python")
    assert len(python_books) == 2
    titles = [book.title for book in python_books]
    assert "Python Programming" in titles
    assert "Advanced Python" in titles


def test_search_books_by_author(new_db):
    """Test searching books by author."""
    books_data = [
        BookCreate(title="Book A", author="Stephen King", genre=Genre.HORROR),
        BookCreate(title="Book B", author="King Jr.", genre=Genre.FICTION),
        BookCreate(title="Book C", author="Other Author", genre=Genre.MYSTERY),
    ]

    for book_data in books_data:
        create_book(book_data)

    # Search for "King"
    king_books = get_all_books(search_query="King")
    assert len(king_books) == 2


def test_search_books_case_insensitive(new_db):
    """Test that search is case insensitive."""
    book_data = BookCreate(title="The GREAT Adventure", author="Amazing Writer", genre=Genre.FICTION)
    create_book(book_data)

    # Search with different cases
    results = get_all_books(search_query="great")
    assert len(results) == 1

    results = get_all_books(search_query="ADVENTURE")
    assert len(results) == 1


def test_filter_books_by_genre(new_db):
    """Test filtering books by genre."""
    books_data = [
        BookCreate(title="Horror Book", author="Author 1", genre=Genre.HORROR),
        BookCreate(title="Fiction Book", author="Author 2", genre=Genre.FICTION),
        BookCreate(title="Another Horror", author="Author 3", genre=Genre.HORROR),
    ]

    for book_data in books_data:
        create_book(book_data)

    horror_books = get_all_books(genre_filter=Genre.HORROR)
    assert len(horror_books) == 2

    fiction_books = get_all_books(genre_filter=Genre.FICTION)
    assert len(fiction_books) == 1


def test_filter_books_by_status(new_db):
    """Test filtering books by reading status."""
    books_data = [
        BookCreate(title="Read Book", author="Author 1", genre=Genre.FICTION, reading_status=ReadingStatus.READ),
        BookCreate(title="Reading Book", author="Author 2", genre=Genre.FICTION, reading_status=ReadingStatus.READING),
        BookCreate(title="Unread Book", author="Author 3", genre=Genre.FICTION, reading_status=ReadingStatus.UNREAD),
    ]

    for book_data in books_data:
        create_book(book_data)

    read_books = get_all_books(status_filter=ReadingStatus.READ)
    assert len(read_books) == 1
    assert read_books[0].title == "Read Book"

    reading_books = get_all_books(status_filter=ReadingStatus.READING)
    assert len(reading_books) == 1
    assert reading_books[0].title == "Reading Book"


def test_combined_filters(new_db):
    """Test combining multiple filters."""
    books_data = [
        BookCreate(title="Fiction Read", author="Author 1", genre=Genre.FICTION, reading_status=ReadingStatus.READ),
        BookCreate(title="Fiction Unread", author="Author 2", genre=Genre.FICTION, reading_status=ReadingStatus.UNREAD),
        BookCreate(title="Mystery Read", author="Author 3", genre=Genre.MYSTERY, reading_status=ReadingStatus.READ),
    ]

    for book_data in books_data:
        create_book(book_data)

    # Filter by genre=FICTION and status=READ
    filtered_books = get_all_books(genre_filter=Genre.FICTION, status_filter=ReadingStatus.READ)
    assert len(filtered_books) == 1
    assert filtered_books[0].title == "Fiction Read"


def test_update_book_existing(new_db):
    """Test updating an existing book."""
    book_data = BookCreate(
        title="Original Title", author="Original Author", genre=Genre.FICTION, reading_status=ReadingStatus.UNREAD
    )

    book = create_book(book_data)
    original_updated_at = book.updated_at

    # Update the book
    update_data = BookUpdate(title="Updated Title", reading_status=ReadingStatus.READ)

    updated_book = update_book(book.id, update_data)

    assert updated_book is not None
    assert updated_book.title == "Updated Title"
    assert updated_book.author == "Original Author"  # Should remain unchanged
    assert updated_book.genre == Genre.FICTION  # Should remain unchanged
    assert updated_book.reading_status == ReadingStatus.READ
    assert updated_book.updated_at > original_updated_at


def test_update_book_nonexistent(new_db):
    """Test updating a non-existent book."""
    update_data = BookUpdate(title="New Title")
    result = update_book(999, update_data)
    assert result is None


def test_update_book_partial(new_db):
    """Test partial update of a book."""
    book_data = BookCreate(title="Title", author="Author", genre=Genre.FICTION, reading_status=ReadingStatus.UNREAD)

    book = create_book(book_data)

    # Update only the genre
    update_data = BookUpdate(genre=Genre.MYSTERY)
    updated_book = update_book(book.id, update_data)

    assert updated_book is not None
    assert updated_book.title == "Title"  # Unchanged
    assert updated_book.author == "Author"  # Unchanged
    assert updated_book.genre == Genre.MYSTERY  # Changed
    assert updated_book.reading_status == ReadingStatus.UNREAD  # Unchanged


def test_delete_book_existing(new_db):
    """Test deleting an existing book."""
    book_data = BookCreate(title="To Delete", author="Author", genre=Genre.FICTION)
    book = create_book(book_data)

    # Delete the book
    success = delete_book(book.id)
    assert success

    # Verify it's gone
    deleted_book = get_book(book.id)
    assert deleted_book is None


def test_delete_book_nonexistent(new_db):
    """Test deleting a non-existent book."""
    success = delete_book(999)
    assert not success


def test_get_stats_empty(new_db):
    """Test getting stats from empty library."""
    stats = get_stats()

    assert stats["total"] == 0
    assert stats["read"] == 0
    assert stats["reading"] == 0
    assert stats["unread"] == 0


def test_get_stats_with_books(new_db):
    """Test getting stats with various books."""
    books_data = [
        BookCreate(title="Read Book 1", author="Author", genre=Genre.FICTION, reading_status=ReadingStatus.READ),
        BookCreate(title="Read Book 2", author="Author", genre=Genre.FICTION, reading_status=ReadingStatus.READ),
        BookCreate(title="Reading Book", author="Author", genre=Genre.FICTION, reading_status=ReadingStatus.READING),
        BookCreate(title="Unread Book 1", author="Author", genre=Genre.FICTION, reading_status=ReadingStatus.UNREAD),
        BookCreate(title="Unread Book 2", author="Author", genre=Genre.FICTION, reading_status=ReadingStatus.UNREAD),
        BookCreate(title="Unread Book 3", author="Author", genre=Genre.FICTION, reading_status=ReadingStatus.UNREAD),
    ]

    for book_data in books_data:
        create_book(book_data)

    stats = get_stats()

    assert stats["total"] == 6
    assert stats["read"] == 2
    assert stats["reading"] == 1
    assert stats["unread"] == 3


def test_empty_search_query_handling(new_db):
    """Test that empty/whitespace search queries are handled correctly."""
    book_data = BookCreate(title="Test Book", author="Test Author", genre=Genre.FICTION)
    create_book(book_data)

    # Empty string should return all books
    results = get_all_books(search_query="")
    assert len(results) == 1

    # Whitespace-only string should return all books
    results = get_all_books(search_query="   ")
    assert len(results) == 1

    # None should return all books
    results = get_all_books(search_query=None)
    assert len(results) == 1
