import pytest
from app.database import reset_db


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_book_library_module_import(new_db):
    """Test that the book library module can be imported without errors."""
    from app import book_library

    assert book_library is not None


def test_book_service_integration(new_db):
    """Test that book service integrates correctly with the application."""
    from app.book_service import create_book, get_all_books, get_stats
    from app.models import BookCreate, Genre, ReadingStatus

    # Test creating books
    book_data = BookCreate(
        title="Test Book", author="Test Author", genre=Genre.FICTION, reading_status=ReadingStatus.UNREAD
    )

    book = create_book(book_data)
    assert book.id is not None

    # Test getting all books
    books = get_all_books()
    assert len(books) == 1
    assert books[0].title == "Test Book"

    # Test stats
    stats = get_stats()
    assert stats["total"] == 1
    assert stats["unread"] == 1
    assert stats["read"] == 0
    assert stats["reading"] == 0


def test_application_startup_integration(new_db):
    """Test that the application starts up correctly with book library."""
    from app.startup import startup

    # Should not raise any exceptions
    startup()
