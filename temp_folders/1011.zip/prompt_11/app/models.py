from sqlmodel import SQLModel, Field
from datetime import datetime
from typing import Optional
from enum import Enum


# Enums for controlled values
class ReadingStatus(str, Enum):
    UNREAD = "Unread"
    READING = "Reading"
    READ = "Read"


class Genre(str, Enum):
    FICTION = "Fiction"
    NON_FICTION = "Non-Fiction"
    MYSTERY = "Mystery"
    ROMANCE = "Romance"
    SCIENCE_FICTION = "Science Fiction"
    FANTASY = "Fantasy"
    BIOGRAPHY = "Biography"
    HISTORY = "History"
    SELF_HELP = "Self-Help"
    THRILLER = "Thriller"
    HORROR = "Horror"
    POETRY = "Poetry"
    DRAMA = "Drama"
    PHILOSOPHY = "Philosophy"
    CHILDREN = "Children"
    YOUNG_ADULT = "Young Adult"
    COOKBOOK = "Cookbook"
    TRAVEL = "Travel"
    HEALTH = "Health"
    BUSINESS = "Business"
    OTHER = "Other"


# Persistent models (stored in database)
class Book(SQLModel, table=True):
    __tablename__ = "books"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    title: str = Field(max_length=500, index=True)
    author: str = Field(max_length=300, index=True)
    genre: Genre = Field(index=True)
    reading_status: ReadingStatus = Field(default=ReadingStatus.UNREAD, index=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class BookCreate(SQLModel, table=False):
    title: str = Field(max_length=500, min_length=1)
    author: str = Field(max_length=300, min_length=1)
    genre: Genre
    reading_status: ReadingStatus = Field(default=ReadingStatus.UNREAD)


class BookUpdate(SQLModel, table=False):
    title: Optional[str] = Field(default=None, max_length=500, min_length=1)
    author: Optional[str] = Field(default=None, max_length=300, min_length=1)
    genre: Optional[Genre] = Field(default=None)
    reading_status: Optional[ReadingStatus] = Field(default=None)


class BookRead(SQLModel, table=False):
    id: int
    title: str
    author: str
    genre: Genre
    reading_status: ReadingStatus
    created_at: datetime
    updated_at: datetime
