from typing import Optional
from sqlmodel import select, or_
from app.database import get_session
from app.models import Book, BookCreate, BookUpdate, Genre, ReadingStatus
from datetime import datetime


def create_book(book_data: BookCreate) -> Book:
    """Create a new book in the database."""
    with get_session() as session:
        book = Book(
            title=book_data.title,
            author=book_data.author,
            genre=book_data.genre,
            reading_status=book_data.reading_status,
        )
        session.add(book)
        session.commit()
        session.refresh(book)
        return book


def get_book(book_id: int) -> Optional[Book]:
    """Get a book by ID."""
    with get_session() as session:
        return session.get(Book, book_id)


def get_all_books(
    search_query: Optional[str] = None,
    genre_filter: Optional[Genre] = None,
    status_filter: Optional[ReadingStatus] = None,
) -> list[Book]:
    """Get all books with optional filtering."""
    with get_session() as session:
        statement = select(Book)

        # Apply search filter (searches in title and author)
        if search_query:
            search_query = search_query.strip()
            if search_query:
                statement = statement.where(
                    or_(Book.title.ilike(f"%{search_query}%"), Book.author.ilike(f"%{search_query}%"))
                )

        # Apply genre filter
        if genre_filter:
            statement = statement.where(Book.genre == genre_filter)

        # Apply status filter
        if status_filter:
            statement = statement.where(Book.reading_status == status_filter)

        # Order by creation date (newest first)
        statement = statement.order_by(Book.created_at.desc())

        return session.exec(statement).all()


def update_book(book_id: int, book_data: BookUpdate) -> Optional[Book]:
    """Update an existing book."""
    with get_session() as session:
        book = session.get(Book, book_id)
        if book is None:
            return None

        # Update only provided fields
        if book_data.title is not None:
            book.title = book_data.title
        if book_data.author is not None:
            book.author = book_data.author
        if book_data.genre is not None:
            book.genre = book_data.genre
        if book_data.reading_status is not None:
            book.reading_status = book_data.reading_status

        book.updated_at = datetime.utcnow()
        session.add(book)
        session.commit()
        session.refresh(book)
        return book


def delete_book(book_id: int) -> bool:
    """Delete a book by ID. Returns True if successful, False if not found."""
    with get_session() as session:
        book = session.get(Book, book_id)
        if book is None:
            return False

        session.delete(book)
        session.commit()
        return True


def get_stats() -> dict[str, int]:
    """Get library statistics."""
    with get_session() as session:
        total_books = session.exec(select(Book)).all()

        stats = {
            "total": len(total_books),
            "read": len([b for b in total_books if b.reading_status == ReadingStatus.READ]),
            "reading": len([b for b in total_books if b.reading_status == ReadingStatus.READING]),
            "unread": len([b for b in total_books if b.reading_status == ReadingStatus.UNREAD]),
        }
        return stats
