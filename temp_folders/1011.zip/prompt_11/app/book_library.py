from nicegui import ui
from typing import Optional
from app.models import Genre, ReadingStatus, BookCreate, BookUpdate
from app.book_service import create_book, get_all_books, get_book, update_book, delete_book, get_stats


def create():
    # Apply modern theme
    ui.colors(
        primary="#2563eb",
        secondary="#64748b",
        accent="#10b981",
        positive="#10b981",
        negative="#ef4444",
        warning="#f59e0b",
        info="#3b82f6",
    )

    @ui.page("/")
    def library_page():
        def create_stat_card(title: str, value: str, icon: str, color: str):
            """Create a statistics card."""
            with ui.card().classes(f"p-4 text-white {color} min-w-32"):
                ui.label(icon).classes("text-2xl mb-1")
                ui.label(value).classes("text-2xl font-bold")
                ui.label(title).classes("text-sm opacity-90")

        def create_book_card(book, refresh_callback):
            """Create a card for displaying a book."""
            with ui.card().classes("w-full p-4 hover:shadow-lg transition-shadow"):
                with ui.row().classes("w-full items-start justify-between"):
                    # Book info
                    with ui.column().classes("flex-1"):
                        ui.label(book.title).classes("text-xl font-bold text-gray-800 mb-1")
                        ui.label(f"by {book.author}").classes("text-lg text-gray-600 mb-2")

                        with ui.row().classes("gap-2 items-center"):
                            # Genre badge
                            ui.badge(book.genre.value).classes("bg-blue-100 text-blue-800")

                            # Status badge
                            status_colors = {
                                ReadingStatus.READ: "bg-green-100 text-green-800",
                                ReadingStatus.READING: "bg-yellow-100 text-yellow-800",
                                ReadingStatus.UNREAD: "bg-gray-100 text-gray-800",
                            }
                            ui.badge(book.reading_status.value).classes(status_colors[book.reading_status])

                    # Action buttons
                    with ui.column().classes("gap-2"):
                        ui.button(icon="edit", on_click=lambda book_id=book.id: open_book_form(book_id)).classes(
                            "bg-blue-500 text-white"
                        ).props("flat round")

                        ui.button(
                            icon="delete",
                            on_click=lambda book_id=book.id: confirm_delete_book(book_id, refresh_callback),
                        ).classes("bg-red-500 text-white").props("flat round")

        async def confirm_delete_book(book_id: int, refresh_callback):
            """Show confirmation dialog for book deletion."""
            book = get_book(book_id)
            if book is None:
                ui.notify("Book not found", type="negative")
                return

            with ui.dialog() as dialog, ui.card():
                ui.label("Confirm Deletion").classes("text-xl font-bold mb-4")
                ui.label(f'Are you sure you want to delete "{book.title}"?').classes("mb-4")
                ui.label("This action cannot be undone.").classes("text-red-500 mb-6")

                with ui.row().classes("gap-2 justify-end"):
                    ui.button("Cancel", on_click=lambda: dialog.submit(False)).props("flat")
                    ui.button("Delete", on_click=lambda: dialog.submit(True)).classes("bg-red-500 text-white")

            result = await dialog
            if result:
                success = delete_book(book_id)
                if success:
                    ui.notify(f'"{book.title}" has been deleted', type="positive")
                    refresh_callback()
                else:
                    ui.notify("Failed to delete book", type="negative")

        async def open_book_form(book_id: Optional[int] = None):
            """Open the add/edit book form dialog."""
            is_edit = book_id is not None
            book = get_book(book_id) if is_edit else None

            if is_edit and book is None:
                ui.notify("Book not found", type="negative")
                return

            with ui.dialog() as dialog, ui.card().classes("w-96"):
                ui.label("Edit Book" if is_edit else "Add New Book").classes("text-xl font-bold mb-4")

                # Form fields
                title_input = (
                    ui.input(label="Title", value=book.title if book else "", placeholder="Enter book title")
                    .classes("w-full mb-2")
                    .props("outlined")
                )

                author_input = (
                    ui.input(label="Author", value=book.author if book else "", placeholder="Enter author name")
                    .classes("w-full mb-2")
                    .props("outlined")
                )

                genre_select = (
                    ui.select(
                        options=[g.value for g in Genre],
                        label="Genre",
                        value=book.genre.value if book else Genre.FICTION.value,
                    )
                    .classes("w-full mb-2")
                    .props("outlined")
                )

                status_select = (
                    ui.select(
                        options=[s.value for s in ReadingStatus],
                        label="Reading Status",
                        value=book.reading_status.value if book else ReadingStatus.UNREAD.value,
                    )
                    .classes("w-full mb-4")
                    .props("outlined")
                )

                # Form validation
                def validate_form():
                    return (
                        title_input.value
                        and title_input.value.strip()
                        and author_input.value
                        and author_input.value.strip()
                    )

                # Action buttons
                with ui.row().classes("gap-2 justify-end w-full"):
                    ui.button("Cancel", on_click=lambda: dialog.submit(None)).props("flat")
                    ui.button(
                        "Update" if is_edit else "Add Book",
                        on_click=lambda: dialog.submit("save") if validate_form() else None,
                    ).classes("bg-primary text-white")

            result = await dialog
            if result == "save":
                if not validate_form():
                    ui.notify("Please fill in all required fields", type="negative")
                    return

                try:
                    if is_edit:
                        # Update existing book
                        book_data = BookUpdate(
                            title=title_input.value.strip(),
                            author=author_input.value.strip(),
                            genre=Genre(genre_select.value),
                            reading_status=ReadingStatus(status_select.value),
                        )
                        updated_book = update_book(book_id, book_data)
                        if updated_book:
                            ui.notify("Book updated successfully!", type="positive")
                        else:
                            ui.notify("Failed to update book", type="negative")
                    else:
                        # Create new book
                        book_data = BookCreate(
                            title=title_input.value.strip(),
                            author=author_input.value.strip(),
                            genre=Genre(genre_select.value),
                            reading_status=ReadingStatus(status_select.value),
                        )
                        create_book(book_data)
                        ui.notify("Book added successfully!", type="positive")

                    # Refresh the page to show updated data
                    ui.navigate.reload()

                except Exception as e:
                    ui.notify(f"Error: {str(e)}", type="negative")

        # Page header
        with ui.card().classes("w-full p-6 mb-6 bg-gradient-to-r from-blue-50 to-indigo-100"):
            ui.label("Welcome to your awesome Book Library! 📚✨").classes("text-3xl font-bold text-gray-800 mb-2")
            ui.label("Organize and track your reading journey").classes("text-lg text-gray-600")

        # Stats cards
        stats = get_stats()
        with ui.row().classes("gap-4 w-full mb-6"):
            create_stat_card("Total Books", str(stats["total"]), "📚", "bg-blue-500")
            create_stat_card("Read", str(stats["read"]), "✅", "bg-green-500")
            create_stat_card("Reading", str(stats["reading"]), "📖", "bg-yellow-500")
            create_stat_card("Unread", str(stats["unread"]), "⏳", "bg-gray-500")

        # Controls section
        with ui.card().classes("w-full p-4 mb-6"):
            with ui.row().classes("w-full items-end gap-4"):
                # Search input
                search_input = (
                    ui.input(placeholder="Search by title or author...").classes("flex-1").props("outlined clearable")
                )

                # Genre filter
                genre_select = (
                    ui.select(options=["All Genres"] + [g.value for g in Genre], value="All Genres", label="Genre")
                    .classes("w-48")
                    .props("outlined")
                )

                # Status filter
                status_select = (
                    ui.select(
                        options=["All Status"] + [s.value for s in ReadingStatus], value="All Status", label="Status"
                    )
                    .classes("w-48")
                    .props("outlined")
                )

                # Add book button
                ui.button("Add New Book", on_click=lambda: open_book_form(), icon="add").classes(
                    "bg-primary text-white px-6 py-2"
                ).props("unelevated")

        # Books container
        books_container = ui.column().classes("w-full gap-4")

        def refresh_books():
            """Refresh the books display with current filters."""
            books_container.clear()

            # Get filter values
            search_query = search_input.value if search_input.value else None
            genre_filter = None if genre_select.value == "All Genres" else Genre(genre_select.value)
            status_filter = None if status_select.value == "All Status" else ReadingStatus(status_select.value)

            books = get_all_books(search_query, genre_filter, status_filter)

            with books_container:
                if not books:
                    with ui.card().classes("w-full p-8 text-center"):
                        ui.icon("search_off").classes("text-6xl text-gray-400 mb-4")
                        ui.label("No books found").classes("text-xl text-gray-500 mb-2")
                        ui.label("Try adjusting your search or filters").classes("text-gray-400")
                else:
                    for book in books:
                        create_book_card(book, refresh_books)

        # Set up reactive updates
        search_input.on("input", lambda: refresh_books())
        genre_select.on("update:model-value", lambda: refresh_books())
        status_select.on("update:model-value", lambda: refresh_books())

        # Initial load
        refresh_books()
