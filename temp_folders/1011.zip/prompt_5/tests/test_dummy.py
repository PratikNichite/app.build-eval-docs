import pytest
from nicegui.testing import User
from app.database import reset_db
from app.currency_service import currency_service


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


@pytest.mark.asyncio
async def test_basic_ui_functionality(user: User, new_db) -> None:
    """Basic test that UI loads correctly."""
    # Test UI loads and displays correctly
    await user.open("/")
    await user.should_see("Currency Converter")
    await user.should_see("Convert currencies using real-time exchange rates")

    # UI should have proper form elements
    await user.should_see("Amount")
    await user.should_see("From Currency")
    await user.should_see("To Currency")
    await user.should_see("Convert")


def test_service_initialization():
    """Test that the currency service initializes correctly."""

    # Service should be initialized
    assert currency_service is not None
    assert hasattr(currency_service, "client")
    assert hasattr(currency_service, "BASE_URL")
    assert currency_service.BASE_URL == "https://api.frankfurter.app"
