import pytest
from decimal import Decimal
from datetime import datetime
from pydantic import ValidationError

from app.models import (
    ConversionRequest,
    ConversionResponse,
    CurrencyCreate,
    CurrencyUpdate,
    ExchangeRateCreate,
    UserPreferencesCreate,
    UserPreferencesUpdate,
)


class TestCurrencyModels:
    """Test currency-related model validation."""

    def test_conversion_request_valid(self):
        """Test valid conversion request creation."""
        request = ConversionRequest(source_currency_code="USD", target_currency_code="EUR", amount=Decimal("100.50"))

        assert request.source_currency_code == "USD"
        assert request.target_currency_code == "EUR"
        assert request.amount == Decimal("100.50")

    def test_conversion_request_invalid_amount(self):
        """Test conversion request with invalid amount."""
        # Zero amount should be invalid
        with pytest.raises(ValidationError):
            ConversionRequest(source_currency_code="USD", target_currency_code="EUR", amount=Decimal("0"))

        # Negative amount should be invalid
        with pytest.raises(ValidationError):
            ConversionRequest(source_currency_code="USD", target_currency_code="EUR", amount=Decimal("-10.50"))

    def test_conversion_request_invalid_currency_code(self):
        """Test conversion request with invalid currency codes."""
        # Note: The current model doesn't enforce max_length on currency codes in ConversionRequest
        # This test documents the current behavior - currency codes are validated elsewhere

        # Empty currency code should be invalid (required field)
        with pytest.raises(ValidationError):
            ConversionRequest(target_currency_code="EUR", amount=Decimal("100.00"))  # Missing source_currency_code

    def test_conversion_response_creation(self):
        """Test conversion response creation."""
        response = ConversionResponse(
            source_currency_code="USD",
            target_currency_code="EUR",
            source_amount=Decimal("100.00"),
            target_amount=Decimal("85.50"),
            exchange_rate=Decimal("0.8550"),
            conversion_date=datetime.utcnow(),
            api_source="frankfurter",
        )

        assert response.source_currency_code == "USD"
        assert response.target_currency_code == "EUR"
        assert response.source_amount == Decimal("100.00")
        assert response.target_amount == Decimal("85.50")
        assert response.exchange_rate == Decimal("0.8550")
        assert response.api_source == "frankfurter"

    def test_currency_create_valid(self):
        """Test valid currency creation schema."""
        currency = CurrencyCreate(code="USD", name="US Dollar", symbol="$", is_active=True)

        assert currency.code == "USD"
        assert currency.name == "US Dollar"
        assert currency.symbol == "$"
        assert currency.is_active is True

    def test_currency_create_defaults(self):
        """Test currency creation with default values."""
        currency = CurrencyCreate(code="EUR", name="Euro")

        assert currency.code == "EUR"
        assert currency.name == "Euro"
        assert currency.symbol == ""  # Default empty string
        assert currency.is_active is True  # Default True

    def test_currency_create_invalid_code(self):
        """Test currency creation with invalid code."""
        # Empty code should be invalid (required field)
        with pytest.raises(ValidationError):
            CurrencyCreate(name="Euro")  # Missing required code field

    def test_currency_update_partial(self):
        """Test currency update with partial data."""
        update = CurrencyUpdate(name="Updated Euro Name")

        assert update.name == "Updated Euro Name"
        assert update.symbol is None  # Not provided
        assert update.is_active is None  # Not provided

    def test_exchange_rate_create_valid(self):
        """Test valid exchange rate creation."""
        rate = ExchangeRateCreate(
            from_currency_code="USD", to_currency_code="EUR", rate=Decimal("0.8550"), date=datetime.utcnow()
        )

        assert rate.from_currency_code == "USD"
        assert rate.to_currency_code == "EUR"
        assert rate.rate == Decimal("0.8550")
        assert rate.date is not None

    def test_exchange_rate_create_invalid_rate(self):
        """Test exchange rate creation with invalid rate."""
        # Zero rate should be invalid
        with pytest.raises(ValidationError):
            ExchangeRateCreate(from_currency_code="USD", to_currency_code="EUR", rate=Decimal("0"))

        # Negative rate should be invalid
        with pytest.raises(ValidationError):
            ExchangeRateCreate(from_currency_code="USD", to_currency_code="EUR", rate=Decimal("-0.8550"))

    def test_user_preferences_create_valid(self):
        """Test valid user preferences creation."""
        prefs = UserPreferencesCreate(
            session_id="test-session-123",
            default_source_currency="USD",
            default_target_currency="EUR",
            favorite_currencies=["USD", "EUR", "GBP"],
            decimal_places=4,
        )

        assert prefs.session_id == "test-session-123"
        assert prefs.default_source_currency == "USD"
        assert prefs.default_target_currency == "EUR"
        assert prefs.favorite_currencies == ["USD", "EUR", "GBP"]
        assert prefs.decimal_places == 4

    def test_user_preferences_create_defaults(self):
        """Test user preferences creation with defaults."""
        prefs = UserPreferencesCreate(session_id="test-session-123")

        assert prefs.session_id == "test-session-123"
        assert prefs.default_source_currency is None
        assert prefs.default_target_currency is None
        assert prefs.favorite_currencies == []
        assert prefs.decimal_places == 2  # Default

    def test_user_preferences_invalid_decimal_places(self):
        """Test user preferences with invalid decimal places."""
        # Too many decimal places
        with pytest.raises(ValidationError):
            UserPreferencesCreate(
                session_id="test-session-123",
                decimal_places=10,  # Max is 8
            )

        # Negative decimal places
        with pytest.raises(ValidationError):
            UserPreferencesCreate(session_id="test-session-123", decimal_places=-1)

    def test_user_preferences_update_partial(self):
        """Test user preferences update with partial data."""
        update = UserPreferencesUpdate(default_source_currency="GBP", decimal_places=3)

        assert update.default_source_currency == "GBP"
        assert update.default_target_currency is None  # Not provided
        assert update.favorite_currencies is None  # Not provided
        assert update.decimal_places == 3

    def test_decimal_precision_handling(self):
        """Test that decimal values are handled with proper precision."""
        # Test high precision rate
        rate = ExchangeRateCreate(
            from_currency_code="BTC",
            to_currency_code="USD",
            rate=Decimal("45123.12345678"),  # 8 decimal places
        )

        assert rate.rate == Decimal("45123.12345678")

        # Test conversion with high precision
        request = ConversionRequest(
            source_currency_code="BTC",
            target_currency_code="USD",
            amount=Decimal("0.00123456"),  # 8 decimal places
        )

        assert request.amount == Decimal("0.00123456")

    def test_currency_code_case_sensitivity(self):
        """Test that currency codes maintain case."""
        request = ConversionRequest(
            source_currency_code="usd",  # lowercase
            target_currency_code="EUR",  # uppercase
            amount=Decimal("100.00"),
        )

        # Should maintain exact case as provided
        assert request.source_currency_code == "usd"
        assert request.target_currency_code == "EUR"

    def test_large_amounts(self):
        """Test handling of large conversion amounts."""
        # Test very large amount
        request = ConversionRequest(
            source_currency_code="USD",
            target_currency_code="EUR",
            amount=Decimal("999999999.99999999"),  # Large amount with precision
        )

        assert request.amount == Decimal("999999999.99999999")

        # Test very small amount
        small_request = ConversionRequest(
            source_currency_code="USD",
            target_currency_code="EUR",
            amount=Decimal("0.00000001"),  # Very small but positive
        )

        assert small_request.amount == Decimal("0.00000001")

    def test_session_id_validation(self):
        """Test session ID validation in user preferences."""
        # Valid long session ID
        prefs = UserPreferencesCreate(
            session_id="a" * 255  # Max length
        )
        assert len(prefs.session_id) == 255

        # Too long session ID should fail
        with pytest.raises(ValidationError):
            UserPreferencesCreate(
                session_id="a" * 256  # Too long
            )
