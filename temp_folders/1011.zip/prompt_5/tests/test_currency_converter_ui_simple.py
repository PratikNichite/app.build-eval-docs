import pytest
from nicegui.testing import User
from app.database import reset_db


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


class TestCurrencyConverterUISimple:
    """Simplified UI tests that focus on static content."""

    @pytest.mark.asyncio
    async def test_page_basic_structure(self, user: User, new_db) -> None:
        """Test that the currency converter page has basic structure."""
        await user.open("/")

        # Check main headings exist
        await user.should_see("Currency Converter")
        await user.should_see("Convert currencies using real-time exchange rates")

        # Check form sections exist
        await user.should_see("Convert Currency")
        await user.should_see("Amount")
        await user.should_see("From Currency")
        await user.should_see("To Currency")

        # Check result and history sections exist
        await user.should_see("Conversion Result")
        await user.should_see("Conversion History")

    @pytest.mark.asyncio
    async def test_form_elements_exist(self, user: User, new_db) -> None:
        """Test that form elements are present."""
        await user.open("/")

        # Check for Convert button
        await user.should_see("Convert")

        # The page should render without errors
        # Specific form functionality is tested in service layer tests
