import pytest
from decimal import Decimal
from app.currency_service import CurrencyService
from app.models import ConversionRequest
from app.database import reset_db


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


@pytest.fixture()
def currency_service():
    return CurrencyService()


class TestCurrencyService:
    """Test currency service functionality."""

    @pytest.mark.asyncio
    async def test_get_available_currencies(self, currency_service: CurrencyService):
        """Test fetching available currencies from API."""
        currencies = await currency_service.get_available_currencies()

        # Should return a dictionary with currency codes and names
        assert isinstance(currencies, dict)
        assert len(currencies) > 0

        # Check for common currencies
        assert "USD" in currencies
        assert "EUR" in currencies
        assert "GBP" in currencies

        # Check values are strings (currency names)
        for code, name in currencies.items():
            assert isinstance(code, str)
            assert isinstance(name, str)
            assert len(code) == 3  # ISO 4217 codes are 3 characters

    @pytest.mark.asyncio
    async def test_get_exchange_rate_same_currency(self, currency_service: CurrencyService):
        """Test exchange rate for same currency should be 1.0."""
        rate = await currency_service.get_exchange_rate("USD", "USD")
        assert rate == Decimal("1.0")

    @pytest.mark.asyncio
    async def test_get_exchange_rate_different_currencies(self, currency_service: CurrencyService):
        """Test exchange rate between different currencies."""
        rate = await currency_service.get_exchange_rate("USD", "EUR")

        # Should return a positive decimal
        assert isinstance(rate, Decimal)
        assert rate > Decimal("0")

        # Should be reasonable (between 0.1 and 10 for major currencies)
        assert Decimal("0.1") <= rate <= Decimal("10")

    @pytest.mark.asyncio
    async def test_get_exchange_rate_invalid_currency(self, currency_service: CurrencyService):
        """Test exchange rate with invalid currency code."""
        with pytest.raises(Exception):
            await currency_service.get_exchange_rate("USD", "INVALID")

    @pytest.mark.asyncio
    async def test_convert_currency_basic(self, new_db, currency_service: CurrencyService):
        """Test basic currency conversion."""
        request = ConversionRequest(source_currency_code="USD", target_currency_code="EUR", amount=Decimal("100.00"))

        response = await currency_service.convert_currency(request, "test-session")

        # Check response structure
        assert response.source_currency_code == "USD"
        assert response.target_currency_code == "EUR"
        assert response.source_amount == Decimal("100.00")
        assert response.target_amount > Decimal("0")
        assert response.exchange_rate > Decimal("0")
        assert response.api_source == "frankfurter"

        # Target amount should be source amount * exchange rate
        expected_target = response.source_amount * response.exchange_rate
        assert abs(response.target_amount - expected_target) < Decimal("0.0001")

    @pytest.mark.asyncio
    async def test_convert_currency_same_currency(self, new_db, currency_service: CurrencyService):
        """Test converting same currency."""
        request = ConversionRequest(source_currency_code="USD", target_currency_code="USD", amount=Decimal("50.00"))

        response = await currency_service.convert_currency(request)

        assert response.source_amount == Decimal("50.00")
        assert response.target_amount == Decimal("50.00")
        assert response.exchange_rate == Decimal("1.0")

    @pytest.mark.asyncio
    async def test_convert_currency_creates_history(self, new_db, currency_service: CurrencyService):
        """Test that conversion creates history record."""
        request = ConversionRequest(source_currency_code="USD", target_currency_code="EUR", amount=Decimal("25.00"))

        await currency_service.convert_currency(request, "test-session")

        # Check history was created
        history = await currency_service.get_conversion_history("test-session")
        assert len(history) == 1

        record = history[0]
        assert record.source_currency.code == "USD"
        assert record.target_currency.code == "EUR"
        assert record.source_amount == Decimal("25.00")
        assert record.user_session == "test-session"

    @pytest.mark.asyncio
    async def test_get_conversion_history_empty(self, new_db, currency_service: CurrencyService):
        """Test getting history for session with no conversions."""
        history = await currency_service.get_conversion_history("empty-session")
        assert history == []

    @pytest.mark.asyncio
    async def test_get_conversion_history_limit(self, new_db, currency_service: CurrencyService):
        """Test history limit functionality."""
        # Create multiple conversions
        for i in range(15):
            request = ConversionRequest(
                source_currency_code="USD", target_currency_code="EUR", amount=Decimal(str(i + 1))
            )
            await currency_service.convert_currency(request, "test-session")

        # Check default limit (10)
        history = await currency_service.get_conversion_history("test-session")
        assert len(history) == 10

        # Check custom limit
        history_limited = await currency_service.get_conversion_history("test-session", limit=5)
        assert len(history_limited) == 5

        # Should be in descending order (newest first)
        assert history[0].source_amount > history[1].source_amount

    def test_get_currency_symbol(self, currency_service: CurrencyService):
        """Test currency symbol mapping."""
        assert currency_service._get_currency_symbol("USD") == "$"
        assert currency_service._get_currency_symbol("EUR") == "€"
        assert currency_service._get_currency_symbol("GBP") == "£"
        assert currency_service._get_currency_symbol("JPY") == "¥"

        # Unknown currency should return the code itself
        assert currency_service._get_currency_symbol("XYZ") == "XYZ"

    @pytest.mark.asyncio
    async def test_ensure_currency_exists(self, new_db, currency_service: CurrencyService):
        """Test currency creation in database."""
        from app.database import get_session
        from app.models import Currency
        from sqlmodel import select

        with get_session() as db:
            # Should not exist initially
            currency = db.exec(select(Currency).where(Currency.code == "USD")).first()
            assert currency is None

            # After calling ensure_currency_exists
            await currency_service._ensure_currency_exists(db, "USD")

            # Should now exist
            currency = db.exec(select(Currency).where(Currency.code == "USD")).first()
            assert currency is not None
            assert currency.code == "USD"
            assert currency.name  # Should have a name
            assert currency.is_active

    @pytest.mark.asyncio
    async def test_multiple_conversions_different_sessions(self, new_db, currency_service: CurrencyService):
        """Test that different sessions have separate histories."""
        request1 = ConversionRequest(source_currency_code="USD", target_currency_code="EUR", amount=Decimal("100.00"))
        request2 = ConversionRequest(source_currency_code="GBP", target_currency_code="USD", amount=Decimal("200.00"))

        await currency_service.convert_currency(request1, "session-1")
        await currency_service.convert_currency(request2, "session-2")

        history1 = await currency_service.get_conversion_history("session-1")
        history2 = await currency_service.get_conversion_history("session-2")

        assert len(history1) == 1
        assert len(history2) == 1
        assert history1[0].source_currency.code == "USD"
        assert history2[0].source_currency.code == "GBP"
