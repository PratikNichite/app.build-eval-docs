import pytest
from nicegui.testing import User
from nicegui import ui
from app.database import reset_db


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


class TestCurrencyConverterUI:
    """Test currency converter UI functionality."""

    @pytest.mark.asyncio
    async def test_page_loads(self, user: User, new_db) -> None:
        """Test that the currency converter page loads correctly."""
        await user.open("/")

        # Check page title and description
        await user.should_see("Currency Converter")
        await user.should_see("Convert currencies using real-time exchange rates")

        # Check main form elements exist
        await user.should_see("Amount")
        await user.should_see("From Currency")
        await user.should_see("To Currency")
        await user.should_see("Convert")

        # Check result and history sections
        await user.should_see("Conversion Result")
        await user.should_see("Conversion History")

    @pytest.mark.asyncio
    async def test_form_elements_structure(self, user: User, new_db) -> None:
        """Test that form elements have correct structure."""
        await user.open("/")

        # Check that input elements exist
        number_inputs = list(user.find(ui.number).elements)
        select_inputs = list(user.find(ui.select).elements)
        buttons = list(user.find(ui.button).elements)

        assert len(number_inputs) >= 1  # Amount input
        assert len(select_inputs) >= 2  # Source and target currency selects
        assert len(buttons) >= 1  # Convert button

    @pytest.mark.asyncio
    async def test_cards_layout(self, user: User, new_db) -> None:
        """Test that the page has proper card layout."""
        await user.open("/")

        # Check that cards exist for main sections
        cards = list(user.find(ui.card).elements)
        assert len(cards) >= 2  # Main conversion card + history card

    @pytest.mark.asyncio
    async def test_table_exists(self, user: User, new_db) -> None:
        """Test that history table exists."""
        await user.open("/")

        # Find history table
        tables = list(user.find(ui.table).elements)
        assert len(tables) >= 1

        history_table = tables[0]
        assert hasattr(history_table, "columns")
        assert hasattr(history_table, "rows")
