from decimal import Decimal
from typing import Dict, List
from nicegui import ui, app
from nicegui.events import ValueChangeEventArguments

from app.currency_service import currency_service
from app.models import ConversionRequest, ConversionResponse


class CurrencyConverterUI:
    """Main currency converter UI component."""

    def __init__(self):
        self.available_currencies: Dict[str, str] = {}
        self.currency_options: List[str] = []
        self.source_currency = ui.select(options=[], value=None)
        self.target_currency = ui.select(options=[], value=None)
        self.amount_input = ui.number(value=1.0, min=0.01, step=0.01)
        self.result_label = ui.label("")
        self.rate_label = ui.label("")
        self.loading_spinner = ui.spinner(size="lg")
        self.history_table = ui.table(columns=[], rows=[])
        self.error_label = ui.label("")

    async def initialize(self):
        """Initialize the component by fetching available currencies."""
        try:
            self.available_currencies = await currency_service.get_available_currencies()
            self.currency_options = [f"{code} - {name}" for code, name in sorted(self.available_currencies.items())]

            # Update select options
            self.source_currency.set_options(self.currency_options)
            self.target_currency.set_options(self.currency_options)

            # Set default values - use the first two different options available
            if len(self.currency_options) >= 2:
                self.source_currency.set_value(self.currency_options[0])
                self.target_currency.set_value(self.currency_options[1])
            elif len(self.currency_options) >= 1:
                self.source_currency.set_value(self.currency_options[0])

        except Exception as e:
            self.show_error(f"Failed to load currencies: {str(e)}")

    def _extract_currency_code(self, option: str) -> str:
        """Extract currency code from select option."""
        return option.split(" - ")[0] if " - " in option else option

    async def convert(self):
        """Perform currency conversion."""
        try:
            self.clear_error()
            self.loading_spinner.set_visibility(True)

            # Validate inputs
            if not self.amount_input.value or self.amount_input.value <= 0:
                self.show_error("Please enter a valid amount")
                return

            if not self.source_currency.value or not self.target_currency.value:
                self.show_error("Please select both currencies")
                return

            source_code = self._extract_currency_code(self.source_currency.value)
            target_code = self._extract_currency_code(self.target_currency.value)

            if source_code == target_code:
                self.show_error("Source and target currencies must be different")
                return

            # Get session ID for history tracking
            await ui.context.client.connected()
            session_id = app.storage.user.get("session_id")
            if not session_id:
                import uuid

                session_id = str(uuid.uuid4())
                app.storage.user["session_id"] = session_id

            # Create conversion request
            request = ConversionRequest(
                source_currency_code=source_code,
                target_currency_code=target_code,
                amount=Decimal(str(self.amount_input.value)),
            )

            # Perform conversion
            response = await currency_service.convert_currency(request, session_id)

            # Display results
            self.display_result(response)

            # Update history
            await self.update_history()

        except Exception as e:
            self.show_error(f"Conversion failed: {str(e)}")
        finally:
            self.loading_spinner.set_visibility(False)

    def display_result(self, response: ConversionResponse):
        """Display conversion result."""
        source_symbol = currency_service._get_currency_symbol(response.source_currency_code)
        target_symbol = currency_service._get_currency_symbol(response.target_currency_code)

        # Format amounts with appropriate decimal places
        source_amount = f"{source_symbol}{response.source_amount:,.2f}"
        target_amount = f"{target_symbol}{response.target_amount:,.2f}"

        self.result_label.set_text(f"✅ {source_amount} = {target_amount}")
        self.rate_label.set_text(
            f"Exchange rate: 1 {response.source_currency_code} = {response.exchange_rate:.4f} {response.target_currency_code}"
        )

    async def update_history(self):
        """Update conversion history table."""
        try:
            await ui.context.client.connected()
            session_id = app.storage.user.get("session_id")
            if not session_id:
                return

            history = await currency_service.get_conversion_history(session_id, limit=10)

            # Prepare table data
            columns = [
                {"name": "date", "label": "Date", "field": "date", "align": "left"},
                {"name": "from", "label": "From", "field": "from", "align": "center"},
                {"name": "to", "label": "To", "field": "to", "align": "center"},
                {"name": "rate", "label": "Rate", "field": "rate", "align": "right"},
            ]

            rows = []
            for item in history:
                source_symbol = currency_service._get_currency_symbol(item.source_currency.code)
                target_symbol = currency_service._get_currency_symbol(item.target_currency.code)

                rows.append(
                    {
                        "date": item.conversion_date.strftime("%Y-%m-%d %H:%M"),
                        "from": f"{source_symbol}{item.source_amount:,.2f} {item.source_currency.code}",
                        "to": f"{target_symbol}{item.target_amount:,.2f} {item.target_currency.code}",
                        "rate": f"{item.exchange_rate:.4f}",
                    }
                )

            self.history_table.columns = columns
            self.history_table.rows = rows

        except Exception as e:
            self.show_error(f"Failed to load history: {str(e)}")

    def show_error(self, message: str):
        """Show error message."""
        self.error_label.set_text(f"❌ Error: {message}")
        self.error_label.set_visibility(True)
        ui.notify(f"❌ {message}", type="negative")

    def clear_error(self):
        """Clear error message."""
        self.error_label.set_text("")
        self.error_label.set_visibility(False)

    async def on_currency_change(self):
        """Handle currency selection change."""
        # Auto-convert if amount is entered
        if self.amount_input.value and self.amount_input.value > 0:
            await self.convert()

    async def on_amount_change(self, e: ValueChangeEventArguments):
        """Handle amount input change."""
        # Auto-convert after a short delay to avoid too many API calls
        import asyncio

        await asyncio.sleep(0.5)  # Debounce
        if e.sender.value and e.sender.value > 0:
            await self.convert()


def create():
    """Create the currency converter application."""

    @ui.page("/")
    async def converter_page():
        # Apply modern theme
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        # Page header
        ui.label("💰 Currency Converter 💱").classes("text-3xl font-bold text-center text-gray-800 mb-8")
        ui.label("✨ Convert currencies using real-time exchange rates! 🚀").classes(
            "text-lg text-gray-600 text-center mb-8"
        )

        # Create converter instance
        converter = CurrencyConverterUI()

        # Main conversion card
        with ui.card().classes("w-full max-w-2xl mx-auto p-8 shadow-xl rounded-xl bg-white"):
            ui.label("Convert Currency").classes("text-xl font-semibold text-gray-800 mb-6")

            # Error display
            converter.error_label.classes("text-red-500 mb-4 hidden")

            # Input section
            with ui.row().classes("w-full gap-4 mb-6"):
                with ui.column().classes("flex-1"):
                    ui.label("Amount").classes("text-sm font-medium text-gray-700 mb-2")
                    converter.amount_input.classes("w-full").props("outlined dense")
                    converter.amount_input.on("change", converter.on_amount_change)

                with ui.column().classes("flex-1"):
                    ui.label("From Currency").classes("text-sm font-medium text-gray-700 mb-2")
                    converter.source_currency.classes("w-full").props("outlined dense")
                    converter.source_currency.on("change", converter.on_currency_change)

                with ui.column().classes("flex-1"):
                    ui.label("To Currency").classes("text-sm font-medium text-gray-700 mb-2")
                    converter.target_currency.classes("w-full").props("outlined dense")
                    converter.target_currency.on("change", converter.on_currency_change)

            # Convert button
            with ui.row().classes("w-full justify-center mb-6"):
                ui.button("Convert", on_click=converter.convert).classes(
                    "bg-primary text-white px-8 py-3 text-lg font-semibold rounded-lg "
                    "hover:bg-blue-600 transition-colors shadow-md"
                )

            # Loading spinner
            with ui.row().classes("w-full justify-center mb-4"):
                converter.loading_spinner.classes("hidden")

            # Result display
            with ui.card().classes("w-full p-6 bg-gray-50 rounded-lg mb-6"):
                ui.label("Conversion Result").classes("text-lg font-semibold text-gray-800 mb-4")
                converter.result_label.classes("text-2xl font-bold text-green-600 mb-2")
                converter.rate_label.classes("text-sm text-gray-600")

        # History card
        with ui.card().classes("w-full max-w-2xl mx-auto mt-8 p-8 shadow-xl rounded-xl bg-white"):
            ui.label("Conversion History").classes("text-xl font-semibold text-gray-800 mb-6")
            converter.history_table.classes("w-full")

        # Initialize currencies
        await converter.initialize()

        # Load initial history
        await converter.update_history()
