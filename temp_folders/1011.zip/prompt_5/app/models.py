from sqlmodel import SQLModel, Field, Relationship, JSON, Column
from datetime import datetime
from decimal import Decimal
from typing import Optional, List, Dict, Any

# Persistent models (stored in database)


class Currency(SQLModel, table=True):
    """Currency information model."""

    __tablename__ = "currencies"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    code: str = Field(max_length=3, unique=True, index=True)  # ISO 4217 currency code (USD, EUR, etc.)
    name: str = Field(max_length=100)  # Full currency name (US Dollar, Euro, etc.)
    symbol: str = Field(max_length=10, default="")  # Currency symbol ($, €, etc.)
    is_active: bool = Field(default=True)  # Whether currency is available for conversion
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    source_conversions: List["ConversionHistory"] = Relationship(
        back_populates="source_currency",
        sa_relationship_kwargs={"foreign_keys": "[ConversionHistory.source_currency_id]"},
    )
    target_conversions: List["ConversionHistory"] = Relationship(
        back_populates="target_currency",
        sa_relationship_kwargs={"foreign_keys": "[ConversionHistory.target_currency_id]"},
    )
    exchange_rates_from: List["ExchangeRate"] = Relationship(
        back_populates="from_currency", sa_relationship_kwargs={"foreign_keys": "[ExchangeRate.from_currency_id]"}
    )
    exchange_rates_to: List["ExchangeRate"] = Relationship(
        back_populates="to_currency", sa_relationship_kwargs={"foreign_keys": "[ExchangeRate.to_currency_id]"}
    )


class ExchangeRate(SQLModel, table=True):
    """Exchange rate information for caching API responses."""

    __tablename__ = "exchange_rates"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    from_currency_id: int = Field(foreign_key="currencies.id")
    to_currency_id: int = Field(foreign_key="currencies.id")
    rate: Decimal = Field(max_digits=20, decimal_places=8)  # Exchange rate value
    date: datetime = Field(default_factory=datetime.utcnow)  # Rate date from API
    created_at: datetime = Field(default_factory=datetime.utcnow)  # When cached in DB
    is_active: bool = Field(default=True)  # Whether rate is still valid

    # Relationships
    from_currency: Currency = Relationship(
        back_populates="exchange_rates_from", sa_relationship_kwargs={"foreign_keys": "[ExchangeRate.from_currency_id]"}
    )
    to_currency: Currency = Relationship(
        back_populates="exchange_rates_to", sa_relationship_kwargs={"foreign_keys": "[ExchangeRate.to_currency_id]"}
    )


class ConversionHistory(SQLModel, table=True):
    """History of currency conversions performed by users."""

    __tablename__ = "conversion_history"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    source_currency_id: int = Field(foreign_key="currencies.id")
    target_currency_id: int = Field(foreign_key="currencies.id")
    source_amount: Decimal = Field(max_digits=20, decimal_places=8)  # Original amount
    target_amount: Decimal = Field(max_digits=20, decimal_places=8)  # Converted amount
    exchange_rate: Decimal = Field(max_digits=20, decimal_places=8)  # Rate used for conversion
    conversion_date: datetime = Field(default_factory=datetime.utcnow)
    api_source: str = Field(max_length=50, default="frankfurter")  # Which API was used
    user_session: Optional[str] = Field(default=None, max_length=255)  # Session identifier

    # Additional metadata
    extra_data: Dict[str, Any] = Field(default={}, sa_column=Column(JSON))  # Extra conversion info

    # Relationships
    source_currency: Currency = Relationship(
        back_populates="source_conversions",
        sa_relationship_kwargs={"foreign_keys": "[ConversionHistory.source_currency_id]"},
    )
    target_currency: Currency = Relationship(
        back_populates="target_conversions",
        sa_relationship_kwargs={"foreign_keys": "[ConversionHistory.target_currency_id]"},
    )


class UserPreferences(SQLModel, table=True):
    """User preferences for currency conversion."""

    __tablename__ = "user_preferences"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    session_id: str = Field(max_length=255, unique=True, index=True)  # Browser session ID
    default_source_currency: Optional[str] = Field(default=None, max_length=3)  # Preferred source currency
    default_target_currency: Optional[str] = Field(default=None, max_length=3)  # Preferred target currency
    favorite_currencies: List[str] = Field(default=[], sa_column=Column(JSON))  # List of favorite currency codes
    decimal_places: int = Field(default=2)  # Preferred decimal places for display
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)


class CurrencyCreate(SQLModel, table=False):
    """Schema for creating a new currency."""

    code: str = Field(max_length=3)
    name: str = Field(max_length=100)
    symbol: str = Field(max_length=10, default="")
    is_active: bool = Field(default=True)


class CurrencyUpdate(SQLModel, table=False):
    """Schema for updating currency information."""

    name: Optional[str] = Field(default=None, max_length=100)
    symbol: Optional[str] = Field(default=None, max_length=10)
    is_active: Optional[bool] = Field(default=None)


class ConversionRequest(SQLModel, table=False):
    """Schema for currency conversion requests."""

    source_currency_code: str = Field(max_length=3)
    target_currency_code: str = Field(max_length=3)
    amount: Decimal = Field(gt=Decimal("0"), max_digits=20, decimal_places=8)


class ConversionResponse(SQLModel, table=False):
    """Schema for currency conversion responses."""

    source_currency_code: str
    target_currency_code: str
    source_amount: Decimal
    target_amount: Decimal
    exchange_rate: Decimal
    conversion_date: datetime
    api_source: str


class ExchangeRateCreate(SQLModel, table=False):
    """Schema for creating exchange rate records."""

    from_currency_code: str = Field(max_length=3)
    to_currency_code: str = Field(max_length=3)
    rate: Decimal = Field(gt=Decimal("0"), max_digits=20, decimal_places=8)
    date: Optional[datetime] = Field(default=None)


class UserPreferencesCreate(SQLModel, table=False):
    """Schema for creating user preferences."""

    session_id: str = Field(max_length=255)
    default_source_currency: Optional[str] = Field(default=None, max_length=3)
    default_target_currency: Optional[str] = Field(default=None, max_length=3)
    favorite_currencies: List[str] = Field(default=[])
    decimal_places: int = Field(default=2, ge=0, le=8)


class UserPreferencesUpdate(SQLModel, table=False):
    """Schema for updating user preferences."""

    default_source_currency: Optional[str] = Field(default=None, max_length=3)
    default_target_currency: Optional[str] = Field(default=None, max_length=3)
    favorite_currencies: Optional[List[str]] = Field(default=None)
    decimal_places: Optional[int] = Field(default=None, ge=0, le=8)


class ConversionHistoryResponse(SQLModel, table=False):
    """Schema for conversion history responses."""

    id: int
    source_currency_code: str
    target_currency_code: str
    source_amount: Decimal
    target_amount: Decimal
    exchange_rate: Decimal
    conversion_date: datetime
    api_source: str
