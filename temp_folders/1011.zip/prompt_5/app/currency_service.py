import httpx
import atexit
from decimal import Decimal
from datetime import datetime
from typing import Dict, List, Optional
from sqlmodel import Session, select
from sqlalchemy.orm import selectinload

from app.database import get_session
from app.models import Currency, ExchangeRate, ConversionHistory, ConversionRequest, ConversionResponse


class CurrencyService:
    """Service for handling currency conversion and API interactions."""

    BASE_URL = "https://api.frankfurter.app"

    def __init__(self):
        self.client = httpx.AsyncClient(timeout=10.0)

    async def get_available_currencies(self) -> Dict[str, str]:
        """Fetch available currencies from Frankfurter API."""
        try:
            response = await self.client.get(f"{self.BASE_URL}/currencies")
            response.raise_for_status()
            return response.json()
        except httpx.RequestError as e:
            raise Exception(f"Failed to fetch currencies: {str(e)}")

    async def get_exchange_rate(self, from_currency: str, to_currency: str) -> Decimal:
        """Get current exchange rate between two currencies."""
        if from_currency == to_currency:
            return Decimal("1.0")

        try:
            response = await self.client.get(
                f"{self.BASE_URL}/latest", params={"from": from_currency, "to": to_currency}
            )
            response.raise_for_status()
            data = response.json()

            # The API returns rates in format: {"amount": 1.0, "base": "EUR", "date": "2024-01-01", "rates": {"USD": 1.1}}
            rates = data.get("rates", {})
            if to_currency in rates:
                return Decimal(str(rates[to_currency]))
            else:
                raise Exception(f"Exchange rate not found for {from_currency} to {to_currency}")

        except httpx.RequestError as e:
            raise Exception(f"Failed to fetch exchange rate: {str(e)}")

    async def convert_currency(
        self, request: ConversionRequest, session_id: Optional[str] = None
    ) -> ConversionResponse:
        """Convert currency amount and save to history."""
        # Get exchange rate
        rate = await self.get_exchange_rate(request.source_currency_code, request.target_currency_code)

        # Calculate converted amount
        target_amount = request.amount * rate

        # Save to database
        with get_session() as db:
            # Ensure currencies exist in database
            await self._ensure_currency_exists(db, request.source_currency_code)
            await self._ensure_currency_exists(db, request.target_currency_code)

            # Get currency IDs
            source_currency = db.exec(select(Currency).where(Currency.code == request.source_currency_code)).first()
            target_currency = db.exec(select(Currency).where(Currency.code == request.target_currency_code)).first()

            if not source_currency or not target_currency:
                raise Exception("Currency not found in database")

            # Save conversion history
            history = ConversionHistory(
                source_currency_id=source_currency.id,
                target_currency_id=target_currency.id,
                source_amount=request.amount,
                target_amount=target_amount,
                exchange_rate=rate,
                user_session=session_id,
                api_source="frankfurter",
            )
            db.add(history)

            # Cache exchange rate
            existing_rate = db.exec(
                select(ExchangeRate).where(
                    ExchangeRate.from_currency_id == source_currency.id,
                    ExchangeRate.to_currency_id == target_currency.id,
                    ExchangeRate.is_active,
                )
            ).first()

            if existing_rate:
                # Update existing rate
                existing_rate.rate = rate
                existing_rate.date = datetime.utcnow()
            else:
                # Create new rate record
                exchange_rate = ExchangeRate(
                    from_currency_id=source_currency.id,
                    to_currency_id=target_currency.id,
                    rate=rate,
                    date=datetime.utcnow(),
                )
                db.add(exchange_rate)

            db.commit()

        return ConversionResponse(
            source_currency_code=request.source_currency_code,
            target_currency_code=request.target_currency_code,
            source_amount=request.amount,
            target_amount=target_amount,
            exchange_rate=rate,
            conversion_date=datetime.utcnow(),
            api_source="frankfurter",
        )

    async def _ensure_currency_exists(self, db: Session, currency_code: str) -> None:
        """Ensure currency exists in database, create if not found."""
        existing = db.exec(select(Currency).where(Currency.code == currency_code)).first()

        if not existing:
            # Fetch currency info from API
            try:
                currencies = await self.get_available_currencies()
                if currency_code in currencies:
                    currency = Currency(
                        code=currency_code,
                        name=currencies[currency_code],
                        symbol=self._get_currency_symbol(currency_code),
                        is_active=True,
                    )
                    db.add(currency)
                    db.commit()
                else:
                    raise Exception(f"Currency {currency_code} not supported by API")
            except Exception:
                # If API fails, create basic currency record
                currency = Currency(code=currency_code, name=currency_code, symbol=currency_code, is_active=True)
                db.add(currency)
                db.commit()

    def _get_currency_symbol(self, currency_code: str) -> str:
        """Get currency symbol for common currencies."""
        symbols = {
            "USD": "$",
            "EUR": "€",
            "GBP": "£",
            "JPY": "¥",
            "CHF": "CHF",
            "CAD": "C$",
            "AUD": "A$",
            "CNY": "¥",
            "INR": "₹",
            "KRW": "₩",
            "MXN": "$",
            "BRL": "R$",
            "RUB": "₽",
            "ZAR": "R",
            "SGD": "S$",
            "HKD": "HK$",
            "NOK": "kr",
            "SEK": "kr",
            "DKK": "kr",
            "PLN": "zł",
            "CZK": "Kč",
            "HUF": "Ft",
            "ILS": "₪",
            "NZD": "NZ$",
            "TRY": "₺",
            "THB": "฿",
            "MYR": "RM",
        }
        return symbols.get(currency_code, currency_code)

    async def get_conversion_history(self, session_id: str, limit: int = 10) -> List[ConversionHistory]:
        """Get conversion history for a session."""
        with get_session() as db:
            history = db.exec(
                select(ConversionHistory)
                .options(selectinload(ConversionHistory.source_currency))
                .options(selectinload(ConversionHistory.target_currency))
                .where(ConversionHistory.user_session == session_id)
                .order_by(ConversionHistory.conversion_date.desc())
                .limit(limit)
            ).all()
            return list(history)

    async def close(self):
        """Close the HTTP client."""
        await self.client.aclose()


# Global service instance
currency_service = CurrencyService()


# Ensure proper cleanup
def cleanup_service():
    import asyncio

    try:
        loop = asyncio.get_event_loop()
        if not loop.is_closed():
            loop.run_until_complete(currency_service.close())
    except RuntimeError:
        # Event loop might be closed already
        pass


atexit.register(cleanup_service)
