from sqlmodel import SQLModel, Field, Relationship
from datetime import datetime
from typing import Optional, List
from enum import Enum


class CardState(str, Enum):
    """Enum for card states in the memory game."""

    FACE_DOWN = "face_down"
    FACE_UP = "face_up"
    MATCHED = "matched"


class GameStatus(str, Enum):
    """Enum for game status."""

    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"


# Persistent models (stored in database)
class Game(SQLModel, table=True):
    """Represents a memory card matching game session."""

    __tablename__ = "games"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    status: GameStatus = Field(default=GameStatus.IN_PROGRESS)
    attempts: int = Field(default=0, description="Number of card pair attempts made")
    matched_pairs: int = Field(default=0, description="Number of pairs successfully matched")
    total_pairs: int = Field(default=18, description="Total pairs in the game (36 cards / 2)")
    grid_size: int = Field(default=6, description="Grid size (6x6 = 36 cards)")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = Field(default=None)

    # Relationship to cards
    cards: List["Card"] = Relationship(back_populates="game", cascade_delete=True)


class Card(SQLModel, table=True):
    """Represents a single card in the memory game."""

    __tablename__ = "cards"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    game_id: int = Field(foreign_key="games.id")
    position: int = Field(description="Position on the grid (0-35 for 6x6 grid)")
    row: int = Field(description="Row position (0-5)")
    col: int = Field(description="Column position (0-5)")
    icon: str = Field(max_length=50, description="Icon identifier or Unicode symbol")
    pair_id: int = Field(description="Identifier for matching pairs (two cards share same pair_id)")
    state: CardState = Field(default=CardState.FACE_DOWN)

    # Relationship to game
    game: Game = Relationship(back_populates="cards")


# Non-persistent schemas (for validation, forms, API requests/responses)
class GameCreate(SQLModel, table=False):
    """Schema for creating a new game."""

    grid_size: int = Field(default=6, ge=2, le=10, description="Grid size (must be even for pairs)")


class GameUpdate(SQLModel, table=False):
    """Schema for updating game state."""

    status: Optional[GameStatus] = Field(default=None)
    attempts: Optional[int] = Field(default=None, ge=0)
    matched_pairs: Optional[int] = Field(default=None, ge=0)
    completed_at: Optional[datetime] = Field(default=None)


class CardFlip(SQLModel, table=False):
    """Schema for card flip actions."""

    card_id: int
    new_state: CardState


class CardUpdate(SQLModel, table=False):
    """Schema for updating card state."""

    state: Optional[CardState] = Field(default=None)


class GameStats(SQLModel, table=False):
    """Schema for game statistics and current state."""

    id: int
    status: GameStatus
    attempts: int
    matched_pairs: int
    total_pairs: int
    grid_size: int
    cards_remaining: int
    completion_percentage: float
    created_at: str  # ISO format datetime string
    completed_at: Optional[str] = Field(default=None)  # ISO format datetime string


class CardResponse(SQLModel, table=False):
    """Schema for card data in API responses."""

    id: int
    position: int
    row: int
    col: int
    icon: str
    pair_id: int
    state: CardState


class GameResponse(SQLModel, table=False):
    """Schema for complete game data in API responses."""

    id: int
    status: GameStatus
    attempts: int
    matched_pairs: int
    total_pairs: int
    grid_size: int
    created_at: str  # ISO format datetime string
    completed_at: Optional[str] = Field(default=None)  # ISO format datetime string
    cards: List[CardResponse]


class PairAttempt(SQLModel, table=False):
    """Schema for attempting to match two cards."""

    first_card_id: int
    second_card_id: int
