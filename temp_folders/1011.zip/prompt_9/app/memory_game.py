from nicegui import ui
from typing import Optional, List
import asyncio
from app.game_service import GameService
from app.models import Game, Card, CardState, GameStatus


class MemoryGameUI:
    """UI component for the memory card matching game."""

    def __init__(self):
        self.game: Optional[Game] = None
        self.selected_cards: List[int] = []
        self.is_processing: bool = False
        self.card_buttons: dict[int, ui.button] = {}
        self.attempts_label: Optional[ui.label] = None
        self.status_label: Optional[ui.label] = None

    def create_new_game(self) -> None:
        """Create a new game and refresh the UI."""
        try:
            self.game = GameService.create_new_game(6)
            self.selected_cards = []
            self.is_processing = False
            self.refresh_ui()
            ui.notify("🎉 New game started! Get ready to find pairs! 🚀", type="positive")
        except Exception as e:
            ui.notify(f"Error creating game: {str(e)}", type="negative")

    def refresh_ui(self) -> None:
        """Refresh the entire game UI."""
        if self.game is None:
            return

        # Update game stats
        if self.attempts_label is not None:
            self.attempts_label.set_text(f"Attempts: {self.game.attempts}")

        if self.status_label is not None:
            status_text = "🎯 Find all pairs!" if self.game.status == GameStatus.IN_PROGRESS else "🎉 Completed!"
            self.status_label.set_text(status_text)

        # Update card buttons
        updated_game = GameService.get_game(self.game.id)
        if updated_game is not None:
            self.game = updated_game

        for card in self.game.cards:
            if card.id in self.card_buttons:
                self.update_card_button(card)

    def update_card_button(self, card: Card) -> None:
        """Update a single card button's appearance."""
        if card.id not in self.card_buttons:
            return

        button = self.card_buttons[card.id]

        if card.state == CardState.FACE_DOWN:
            button.set_text("❓")
            button.classes(
                replace="bg-blue-500 hover:bg-blue-600 text-white text-2xl w-16 h-16 rounded-lg shadow-md transition-all duration-200"
            )
            button.enable()
        elif card.state == CardState.FACE_UP:
            button.set_text(card.icon)
            button.classes(
                replace="bg-yellow-300 text-black text-2xl w-16 h-16 rounded-lg shadow-md border-2 border-yellow-400"
            )
            button.disable()
        elif card.state == CardState.MATCHED:
            button.set_text(card.icon)
            button.classes(replace="bg-green-500 text-white text-2xl w-16 h-16 rounded-lg shadow-md opacity-75")
            button.disable()

    async def handle_card_click(self, card_id: int) -> None:
        """Handle clicking on a card."""
        if self.is_processing or self.game is None:
            return

        card = GameService.get_card(card_id)
        if card is None or card.state != CardState.FACE_DOWN:
            return

        # Flip the card
        flipped_card = GameService.flip_card(card_id)
        if flipped_card is None:
            return

        self.update_card_button(flipped_card)
        self.selected_cards.append(card_id)

        # If this is the second card selected, check for match
        if len(self.selected_cards) == 2:
            self.is_processing = True
            await self.process_pair_attempt()

    async def process_pair_attempt(self) -> None:
        """Process the attempt to match two selected cards."""
        if len(self.selected_cards) != 2 or self.game is None:
            return

        first_card_id, second_card_id = self.selected_cards

        # Wait a moment to show both cards
        await asyncio.sleep(1)

        # Attempt to match the cards
        is_match, updated_game = GameService.attempt_match(first_card_id, second_card_id)

        if updated_game is not None:
            self.game = updated_game

        if is_match:
            ui.notify("✨ Perfect Match! You got one! 🙌", type="positive")
            # Cards are already marked as matched by the service
            # Update the UI to show matched state
            first_card = GameService.get_card(first_card_id)
            second_card = GameService.get_card(second_card_id)
            if first_card is not None:
                self.update_card_button(first_card)
            if second_card is not None:
                self.update_card_button(second_card)
        else:
            ui.notify("❌ No match this time. Keep trying! 💪", type="warning")
            # Flip cards back to face down after a delay
            await asyncio.sleep(1)
            GameService.flip_card_down(first_card_id)
            GameService.flip_card_down(second_card_id)

            # Update UI to show face-down state
            first_card = GameService.get_card(first_card_id)
            second_card = GameService.get_card(second_card_id)
            if first_card is not None:
                self.update_card_button(first_card)
            if second_card is not None:
                self.update_card_button(second_card)

        # Reset selection
        self.selected_cards = []
        self.is_processing = False

        # Update game stats
        self.refresh_ui()

        # Check if game is complete
        if self.game and self.game.status == GameStatus.COMPLETED:
            await self.show_victory_dialog()

    async def show_victory_dialog(self) -> None:
        """Show the victory dialog when game is complete."""
        if self.game is None:
            return

        with ui.dialog() as dialog, ui.card():
            ui.label("🏆 You Win! Amazing job! 🥳").classes("text-2xl font-bold text-center mb-4")
            ui.label(f"Game completed in {self.game.attempts} attempts! 📊").classes("text-lg text-center mb-4")

            with ui.row().classes("gap-4 justify-center"):
                ui.button("Play Again", on_click=lambda: (dialog.close(), self.create_new_game())).classes(
                    "bg-green-500 text-white px-6 py-2 rounded-lg"
                )
                ui.button("Close", on_click=dialog.close).classes("bg-gray-500 text-white px-6 py-2 rounded-lg")

        dialog.open()

    def create_game_ui(self) -> None:
        """Create the complete game user interface."""
        # Apply modern theme colors
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        # Header
        with ui.row().classes("w-full justify-between items-center mb-6 p-4 bg-white shadow-lg rounded-xl"):
            ui.label("🧠 Memory Card Game").classes("text-3xl font-bold text-gray-800")

            with ui.row().classes("gap-4 items-center"):
                self.attempts_label = ui.label("Attempts: 0").classes("text-lg font-semibold text-gray-600")
                ui.button("New Game", on_click=self.create_new_game).classes(
                    "bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold shadow-md"
                )

        # Game status
        self.status_label = ui.label("🎯 Start a new game to begin!").classes("text-xl text-center mb-6 text-gray-700")

        # Game grid container
        with ui.card().classes("p-6 bg-white shadow-xl rounded-xl max-w-4xl mx-auto"):
            with ui.grid(columns=6).classes("gap-3 justify-center"):
                # Create placeholder for cards - will be populated when game starts
                pass

        # Initialize with a new game
        self.create_new_game()

    def populate_game_grid(self) -> None:
        """Populate the game grid with card buttons."""
        if self.game is None:
            return

        # Clear existing buttons
        self.card_buttons.clear()

        # Find the grid container and clear it
        # We'll recreate the grid each time for simplicity

        # Create card buttons
        for card in self.game.cards:
            if card.id is not None:
                button = ui.button(
                    "❓", on_click=lambda card_id=card.id: asyncio.create_task(self.handle_card_click(card_id))
                ).classes(
                    "bg-blue-500 hover:bg-blue-600 text-white text-2xl w-16 h-16 rounded-lg shadow-md transition-all duration-200"
                )

                self.card_buttons[card.id] = button


def create():
    """Create the memory game page."""

    @ui.page("/memory-game")
    def memory_game_page():
        """Memory card matching game page."""
        # Set page styling
        ui.add_head_html("""
        <style>
            body {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                margin: 0;
                font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            }
            .nicegui-content {
                padding: 2rem;
                max-width: 100%;
            }
        </style>
        """)

        # Header
        with ui.row().classes("w-full justify-between items-center mb-6 p-6 bg-white shadow-lg rounded-xl"):
            ui.label("🧠 Memory Card Game").classes("text-3xl font-bold text-gray-800")

            with ui.row().classes("gap-4 items-center"):
                attempts_label = ui.label("Attempts: 0").classes("text-lg font-semibold text-gray-600")
                ui.button("New Game", on_click=lambda: start_new_game()).classes(
                    "bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold shadow-md transition-colors"
                )

        # Game status
        status_label = ui.label('🎯 Click "New Game" to start!').classes(
            "text-xl text-center mb-6 text-white font-semibold"
        )

        # Game grid container
        game_container = ui.column().classes("items-center")

        def start_new_game():
            """Start a new memory game."""
            try:
                # Create new game
                game = GameService.create_new_game(6)

                # Update status
                status_label.set_text("🎯 Find all matching pairs!")
                attempts_label.set_text("Attempts: 0")

                # Clear and recreate the game grid
                game_container.clear()

                with game_container:
                    with ui.card().classes("p-6 bg-white shadow-xl rounded-xl"):
                        with ui.grid(columns=6).classes("gap-3"):
                            card_buttons = {}
                            selected_cards = []
                            is_processing = False

                            async def handle_card_click(card_id: int):
                                nonlocal selected_cards, is_processing

                                if is_processing:
                                    return

                                card = GameService.get_card(card_id)
                                if card is None or card.state != CardState.FACE_DOWN:
                                    return

                                # Flip the card
                                flipped_card = GameService.flip_card(card_id)
                                if flipped_card is None:
                                    return

                                # Update button appearance
                                if card_id in card_buttons:
                                    button = card_buttons[card_id]
                                    button.set_text(flipped_card.icon)
                                    button.classes(
                                        replace="bg-yellow-300 text-black text-2xl w-16 h-16 rounded-lg shadow-md border-2 border-yellow-400"
                                    )
                                    button.disable()

                                selected_cards.append(card_id)

                                # If this is the second card selected, check for match
                                if len(selected_cards) == 2:
                                    is_processing = True
                                    await process_pair_attempt()

                            async def process_pair_attempt():
                                nonlocal selected_cards, is_processing

                                if len(selected_cards) != 2:
                                    return

                                first_card_id, second_card_id = selected_cards

                                # Wait a moment to show both cards
                                await asyncio.sleep(1)

                                # Attempt to match the cards
                                is_match, updated_game = GameService.attempt_match(first_card_id, second_card_id)

                                if updated_game is not None:
                                    attempts_label.set_text(f"Attempts: {updated_game.attempts}")

                                if is_match:
                                    ui.notify("✨ Perfect Match! You got one! 🙌", type="positive")
                                    # Update buttons to show matched state
                                    for card_id in [first_card_id, second_card_id]:
                                        if card_id in card_buttons:
                                            button = card_buttons[card_id]
                                            card = GameService.get_card(card_id)
                                            if card is not None:
                                                button.set_text(card.icon)
                                                button.classes(
                                                    replace="bg-green-500 text-white text-2xl w-16 h-16 rounded-lg shadow-md opacity-75"
                                                )
                                else:
                                    ui.notify("❌ No match this time. Keep trying! 💪", type="warning")
                                    # Flip cards back to face down after a delay
                                    await asyncio.sleep(1)
                                    GameService.flip_card_down(first_card_id)
                                    GameService.flip_card_down(second_card_id)

                                    # Update buttons to show face-down state
                                    for card_id in [first_card_id, second_card_id]:
                                        if card_id in card_buttons:
                                            button = card_buttons[card_id]
                                            button.set_text("❓")
                                            button.classes(
                                                replace="bg-blue-500 hover:bg-blue-600 text-white text-2xl w-16 h-16 rounded-lg shadow-md transition-all duration-200"
                                            )
                                            button.enable()

                                # Reset selection
                                selected_cards = []
                                is_processing = False

                                # Check if game is complete
                                if updated_game and updated_game.status == GameStatus.COMPLETED:
                                    await show_victory_dialog(updated_game)

                            async def show_victory_dialog(completed_game: Game):
                                """Show the victory dialog when game is complete."""
                                with ui.dialog() as dialog, ui.card():
                                    ui.label("🎉 Congratulations!").classes(
                                        "text-3xl font-bold text-center mb-4 text-green-600"
                                    )
                                    ui.label("🏆 You Win! Amazing job! 🥳").classes(
                                        "text-2xl font-bold text-center mb-4"
                                    )
                                    ui.label(f"Game completed in {completed_game.attempts} attempts! 📊").classes(
                                        "text-lg text-center mb-6 text-gray-600"
                                    )

                                    with ui.row().classes("gap-4 justify-center"):
                                        ui.button(
                                            "Play Again", on_click=lambda: (dialog.close(), start_new_game())
                                        ).classes(
                                            "bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold"
                                        )
                                        ui.button("Close", on_click=dialog.close).classes(
                                            "bg-gray-500 hover:bg-gray-600 text-white px-6 py-3 rounded-lg font-semibold"
                                        )

                                dialog.open()

                            # Create card buttons
                            for card in game.cards:
                                if card.id is not None:
                                    button = ui.button(
                                        "❓",
                                        on_click=lambda card_id=card.id: asyncio.create_task(
                                            handle_card_click(card_id)
                                        ),
                                    ).classes(
                                        "bg-blue-500 hover:bg-blue-600 text-white text-2xl w-16 h-16 rounded-lg shadow-md transition-all duration-200 hover:scale-105"
                                    )

                                    card_buttons[card.id] = button

                ui.notify("🎉 New game started! Get ready to find pairs! 🚀", type="positive")

            except Exception as e:
                ui.notify(f"Error creating game: {str(e)}", type="negative")

    @ui.page("/")
    def index():
        """Redirect to memory game."""
        ui.navigate.to("/memory-game")
