import random
from typing import List, Tuple, Optional
from datetime import datetime
from sqlmodel import Session, select
from app.database import ENGINE
from app.models import Game, Card, GameStatus, CardState


class GameService:
    """Service class for managing memory card game logic."""

    CARD_ICONS = [
        "🐶",
        "🐱",
        "🐭",
        "🐹",
        "🐰",
        "🦊",
        "🐻",
        "🐼",
        "🐨",
        "🐯",
        "🦁",
        "🐮",
        "🐷",
        "🐸",
        "🐵",
        "🐔",
        "🐧",
        "🐦",
        "🦆",
        "🦅",
        "🦉",
        "🦇",
        "🐺",
        "🐗",
        "🐴",
        "🦄",
        "🐝",
        "🐛",
        "🦋",
        "🐌",
    ]

    @staticmethod
    def create_new_game(grid_size: int = 6) -> Game:
        """Create a new memory card game with shuffled cards."""
        if grid_size % 2 != 0:
            raise ValueError("Grid size must be even to create pairs")

        total_cards = grid_size * grid_size
        if total_cards % 2 != 0:
            raise ValueError("Total cards must be even to create pairs")

        total_pairs = total_cards // 2

        # Select random icons for the game
        selected_icons = random.sample(GameService.CARD_ICONS, total_pairs)

        # Create pairs of cards
        card_data = []
        for i, icon in enumerate(selected_icons):
            # Add two cards for each icon (a pair)
            card_data.extend([{"icon": icon, "pair_id": i}, {"icon": icon, "pair_id": i}])

        # Shuffle the cards
        random.shuffle(card_data)

        with Session(ENGINE) as session:
            # Create the game
            game = Game(status=GameStatus.IN_PROGRESS, total_pairs=total_pairs, grid_size=grid_size)
            session.add(game)
            session.commit()
            session.refresh(game)

            # Create the cards
            cards = []
            for position, card_info in enumerate(card_data):
                row = position // grid_size
                col = position % grid_size

                card = Card(
                    game_id=game.id,
                    position=position,
                    row=row,
                    col=col,
                    icon=card_info["icon"],
                    pair_id=card_info["pair_id"],
                    state=CardState.FACE_DOWN,
                )
                cards.append(card)

            session.add_all(cards)
            session.commit()

            # Create a new detached game object with cards
            game_dict = {
                "id": game.id,
                "status": game.status,
                "attempts": game.attempts,
                "matched_pairs": game.matched_pairs,
                "total_pairs": game.total_pairs,
                "grid_size": game.grid_size,
                "created_at": game.created_at,
                "completed_at": game.completed_at,
            }

            detached_game = Game(**game_dict)
            detached_game.cards = []

            # Load and attach cards
            for card in cards:
                session.refresh(card)
                card_dict = {
                    "id": card.id,
                    "game_id": card.game_id,
                    "position": card.position,
                    "row": card.row,
                    "col": card.col,
                    "icon": card.icon,
                    "pair_id": card.pair_id,
                    "state": card.state,
                }
                detached_card = Card(**card_dict)
                detached_game.cards.append(detached_card)

            return detached_game

    @staticmethod
    def get_game(game_id: int) -> Optional[Game]:
        """Get a game by ID with all its cards."""
        with Session(ENGINE) as session:
            statement = select(Game).where(Game.id == game_id)
            game = session.exec(statement).first()
            if game is None:
                return None

            # Load cards
            cards_statement = select(Card).where(Card.game_id == game_id).order_by(Card.position)
            cards = list(session.exec(cards_statement))

            # Create detached objects
            game_dict = {
                "id": game.id,
                "status": game.status,
                "attempts": game.attempts,
                "matched_pairs": game.matched_pairs,
                "total_pairs": game.total_pairs,
                "grid_size": game.grid_size,
                "created_at": game.created_at,
                "completed_at": game.completed_at,
            }

            detached_game = Game(**game_dict)
            detached_game.cards = []

            for card in cards:
                card_dict = {
                    "id": card.id,
                    "game_id": card.game_id,
                    "position": card.position,
                    "row": card.row,
                    "col": card.col,
                    "icon": card.icon,
                    "pair_id": card.pair_id,
                    "state": card.state,
                }
                detached_card = Card(**card_dict)
                detached_game.cards.append(detached_card)

            return detached_game

    @staticmethod
    def flip_card(card_id: int) -> Optional[Card]:
        """Flip a card to face up state."""
        with Session(ENGINE) as session:
            card = session.get(Card, card_id)
            if card is None:
                return None

            if card.state == CardState.FACE_DOWN:
                card.state = CardState.FACE_UP
                session.add(card)
                session.commit()
                session.refresh(card)

            # Return detached card
            card_dict = {
                "id": card.id,
                "game_id": card.game_id,
                "position": card.position,
                "row": card.row,
                "col": card.col,
                "icon": card.icon,
                "pair_id": card.pair_id,
                "state": card.state,
            }
            return Card(**card_dict)

    @staticmethod
    def flip_card_down(card_id: int) -> Optional[Card]:
        """Flip a card back to face down state."""
        with Session(ENGINE) as session:
            card = session.get(Card, card_id)
            if card is None:
                return None

            if card.state == CardState.FACE_UP:
                card.state = CardState.FACE_DOWN
                session.add(card)
                session.commit()
                session.refresh(card)

            # Return detached card
            card_dict = {
                "id": card.id,
                "game_id": card.game_id,
                "position": card.position,
                "row": card.row,
                "col": card.col,
                "icon": card.icon,
                "pair_id": card.pair_id,
                "state": card.state,
            }
            return Card(**card_dict)

    @staticmethod
    def attempt_match(first_card_id: int, second_card_id: int) -> Tuple[bool, Optional[Game]]:
        """
        Attempt to match two cards.
        Returns (is_match, updated_game).
        """
        with Session(ENGINE) as session:
            first_card = session.get(Card, first_card_id)
            second_card = session.get(Card, second_card_id)

            if first_card is None or second_card is None:
                return False, None

            if first_card.game_id != second_card.game_id:
                return False, None

            game = session.get(Game, first_card.game_id)
            if game is None:
                return False, None

            # Increment attempts
            game.attempts += 1

            # Check if cards match
            is_match = first_card.pair_id == second_card.pair_id

            if is_match:
                # Mark both cards as matched
                first_card.state = CardState.MATCHED
                second_card.state = CardState.MATCHED
                game.matched_pairs += 1

                # Check if game is complete
                if game.matched_pairs >= game.total_pairs:
                    game.status = GameStatus.COMPLETED
                    game.completed_at = datetime.utcnow()

            session.add(game)
            session.add(first_card)
            session.add(second_card)
            session.commit()
            session.refresh(game)

            # Return detached game
            game_dict = {
                "id": game.id,
                "status": game.status,
                "attempts": game.attempts,
                "matched_pairs": game.matched_pairs,
                "total_pairs": game.total_pairs,
                "grid_size": game.grid_size,
                "created_at": game.created_at,
                "completed_at": game.completed_at,
            }
            detached_game = Game(**game_dict)

            return is_match, detached_game

    @staticmethod
    def get_face_up_cards(game_id: int) -> List[Card]:
        """Get all face-up cards for a game."""
        with Session(ENGINE) as session:
            statement = select(Card).where(Card.game_id == game_id, Card.state == CardState.FACE_UP)
            cards = list(session.exec(statement))

            # Return detached cards
            detached_cards = []
            for card in cards:
                card_dict = {
                    "id": card.id,
                    "game_id": card.game_id,
                    "position": card.position,
                    "row": card.row,
                    "col": card.col,
                    "icon": card.icon,
                    "pair_id": card.pair_id,
                    "state": card.state,
                }
                detached_cards.append(Card(**card_dict))

            return detached_cards

    @staticmethod
    def reset_face_up_cards(game_id: int) -> None:
        """Reset all face-up cards back to face-down."""
        with Session(ENGINE) as session:
            statement = select(Card).where(Card.game_id == game_id, Card.state == CardState.FACE_UP)
            cards = session.exec(statement)

            for card in cards:
                card.state = CardState.FACE_DOWN
                session.add(card)

            session.commit()

    @staticmethod
    def get_card(card_id: int) -> Optional[Card]:
        """Get a single card by ID."""
        with Session(ENGINE) as session:
            card = session.get(Card, card_id)
            if card is None:
                return None

            # Return detached card
            card_dict = {
                "id": card.id,
                "game_id": card.game_id,
                "position": card.position,
                "row": card.row,
                "col": card.col,
                "icon": card.icon,
                "pair_id": card.pair_id,
                "state": card.state,
            }
            return Card(**card_dict)
