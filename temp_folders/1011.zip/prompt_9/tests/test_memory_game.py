import pytest
from nicegui.testing import User
from nicegui import ui
from app.database import reset_db
from app.game_service import GameService
from app.models import CardState


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


async def test_memory_game_page_loads(user: User, new_db) -> None:
    """Test that the memory game page loads correctly."""
    await user.open("/memory-game")

    # Check that main elements are present
    await user.should_see("Memory Card Game")
    await user.should_see("New Game")
    await user.should_see("Attempts: 0")


async def test_new_game_button_creates_game(user: User, new_db) -> None:
    """Test that clicking New Game creates a functioning game."""
    await user.open("/memory-game")

    # Click new game button
    user.find("New Game").click()

    # Should see game status update
    await user.should_see("Find all matching pairs!")

    # Should see card buttons (face-down state with ❓)
    card_buttons = list(user.find(ui.button).elements)
    card_buttons_with_question = [btn for btn in card_buttons if btn.text == "❓"]

    # Should have 36 card buttons for 6x6 grid (excluding the New Game button)
    assert len(card_buttons_with_question) == 36


async def test_card_click_functionality(user: User, new_db) -> None:
    """Test that card clicking logic works correctly."""
    # Test the card flipping logic directly through the service
    game = GameService.create_new_game(4)
    card = game.cards[0]

    # Initially card should be face down
    assert card.state == CardState.FACE_DOWN

    # Flip the card
    flipped_card = GameService.flip_card(card.id)
    assert flipped_card is not None
    assert flipped_card.state == CardState.FACE_UP

    # The UI test just checks that the page loads with correct elements


async def test_matching_pair_removes_cards(user: User, new_db) -> None:
    """Test the core game logic by programmatically creating a match."""
    # Create a game directly via service for controlled testing
    game = GameService.create_new_game(4)  # Smaller grid for easier testing

    # Find two matching cards
    matching_cards = []
    for card in game.cards:
        if card.pair_id == 0:  # Get first pair
            matching_cards.append(card)
        if len(matching_cards) == 2:
            break

    assert len(matching_cards) == 2
    first_card, second_card = matching_cards

    # Flip both cards
    GameService.flip_card(first_card.id)
    GameService.flip_card(second_card.id)

    # Attempt match
    is_match, updated_game = GameService.attempt_match(first_card.id, second_card.id)

    assert is_match
    assert updated_game is not None
    assert updated_game.matched_pairs == 1
    assert updated_game.attempts == 1

    # Verify cards are in matched state
    updated_first = GameService.get_card(first_card.id)
    updated_second = GameService.get_card(second_card.id)
    assert updated_first.state == CardState.MATCHED
    assert updated_second.state == CardState.MATCHED


async def test_non_matching_pair_flips_back(user: User, new_db) -> None:
    """Test that non-matching cards flip back to face-down."""
    # Create a game directly via service for controlled testing
    game = GameService.create_new_game(4)

    # Find two non-matching cards
    different_cards = []
    for card in game.cards:
        if len(different_cards) == 0:
            different_cards.append(card)
        elif card.pair_id != different_cards[0].pair_id:
            different_cards.append(card)
            break

    assert len(different_cards) == 2
    first_card, second_card = different_cards

    # Flip both cards
    GameService.flip_card(first_card.id)
    GameService.flip_card(second_card.id)

    # Attempt match
    is_match, updated_game = GameService.attempt_match(first_card.id, second_card.id)

    assert not is_match
    assert updated_game is not None
    assert updated_game.matched_pairs == 0
    assert updated_game.attempts == 1

    # Cards should still be face up initially (UI should flip them back)
    updated_first = GameService.get_card(first_card.id)
    updated_second = GameService.get_card(second_card.id)
    assert updated_first.state == CardState.FACE_UP
    assert updated_second.state == CardState.FACE_UP

    # Manually flip them back (simulating UI behavior)
    GameService.flip_card_down(first_card.id)
    GameService.flip_card_down(second_card.id)

    # Now they should be face down
    final_first = GameService.get_card(first_card.id)
    final_second = GameService.get_card(second_card.id)
    assert final_first.state == CardState.FACE_DOWN
    assert final_second.state == CardState.FACE_DOWN


async def test_game_completion_scenario(user: User, new_db) -> None:
    """Test a complete game scenario with victory condition."""
    # Create a small 2x2 game for quick completion
    game = GameService.create_new_game(2)
    assert game.total_pairs == 2

    # Group cards by pair_id
    pairs = {}
    for card in game.cards:
        if card.pair_id not in pairs:
            pairs[card.pair_id] = []
        pairs[card.pair_id].append(card)

    attempts = 0

    # Match all pairs
    for pair_id, cards in pairs.items():
        assert len(cards) == 2
        first_card, second_card = cards

        # Flip and match
        GameService.flip_card(first_card.id)
        GameService.flip_card(second_card.id)
        is_match, updated_game = GameService.attempt_match(first_card.id, second_card.id)

        attempts += 1
        assert is_match
        assert updated_game is not None
        assert updated_game.attempts == attempts

    # Check final game state
    final_game = GameService.get_game(game.id)
    assert final_game is not None
    assert final_game.status.value == "completed"
    assert final_game.matched_pairs == 2
    assert final_game.completed_at is not None


async def test_attempts_counter_increments(user: User, new_db) -> None:
    """Test that the attempts counter increments correctly."""
    game = GameService.create_new_game(4)

    # Find two different cards
    first_card = game.cards[0]
    second_card = None
    for card in game.cards[1:]:
        if card.pair_id != first_card.pair_id:
            second_card = card
            break

    assert second_card is not None

    # Initial attempts should be 0
    assert game.attempts == 0

    # Make a failed match attempt
    GameService.flip_card(first_card.id)
    GameService.flip_card(second_card.id)
    is_match, updated_game = GameService.attempt_match(first_card.id, second_card.id)

    assert not is_match
    assert updated_game is not None
    assert updated_game.attempts == 1

    # Reset cards for another attempt
    GameService.flip_card_down(first_card.id)
    GameService.flip_card_down(second_card.id)

    # Make another failed attempt
    GameService.flip_card(first_card.id)
    GameService.flip_card(second_card.id)
    is_match, updated_game = GameService.attempt_match(first_card.id, second_card.id)

    assert not is_match
    assert updated_game is not None
    assert updated_game.attempts == 2


async def test_index_page_redirects(user: User, new_db) -> None:
    """Test that the index page redirects to the memory game."""
    await user.open("/")

    # Should be redirected to memory game
    # We can't directly test the redirect, but we can verify the memory game elements are present
    await user.should_see("Memory Card Game")


async def test_card_icons_are_emoji(user: User, new_db) -> None:
    """Test that cards use emoji icons from the predefined set."""
    game = GameService.create_new_game(4)

    # Verify all card icons are from the allowed set
    for card in game.cards:
        assert card.icon in GameService.CARD_ICONS

    # Verify we have exactly 8 unique icons for 8 pairs
    unique_icons = {card.icon for card in game.cards}
    assert len(unique_icons) == 8
