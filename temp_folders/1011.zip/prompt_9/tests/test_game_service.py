import pytest
from app.game_service import GameService
from app.models import GameStatus, CardState
from app.database import reset_db


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_create_new_game_default_size(new_db):
    """Test creating a new 6x6 game with default parameters."""
    game = GameService.create_new_game()

    assert game.id is not None
    assert game.status == GameStatus.IN_PROGRESS
    assert game.attempts == 0
    assert game.matched_pairs == 0
    assert game.total_pairs == 18
    assert game.grid_size == 6
    assert game.created_at is not None
    assert game.completed_at is None
    assert len(game.cards) == 36


def test_create_new_game_custom_size(new_db):
    """Test creating a game with custom grid size."""
    game = GameService.create_new_game(4)

    assert game.grid_size == 4
    assert game.total_pairs == 8
    assert len(game.cards) == 16


def test_create_new_game_invalid_size(new_db):
    """Test creating a game with invalid grid size."""
    with pytest.raises(ValueError, match="Grid size must be even"):
        GameService.create_new_game(5)


def test_game_cards_have_valid_pairs(new_db):
    """Test that created game has proper card pairs."""
    game = GameService.create_new_game(4)

    # Count occurrences of each pair_id
    pair_counts = {}
    for card in game.cards:
        pair_counts[card.pair_id] = pair_counts.get(card.pair_id, 0) + 1

    # Each pair_id should appear exactly twice
    for count in pair_counts.values():
        assert count == 2

    # Should have correct number of unique pairs
    assert len(pair_counts) == game.total_pairs


def test_game_cards_have_valid_positions(new_db):
    """Test that cards have correct position and grid coordinates."""
    game = GameService.create_new_game(4)

    positions = []
    for card in game.cards:
        positions.append(card.position)

        # Check row and column calculations
        expected_row = card.position // game.grid_size
        expected_col = card.position % game.grid_size
        assert card.row == expected_row
        assert card.col == expected_col

        # Check bounds
        assert 0 <= card.row < game.grid_size
        assert 0 <= card.col < game.grid_size

    # All positions should be unique and sequential
    assert sorted(positions) == list(range(16))


def test_get_game_existing(new_db):
    """Test retrieving an existing game."""
    original_game = GameService.create_new_game()

    retrieved_game = GameService.get_game(original_game.id)

    assert retrieved_game is not None
    assert retrieved_game.id == original_game.id
    assert retrieved_game.grid_size == original_game.grid_size
    assert len(retrieved_game.cards) == len(original_game.cards)


def test_get_game_nonexistent(new_db):
    """Test retrieving a non-existent game."""
    result = GameService.get_game(999)
    assert result is None


def test_flip_card_success(new_db):
    """Test successfully flipping a card face up."""
    game = GameService.create_new_game(4)
    card = game.cards[0]

    flipped_card = GameService.flip_card(card.id)

    assert flipped_card is not None
    assert flipped_card.state == CardState.FACE_UP


def test_flip_card_already_face_up(new_db):
    """Test flipping a card that's already face up."""
    game = GameService.create_new_game(4)
    card = game.cards[0]

    # Flip it once
    GameService.flip_card(card.id)

    # Try to flip it again
    result = GameService.flip_card(card.id)

    assert result is not None
    assert result.state == CardState.FACE_UP


def test_flip_card_nonexistent(new_db):
    """Test flipping a non-existent card."""
    result = GameService.flip_card(999)
    assert result is None


def test_flip_card_down_success(new_db):
    """Test flipping a card back to face down."""
    game = GameService.create_new_game(4)
    card = game.cards[0]

    # First flip it up
    GameService.flip_card(card.id)

    # Then flip it back down
    flipped_card = GameService.flip_card_down(card.id)

    assert flipped_card is not None
    assert flipped_card.state == CardState.FACE_DOWN


def test_attempt_match_success(new_db):
    """Test successful card match."""
    game = GameService.create_new_game(4)

    # Find two cards with the same pair_id
    matching_cards = []
    for card in game.cards:
        if card.pair_id == 0:
            matching_cards.append(card)
        if len(matching_cards) == 2:
            break

    assert len(matching_cards) == 2

    first_card, second_card = matching_cards

    # Flip both cards first
    GameService.flip_card(first_card.id)
    GameService.flip_card(second_card.id)

    # Attempt match
    is_match, updated_game = GameService.attempt_match(first_card.id, second_card.id)

    assert is_match
    assert updated_game is not None
    assert updated_game.attempts == 1
    assert updated_game.matched_pairs == 1

    # Verify cards are marked as matched
    first_updated = GameService.get_card(first_card.id)
    second_updated = GameService.get_card(second_card.id)
    assert first_updated.state == CardState.MATCHED
    assert second_updated.state == CardState.MATCHED


def test_attempt_match_failure(new_db):
    """Test failed card match."""
    game = GameService.create_new_game(4)

    # Find two cards with different pair_ids
    different_cards = []
    for card in game.cards:
        if len(different_cards) == 0:
            different_cards.append(card)
        elif card.pair_id != different_cards[0].pair_id:
            different_cards.append(card)
            break

    assert len(different_cards) == 2
    assert different_cards[0].pair_id != different_cards[1].pair_id

    first_card, second_card = different_cards

    # Flip both cards first
    GameService.flip_card(first_card.id)
    GameService.flip_card(second_card.id)

    # Attempt match
    is_match, updated_game = GameService.attempt_match(first_card.id, second_card.id)

    assert not is_match
    assert updated_game is not None
    assert updated_game.attempts == 1
    assert updated_game.matched_pairs == 0

    # Verify cards remain face up (they should be flipped down by the UI layer)
    first_updated = GameService.get_card(first_card.id)
    second_updated = GameService.get_card(second_card.id)
    assert first_updated.state == CardState.FACE_UP
    assert second_updated.state == CardState.FACE_UP


def test_attempt_match_nonexistent_cards(new_db):
    """Test attempting to match non-existent cards."""
    is_match, updated_game = GameService.attempt_match(999, 1000)

    assert not is_match
    assert updated_game is None


def test_attempt_match_different_games(new_db):
    """Test attempting to match cards from different games."""
    game1 = GameService.create_new_game(4)
    game2 = GameService.create_new_game(4)

    card1 = game1.cards[0]
    card2 = game2.cards[0]

    is_match, updated_game = GameService.attempt_match(card1.id, card2.id)

    assert not is_match
    assert updated_game is None


def test_game_completion(new_db):
    """Test game completion when all pairs are matched."""
    game = GameService.create_new_game(2)  # Small 2x2 game for easy testing
    assert game.total_pairs == 2

    # Group cards by pair_id
    pairs = {}
    for card in game.cards:
        if card.pair_id not in pairs:
            pairs[card.pair_id] = []
        pairs[card.pair_id].append(card)

    # Match all pairs
    for pair_id, cards in pairs.items():
        assert len(cards) == 2
        first_card, second_card = cards

        GameService.flip_card(first_card.id)
        GameService.flip_card(second_card.id)
        is_match, updated_game = GameService.attempt_match(first_card.id, second_card.id)

        assert is_match
        assert updated_game is not None

    # Verify game is completed
    final_game = GameService.get_game(game.id)
    assert final_game is not None
    assert final_game.status == GameStatus.COMPLETED
    assert final_game.matched_pairs == final_game.total_pairs
    assert final_game.attempts == 2
    assert final_game.completed_at is not None


def test_get_face_up_cards(new_db):
    """Test retrieving face-up cards."""
    game = GameService.create_new_game(4)

    # Initially no cards should be face up
    face_up_cards = GameService.get_face_up_cards(game.id)
    assert len(face_up_cards) == 0

    # Flip some cards
    GameService.flip_card(game.cards[0].id)
    GameService.flip_card(game.cards[1].id)

    face_up_cards = GameService.get_face_up_cards(game.id)
    assert len(face_up_cards) == 2

    face_up_ids = {card.id for card in face_up_cards}
    assert game.cards[0].id in face_up_ids
    assert game.cards[1].id in face_up_ids


def test_reset_face_up_cards(new_db):
    """Test resetting face-up cards to face-down."""
    game = GameService.create_new_game(4)

    # Flip some cards
    GameService.flip_card(game.cards[0].id)
    GameService.flip_card(game.cards[1].id)
    GameService.flip_card(game.cards[2].id)

    # Verify they are face up
    face_up_cards = GameService.get_face_up_cards(game.id)
    assert len(face_up_cards) == 3

    # Reset them
    GameService.reset_face_up_cards(game.id)

    # Verify they are face down
    face_up_cards = GameService.get_face_up_cards(game.id)
    assert len(face_up_cards) == 0

    # Verify by checking individual cards
    for i in range(3):
        card = GameService.get_card(game.cards[i].id)
        assert card.state == CardState.FACE_DOWN


def test_get_card_success(new_db):
    """Test retrieving a single card by ID."""
    game = GameService.create_new_game(4)
    original_card = game.cards[0]

    retrieved_card = GameService.get_card(original_card.id)

    assert retrieved_card is not None
    assert retrieved_card.id == original_card.id
    assert retrieved_card.position == original_card.position
    assert retrieved_card.icon == original_card.icon


def test_get_card_nonexistent(new_db):
    """Test retrieving a non-existent card."""
    result = GameService.get_card(999)
    assert result is None


def test_card_icons_uniqueness(new_db):
    """Test that different games use random card selections."""
    game1 = GameService.create_new_game(4)
    game2 = GameService.create_new_game(4)

    icons1 = {card.icon for card in game1.cards}
    icons2 = {card.icon for card in game2.cards}

    # Both games should have exactly 8 unique icons (for 8 pairs)
    assert len(icons1) == 8
    assert len(icons2) == 8

    # Games might have different icon sets (though not guaranteed due to randomness)
    # At minimum, verify that the icons are valid
    all_icons = icons1.union(icons2)
    for icon in all_icons:
        assert icon in GameService.CARD_ICONS


def test_card_shuffling(new_db):
    """Test that cards are shuffled in different games."""
    # Create multiple games and check that card positions vary
    games = [GameService.create_new_game(4) for _ in range(5)]

    # Check that at least some games have different arrangements
    first_game_positions = [(card.position, card.icon) for card in games[0].cards]

    different_arrangements = 0
    for game in games[1:]:
        game_positions = [(card.position, card.icon) for card in game.cards]
        if game_positions != first_game_positions:
            different_arrangements += 1

    # At least some games should have different arrangements
    # (Note: there's a tiny chance all could be the same due to randomness, but highly unlikely)
    assert different_arrangements > 0
