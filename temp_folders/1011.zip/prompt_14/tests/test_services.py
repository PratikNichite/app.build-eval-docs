"""Tests for service layer logic."""

import pytest
from datetime import date, timedelta
from decimal import Decimal
from app.database import reset_db
from app.services import ActivityService, UserService


@pytest.fixture()
def new_db():
    """Reset database for each test."""
    reset_db()
    yield
    reset_db()


@pytest.fixture()
def demo_user(new_db):
    """Create demo user for tests."""
    return UserService.get_or_create_demo_user()


class TestActivityService:
    """Test activity service functionality."""

    def test_create_activity_log_new_entry(self, demo_user):
        """Test creating a new activity log entry."""
        log_date = date.today()

        result = ActivityService.create_activity_log(
            user_id=demo_user.id,
            log_date=log_date,
            sleep_hours=Decimal("8.0"),
            work_hours=Decimal("7.5"),
            social_time_hours=Decimal("2.0"),
            screen_time_hours=Decimal("5.0"),
            emotional_energy=7,
            notes="Good day!",
        )

        assert result is not None
        assert result.user_id == demo_user.id
        assert result.log_date == log_date
        assert result.sleep_hours == Decimal("8.0")
        assert result.work_hours == Decimal("7.5")
        assert result.emotional_energy == 7
        assert result.notes == "Good day!"

    def test_create_activity_log_update_existing(self, demo_user):
        """Test updating an existing activity log for the same date."""
        log_date = date.today()

        # Create initial entry
        initial = ActivityService.create_activity_log(
            user_id=demo_user.id,
            log_date=log_date,
            sleep_hours=Decimal("8.0"),
            work_hours=Decimal("7.0"),
            social_time_hours=Decimal("2.0"),
            screen_time_hours=Decimal("5.0"),
            emotional_energy=7,
            notes="Initial entry",
        )

        # Update same date
        updated = ActivityService.create_activity_log(
            user_id=demo_user.id,
            log_date=log_date,
            sleep_hours=Decimal("7.5"),
            work_hours=Decimal("8.0"),
            social_time_hours=Decimal("1.5"),
            screen_time_hours=Decimal("6.0"),
            emotional_energy=6,
            notes="Updated entry",
        )

        assert updated.id == initial.id  # Same record
        assert updated.sleep_hours == Decimal("7.5")
        assert updated.work_hours == Decimal("8.0")
        assert updated.emotional_energy == 6
        assert updated.notes == "Updated entry"

    def test_get_recent_logs(self, demo_user):
        """Test retrieving recent activity logs."""
        # Create logs for multiple dates
        dates = [date.today() - timedelta(days=i) for i in range(5)]

        for i, log_date in enumerate(dates):
            ActivityService.create_activity_log(
                user_id=demo_user.id,
                log_date=log_date,
                sleep_hours=Decimal("8.0"),
                work_hours=Decimal(str(7 + i)),  # Varying work hours
                social_time_hours=Decimal("2.0"),
                screen_time_hours=Decimal("5.0"),
                emotional_energy=7,
                notes=f"Day {i}",
            )

        recent_logs = ActivityService.get_recent_logs(demo_user.id, limit=3)

        assert len(recent_logs) == 3
        # Should be ordered by most recent first
        assert recent_logs[0].log_date == dates[0]  # Today
        assert recent_logs[1].log_date == dates[1]  # Yesterday
        assert recent_logs[2].log_date == dates[2]  # Day before

    def test_get_logs_by_date_range(self, demo_user):
        """Test retrieving logs within a date range."""
        # Create logs for a week
        base_date = date.today()
        dates = [base_date - timedelta(days=i) for i in range(10)]

        for log_date in dates:
            ActivityService.create_activity_log(
                user_id=demo_user.id,
                log_date=log_date,
                sleep_hours=Decimal("8.0"),
                work_hours=Decimal("7.0"),
                social_time_hours=Decimal("2.0"),
                screen_time_hours=Decimal("5.0"),
                emotional_energy=7,
            )

        # Get logs for specific range (last 5 days)
        start_date = base_date - timedelta(days=4)
        end_date = base_date

        range_logs = ActivityService.get_logs_by_date_range(demo_user.id, start_date, end_date)

        assert len(range_logs) == 5
        for log in range_logs:
            assert start_date <= log.log_date <= end_date

    def test_calculate_daily_stats_valid_data(self, demo_user):
        """Test daily statistics calculation with valid data."""
        log_date = date.today()

        # Create activity log
        ActivityService.create_activity_log(
            user_id=demo_user.id,
            log_date=log_date,
            sleep_hours=Decimal("8.0"),  # Good sleep
            work_hours=Decimal("8.0"),
            social_time_hours=Decimal("2.0"),
            screen_time_hours=Decimal("4.0"),  # 2:1 work to screen ratio
            emotional_energy=8,
        )

        stats = ActivityService.calculate_daily_stats(demo_user.id, log_date)

        assert stats is not None
        assert stats.total_logged_hours == Decimal("22.0")
        assert stats.work_screen_ratio == Decimal("2.0")  # 8.0 / 4.0
        assert stats.sleep_quality_score == 10  # 8 hours is optimal
        assert len(stats.break_recommendations) > 0

    def test_calculate_daily_stats_no_data(self, demo_user):
        """Test daily statistics calculation with no data."""
        stats = ActivityService.calculate_daily_stats(demo_user.id, date.today())
        assert stats is None

    def test_calculate_weekly_stats_valid_data(self, demo_user):
        """Test weekly statistics calculation with valid data."""
        week_start = date.today() - timedelta(days=date.today().weekday())  # Monday

        # Create logs for the week
        for i in range(7):
            log_date = week_start + timedelta(days=i)
            ActivityService.create_activity_log(
                user_id=demo_user.id,
                log_date=log_date,
                sleep_hours=Decimal("8.0"),
                work_hours=Decimal(str(6 + i % 3)),  # Varying work hours
                social_time_hours=Decimal("2.0"),
                screen_time_hours=Decimal("5.0"),
                emotional_energy=7 + (i % 3),  # Varying energy levels
            )

        stats = ActivityService.calculate_weekly_stats(demo_user.id, week_start)

        assert stats.total_entries == 7
        assert stats.avg_sleep_hours == Decimal("8.0")
        assert stats.avg_social_time_hours == Decimal("2.0")
        assert stats.wellness_score > 0
        assert stats.most_productive_day != "N/A"

    def test_calculate_weekly_stats_no_data(self, demo_user):
        """Test weekly statistics calculation with no data."""
        week_start = date.today() - timedelta(days=date.today().weekday())

        stats = ActivityService.calculate_weekly_stats(demo_user.id, week_start)

        assert stats.total_entries == 0
        assert stats.avg_sleep_hours == Decimal("0")
        assert stats.wellness_score == 0
        assert stats.most_productive_day == "N/A"

    def test_generate_break_recommendations_high_work_screen(self, demo_user):
        """Test break recommendations for high work and screen time."""
        log_date = date.today()

        ActivityService.create_activity_log(
            user_id=demo_user.id,
            log_date=log_date,
            sleep_hours=Decimal("6.0"),  # Low sleep
            work_hours=Decimal("10.0"),  # High work
            social_time_hours=Decimal("0.5"),  # Low social
            screen_time_hours=Decimal("12.0"),  # High screen time
            emotional_energy=2,  # Low energy
        )

        stats = ActivityService.calculate_daily_stats(demo_user.id, log_date)

        assert stats is not None
        recommendations = stats.break_recommendations

        # Should contain multiple recommendations
        assert len(recommendations) >= 3

        # Check for specific recommendation types
        work_rec = any("work" in rec.lower() or "break" in rec.lower() for rec in recommendations)
        screen_rec = any("20-20-20" in rec or "screen" in rec.lower() for rec in recommendations)
        energy_rec = any(
            "energy" in rec.lower() or "walk" in rec.lower() or "exercise" in rec.lower() for rec in recommendations
        )
        sleep_rec = any("sleep" in rec.lower() for rec in recommendations)
        social_rec = any("social" in rec.lower() for rec in recommendations)

        # At least some recommendations should be present
        assert work_rec or screen_rec or energy_rec or sleep_rec or social_rec

    def test_energy_trend_calculation(self, demo_user):
        """Test energy trend calculation logic."""
        base_date = date.today()

        # Create declining energy pattern
        energy_values = [8, 7, 6, 5, 4, 3, 2]  # Declining
        for i, energy in enumerate(energy_values):
            log_date = base_date - timedelta(days=len(energy_values) - 1 - i)
            ActivityService.create_activity_log(
                user_id=demo_user.id,
                log_date=log_date,
                sleep_hours=Decimal("8.0"),
                work_hours=Decimal("7.0"),
                social_time_hours=Decimal("2.0"),
                screen_time_hours=Decimal("5.0"),
                emotional_energy=energy,
            )

        stats = ActivityService.calculate_daily_stats(demo_user.id, base_date)
        assert stats is not None
        assert stats.energy_trend == "declining"

    def test_wellness_score_calculation(self, demo_user):
        """Test wellness score calculation with different scenarios."""
        log_date = date.today()

        # Test optimal scenario
        ActivityService.create_activity_log(
            user_id=demo_user.id,
            log_date=log_date,
            sleep_hours=Decimal("8.0"),  # Optimal
            work_hours=Decimal("7.0"),  # Good balance
            social_time_hours=Decimal("3.0"),  # Good social time
            screen_time_hours=Decimal("3.0"),  # Low screen time
            emotional_energy=8,  # High energy
        )

        week_start = log_date - timedelta(days=log_date.weekday())
        stats = ActivityService.calculate_weekly_stats(demo_user.id, week_start)

        # Should have high wellness score
        assert stats.wellness_score >= 8

    def test_decimal_precision_handling(self, demo_user):
        """Test proper handling of Decimal precision."""
        log_date = date.today()

        # Test with precise decimal values
        result = ActivityService.create_activity_log(
            user_id=demo_user.id,
            log_date=log_date,
            sleep_hours=Decimal("7.5"),
            work_hours=Decimal("8.25"),
            social_time_hours=Decimal("1.75"),
            screen_time_hours=Decimal("4.5"),
            emotional_energy=7,
        )

        assert result.sleep_hours == Decimal("7.5")
        assert result.work_hours == Decimal("8.25")
        assert result.social_time_hours == Decimal("1.75")
        assert result.screen_time_hours == Decimal("4.5")


class TestUserService:
    """Test user service functionality."""

    def test_get_or_create_demo_user_new(self, new_db):
        """Test creating a new demo user."""
        user = UserService.get_or_create_demo_user()

        assert user is not None
        assert user.name == "Demo User"
        assert user.email == "demo@example.com"
        assert user.is_active
        assert user.id is not None

    def test_get_or_create_demo_user_existing(self, new_db):
        """Test getting existing demo user."""
        # Create first time
        user1 = UserService.get_or_create_demo_user()
        user1_id = user1.id

        # Get existing
        user2 = UserService.get_or_create_demo_user()

        assert user2.id == user1_id  # Same user
        assert user2.email == "demo@example.com"

    def test_get_user_by_id_exists(self, demo_user):
        """Test getting user by ID when user exists."""
        user = UserService.get_user_by_id(demo_user.id)

        assert user is not None
        assert user.id == demo_user.id
        assert user.email == demo_user.email

    def test_get_user_by_id_not_exists(self, new_db):
        """Test getting user by ID when user doesn't exist."""
        user = UserService.get_user_by_id(999)
        assert user is None
