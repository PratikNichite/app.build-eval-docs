"""Basic functionality tests for dashboard without full UI testing."""

import pytest
from datetime import date, timedelta
from decimal import Decimal
from app.database import reset_db
from app.services import ActivityService, UserService
from app.dashboard import create


@pytest.fixture()
def new_db():
    """Reset database for each test."""
    reset_db()
    yield
    reset_db()


def test_dashboard_initialization(new_db):
    """Test that dashboard can be initialized without errors."""
    # This test verifies the dashboard creation doesn't crash
    # The actual UI rendering would be tested in a full NiceGUI environment
    try:
        # Just test that the creation function can be called
        # In actual usage, this would set up the routes
        assert callable(create)

        # Test that we can create a user
        user = UserService.get_or_create_demo_user()
        assert user is not None
        assert user.id is not None

        # Test that we can create an activity log
        log = ActivityService.create_activity_log(
            user_id=user.id,
            log_date=date.today(),
            sleep_hours=Decimal("8.0"),
            work_hours=Decimal("7.0"),
            social_time_hours=Decimal("2.0"),
            screen_time_hours=Decimal("5.0"),
            emotional_energy=7,
            notes="Test",
        )
        assert log is not None

    except Exception as e:
        pytest.fail(f"Dashboard initialization failed: {e}")


def test_dashboard_data_flow(new_db):
    """Test the complete data flow for dashboard functionality."""
    # Create user
    user = UserService.get_or_create_demo_user()
    assert user.id is not None

    # Create some activity logs
    test_dates = [date.today() - timedelta(days=i) for i in range(7)]

    for i, log_date in enumerate(test_dates):
        log = ActivityService.create_activity_log(
            user_id=user.id,
            log_date=log_date,
            sleep_hours=Decimal("7.5"),
            work_hours=Decimal(str(7 + i % 2)),
            social_time_hours=Decimal("2.0"),
            screen_time_hours=Decimal("5.0"),
            emotional_energy=6 + (i % 3),
            notes=f"Day {i}",
        )
        assert log is not None

    # Test data retrieval
    recent_logs = ActivityService.get_recent_logs(user.id, limit=5)
    assert len(recent_logs) == 5

    # Test daily stats calculation
    daily_stats = ActivityService.calculate_daily_stats(user.id, date.today())
    assert daily_stats is not None
    assert daily_stats.total_logged_hours > 0
    assert len(daily_stats.break_recommendations) > 0

    # Test weekly stats calculation
    week_start = date.today() - timedelta(days=date.today().weekday())
    weekly_stats = ActivityService.calculate_weekly_stats(user.id, week_start)
    assert weekly_stats.total_entries > 0
    assert weekly_stats.wellness_score > 0


def test_recommendation_system(new_db):
    """Test the recommendation system with various scenarios."""
    user = UserService.get_or_create_demo_user()

    # Test case 1: Balanced day
    ActivityService.create_activity_log(
        user_id=user.id,
        log_date=date.today(),
        sleep_hours=Decimal("8.0"),
        work_hours=Decimal("7.0"),
        social_time_hours=Decimal("2.0"),
        screen_time_hours=Decimal("4.0"),
        emotional_energy=8,
        notes="Balanced day",
    )

    stats = ActivityService.calculate_daily_stats(user.id, date.today())
    assert stats is not None
    assert len(stats.break_recommendations) > 0
    # Should have some form of recommendations (positive or improvement-focused)
    has_recommendations = len(stats.break_recommendations) > 0
    assert has_recommendations

    # Test case 2: Unbalanced day
    unbalanced_date = date.today() - timedelta(days=1)
    ActivityService.create_activity_log(
        user_id=user.id,
        log_date=unbalanced_date,
        sleep_hours=Decimal("4.0"),  # Poor sleep
        work_hours=Decimal("12.0"),  # Overwork
        social_time_hours=Decimal("0.5"),  # No social time
        screen_time_hours=Decimal("10.0"),  # Too much screen
        emotional_energy=2,  # Low energy
        notes="Rough day",
    )

    unbalanced_stats = ActivityService.calculate_daily_stats(user.id, unbalanced_date)
    assert unbalanced_stats is not None
    # Should have multiple recommendations for improvement
    assert len(unbalanced_stats.break_recommendations) >= 3


def test_edge_cases(new_db):
    """Test edge cases and error conditions."""
    user = UserService.get_or_create_demo_user()

    # Test with no data
    empty_stats = ActivityService.calculate_daily_stats(user.id, date.today() + timedelta(days=30))
    assert empty_stats is None

    # Test with minimal data
    ActivityService.create_activity_log(
        user_id=user.id,
        log_date=date.today(),
        sleep_hours=Decimal("0.0"),
        work_hours=Decimal("0.0"),
        social_time_hours=Decimal("0.0"),
        screen_time_hours=Decimal("0.0"),
        emotional_energy=1,
        notes="",
    )

    minimal_stats = ActivityService.calculate_daily_stats(user.id, date.today())
    assert minimal_stats is not None
    assert minimal_stats.total_logged_hours == Decimal("0.0")

    # Test weekly stats with no data
    future_week = date.today() + timedelta(days=30)
    empty_weekly = ActivityService.calculate_weekly_stats(user.id, future_week)
    assert empty_weekly.total_entries == 0
    assert empty_weekly.wellness_score == 0


def test_data_persistence_and_updates(new_db):
    """Test data persistence and update scenarios."""
    user = UserService.get_or_create_demo_user()
    log_date = date.today()

    # Create initial log
    initial_log = ActivityService.create_activity_log(
        user_id=user.id,
        log_date=log_date,
        sleep_hours=Decimal("7.0"),
        work_hours=Decimal("8.0"),
        social_time_hours=Decimal("1.0"),
        screen_time_hours=Decimal("6.0"),
        emotional_energy=5,
        notes="Initial entry",
    )

    initial_id = initial_log.id

    # Update the same date
    updated_log = ActivityService.create_activity_log(
        user_id=user.id,
        log_date=log_date,
        sleep_hours=Decimal("8.0"),  # Changed
        work_hours=Decimal("7.0"),  # Changed
        social_time_hours=Decimal("2.0"),  # Changed
        screen_time_hours=Decimal("5.0"),  # Changed
        emotional_energy=7,  # Changed
        notes="Updated entry",  # Changed
    )

    # Should be the same record, just updated
    assert updated_log.id == initial_id
    assert updated_log.sleep_hours == Decimal("8.0")
    assert updated_log.notes == "Updated entry"

    # Verify only one record exists for this date
    logs_for_date = ActivityService.get_logs_by_date_range(user.id, log_date, log_date)
    assert len(logs_for_date) == 1
    assert logs_for_date[0].id == initial_id
