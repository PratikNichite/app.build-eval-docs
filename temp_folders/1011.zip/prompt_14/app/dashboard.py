"""Main dashboard module with all pages and routing."""

from datetime import date, timedelta
from nicegui import ui
from app.components import (
    create_modern_theme,
    create_navigation,
    create_activity_form,
    create_activity_history,
    create_daily_stats_card,
    create_weekly_stats_card,
    create_simple_chart,
    TextStyles,
)
from app.services import ActivityService, UserService


def create():
    """Initialize dashboard routes and pages."""
    # Apply modern theme
    create_modern_theme()

    @ui.page("/")
    def dashboard_page():
        """Main dashboard page with overview and quick actions."""
        create_navigation()

        with ui.column().classes("w-full max-w-6xl mx-auto p-6 gap-6"):
            # Welcome section
            ui.label("Welcome to Your Activity Dashboard! 👋").classes(TextStyles.HEADING)
            ui.label("Track your daily activities and gain insights into your wellness patterns.").classes(
                TextStyles.BODY + " mb-6"
            )

            # Get demo user and recent data
            user = UserService.get_or_create_demo_user()
            if not user.id:
                ui.label("Error: Could not initialize user").classes("text-red-500")
                return

            recent_logs = ActivityService.get_recent_logs(user.id, limit=7)
            today_stats = ActivityService.calculate_daily_stats(user.id, date.today())

            # Today's stats and weekly summary
            with ui.row().classes("gap-6 w-full"):
                with ui.column().classes("flex-1"):
                    create_daily_stats_card(today_stats)

                with ui.column().classes("flex-1"):
                    # Calculate this week's stats
                    week_start = date.today() - timedelta(days=date.today().weekday())
                    weekly_stats = ActivityService.calculate_weekly_stats(user.id, week_start)
                    create_weekly_stats_card(weekly_stats)

            # Quick actions
            with ui.card().classes("w-full p-6 shadow-lg rounded-lg bg-white"):
                ui.label("Quick Actions").classes(TextStyles.SUBHEADING)
                with ui.row().classes("gap-4"):
                    ui.button("Log Today's Activities", on_click=lambda: ui.navigate.to("/log")).classes(
                        "bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-medium"
                    )
                    ui.button("View Analytics", on_click=lambda: ui.navigate.to("/analytics")).classes(
                        "bg-purple-500 hover:bg-purple-600 text-white px-6 py-3 rounded-lg font-medium"
                    )

            # Recent activity summary
            if recent_logs:
                with ui.row().classes("gap-4 w-full"):
                    create_simple_chart(recent_logs, "energy", "Energy Levels (7 days)")
                    create_simple_chart(recent_logs, "sleep", "Sleep Hours (7 days)")

    @ui.page("/log")
    async def log_activity_page():
        """Activity logging page with form."""
        create_navigation()

        with ui.column().classes("w-full max-w-4xl mx-auto p-6 gap-6"):
            ui.label("Log Your Daily Activities 📝").classes(TextStyles.HEADING)
            ui.label("Enter your activities for today or any previous day.").classes(TextStyles.BODY + " mb-6")

            def refresh_page():
                """Refresh the page after successful submission."""
                ui.notify("Redirecting to dashboard...", type="info")
                ui.timer(1.0, lambda: ui.navigate.to("/"), once=True)

            # Activity form
            create_activity_form(on_submit_callback=refresh_page)

            # Show recent entries for context
            user = UserService.get_or_create_demo_user()
            if user.id:
                recent_logs = ActivityService.get_recent_logs(user.id, limit=5)
                if recent_logs:
                    ui.label("Recent Entries").classes(TextStyles.SUBHEADING + " mt-8")
                    create_activity_history(recent_logs)

    @ui.page("/analytics")
    def analytics_page():
        """Analytics and visualization page."""
        create_navigation()

        with ui.column().classes("w-full max-w-6xl mx-auto p-6 gap-6"):
            ui.label("Analytics & Insights 📊").classes(TextStyles.HEADING)
            ui.label("Explore your activity patterns and trends over time.").classes(TextStyles.BODY + " mb-6")

            # Get user data
            user = UserService.get_or_create_demo_user()
            if not user.id:
                ui.label("Error: Could not load user data").classes("text-red-500")
                return

            # Date range selector
            with ui.card().classes("w-full p-4 shadow-md rounded-lg bg-white mb-6"):
                ui.label("Time Period").classes("text-lg font-semibold text-gray-700 mb-3")

                with ui.row().classes("gap-4 items-end"):
                    end_date = date.today()
                    start_date = end_date - timedelta(days=30)

                    start_input = ui.date(label="From", value=start_date.isoformat()).classes("w-48")
                    end_input = ui.date(label="To", value=end_date.isoformat()).classes("w-48")

                    def update_analytics():
                        try:
                            start = date.fromisoformat(start_input.value)
                            end = date.fromisoformat(end_input.value)

                            if start > end:
                                ui.notify("Start date must be before end date", type="warning")
                                return

                            # Refresh the page with new date range
                            ui.navigate.to(f"/analytics?start={start.isoformat()}&end={end.isoformat()}")
                        except Exception as e:
                            ui.notify(f"Error: {str(e)}", type="negative")

                    ui.button("Update", on_click=update_analytics).classes(
                        "bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded"
                    )

            # Get logs for the period
            logs = ActivityService.get_logs_by_date_range(user.id, start_date, end_date)

            if not logs:
                with ui.card().classes("p-8 text-center bg-gray-50"):
                    ui.icon("analytics", size="3rem").classes("text-gray-400 mb-4")
                    ui.label("No data available for this period 📉").classes("text-xl text-gray-600 mb-2")
                    ui.label("Start logging activities to see your patterns! 🚀").classes("text-gray-500")
                return

            # Activity trends charts
            ui.label("Activity Trends").classes(TextStyles.SUBHEADING)
            with ui.row().classes("gap-4 w-full mb-6"):
                create_simple_chart(logs, "work", "Work Hours")
                create_simple_chart(logs, "screen", "Screen Time")

            with ui.row().classes("gap-4 w-full mb-6"):
                create_simple_chart(logs, "sleep", "Sleep Hours")
                create_simple_chart(logs, "social", "Social Time")

            # Weekly analysis
            ui.label("Weekly Analysis").classes(TextStyles.SUBHEADING)

            # Calculate multiple weeks if we have enough data
            weeks_to_show = min(4, (end_date - start_date).days // 7 + 1)

            for week_offset in range(weeks_to_show):
                week_start = end_date - timedelta(days=end_date.weekday()) - timedelta(weeks=week_offset)
                weekly_stats = ActivityService.calculate_weekly_stats(user.id, week_start)

                if weekly_stats.total_entries > 0:
                    with ui.expansion(f"Week of {week_start.strftime('%B %d, %Y')}").classes("w-full mb-4"):
                        create_weekly_stats_card(weekly_stats)

            # Full history table
            ui.label("Complete History").classes(TextStyles.SUBHEADING)
            create_activity_history(logs)

    @ui.page("/health")
    def health_check():
        """Simple health check endpoint."""
        ui.label("Dashboard is running! ✅").classes("text-2xl text-center mt-8")
        ui.label(f"Database connection: {'OK' if UserService.get_or_create_demo_user() else 'Failed'}").classes(
            "text-lg text-center mt-4"
        )
