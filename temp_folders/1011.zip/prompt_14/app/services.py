"""Service layer for activity logging and analytics."""

from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import List, Optional
from sqlmodel import select, desc
from statistics import stdev

from app.database import get_session
from app.models import User, ActivityLog, DailyStats, WeeklyStats


class ActivityService:
    """Service for managing activity logs and analytics."""

    @staticmethod
    def create_activity_log(
        user_id: int,
        log_date: date,
        sleep_hours: Decimal,
        work_hours: Decimal,
        social_time_hours: Decimal,
        screen_time_hours: Decimal,
        emotional_energy: int,
        notes: str = "",
    ) -> Optional[ActivityLog]:
        """Create or update an activity log for a specific date."""
        with get_session() as session:
            # Check if entry already exists for this date
            existing = session.exec(
                select(ActivityLog).where(ActivityLog.user_id == user_id, ActivityLog.log_date == log_date)
            ).first()

            if existing:
                # Update existing entry
                existing.sleep_hours = sleep_hours
                existing.work_hours = work_hours
                existing.social_time_hours = social_time_hours
                existing.screen_time_hours = screen_time_hours
                existing.emotional_energy = emotional_energy
                existing.notes = notes
                existing.updated_at = datetime.utcnow()
                session.add(existing)
            else:
                # Create new entry
                activity_log = ActivityLog(
                    user_id=user_id,
                    log_date=log_date,
                    sleep_hours=sleep_hours,
                    work_hours=work_hours,
                    social_time_hours=social_time_hours,
                    screen_time_hours=screen_time_hours,
                    emotional_energy=emotional_energy,
                    notes=notes,
                )
                session.add(activity_log)
                existing = activity_log

            session.commit()
            session.refresh(existing)
            return existing

    @staticmethod
    def get_recent_logs(user_id: int, limit: int = 30) -> List[ActivityLog]:
        """Get recent activity logs for a user."""
        with get_session() as session:
            statement = (
                select(ActivityLog)
                .where(ActivityLog.user_id == user_id)
                .order_by(desc(ActivityLog.log_date))
                .limit(limit)
            )
            return list(session.exec(statement))

    @staticmethod
    def get_logs_by_date_range(user_id: int, start_date: date, end_date: date) -> List[ActivityLog]:
        """Get activity logs within a date range."""
        with get_session() as session:
            statement = (
                select(ActivityLog)
                .where(
                    ActivityLog.user_id == user_id, ActivityLog.log_date >= start_date, ActivityLog.log_date <= end_date
                )
                .order_by(desc(ActivityLog.log_date))
            )
            return list(session.exec(statement))

    @staticmethod
    def calculate_daily_stats(user_id: int, target_date: date) -> Optional[DailyStats]:
        """Calculate daily statistics for a specific date."""
        with get_session() as session:
            log = session.exec(
                select(ActivityLog).where(ActivityLog.user_id == user_id, ActivityLog.log_date == target_date)
            ).first()

            if not log:
                return None

            # Calculate total logged hours
            total_hours = log.sleep_hours + log.work_hours + log.social_time_hours + log.screen_time_hours

            # Calculate work to screen ratio
            work_screen_ratio = log.work_hours / log.screen_time_hours if log.screen_time_hours > 0 else Decimal("0")

            # Calculate sleep quality score (7-9 hours is optimal)
            sleep_quality_score = 10
            if log.sleep_hours < 7:
                sleep_quality_score = max(1, int(10 * (log.sleep_hours / 7)))
            elif log.sleep_hours > 9:
                sleep_quality_score = max(1, 10 - int((log.sleep_hours - 9) * 2))

            # Get energy trend by comparing with previous days
            energy_trend = ActivityService._calculate_energy_trend(user_id, target_date)

            # Generate break recommendations
            break_recommendations = ActivityService._generate_break_recommendations(log)

            return DailyStats(
                log_date=target_date.isoformat(),
                total_logged_hours=total_hours,
                work_screen_ratio=work_screen_ratio,
                sleep_quality_score=sleep_quality_score,
                energy_trend=energy_trend,
                break_recommendations=break_recommendations,
            )

    @staticmethod
    def calculate_weekly_stats(user_id: int, week_start: date) -> WeeklyStats:
        """Calculate weekly statistics starting from a specific date."""
        week_end = week_start + timedelta(days=6)
        logs = ActivityService.get_logs_by_date_range(user_id, week_start, week_end)

        if not logs:
            return WeeklyStats(
                week_start_date=week_start.isoformat(),
                avg_sleep_hours=Decimal("0"),
                avg_work_hours=Decimal("0"),
                avg_social_time_hours=Decimal("0"),
                avg_screen_time_hours=Decimal("0"),
                avg_emotional_energy=Decimal("0"),
                total_entries=0,
                energy_variance=Decimal("0"),
                most_productive_day="N/A",
                wellness_score=0,
            )

        # Calculate averages
        total_entries = len(logs)
        avg_sleep = sum(log.sleep_hours for log in logs) / total_entries
        avg_work = sum(log.work_hours for log in logs) / total_entries
        avg_social = sum(log.social_time_hours for log in logs) / total_entries
        avg_screen = sum(log.screen_time_hours for log in logs) / total_entries
        avg_energy = sum(Decimal(str(log.emotional_energy)) for log in logs) / total_entries

        # Calculate energy variance
        energy_values = [float(log.emotional_energy) for log in logs]
        energy_variance = Decimal(str(stdev(energy_values))) if len(energy_values) > 1 else Decimal("0")

        # Find most productive day
        work_by_day = {}
        for log in logs:
            day_name = log.log_date.strftime("%A")
            work_by_day[day_name] = work_by_day.get(day_name, []) + [log.work_hours]

        most_productive_day = "N/A"
        if work_by_day:
            avg_work_by_day = {day: sum(hours) / len(hours) for day, hours in work_by_day.items()}
            most_productive_day = max(avg_work_by_day, key=avg_work_by_day.get)

        # Calculate wellness score (1-10 based on balanced metrics)
        wellness_score = ActivityService._calculate_wellness_score(
            avg_sleep, avg_work, avg_social, avg_screen, avg_energy
        )

        return WeeklyStats(
            week_start_date=week_start.isoformat(),
            avg_sleep_hours=avg_sleep,
            avg_work_hours=avg_work,
            avg_social_time_hours=avg_social,
            avg_screen_time_hours=avg_screen,
            avg_emotional_energy=avg_energy,
            total_entries=total_entries,
            energy_variance=energy_variance,
            most_productive_day=most_productive_day,
            wellness_score=wellness_score,
        )

    @staticmethod
    def _calculate_energy_trend(user_id: int, target_date: date) -> str:
        """Calculate energy trend by comparing recent days."""
        with get_session() as session:
            # Get last 7 days of data
            start_date = target_date - timedelta(days=6)
            logs = session.exec(
                select(ActivityLog)
                .where(
                    ActivityLog.user_id == user_id,
                    ActivityLog.log_date >= start_date,
                    ActivityLog.log_date <= target_date,
                )
                .order_by(ActivityLog.log_date)
            ).all()

            if len(logs) < 3:
                return "stable"

            # Compare first half vs second half
            mid_point = len(logs) // 2
            first_half_avg = sum(log.emotional_energy for log in logs[:mid_point]) / mid_point
            second_half_avg = sum(log.emotional_energy for log in logs[mid_point:]) / (len(logs) - mid_point)

            diff = second_half_avg - first_half_avg
            if diff > 1:
                return "improving"
            elif diff < -1:
                return "declining"
            return "stable"

    @staticmethod
    def _generate_break_recommendations(log: ActivityLog) -> List[str]:
        """Generate break recommendations based on activity data."""
        recommendations = []

        # Work break recommendations
        if log.work_hours > 6:
            recommendations.append("Consider taking regular breaks during long work sessions")

        # Screen time recommendations
        if log.screen_time_hours > 8:
            recommendations.append(
                "Try the 20-20-20 rule: every 20 minutes, look at something 20 feet away for 20 seconds"
            )

        # Energy recommendations
        if log.emotional_energy <= 3:
            recommendations.append("Low energy detected - consider light exercise or a short walk")

        # Sleep recommendations
        if log.sleep_hours < 6:
            recommendations.append("Prioritize getting more sleep tonight for better recovery")
        elif log.sleep_hours > 10:
            recommendations.append("Consider maintaining a more consistent sleep schedule")

        # Balance recommendations
        if log.social_time_hours < 1:
            recommendations.append("Consider scheduling some social time to maintain balance")

        if not recommendations:
            recommendations.append("Great balance! Keep up the healthy habits")

        return recommendations

    @staticmethod
    def _calculate_wellness_score(
        sleep_hours: Decimal, work_hours: Decimal, social_hours: Decimal, screen_hours: Decimal, energy: Decimal
    ) -> int:
        """Calculate overall wellness score (1-10)."""
        score = 5  # Base score

        # Sleep factor (optimal 7-9 hours)
        if 7 <= sleep_hours <= 9:
            score += 2
        elif 6 <= sleep_hours <= 10:
            score += 1
        elif sleep_hours < 5:
            score -= 2

        # Work-life balance (optimal 6-8 hours work)
        if 6 <= work_hours <= 8:
            score += 1
        elif work_hours > 10:
            score -= 1

        # Social time (at least 1 hour)
        if social_hours >= 2:
            score += 1
        elif social_hours < 1:
            score -= 1

        # Screen time (less is better)
        if screen_hours <= 4:
            score += 1
        elif screen_hours > 8:
            score -= 2

        # Energy level
        if energy >= 7:
            score += 1
        elif energy <= 3:
            score -= 1

        return max(1, min(10, score))


class UserService:
    """Service for user management."""

    @staticmethod
    def get_or_create_demo_user() -> User:
        """Get or create a demo user for the application."""
        with get_session() as session:
            user = session.exec(select(User).where(User.email == "demo@example.com")).first()

            if not user:
                user = User(name="Demo User", email="demo@example.com", is_active=True)
                session.add(user)
                session.commit()
                session.refresh(user)

            return user

    @staticmethod
    def get_user_by_id(user_id: int) -> Optional[User]:
        """Get user by ID."""
        with get_session() as session:
            return session.get(User, user_id)
