from sqlmodel import SQLModel, Field, Relationship
from datetime import datetime, date
from typing import Optional, List
from decimal import Decimal


# Persistent models (stored in database)
class User(SQLModel, table=True):
    __tablename__ = "users"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100)
    email: str = Field(unique=True, max_length=255)
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)

    activity_logs: List["ActivityLog"] = Relationship(back_populates="user")


class ActivityLog(SQLModel, table=True):
    __tablename__ = "activity_logs"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="users.id")
    log_date: date = Field(index=True)
    sleep_hours: Decimal = Field(decimal_places=1, ge=0, le=24)
    work_hours: Decimal = Field(decimal_places=1, ge=0, le=24)
    social_time_hours: Decimal = Field(decimal_places=1, ge=0, le=24)
    screen_time_hours: Decimal = Field(decimal_places=1, ge=0, le=24)
    emotional_energy: int = Field(ge=1, le=10)
    notes: str = Field(default="", max_length=500)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    user: User = Relationship(back_populates="activity_logs")


class BreakSuggestion(SQLModel, table=True):
    __tablename__ = "break_suggestions"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="users.id")
    suggestion_type: str = Field(max_length=50)  # "work_break", "screen_break", "energy_boost"
    message: str = Field(max_length=500)
    priority: int = Field(ge=1, le=5)  # 1=low, 5=urgent
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class UserCreate(SQLModel, table=False):
    name: str = Field(max_length=100)
    email: str = Field(max_length=255)


class UserUpdate(SQLModel, table=False):
    name: Optional[str] = Field(default=None, max_length=100)
    email: Optional[str] = Field(default=None, max_length=255)
    is_active: Optional[bool] = Field(default=None)


class ActivityLogCreate(SQLModel, table=False):
    user_id: int
    log_date: date
    sleep_hours: Decimal = Field(decimal_places=1, ge=0, le=24)
    work_hours: Decimal = Field(decimal_places=1, ge=0, le=24)
    social_time_hours: Decimal = Field(decimal_places=1, ge=0, le=24)
    screen_time_hours: Decimal = Field(decimal_places=1, ge=0, le=24)
    emotional_energy: int = Field(ge=1, le=10)
    notes: str = Field(default="", max_length=500)


class ActivityLogUpdate(SQLModel, table=False):
    sleep_hours: Optional[Decimal] = Field(default=None, decimal_places=1, ge=0, le=24)
    work_hours: Optional[Decimal] = Field(default=None, decimal_places=1, ge=0, le=24)
    social_time_hours: Optional[Decimal] = Field(default=None, decimal_places=1, ge=0, le=24)
    screen_time_hours: Optional[Decimal] = Field(default=None, decimal_places=1, ge=0, le=24)
    emotional_energy: Optional[int] = Field(default=None, ge=1, le=10)
    notes: Optional[str] = Field(default=None, max_length=500)


class ActivityLogResponse(SQLModel, table=False):
    id: int
    user_id: int
    log_date: str  # ISO format date string
    sleep_hours: Decimal
    work_hours: Decimal
    social_time_hours: Decimal
    screen_time_hours: Decimal
    emotional_energy: int
    notes: str
    created_at: str  # ISO format datetime string
    updated_at: str  # ISO format datetime string


class BreakSuggestionCreate(SQLModel, table=False):
    user_id: int
    suggestion_type: str = Field(max_length=50)
    message: str = Field(max_length=500)
    priority: int = Field(ge=1, le=5)


class DailyStats(SQLModel, table=False):
    """Non-persistent model for daily activity statistics"""

    log_date: str  # ISO format date string
    total_logged_hours: Decimal
    work_screen_ratio: Decimal  # work_hours / screen_time_hours
    sleep_quality_score: int  # Derived from sleep hours (7-9 hours = 10, scaling down)
    energy_trend: str  # "improving", "declining", "stable"
    break_recommendations: List[str]


class WeeklyStats(SQLModel, table=False):
    """Non-persistent model for weekly activity statistics"""

    week_start_date: str  # ISO format date string
    avg_sleep_hours: Decimal
    avg_work_hours: Decimal
    avg_social_time_hours: Decimal
    avg_screen_time_hours: Decimal
    avg_emotional_energy: Decimal
    total_entries: int
    energy_variance: Decimal  # Standard deviation of emotional energy
    most_productive_day: str  # Day of week with highest work hours
    wellness_score: int  # Overall wellness score (1-10)
