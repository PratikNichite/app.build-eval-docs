"""UI components for the activity dashboard."""

from datetime import date, datetime
from decimal import Decimal
from typing import List, Optional
from nicegui import ui
from app.services import ActivityService, UserService
from app.models import ActivityLog, DailyStats, WeeklyStats


def create_modern_theme():
    """Apply modern color theme to the application."""
    ui.colors(
        primary="#2563eb",  # Professional blue
        secondary="#64748b",  # Subtle gray
        accent="#10b981",  # Success green
        positive="#10b981",
        negative="#ef4444",  # Error red
        warning="#f59e0b",  # Warning amber
        info="#3b82f6",  # Info blue
    )


class TextStyles:
    """Reusable text style constants."""

    HEADING = "text-2xl font-bold text-gray-800 mb-4"
    SUBHEADING = "text-lg font-semibold text-gray-700 mb-2"
    BODY = "text-base text-gray-600 leading-relaxed"
    CAPTION = "text-sm text-gray-500"
    METRIC_VALUE = "text-3xl font-bold text-gray-800 mt-2"
    METRIC_TITLE = "text-sm text-gray-500 uppercase tracking-wider"


def create_metric_card(title: str, value: str, subtitle: str = "", color_class: str = "text-blue-500", icon: str = ""):
    """Create a metric display card."""
    with ui.card().classes("p-6 bg-white shadow-md rounded-lg hover:shadow-lg transition-shadow"):
        with ui.row().classes("items-center"):
            if icon:
                ui.label(icon).classes(f"{color_class} text-2xl mr-2")
            ui.label(title).classes(TextStyles.METRIC_TITLE)
        ui.label(value).classes(f"{TextStyles.METRIC_VALUE} {color_class}")
        if subtitle:
            ui.label(subtitle).classes(TextStyles.CAPTION + " mt-1")


def create_activity_form(on_submit_callback=None):
    """Create the activity logging form."""
    with ui.card().classes("w-full max-w-2xl p-6 shadow-lg rounded-lg bg-white"):
        ui.label("Log Daily Activities").classes(TextStyles.HEADING)

        # Date input
        ui.label("Date").classes("text-sm font-medium text-gray-700 mb-1")
        date_input = ui.date(value=date.today().isoformat()).classes("w-full mb-4")

        # Time inputs arranged in a grid
        with ui.row().classes("gap-4 w-full"):
            with ui.column().classes("flex-1"):
                ui.label("Sleep Hours").classes("text-sm font-medium text-gray-700 mb-1")
                sleep_input = ui.number(label="Hours", value=8.0, min=0, max=24, step=0.5, format="%.1f").classes(
                    "w-full"
                )

            with ui.column().classes("flex-1"):
                ui.label("Work Hours").classes("text-sm font-medium text-gray-700 mb-1")
                work_input = ui.number(label="Hours", value=8.0, min=0, max=24, step=0.5, format="%.1f").classes(
                    "w-full"
                )

        with ui.row().classes("gap-4 w-full mt-4"):
            with ui.column().classes("flex-1"):
                ui.label("Social Time Hours").classes("text-sm font-medium text-gray-700 mb-1")
                social_input = ui.number(label="Hours", value=2.0, min=0, max=24, step=0.5, format="%.1f").classes(
                    "w-full"
                )

            with ui.column().classes("flex-1"):
                ui.label("Screen Time Hours").classes("text-sm font-medium text-gray-700 mb-1")
                screen_input = ui.number(label="Hours", value=6.0, min=0, max=24, step=0.5, format="%.1f").classes(
                    "w-full"
                )

        # Emotional energy slider
        ui.label("Emotional Energy Level").classes("text-sm font-medium text-gray-700 mb-1 mt-4")
        energy_input = ui.slider(min=1, max=10, value=5, step=1).classes("w-full")
        energy_display = ui.label("5").classes("text-lg font-semibold text-center")
        energy_input.bind_value_to(energy_display, "text", lambda x: f"{int(x)} / 10")

        # Notes input
        ui.label("Notes (Optional)").classes("text-sm font-medium text-gray-700 mb-1 mt-4")
        notes_input = (
            ui.textarea(placeholder="Any additional notes about your day...").classes("w-full mb-4").props("rows=3")
        )

        # Submit button
        def handle_submit():
            try:
                # Get demo user
                user = UserService.get_or_create_demo_user()
                if not user.id:
                    ui.notify("Error: Could not create user", type="negative")
                    return

                # Parse and validate inputs
                log_date = datetime.fromisoformat(date_input.value).date()

                # Create activity log
                activity_log = ActivityService.create_activity_log(
                    user_id=user.id,
                    log_date=log_date,
                    sleep_hours=Decimal(str(sleep_input.value or 0)),
                    work_hours=Decimal(str(work_input.value or 0)),
                    social_time_hours=Decimal(str(social_input.value or 0)),
                    screen_time_hours=Decimal(str(screen_input.value or 0)),
                    emotional_energy=int(energy_input.value or 5),
                    notes=notes_input.value or "",
                )

                if activity_log:
                    ui.notify("Activity logged successfully! 🎉", type="positive")
                    if on_submit_callback:
                        on_submit_callback()
                else:
                    ui.notify("Failed to log activity 😔", type="negative")

            except Exception as e:
                ui.notify(f"Error: {str(e)}", type="negative")

        ui.button("Log Activity", on_click=handle_submit).classes(
            "bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-medium"
        )

        return {
            "date": date_input,
            "sleep": sleep_input,
            "work": work_input,
            "social": social_input,
            "screen": screen_input,
            "energy": energy_input,
            "notes": notes_input,
        }


def create_activity_history(logs: List[ActivityLog]):
    """Create activity history table."""
    if not logs:
        with ui.card().classes("p-8 text-center bg-gray-50"):
            ui.label("🗓️").classes("text-6xl text-gray-400 mb-4")
            ui.label("No activity logs yet... 📖").classes("text-xl text-gray-600 mb-2")
            ui.label("Start by logging your first day!").classes("text-gray-500")
        return

    with ui.card().classes("w-full p-6 shadow-lg rounded-lg bg-white"):
        ui.label("Activity History").classes(TextStyles.SUBHEADING)

        # Create table data
        columns = [
            {"name": "date", "label": "Date", "field": "date", "align": "left", "sortable": True},
            {"name": "sleep", "label": "Sleep", "field": "sleep", "align": "center"},
            {"name": "work", "label": "Work", "field": "work", "align": "center"},
            {"name": "social", "label": "Social", "field": "social", "align": "center"},
            {"name": "screen", "label": "Screen", "field": "screen", "align": "center"},
            {"name": "energy", "label": "Energy", "field": "energy", "align": "center"},
        ]

        rows = []
        for log in logs:
            rows.append(
                {
                    "date": log.log_date.strftime("%Y-%m-%d"),
                    "sleep": f"{float(log.sleep_hours):.1f}h",
                    "work": f"{float(log.work_hours):.1f}h",
                    "social": f"{float(log.social_time_hours):.1f}h",
                    "screen": f"{float(log.screen_time_hours):.1f}h",
                    "energy": f"{log.emotional_energy}/10",
                }
            )

        ui.table(columns=columns, rows=rows).classes("w-full").props("dense")


def create_daily_stats_card(stats: Optional[DailyStats]):
    """Create daily statistics display."""
    with ui.card().classes("w-full p-6 shadow-lg rounded-lg bg-white"):
        ui.label("Today's Insights 📈").classes(TextStyles.SUBHEADING)

        if not stats:
            ui.label("No data available for today").classes("text-gray-500 text-center py-8")
            return

        # Metrics grid
        with ui.row().classes("gap-4 w-full mb-6"):
            create_metric_card(
                "Total Hours",
                f"{float(stats.total_logged_hours):.1f}h",
                "Activities logged",
                "text-blue-500",
                icon="⏰",
            )
            create_metric_card(
                "Work/Screen Ratio",
                f"{float(stats.work_screen_ratio):.2f}",
                "Balance indicator",
                "text-purple-500" if stats.work_screen_ratio > Decimal("1") else "text-orange-500",
                icon="⚖️",
            )
            create_metric_card(
                "Sleep Quality",
                f"{stats.sleep_quality_score}/10",
                "Based on 7-9h optimal",
                "text-green-500" if stats.sleep_quality_score >= 8 else "text-yellow-500",
                icon="🛌",
            )
            create_metric_card(
                "Energy Trend",
                stats.energy_trend.title(),
                "Recent pattern",
                "text-green-500"
                if stats.energy_trend == "improving"
                else "text-red-500"
                if stats.energy_trend == "declining"
                else "text-blue-500",
                icon="⚡",
            )

        # Recommendations
        if stats.break_recommendations:
            ui.label("💡 Recommendations").classes("text-lg font-semibold text-gray-700 mb-3")
            for recommendation in stats.break_recommendations:
                with ui.row().classes("items-start gap-2 mb-2"):
                    ui.icon("lightbulb", size="sm").classes("text-yellow-500 mt-1")
                    ui.label(recommendation).classes("text-gray-600 flex-1")


def create_weekly_stats_card(stats: WeeklyStats):
    """Create weekly statistics display."""
    with ui.card().classes("w-full p-6 shadow-lg rounded-lg bg-white"):
        ui.label("Weekly Summary 🗓️").classes(TextStyles.SUBHEADING)

        if stats.total_entries == 0:
            ui.label("No data available for this week").classes("text-gray-500 text-center py-8")
            return

        # Weekly metrics
        with ui.row().classes("gap-4 w-full mb-4"):
            create_metric_card(
                "Avg Sleep", f"{float(stats.avg_sleep_hours):.1f}h", f"{stats.total_entries} days logged", icon="😴"
            )
            create_metric_card("Avg Work", f"{float(stats.avg_work_hours):.1f}h", "Daily average", icon="💼")
            create_metric_card(
                "Avg Energy",
                f"{float(stats.avg_emotional_energy):.1f}/10",
                f"Variance: {float(stats.energy_variance):.1f}",
                "text-green-500" if stats.avg_emotional_energy >= 7 else "text-yellow-500",
                icon="🔋",
            )
            create_metric_card(
                "Wellness Score",
                f"{stats.wellness_score}/10",
                "Overall balance",
                "text-green-500"
                if stats.wellness_score >= 8
                else "text-yellow-500"
                if stats.wellness_score >= 6
                else "text-red-500",
                icon="❤️‍🩹",
            )

        # Additional insights
        with ui.row().classes("gap-8 w-full"):
            with ui.column().classes("flex-1"):
                ui.label("🚀 Most Productive Day").classes("text-sm font-medium text-gray-700 mb-2")
                ui.label(stats.most_productive_day).classes("text-lg font-semibold text-blue-600")

            with ui.column().classes("flex-1"):
                ui.label("🎯 Week Goal").classes("text-sm font-medium text-gray-700 mb-2")
                goal = (
                    "Maintain balance"
                    if stats.wellness_score >= 8
                    else "Improve sleep routine"
                    if stats.avg_sleep_hours < 7
                    else "Reduce screen time"
                )
                ui.label(goal).classes("text-lg font-semibold text-purple-600")


def create_simple_chart(logs: List[ActivityLog], metric: str, title: str):
    """Create a simple line chart visualization."""
    if not logs:
        return

    with ui.card().classes("w-full p-4 shadow-md rounded-lg bg-white"):
        ui.label(title).classes("text-lg font-semibold text-gray-700 mb-4")

        # Prepare data for last 7 days
        recent_logs = sorted(logs[:7], key=lambda x: x.log_date)
        if not recent_logs:
            ui.label("No data to display").classes("text-gray-500 text-center py-4")
            return

        dates = [log.log_date.strftime("%m/%d") for log in recent_logs]

        if metric == "energy":
            values = [log.emotional_energy for log in recent_logs]
            chart_color = "#f59e0b"
        elif metric == "sleep":
            values = [float(log.sleep_hours) for log in recent_logs]
            chart_color = "#3b82f6"
        elif metric == "work":
            values = [float(log.work_hours) for log in recent_logs]
            chart_color = "#10b981"
        elif metric == "screen":
            values = [float(log.screen_time_hours) for log in recent_logs]
            chart_color = "#ef4444"
        else:
            values = [float(log.social_time_hours) for log in recent_logs]
            chart_color = "#8b5cf6"

        # Create a simple HTML chart using Chart.js
        chart_id = f"chart_{metric}_{id(logs)}"

        ui.add_head_html("""
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        """)

        chart_html = f'''
        <div style="width: 100%; height: 200px;">
            <canvas id="{chart_id}" width="400" height="200"></canvas>
        </div>
        <script>
        const ctx_{chart_id} = document.getElementById('{chart_id}').getContext('2d');
        const chart_{chart_id} = new Chart(ctx_{chart_id}, {{
            type: 'line',
            data: {{
                labels: {dates},
                datasets: [{{
                    label: '{title}',
                    data: {values},
                    borderColor: '{chart_color}',
                    backgroundColor: '{chart_color}20',
                    tension: 0.1,
                    fill: true
                }}]
            }},
            options: {{
                responsive: true,
                maintainAspectRatio: false,
                scales: {{
                    y: {{
                        beginAtZero: true
                    }}
                }},
                plugins: {{
                    legend: {{
                        display: false
                    }}
                }}
            }}
        }});
        </script>
        '''

        ui.html(chart_html)


def create_navigation():
    """Create top navigation bar."""
    with ui.header().classes("bg-white shadow-sm border-b border-gray-200"):
        with ui.row().classes("items-center justify-between w-full max-w-6xl mx-auto px-6 py-4"):
            # Logo/Title
            ui.label("✨ Daily Activity Dashboard").classes("text-xl font-bold text-gray-800")

            # Navigation links
            with ui.row().classes("gap-6"):
                ui.link("Dashboard", "/").classes("text-gray-600 hover:text-blue-600 font-medium")
                ui.link("Log Activity", "/log").classes("text-gray-600 hover:text-blue-600 font-medium")
                ui.link("Analytics", "/analytics").classes("text-gray-600 hover:text-blue-600 font-medium")
