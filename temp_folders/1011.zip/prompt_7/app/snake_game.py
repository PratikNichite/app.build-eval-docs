from nicegui import ui, events
import random
from typing import List, Tuple, Optional
from enum import Enum


class Direction(Enum):
    UP = (0, -1)
    DOWN = (0, 1)
    LEFT = (-1, 0)
    RIGHT = (1, 0)


class GameState(Enum):
    PLAYING = "playing"
    GAME_OVER = "game_over"
    PAUSED = "paused"


class SnakeGame:
    def __init__(self, grid_size: int = 20, cell_size: int = 25):
        self.grid_size = grid_size
        self.cell_size = cell_size

        # Game state
        self.snake: List[Tuple[int, int]] = [(10, 10)]
        self.direction = Direction.RIGHT
        self.next_direction = Direction.RIGHT
        self.food: Optional[Tuple[int, int]] = None
        self.score = 0
        self.game_state = GameState.PLAYING

        # UI elements
        self.game_board: Optional[ui.element] = None
        self.score_label: Optional[ui.label] = None
        self.game_over_card: Optional[ui.card] = None
        self.timer: Optional[ui.timer] = None

    def generate_food(self) -> None:
        """Generate new food at random position not occupied by snake."""
        while True:
            x = random.randint(0, self.grid_size - 1)
            y = random.randint(0, self.grid_size - 1)
            if (x, y) not in self.snake:
                self.food = (x, y)
                break

    def move_snake(self) -> None:
        """Move snake in current direction and handle game logic."""
        if self.game_state != GameState.PLAYING:
            return

        # Update direction
        self.direction = self.next_direction

        # Calculate new head position
        head_x, head_y = self.snake[0]
        dx, dy = self.direction.value
        new_head = (head_x + dx, head_y + dy)

        # Check wall collision
        if new_head[0] < 0 or new_head[0] >= self.grid_size or new_head[1] < 0 or new_head[1] >= self.grid_size:
            self.game_over()
            return

        # Check self collision
        if new_head in self.snake:
            self.game_over()
            return

        # Add new head
        self.snake.insert(0, new_head)

        # Check food collision
        if new_head == self.food:
            self.score += 10
            if self.score_label:
                self.score_label.set_text(f"Score: {self.score}")
            self.generate_food()
            # Speed up slightly as score increases
            if self.timer:
                new_interval = max(0.1, 0.2 - (self.score // 100) * 0.01)
                self.timer.interval = new_interval
        else:
            # Remove tail if no food eaten
            self.snake.pop()

        self.draw_game()

    def game_over(self) -> None:
        """Handle game over state."""
        self.game_state = GameState.GAME_OVER
        if self.timer:
            self.timer.deactivate()
        if self.game_over_card:
            self.game_over_card.set_visibility(True)

    def restart_game(self) -> None:
        """Reset game to initial state."""
        self.snake = [(10, 10)]
        self.direction = Direction.RIGHT
        self.next_direction = Direction.RIGHT
        self.score = 0
        self.game_state = GameState.PLAYING

        if self.score_label:
            self.score_label.set_text(f"Score: {self.score}")
        if self.game_over_card:
            self.game_over_card.set_visibility(False)

        self.generate_food()

        if self.timer:
            self.timer.interval = 0.2
            self.timer.activate()

        self.draw_game()

    def handle_keydown(self, e: events.KeyEventArguments) -> None:
        """Handle keyboard input for game controls."""
        if e.key == "r" and self.game_state == GameState.GAME_OVER:
            self.restart_game()
            return

        if self.game_state != GameState.PLAYING:
            return

        # Prevent reverse direction
        key_to_direction = {
            "ArrowUp": Direction.UP,
            "ArrowDown": Direction.DOWN,
            "ArrowLeft": Direction.LEFT,
            "ArrowRight": Direction.RIGHT,
        }

        if e.key in key_to_direction:
            new_direction = key_to_direction[e.key]
            # Prevent moving in opposite direction
            opposite_directions = {
                Direction.UP: Direction.DOWN,
                Direction.DOWN: Direction.UP,
                Direction.LEFT: Direction.RIGHT,
                Direction.RIGHT: Direction.LEFT,
            }

            if new_direction != opposite_directions[self.direction]:
                self.next_direction = new_direction

    def draw_game(self) -> None:
        """Draw the current game state using CSS grid."""
        if not self.game_board:
            return

        # Clear the board
        self.game_board.clear()

        # Create grid cells
        with self.game_board:
            for y in range(self.grid_size):
                for x in range(self.grid_size):
                    cell_type = "empty"
                    cell_content = ""

                    if (x, y) in self.snake:
                        if (x, y) == self.snake[0]:  # Head
                            cell_type = "snake-head"
                            # Add eyes based on direction
                            if self.direction == Direction.UP:
                                cell_content = "⬆️"
                            elif self.direction == Direction.DOWN:
                                cell_content = "⬇️"
                            elif self.direction == Direction.LEFT:
                                cell_content = "⬅️"
                            else:  # RIGHT
                                cell_content = "➡️"
                        else:  # Body
                            cell_type = "snake-body"
                    elif self.food and (x, y) == self.food:
                        cell_type = "food"
                        cell_content = "🍎"

                    ui.element("div").classes(f"game-cell {cell_type}").style(
                        f"grid-column: {x + 1}; grid-row: {y + 1};"
                    ).props(f'innerHTML="{cell_content}"')


def create():
    """Create the Snake game page."""

    @ui.page("/snake")
    def snake_page():
        ui.add_head_html("""
        <style>
        body { 
            margin: 0; 
            padding: 0; 
            background: #111827; 
            font-family: 'Arial', sans-serif; 
        }
        .game-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 20px;
        }
        .game-board {
            display: grid;
            grid-template-columns: repeat(20, 25px);
            grid-template-rows: repeat(20, 25px);
            gap: 1px;
            background-color: #374151;
            padding: 2px;
            border-radius: 8px;
        }
        .game-cell {
            width: 25px;
            height: 25px;
            background-color: #1f2937;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
        }
        .game-cell.snake-head {
            background-color: #22c55e;
            border-radius: 4px;
        }
        .game-cell.snake-body {
            background-color: #4ade80;
            border-radius: 3px;
        }
        .game-cell.food {
            background-color: #1f2937;
        }
        </style>
        """)

        game = SnakeGame(grid_size=20, cell_size=25)

        with ui.column().classes("game-container"):
            # Game title and score
            ui.label("🐍 Snake Game").classes("text-4xl font-bold text-green-400 mb-4 text-center")

            game.score_label = ui.label(f"Score: {game.score}").classes("text-2xl text-white mb-4 font-mono")

            # Game board container
            with ui.card().classes("p-4 bg-gray-800 rounded-lg shadow-xl"):
                game.game_board = ui.element("div").classes("game-board")

            # Instructions
            with ui.card().classes("mt-6 p-4 bg-gray-800 text-white max-w-md"):
                ui.label("How to Play:").classes("text-lg font-bold mb-2 text-green-400")
                ui.label("• Use arrow keys to control the snake").classes("mb-1")
                ui.label("• Eat red food to grow and increase score").classes("mb-1")
                ui.label("• Avoid walls and your own tail").classes("mb-1")
                ui.label("• Press R to restart after game over").classes("text-yellow-400")

            # Game over overlay
            with (
                ui.card()
                .classes(
                    "absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 p-8 bg-red-900 text-white text-center z-10"
                )
                .bind_visibility_from(game, "game_state", lambda state: state == GameState.GAME_OVER) as game_over_card
            ):
                game.game_over_card = game_over_card
                ui.label("Game Over!").classes("text-3xl font-bold mb-4 text-red-300")
                ui.label("Final Score:").classes("text-lg mb-2")
                ui.label().bind_text_from(game, "score").classes("text-2xl font-bold mb-4 text-yellow-400")
                ui.label("Press R to Restart").classes("text-lg text-green-400 animate-pulse")

            # Initially hide game over card
            game_over_card.set_visibility(False)

        # Set up keyboard controls
        ui.keyboard(on_key=game.handle_keydown)

        # Initialize game
        game.generate_food()
        game.draw_game()

        # Start game timer
        game.timer = ui.timer(0.2, game.move_snake)

    @ui.page("/")
    def index():
        ui.add_head_html("""
        <style>
        body { 
            margin: 0; 
            padding: 0; 
            background: linear-gradient(135deg, #1f2937 0%, #111827 100%); 
            font-family: 'Arial', sans-serif; 
            min-height: 100vh;
        }
        </style>
        """)

        with ui.column().classes("items-center justify-center min-h-screen p-8"):
            ui.label("🎮 Game Center").classes("text-5xl font-bold text-white mb-8 text-center")

            with ui.card().classes("p-8 bg-gray-800 rounded-xl shadow-2xl max-w-md"):
                ui.label("Welcome to the Game Portal").classes("text-2xl font-bold text-green-400 mb-6 text-center")

                ui.label("Available Games:").classes("text-lg text-white mb-4 font-semibold")

                with ui.row().classes("w-full justify-center"):
                    ui.button("🐍 Play Snake Game", on_click=lambda: ui.navigate.to("/snake")).classes(
                        "bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-bold text-lg shadow-lg transform hover:scale-105 transition-all"
                    )

                ui.separator().classes("my-6")

                ui.label("Controls:").classes("text-lg text-white mb-2 font-semibold")
                ui.label("• Arrow keys to move").classes("text-gray-300 mb-1")
                ui.label("• R to restart after game over").classes("text-gray-300")
