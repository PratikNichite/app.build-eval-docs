from sqlmodel import SQLModel, Field, JSON, Column
from datetime import datetime
from typing import Optional, List, Dict
from decimal import Decimal


# Persistent models (stored in database)
class Player(SQLModel, table=True):
    """Player model to track individual players."""

    __tablename__ = "players"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_played: datetime = Field(default_factory=datetime.utcnow)
    total_games: int = Field(default=0)
    best_score: int = Field(default=0)


class GameSession(SQLModel, table=True):
    """Individual game session with complete game state and statistics."""

    __tablename__ = "game_sessions"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    player_id: Optional[int] = Field(default=None, foreign_key="players.id")
    score: int = Field(default=0)
    snake_length: int = Field(default=1)
    moves_count: int = Field(default=0)
    food_eaten: int = Field(default=0)
    game_duration_seconds: int = Field(default=0)
    final_snake_positions: List[Dict[str, int]] = Field(default=[], sa_column=Column(JSON))
    food_position: Dict[str, int] = Field(default={}, sa_column=Column(JSON))
    game_over_reason: str = Field(default="", max_length=50)  # "wall_collision", "self_collision", "quit"
    grid_width: int = Field(default=20)
    grid_height: int = Field(default=20)
    started_at: datetime = Field(default_factory=datetime.utcnow)
    ended_at: Optional[datetime] = Field(default=None)
    is_completed: bool = Field(default=False)


class HighScore(SQLModel, table=True):
    """High score leaderboard entries."""

    __tablename__ = "high_scores"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    player_id: Optional[int] = Field(default=None, foreign_key="players.id")
    score: int = Field(ge=0)
    snake_length: int = Field(ge=1)
    game_duration_seconds: int = Field(ge=0)
    achieved_at: datetime = Field(default_factory=datetime.utcnow)
    grid_width: int = Field(default=20)
    grid_height: int = Field(default=20)


class GameStatistics(SQLModel, table=True):
    """Aggregated game statistics for analytics."""

    __tablename__ = "game_statistics"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    date: datetime = Field(default_factory=datetime.utcnow)
    total_games_played: int = Field(default=0)
    total_players: int = Field(default=0)
    average_score: Decimal = Field(default=Decimal("0"), decimal_places=2)
    average_game_duration: Decimal = Field(default=Decimal("0"), decimal_places=2)
    highest_score_today: int = Field(default=0)
    most_common_game_over_reason: str = Field(default="", max_length=50)


# Non-persistent schemas (for validation, forms, API requests/responses)
class PlayerCreate(SQLModel, table=False):
    """Schema for creating a new player."""

    name: str = Field(max_length=100)


class PlayerUpdate(SQLModel, table=False):
    """Schema for updating player information."""

    name: Optional[str] = Field(default=None, max_length=100)
    last_played: Optional[datetime] = Field(default=None)
    total_games: Optional[int] = Field(default=None, ge=0)
    best_score: Optional[int] = Field(default=None, ge=0)


class GameSessionCreate(SQLModel, table=False):
    """Schema for creating a new game session."""

    player_id: Optional[int] = Field(default=None)
    grid_width: int = Field(default=20, ge=10, le=50)
    grid_height: int = Field(default=20, ge=10, le=50)


class GameSessionUpdate(SQLModel, table=False):
    """Schema for updating game session during or after gameplay."""

    score: Optional[int] = Field(default=None, ge=0)
    snake_length: Optional[int] = Field(default=None, ge=1)
    moves_count: Optional[int] = Field(default=None, ge=0)
    food_eaten: Optional[int] = Field(default=None, ge=0)
    game_duration_seconds: Optional[int] = Field(default=None, ge=0)
    final_snake_positions: Optional[List[Dict[str, int]]] = Field(default=None)
    food_position: Optional[Dict[str, int]] = Field(default=None)
    game_over_reason: Optional[str] = Field(default=None, max_length=50)
    ended_at: Optional[datetime] = Field(default=None)
    is_completed: Optional[bool] = Field(default=None)


class GameConfig(SQLModel, table=False):
    """Game configuration schema for runtime settings."""

    grid_width: int = Field(default=20, ge=10, le=50)
    grid_height: int = Field(default=20, ge=10, le=50)
    initial_snake_length: int = Field(default=1, ge=1)
    game_speed: int = Field(default=150, ge=50, le=1000)  # milliseconds between moves
    cell_size: int = Field(default=20, ge=10, le=50)  # pixels
    enable_wall_wrap: bool = Field(default=False)  # snake wraps around edges
    enable_pause: bool = Field(default=True)


class GameState(SQLModel, table=False):
    """Current game state schema for real-time gameplay."""

    snake_positions: List[Dict[str, int]] = Field(default=[])
    food_position: Dict[str, int] = Field(default={})
    direction: str = Field(default="RIGHT")
    score: int = Field(default=0, ge=0)
    is_game_over: bool = Field(default=False)
    is_paused: bool = Field(default=False)
    moves_count: int = Field(default=0, ge=0)
    game_start_time: Optional[datetime] = Field(default=None)


class LeaderboardEntry(SQLModel, table=False):
    """Schema for leaderboard display."""

    rank: int = Field(ge=1)
    player_name: str
    score: int = Field(ge=0)
    snake_length: int = Field(ge=1)
    achieved_at: datetime
    game_duration_seconds: int = Field(ge=0)
