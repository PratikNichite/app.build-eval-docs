from nicegui.testing import User
from app.snake_game import SnakeGame, Direction, GameState


class TestSnakeGameLogic:
    """Test the core game logic without UI interactions."""

    def test_initial_game_state(self):
        """Test that game initializes with correct default values."""
        game = SnakeGame()

        assert len(game.snake) == 1
        assert game.snake[0] == (10, 10)
        assert game.direction == Direction.RIGHT
        assert game.next_direction == Direction.RIGHT
        assert game.score == 0
        assert game.game_state == GameState.PLAYING
        assert game.food is None

    def test_generate_food(self):
        """Test food generation logic."""
        game = SnakeGame(grid_size=5)
        game.snake = [(0, 0), (1, 0), (2, 0)]  # Horizontal snake

        game.generate_food()

        assert game.food is not None
        assert game.food not in game.snake
        assert 0 <= game.food[0] < game.grid_size
        assert 0 <= game.food[1] < game.grid_size

    def test_generate_food_avoids_snake(self):
        """Test that food is never placed on snake body."""
        game = SnakeGame(grid_size=3)
        # Fill most of the grid with snake
        game.snake = [(0, 0), (1, 0), (2, 0), (0, 1), (1, 1), (2, 1), (0, 2), (1, 2)]

        game.generate_food()

        assert game.food == (2, 2)  # Only remaining position
        assert game.food not in game.snake

    def test_move_snake_basic(self):
        """Test basic snake movement without collisions."""
        game = SnakeGame(grid_size=20)
        game.snake = [(5, 5)]
        game.direction = Direction.RIGHT
        game.next_direction = Direction.RIGHT
        game.food = (10, 10)  # Far from snake

        # Mock the UI elements to avoid None errors
        game.score_label = type("MockLabel", (), {"set_text": lambda self, text: None})()
        game.draw_game = lambda: None  # Mock drawing

        initial_length = len(game.snake)
        game.move_snake()

        assert game.snake[0] == (6, 5)  # Head moved right
        assert len(game.snake) == initial_length  # No food eaten
        assert game.game_state == GameState.PLAYING

    def test_move_snake_eat_food(self):
        """Test snake eating food increases length and score."""
        game = SnakeGame(grid_size=20)
        game.snake = [(5, 5)]
        game.direction = Direction.RIGHT
        game.next_direction = Direction.RIGHT
        game.food = (6, 5)  # Food directly in front

        # Mock UI elements
        game.score_label = type("MockLabel", (), {"set_text": lambda self, text: None})()
        game.timer = type("MockTimer", (), {"interval": 0.2})()
        game.draw_game = lambda: None

        initial_length = len(game.snake)
        initial_score = game.score

        game.move_snake()

        assert len(game.snake) == initial_length + 1  # Snake grew
        assert game.score == initial_score + 10  # Score increased
        assert game.food != (6, 5)  # New food generated
        assert game.food is not None

    def test_wall_collision_detection(self):
        """Test collision with walls triggers game over."""
        game = SnakeGame(grid_size=5)
        game.snake = [(4, 2)]  # Near right wall
        game.direction = Direction.RIGHT
        game.next_direction = Direction.RIGHT

        # Mock UI elements
        class MockTimer:
            def deactivate(self):
                pass

        class MockCard:
            def set_visibility(self, visible):
                pass

        game.timer = MockTimer()
        game.game_over_card = MockCard()

        game.move_snake()

        assert game.game_state == GameState.GAME_OVER

    def test_self_collision_detection(self):
        """Test collision with snake body triggers game over."""
        game = SnakeGame(grid_size=10)
        # Create snake that will collide with itself
        game.snake = [(5, 5), (4, 5), (3, 5), (3, 6), (4, 6), (5, 6)]
        game.direction = Direction.DOWN
        game.next_direction = Direction.DOWN

        # Mock UI elements
        class MockTimer:
            def deactivate(self):
                pass

        class MockCard:
            def set_visibility(self, visible):
                pass

        game.timer = MockTimer()
        game.game_over_card = MockCard()

        game.move_snake()

        assert game.game_state == GameState.GAME_OVER

    def test_direction_change_prevention(self):
        """Test that snake cannot reverse into itself."""
        game = SnakeGame()
        game.snake = [(5, 5), (4, 5)]  # Snake moving right
        game.direction = Direction.RIGHT

        # Try to move left (opposite direction)
        key_event = type("KeyEvent", (), {"key": "ArrowLeft"})()
        game.handle_keydown(key_event)

        # Direction should not change
        assert game.next_direction == Direction.RIGHT

        # But up/down should work
        key_event.key = "ArrowUp"
        game.handle_keydown(key_event)
        assert game.next_direction == Direction.UP

    def test_restart_game(self):
        """Test that restart properly resets game state."""
        game = SnakeGame()

        # Modify game state
        game.snake = [(0, 0), (1, 0), (2, 0)]
        game.score = 50
        game.game_state = GameState.GAME_OVER
        game.direction = Direction.DOWN

        # Mock UI elements
        class MockLabel:
            def set_text(self, text):
                pass

        class MockCard:
            def set_visibility(self, visible):
                pass

        class MockTimer:
            def __init__(self):
                self.interval = 0.2

            def activate(self):
                pass

        game.score_label = MockLabel()
        game.game_over_card = MockCard()
        game.timer = MockTimer()
        game.draw_game = lambda: None

        game.restart_game()

        assert len(game.snake) == 1
        assert game.snake[0] == (10, 10)
        assert game.score == 0
        assert game.game_state == GameState.PLAYING
        assert game.direction == Direction.RIGHT
        assert game.next_direction == Direction.RIGHT
        assert game.food is not None

    def test_score_speed_increase(self):
        """Test that game speed increases with score."""
        game = SnakeGame()
        game.score = 200  # High score
        game.snake = [(5, 5)]
        game.direction = Direction.RIGHT
        game.next_direction = Direction.RIGHT
        game.food = (6, 5)  # Food directly in front

        # Mock UI elements with timer that tracks interval changes
        timer_intervals = []

        class MockTimer:
            def __init__(self):
                self.interval = 0.2

            def __setattr__(self, name, value):
                if name == "interval":
                    timer_intervals.append(value)
                super().__setattr__(name, value)

        game.timer = MockTimer()
        game.score_label = type("MockLabel", (), {"set_text": lambda self, text: None})()
        game.draw_game = lambda: None

        game.move_snake()

        # Timer interval should have been updated to be faster
        assert len(timer_intervals) > 0
        assert timer_intervals[-1] < 0.2  # Speed increased

    def test_keyboard_controls_game_over(self):
        """Test that R key restarts game when in game over state."""
        game = SnakeGame()
        game.game_state = GameState.GAME_OVER

        # Mock restart method
        game.restart_game = lambda: setattr(game, "_restart_called", True)

        key_event = type("KeyEvent", (), {"key": "r"})()
        game.handle_keydown(key_event)

        assert hasattr(game, "_restart_called")

    def test_edge_case_tiny_grid(self):
        """Test game works with minimal grid size."""
        game = SnakeGame(grid_size=3)
        game.snake = [(1, 1)]  # Center position

        game.generate_food()

        assert game.food is not None
        assert game.food != (1, 1)
        assert 0 <= game.food[0] < 3
        assert 0 <= game.food[1] < 3


class TestSnakeGameUI:
    """Test UI interactions and page rendering."""

    async def test_snake_page_loads(self, user: User) -> None:
        """Test that the snake game page loads correctly."""
        await user.open("/snake")

        # Check page elements exist - using simpler text that should be found
        await user.should_see("Snake Game")
        await user.should_see("arrow keys")

    async def test_index_page_navigation(self, user: User) -> None:
        """Test navigation from index page to snake game."""
        await user.open("/")

        await user.should_see("Game Center")
        await user.should_see("Play Snake Game")

        # Click the snake game button
        user.find("Play Snake Game").click()

        # Should navigate to snake game - check for a unique element
        await user.should_see("Snake Game")

    async def test_index_page_content(self, user: User) -> None:
        """Test that index page shows correct content."""
        await user.open("/")

        # Check all expected elements on index page
        await user.should_see("Game Center")
        await user.should_see("Welcome to the Game Portal")
        await user.should_see("Available Games:")
        await user.should_see("Arrow keys to move")
