from typing import Optional
from datetime import datetime
from sqlmodel import select
from app.database import get_session
from app.models import Movie, MovieCreate, MovieUpdate


class MovieService:
    """Service layer for movie operations."""

    @staticmethod
    def get_all_movies() -> list[Movie]:
        """Retrieve all movies from the database."""
        with get_session() as session:
            statement = select(Movie).order_by(Movie.created_at.desc())
            movies = session.exec(statement).all()
            return list(movies)

    @staticmethod
    def create_movie(movie_data: MovieCreate) -> Movie:
        """Create a new movie entry."""
        with get_session() as session:
            movie = Movie(**movie_data.model_dump())
            movie.created_at = datetime.utcnow()
            movie.updated_at = datetime.utcnow()
            session.add(movie)
            session.commit()
            session.refresh(movie)
            return movie

    @staticmethod
    def update_movie(movie_id: int, movie_data: MovieUpdate) -> Optional[Movie]:
        """Update an existing movie entry."""
        with get_session() as session:
            movie = session.get(Movie, movie_id)
            if movie is None:
                return None

            # Update only provided fields
            update_data = movie_data.model_dump(exclude_unset=True)
            for field, value in update_data.items():
                setattr(movie, field, value)

            movie.updated_at = datetime.utcnow()
            session.add(movie)
            session.commit()
            session.refresh(movie)
            return movie

    @staticmethod
    def delete_movie(movie_id: int) -> bool:
        """Delete a movie entry."""
        with get_session() as session:
            movie = session.get(Movie, movie_id)
            if movie is None:
                return False

            session.delete(movie)
            session.commit()
            return True

    @staticmethod
    def get_movie_by_id(movie_id: int) -> Optional[Movie]:
        """Retrieve a movie by ID."""
        with get_session() as session:
            return session.get(Movie, movie_id)
