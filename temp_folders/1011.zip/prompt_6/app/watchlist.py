from nicegui import ui
from app.movie_service import MovieService
from app.models import MovieCreate, MovieUpdate, WatchStatus
from datetime import datetime
from typing import Optional


def create():
    """Create the movie watchlist application."""

    @ui.page("/")
    def index():
        # Apply modern theme
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        # Initialize state
        movies_data = []
        movie_table: Optional[ui.table] = None

        def refresh_movies():
            """Refresh the movies list and update the table."""
            nonlocal movies_data, movie_table
            movies = MovieService.get_all_movies()
            movies_data.clear()
            movies_data.extend(
                [
                    {
                        "id": movie.id,
                        "title": movie.title,
                        "director": movie.director,
                        "release_year": movie.release_year,
                        "watch_status": movie.watch_status.value,
                        "created_at": movie.created_at.strftime("%Y-%m-%d %H:%M"),
                        "actions": movie.id,
                    }
                    for movie in movies
                ]
            )

            if movie_table is not None:
                movie_table.rows = movies_data
                movie_table.update()

        async def delete_movie(movie_id: int):
            """Delete a movie with confirmation."""
            with ui.dialog() as dialog, ui.card():
                ui.label("Are you sure you want to delete this movie?").classes("text-lg mb-4")
                with ui.row().classes("gap-2 justify-end"):
                    ui.button("Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
                    ui.button("🗑️ Delete", on_click=lambda: dialog.submit("delete")).props("color=negative")

            result = await dialog
            if result == "delete":
                if MovieService.delete_movie(movie_id):
                    ui.notify("Movie deleted successfully!", type="positive")
                    refresh_movies()
                else:
                    ui.notify("Failed to delete movie", type="negative")

        async def edit_movie(movie_id: int):
            """Edit a movie in a dialog."""
            movie = MovieService.get_movie_by_id(movie_id)
            if movie is None:
                ui.notify("Movie not found", type="negative")
                return

            with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
                ui.label("✏️ Edit Movie").classes("text-xl font-bold mb-4")

                title_input = ui.input("Title", value=movie.title).classes("w-full mb-3")
                director_input = ui.input("Director", value=movie.director).classes("w-full mb-3")
                year_input = ui.number("Release Year", value=movie.release_year, format="%.0f", precision=0).classes(
                    "w-full mb-3"
                )
                status_select = ui.select(
                    options={status.value: status.value for status in WatchStatus},
                    value=movie.watch_status.value,
                    label="Watch Status",
                ).classes("w-full mb-4")

                with ui.row().classes("gap-2 justify-end w-full"):
                    ui.button("Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
                    ui.button("💾 Update", on_click=lambda: dialog.submit("update")).props("color=primary")

            result = await dialog
            if result == "update":
                try:
                    # Validate year
                    if year_input.value is None or year_input.value < 1800 or year_input.value > 2100:
                        ui.notify("Please enter a valid release year (1800-2100)", type="negative")
                        return

                    if not title_input.value or not director_input.value:
                        ui.notify("Title and Director are required", type="negative")
                        return

                    update_data = MovieUpdate(
                        title=title_input.value.strip(),
                        director=director_input.value.strip(),
                        release_year=int(year_input.value),
                        watch_status=WatchStatus(status_select.value),
                    )

                    updated_movie = MovieService.update_movie(movie_id, update_data)
                    if updated_movie:
                        ui.notify("Movie updated successfully!", type="positive")
                        refresh_movies()
                    else:
                        ui.notify("Failed to update movie", type="negative")

                except Exception as e:
                    ui.notify(f"Error updating movie: {str(e)}", type="negative")

        # Page header
        with ui.column().classes("w-full max-w-6xl mx-auto p-6"):
            ui.label("🎬 Movie Watchlist Manager").classes("text-3xl font-bold text-gray-800 mb-2")
            ui.label("Track your movies and their watch status").classes("text-lg text-gray-600 mb-6")

            # Add new movie form
            with ui.card().classes("w-full p-6 mb-6 shadow-lg"):
                ui.label("Add New Movie").classes("text-xl font-semibold mb-4")

                with ui.row().classes("gap-4 w-full items-end"):
                    title_input = ui.input("Movie Title", placeholder="Enter movie title").classes("flex-1")
                    director_input = ui.input("Director", placeholder="Enter director name").classes("flex-1")
                    year_input = ui.number(
                        "Release Year", value=datetime.now().year, format="%.0f", precision=0
                    ).classes("w-32")
                    status_select = ui.select(
                        options={status.value: status.value for status in WatchStatus},
                        value=WatchStatus.PLANNED.value,
                        label="Status",
                    ).classes("w-40")

                def add_movie():
                    """Add a new movie to the watchlist."""
                    try:
                        # Validation
                        if not title_input.value or not director_input.value:
                            ui.notify("Title and Director are required", type="negative")
                            return

                        if year_input.value is None or year_input.value < 1800 or year_input.value > 2100:
                            ui.notify("Please enter a valid release year (1800-2100)", type="negative")
                            return

                        # Create movie
                        movie_data = MovieCreate(
                            title=title_input.value.strip(),
                            director=director_input.value.strip(),
                            release_year=int(year_input.value),
                            watch_status=WatchStatus(status_select.value),
                        )

                        MovieService.create_movie(movie_data)
                        ui.notify("Movie added successfully!", type="positive")

                        # Clear form
                        title_input.value = ""
                        director_input.value = ""
                        year_input.value = datetime.now().year
                        status_select.value = WatchStatus.PLANNED.value

                        # Refresh table
                        refresh_movies()

                    except Exception as e:
                        ui.notify(f"Error adding movie: {str(e)}", type="negative")

                ui.button("➕ Add Movie", on_click=add_movie).classes("bg-primary text-white px-6 py-2 mt-4")

            # Movies table
            with ui.card().classes("w-full p-6 shadow-lg"):
                ui.label("Your Movies").classes("text-xl font-semibold mb-4")

                # Define table columns
                columns = [
                    {"name": "title", "label": "Title", "field": "title", "align": "left", "sortable": True},
                    {"name": "director", "label": "Director", "field": "director", "align": "left", "sortable": True},
                    {
                        "name": "release_year",
                        "label": "Year",
                        "field": "release_year",
                        "align": "center",
                        "sortable": True,
                    },
                    {
                        "name": "watch_status",
                        "label": "Status",
                        "field": "watch_status",
                        "align": "center",
                        "sortable": True,
                    },
                    {
                        "name": "created_at",
                        "label": "Added",
                        "field": "created_at",
                        "align": "center",
                        "sortable": True,
                    },
                    {"name": "actions", "label": "Actions", "field": "actions", "align": "center", "sortable": False},
                ]

                # Create table
                movie_table = ui.table(columns=columns, rows=movies_data, pagination=10).classes("w-full")

                # Add custom slot for actions column
                movie_table.add_slot(
                    "body-cell-actions",
                    """
                    <q-td :props="props">
                        <q-btn flat round color="primary" icon="edit" size="sm" 
                               @click="$parent.$emit('edit', props.row.id)" class="q-mr-xs">
                            <q-tooltip>Edit</q-tooltip>
                        </q-btn>
                        <q-btn flat round color="negative" icon="delete" size="sm" 
                               @click="$parent.$emit('delete', props.row.id)">
                            <q-tooltip>Delete</q-tooltip>
                        </q-btn>
                    </q-td>
                """,
                )

                # Add custom slot for status column with color coding
                movie_table.add_slot(
                    "body-cell-watch_status",
                    """
                    <q-td :props="props">
                        <q-badge :color="props.value === 'Completed' ? 'positive' : 
                                        props.value === 'Watching' ? 'warning' : 'info'" 
                                :label="props.value" />
                    </q-td>
                """,
                )

                # Handle table events
                movie_table.on("edit", lambda e: edit_movie(e.args))
                movie_table.on("delete", lambda e: delete_movie(e.args))

                # Status summary
                def get_status_summary():
                    """Get summary of movies by status."""
                    if not movies_data:
                        return "No movies added yet"

                    status_counts = {}
                    for movie in movies_data:
                        status = movie["watch_status"]
                        status_counts[status] = status_counts.get(status, 0) + 1

                    total = len(movies_data)
                    summary_parts = []

                    if "Completed" in status_counts:
                        summary_parts.append(f"{status_counts['Completed']} completed")
                    if "Watching" in status_counts:
                        summary_parts.append(f"{status_counts['Watching']} watching")
                    if "Planned" in status_counts:
                        summary_parts.append(f"{status_counts['Planned']} planned")

                    return f"Total: {total} movies ({', '.join(summary_parts)})"

                summary_label = ui.label().classes("text-sm text-gray-600 mt-4")

                def update_summary():
                    """Update the summary label."""
                    summary_label.text = get_status_summary()

                # Override refresh to update summary
                original_refresh = refresh_movies

                def refresh_movies():
                    original_refresh()
                    update_summary()

        # Initial load
        refresh_movies()
