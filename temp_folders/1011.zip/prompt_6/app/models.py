from sqlmodel import SQLModel, Field
from datetime import datetime
from typing import Optional
from enum import Enum


class WatchStatus(str, Enum):
    """Enum for movie watch status."""

    PLANNED = "Planned"
    WATCHING = "Watching"
    COMPLETED = "Completed"


# Persistent models (stored in database)
class Movie(SQLModel, table=True):
    """Movie model for watchlist management."""

    __tablename__ = "movies"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    title: str = Field(max_length=255, index=True)
    director: str = Field(max_length=255)
    release_year: int = Field(ge=1800, le=2100)  # Reasonable year constraints
    watch_status: WatchStatus = Field(default=WatchStatus.PLANNED)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class MovieCreate(SQLModel, table=False):
    """Schema for creating a new movie entry."""

    title: str = Field(max_length=255)
    director: str = Field(max_length=255)
    release_year: int = Field(ge=1800, le=2100)
    watch_status: WatchStatus = Field(default=WatchStatus.PLANNED)


class MovieUpdate(SQLModel, table=False):
    """Schema for updating an existing movie entry."""

    title: Optional[str] = Field(default=None, max_length=255)
    director: Optional[str] = Field(default=None, max_length=255)
    release_year: Optional[int] = Field(default=None, ge=1800, le=2100)
    watch_status: Optional[WatchStatus] = Field(default=None)


class MovieResponse(SQLModel, table=False):
    """Schema for movie API responses."""

    id: int
    title: str
    director: str
    release_year: int
    watch_status: WatchStatus
    created_at: str  # ISO format string for JSON serialization
    updated_at: str  # ISO format string for JSON serialization
