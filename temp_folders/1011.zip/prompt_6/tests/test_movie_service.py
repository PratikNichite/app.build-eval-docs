import pytest
from app.database import reset_db
from app.movie_service import MovieService
from app.models import MovieCreate, MovieUpdate, WatchStatus


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_create_movie(new_db):
    """Test creating a new movie."""
    movie_data = MovieCreate(
        title="The Matrix", director="The Wachowskis", release_year=1999, watch_status=WatchStatus.PLANNED
    )

    movie = MovieService.create_movie(movie_data)

    assert movie.id is not None
    assert movie.title == "The Matrix"
    assert movie.director == "The Wachowskis"
    assert movie.release_year == 1999
    assert movie.watch_status == WatchStatus.PLANNED
    assert movie.created_at is not None
    assert movie.updated_at is not None


def test_get_all_movies_empty(new_db):
    """Test getting all movies when database is empty."""
    movies = MovieService.get_all_movies()
    assert movies == []


def test_get_all_movies_with_data(new_db):
    """Test getting all movies with data."""
    # Create test movies
    movie1_data = MovieCreate(
        title="Movie 1", director="Director 1", release_year=2020, watch_status=WatchStatus.COMPLETED
    )
    movie2_data = MovieCreate(
        title="Movie 2", director="Director 2", release_year=2021, watch_status=WatchStatus.WATCHING
    )

    MovieService.create_movie(movie1_data)
    MovieService.create_movie(movie2_data)

    movies = MovieService.get_all_movies()
    assert len(movies) == 2

    # Should be ordered by created_at desc (most recent first)
    assert movies[0].title == "Movie 2"
    assert movies[1].title == "Movie 1"


def test_get_movie_by_id(new_db):
    """Test getting a movie by ID."""
    movie_data = MovieCreate(title="Test Movie", director="Test Director", release_year=2022)

    created_movie = MovieService.create_movie(movie_data)
    movie_id = created_movie.id
    assert movie_id is not None

    retrieved_movie = MovieService.get_movie_by_id(movie_id)
    assert retrieved_movie is not None
    assert retrieved_movie.title == "Test Movie"
    assert retrieved_movie.director == "Test Director"


def test_get_movie_by_id_not_found(new_db):
    """Test getting a movie by non-existent ID."""
    movie = MovieService.get_movie_by_id(999)
    assert movie is None


def test_update_movie(new_db):
    """Test updating a movie."""
    # Create a movie
    movie_data = MovieCreate(
        title="Original Title", director="Original Director", release_year=2020, watch_status=WatchStatus.PLANNED
    )
    created_movie = MovieService.create_movie(movie_data)
    movie_id = created_movie.id
    assert movie_id is not None

    # Update the movie
    update_data = MovieUpdate(title="Updated Title", watch_status=WatchStatus.COMPLETED)

    updated_movie = MovieService.update_movie(movie_id, update_data)
    assert updated_movie is not None
    assert updated_movie.title == "Updated Title"
    assert updated_movie.director == "Original Director"  # Unchanged
    assert updated_movie.release_year == 2020  # Unchanged
    assert updated_movie.watch_status == WatchStatus.COMPLETED
    assert updated_movie.updated_at > updated_movie.created_at


def test_update_movie_partial(new_db):
    """Test updating only specific fields of a movie."""
    # Create a movie
    movie_data = MovieCreate(
        title="Test Movie", director="Test Director", release_year=2020, watch_status=WatchStatus.PLANNED
    )
    created_movie = MovieService.create_movie(movie_data)
    movie_id = created_movie.id
    assert movie_id is not None

    # Update only the status
    update_data = MovieUpdate(watch_status=WatchStatus.WATCHING)

    updated_movie = MovieService.update_movie(movie_id, update_data)
    assert updated_movie is not None
    assert updated_movie.title == "Test Movie"  # Unchanged
    assert updated_movie.director == "Test Director"  # Unchanged
    assert updated_movie.release_year == 2020  # Unchanged
    assert updated_movie.watch_status == WatchStatus.WATCHING


def test_update_movie_not_found(new_db):
    """Test updating a non-existent movie."""
    update_data = MovieUpdate(title="New Title")

    result = MovieService.update_movie(999, update_data)
    assert result is None


def test_delete_movie(new_db):
    """Test deleting a movie."""
    # Create a movie
    movie_data = MovieCreate(title="To Be Deleted", director="Test Director", release_year=2020)
    created_movie = MovieService.create_movie(movie_data)
    movie_id = created_movie.id
    assert movie_id is not None

    # Verify it exists
    assert MovieService.get_movie_by_id(movie_id) is not None

    # Delete it
    result = MovieService.delete_movie(movie_id)
    assert result is True

    # Verify it's gone
    assert MovieService.get_movie_by_id(movie_id) is None


def test_delete_movie_not_found(new_db):
    """Test deleting a non-existent movie."""
    result = MovieService.delete_movie(999)
    assert not result


def test_movie_validation_constraints(new_db):
    """Test that movie validation constraints work."""
    # Test year constraints
    with pytest.raises(Exception):
        MovieService.create_movie(
            MovieCreate(
                title="Test",
                director="Test",
                release_year=1700,  # Too early
            )
        )

    with pytest.raises(Exception):
        MovieService.create_movie(
            MovieCreate(
                title="Test",
                director="Test",
                release_year=2200,  # Too late
            )
        )


def test_watch_status_enum_values(new_db):
    """Test all watch status enum values work correctly."""
    for status in WatchStatus:
        movie_data = MovieCreate(
            title=f"Test Movie {status.value}", director="Test Director", release_year=2020, watch_status=status
        )

        movie = MovieService.create_movie(movie_data)
        assert movie.watch_status == status

        # Test updating to different status
        other_statuses = [s for s in WatchStatus if s != status]
        if other_statuses:
            new_status = other_statuses[0]
            update_data = MovieUpdate(watch_status=new_status)
            updated_movie = MovieService.update_movie(movie.id, update_data)
            assert updated_movie is not None
            assert updated_movie.watch_status == new_status


def test_multiple_movies_different_statuses(new_db):
    """Test creating movies with different statuses and retrieving them."""
    movies_data = [
        MovieCreate(title="Planned Movie", director="Director 1", release_year=2020, watch_status=WatchStatus.PLANNED),
        MovieCreate(
            title="Watching Movie", director="Director 2", release_year=2021, watch_status=WatchStatus.WATCHING
        ),
        MovieCreate(
            title="Completed Movie", director="Director 3", release_year=2022, watch_status=WatchStatus.COMPLETED
        ),
    ]

    created_movies = []
    for movie_data in movies_data:
        created_movies.append(MovieService.create_movie(movie_data))

    all_movies = MovieService.get_all_movies()
    assert len(all_movies) == 3

    # Check that all statuses are represented
    statuses = {movie.watch_status for movie in all_movies}
    assert statuses == {WatchStatus.PLANNED, WatchStatus.WATCHING, WatchStatus.COMPLETED}


def test_movie_timestamps(new_db):
    """Test that created_at and updated_at timestamps work correctly."""
    # Create a movie
    movie_data = MovieCreate(title="Timestamp Test", director="Test Director", release_year=2020)

    created_movie = MovieService.create_movie(movie_data)

    # Check initial timestamps
    assert created_movie.created_at is not None
    assert created_movie.updated_at is not None
    # Note: These might be slightly different due to processing time

    # Wait a bit and update
    import time

    time.sleep(0.2)  # Use longer sleep for more reliable test

    update_data = MovieUpdate(title="Updated Title")
    updated_movie = MovieService.update_movie(created_movie.id, update_data)

    assert updated_movie is not None
    assert updated_movie.created_at == created_movie.created_at  # Should not change
    assert updated_movie.updated_at > created_movie.created_at  # Should be newer than creation
