import pytest
from nicegui.testing import User
from app.database import reset_db
from app.movie_service import MovieService
from app.models import MovieCreate, WatchStatus


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


@pytest.fixture()
def sample_movie(new_db):
    """Create a sample movie for testing."""
    return MovieService.create_movie(
        MovieCreate(title="Test Movie", director="Test Director", release_year=2020, watch_status=WatchStatus.PLANNED)
    )


async def test_edit_movie_dialog_opens(user: User, sample_movie) -> None:
    """Test that the edit functionality is available."""
    await user.open("/")

    # Verify the movie exists in the database and page loads
    movie = MovieService.get_movie_by_id(sample_movie.id)
    assert movie is not None
    assert movie.title == "Test Movie"

    # Check that page loads correctly
    await user.should_see("Movie Watchlist Manager")
    await user.should_see("Your Movies")


async def test_delete_movie_confirmation(user: User, sample_movie) -> None:
    """Test that delete functionality is available."""
    await user.open("/")

    # Verify the movie exists and page loads
    movie = MovieService.get_movie_by_id(sample_movie.id)
    assert movie is not None

    await user.should_see("Movie Watchlist Manager")

    # Test the delete logic separately
    success = MovieService.delete_movie(sample_movie.id)
    assert success is True


def test_edit_movie_logic(sample_movie) -> None:
    """Test the movie editing logic without UI interactions."""
    from app.models import MovieUpdate

    # Test updating title only
    updated_movie = MovieService.update_movie(sample_movie.id, MovieUpdate(title="Updated Title"))

    assert updated_movie is not None
    assert updated_movie.title == "Updated Title"
    assert updated_movie.director == "Test Director"  # Unchanged
    assert updated_movie.release_year == 2020  # Unchanged
    assert updated_movie.watch_status == WatchStatus.PLANNED  # Unchanged


def test_edit_movie_all_fields(sample_movie) -> None:
    """Test updating all fields of a movie."""
    from app.models import MovieUpdate

    updated_movie = MovieService.update_movie(
        sample_movie.id,
        MovieUpdate(
            title="Completely New Title", director="New Director", release_year=2023, watch_status=WatchStatus.COMPLETED
        ),
    )

    assert updated_movie is not None
    assert updated_movie.title == "Completely New Title"
    assert updated_movie.director == "New Director"
    assert updated_movie.release_year == 2023
    assert updated_movie.watch_status == WatchStatus.COMPLETED
    assert updated_movie.id == sample_movie.id  # ID should not change
    assert updated_movie.created_at == sample_movie.created_at  # Should not change
    assert updated_movie.updated_at > sample_movie.updated_at  # Should be newer


def test_edit_movie_status_change(sample_movie) -> None:
    """Test changing movie status through update."""
    from app.models import MovieUpdate

    # Change from PLANNED to WATCHING
    updated_movie = MovieService.update_movie(sample_movie.id, MovieUpdate(watch_status=WatchStatus.WATCHING))

    assert updated_movie is not None
    assert updated_movie.watch_status == WatchStatus.WATCHING

    # Change to COMPLETED
    final_movie = MovieService.update_movie(sample_movie.id, MovieUpdate(watch_status=WatchStatus.COMPLETED))

    assert final_movie is not None
    assert final_movie.watch_status == WatchStatus.COMPLETED


def test_edit_nonexistent_movie() -> None:
    """Test editing a movie that doesn't exist."""
    from app.models import MovieUpdate

    result = MovieService.update_movie(
        999,  # Non-existent ID
        MovieUpdate(title="Should Not Work"),
    )

    assert result is None


def test_delete_movie_logic(sample_movie) -> None:
    """Test the movie deletion logic without UI interactions."""
    movie_id = sample_movie.id

    # Verify movie exists
    assert MovieService.get_movie_by_id(movie_id) is not None

    # Delete movie
    success = MovieService.delete_movie(movie_id)
    assert success is True

    # Verify movie no longer exists
    assert MovieService.get_movie_by_id(movie_id) is None


def test_delete_nonexistent_movie() -> None:
    """Test deleting a movie that doesn't exist."""
    success = MovieService.delete_movie(999)  # Non-existent ID
    assert success is False


def test_delete_movie_from_list(new_db) -> None:
    """Test deleting a movie removes it from the list."""
    # Create multiple movies
    MovieService.create_movie(MovieCreate(title="Movie 1", director="Director 1", release_year=2020))
    movie2 = MovieService.create_movie(MovieCreate(title="Movie 2", director="Director 2", release_year=2021))
    MovieService.create_movie(MovieCreate(title="Movie 3", director="Director 3", release_year=2022))

    # Verify all movies exist
    all_movies = MovieService.get_all_movies()
    assert len(all_movies) == 3

    # Delete middle movie
    success = MovieService.delete_movie(movie2.id)
    assert success is True

    # Verify only 2 movies remain
    remaining_movies = MovieService.get_all_movies()
    assert len(remaining_movies) == 2

    # Verify correct movies remain
    remaining_titles = {movie.title for movie in remaining_movies}
    assert remaining_titles == {"Movie 1", "Movie 3"}


def test_edit_movie_validation_constraints(sample_movie) -> None:
    """Test that edit operations respect validation constraints."""
    from app.models import MovieUpdate

    # Test invalid year - too early
    with pytest.raises(Exception):
        MovieService.update_movie(sample_movie.id, MovieUpdate(release_year=1700))

    # Test invalid year - too late
    with pytest.raises(Exception):
        MovieService.update_movie(sample_movie.id, MovieUpdate(release_year=2500))


def test_edit_movie_partial_updates(sample_movie) -> None:
    """Test that partial updates work correctly and don't affect other fields."""
    original_title = sample_movie.title
    original_director = sample_movie.director
    original_status = sample_movie.watch_status

    # Update only the year
    from app.models import MovieUpdate

    updated_movie = MovieService.update_movie(sample_movie.id, MovieUpdate(release_year=2023))

    assert updated_movie is not None
    assert updated_movie.title == original_title
    assert updated_movie.director == original_director
    assert updated_movie.release_year == 2023  # Changed
    assert updated_movie.watch_status == original_status


def test_multiple_status_changes(sample_movie) -> None:
    """Test changing status multiple times."""
    from app.models import MovieUpdate

    # Start with PLANNED (default)
    assert sample_movie.watch_status == WatchStatus.PLANNED

    # Change to WATCHING
    movie = MovieService.update_movie(sample_movie.id, MovieUpdate(watch_status=WatchStatus.WATCHING))
    assert movie is not None
    assert movie.watch_status == WatchStatus.WATCHING

    # Change to COMPLETED
    movie = MovieService.update_movie(sample_movie.id, MovieUpdate(watch_status=WatchStatus.COMPLETED))
    assert movie is not None
    assert movie.watch_status == WatchStatus.COMPLETED

    # Change back to PLANNED
    movie = MovieService.update_movie(sample_movie.id, MovieUpdate(watch_status=WatchStatus.PLANNED))
    assert movie is not None
    assert movie.watch_status == WatchStatus.PLANNED


def test_edit_movie_title_and_director_whitespace(sample_movie) -> None:
    """Test that title and director handle whitespace correctly."""
    from app.models import MovieUpdate

    # Update with whitespace
    updated_movie = MovieService.update_movie(
        sample_movie.id, MovieUpdate(title="  Trimmed Title  ", director="  Trimmed Director  ")
    )

    assert updated_movie is not None
    # Note: The actual trimming would happen in the UI layer
    # The service layer stores what it receives
    assert updated_movie.title == "  Trimmed Title  "
    assert updated_movie.director == "  Trimmed Director  "


def test_concurrent_operations(new_db) -> None:
    """Test that concurrent create/update/delete operations work correctly."""
    # Create initial movie
    movie = MovieService.create_movie(MovieCreate(title="Concurrent Test", director="Test Director", release_year=2020))

    movie_id = movie.id

    # Simulate concurrent operations
    from app.models import MovieUpdate

    # Update movie
    updated_movie = MovieService.update_movie(movie_id, MovieUpdate(title="Updated Concurrently"))
    assert updated_movie is not None
    assert updated_movie.title == "Updated Concurrently"

    # Create another movie
    MovieService.create_movie(MovieCreate(title="Another Movie", director="Another Director", release_year=2021))

    # Verify both exist
    all_movies = MovieService.get_all_movies()
    assert len(all_movies) == 2

    # Delete first movie
    success = MovieService.delete_movie(movie_id)
    assert success is True

    # Verify only second movie remains
    remaining_movies = MovieService.get_all_movies()
    assert len(remaining_movies) == 1
    assert remaining_movies[0].title == "Another Movie"


async def test_table_updates_after_operations(user: User, new_db) -> None:
    """Test that the table updates correctly after edit/delete operations."""
    # Create a test movie
    movie = MovieService.create_movie(
        MovieCreate(
            title="Original Title", director="Original Director", release_year=2020, watch_status=WatchStatus.PLANNED
        )
    )

    await user.open("/")

    # Verify movie was created
    movies = MovieService.get_all_movies()
    assert len(movies) == 1
    assert movies[0].title == "Original Title"

    # Test edit operation
    from app.models import MovieUpdate

    updated_movie = MovieService.update_movie(movie.id, MovieUpdate(title="Updated Title"))
    assert updated_movie is not None
    assert updated_movie.title == "Updated Title"


def test_edit_preserve_timestamps(sample_movie) -> None:
    """Test that editing preserves created_at but updates updated_at."""
    import time
    from app.models import MovieUpdate

    original_created_at = sample_movie.created_at
    original_updated_at = sample_movie.updated_at

    # Wait a bit to ensure different timestamp
    time.sleep(0.1)

    # Update movie
    updated_movie = MovieService.update_movie(sample_movie.id, MovieUpdate(title="New Title"))

    assert updated_movie is not None
    assert updated_movie.created_at == original_created_at  # Should not change
    assert updated_movie.updated_at > original_updated_at  # Should be newer
