import pytest
from datetime import date, timedelta
from decimal import Decimal
from app.database import reset_db
from app.services.car_service import create_car
from app.services.maintenance_service import (
    create_maintenance_record,
    get_maintenance_records_by_car,
    get_maintenance_record_by_id,
    update_maintenance_record,
    delete_maintenance_record,
    get_recent_maintenance_records,
)
from app.models import CarCreate, MaintenanceRecordCreate, MaintenanceRecordUpdate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


@pytest.fixture()
def sample_car(new_db):
    """Create a sample car for testing."""
    car_data = CarCreate(
        make="Toyota", model="Camry", year=2023, vin="1HGBH41JXMN109186", license_plate="ABC123", color="Silver"
    )
    return create_car(car_data)


def test_create_maintenance_record(sample_car):
    """Test creating a new maintenance record."""
    record_data = MaintenanceRecordCreate(
        car_id=sample_car.id,
        service_type="Oil Change",
        description="Regular oil change",
        service_date=date.today(),
        odometer_reading=15000,
        cost=Decimal("45.99"),
        service_provider="Quick Lube",
        notes="Used synthetic oil",
    )

    record = create_maintenance_record(record_data)

    assert record.id is not None
    assert record.car_id == sample_car.id
    assert record.service_type == "Oil Change"
    assert record.description == "Regular oil change"
    assert record.service_date == date.today()
    assert record.odometer_reading == 15000
    assert record.cost == Decimal("45.99")
    assert record.service_provider == "Quick Lube"
    assert record.notes == "Used synthetic oil"


def test_get_maintenance_records_by_car_empty(sample_car):
    """Test getting maintenance records when none exist."""
    records = get_maintenance_records_by_car(sample_car.id)
    assert records == []


def test_get_maintenance_records_by_car_with_data(sample_car):
    """Test getting maintenance records when some exist."""
    record_data1 = MaintenanceRecordCreate(
        car_id=sample_car.id,
        service_type="Oil Change",
        service_date=date.today(),
        odometer_reading=15000,
        cost=Decimal("45.99"),
    )
    record_data2 = MaintenanceRecordCreate(
        car_id=sample_car.id,
        service_type="Tire Rotation",
        service_date=date.today() - timedelta(days=30),
        odometer_reading=14000,
        cost=Decimal("25.00"),
    )

    create_maintenance_record(record_data1)
    create_maintenance_record(record_data2)

    records = get_maintenance_records_by_car(sample_car.id)
    assert len(records) == 2
    # Should be ordered by service_date descending
    assert records[0].service_type == "Oil Change"
    assert records[1].service_type == "Tire Rotation"


def test_get_maintenance_record_by_id_existing(sample_car):
    """Test getting a maintenance record by ID when it exists."""
    record_data = MaintenanceRecordCreate(
        car_id=sample_car.id,
        service_type="Oil Change",
        service_date=date.today(),
        odometer_reading=15000,
        cost=Decimal("45.99"),
    )

    created_record = create_maintenance_record(record_data)
    retrieved_record = get_maintenance_record_by_id(created_record.id)

    assert retrieved_record is not None
    assert retrieved_record.id == created_record.id
    assert retrieved_record.service_type == "Oil Change"


def test_get_maintenance_record_by_id_nonexistent(sample_car):
    """Test getting a maintenance record by ID when it doesn't exist."""
    record = get_maintenance_record_by_id(999)
    assert record is None


def test_update_maintenance_record(sample_car):
    """Test updating an existing maintenance record."""
    record_data = MaintenanceRecordCreate(
        car_id=sample_car.id,
        service_type="Oil Change",
        service_date=date.today(),
        odometer_reading=15000,
        cost=Decimal("45.99"),
    )

    created_record = create_maintenance_record(record_data)

    update_data = MaintenanceRecordUpdate(
        service_type="Full Service Oil Change", cost=Decimal("65.99"), notes="Premium synthetic oil used"
    )

    updated_record = update_maintenance_record(created_record.id, update_data)

    assert updated_record is not None
    assert updated_record.service_type == "Full Service Oil Change"
    assert updated_record.cost == Decimal("65.99")
    assert updated_record.notes == "Premium synthetic oil used"
    assert updated_record.service_date == date.today()  # Unchanged


def test_update_maintenance_record_nonexistent(sample_car):
    """Test updating a maintenance record that doesn't exist."""
    update_data = MaintenanceRecordUpdate(service_type="Oil Change")
    result = update_maintenance_record(999, update_data)
    assert result is None


def test_delete_maintenance_record_existing(sample_car):
    """Test deleting an existing maintenance record."""
    record_data = MaintenanceRecordCreate(
        car_id=sample_car.id,
        service_type="Oil Change",
        service_date=date.today(),
        odometer_reading=15000,
        cost=Decimal("45.99"),
    )

    created_record = create_maintenance_record(record_data)
    result = delete_maintenance_record(created_record.id)

    assert result is True
    assert get_maintenance_record_by_id(created_record.id) is None


def test_delete_maintenance_record_nonexistent(sample_car):
    """Test deleting a maintenance record that doesn't exist."""
    result = delete_maintenance_record(999)
    assert result is False


def test_get_recent_maintenance_records(sample_car):
    """Test getting recent maintenance records across all cars."""
    # Create multiple records with different dates
    dates = [
        date.today(),
        date.today() - timedelta(days=1),
        date.today() - timedelta(days=5),
        date.today() - timedelta(days=10),
    ]

    for i, service_date in enumerate(dates):
        record_data = MaintenanceRecordCreate(
            car_id=sample_car.id,
            service_type=f"Service {i + 1}",
            service_date=service_date,
            odometer_reading=15000 + (i * 100),
            cost=Decimal("50.00"),
        )
        create_maintenance_record(record_data)

    # Get recent records with limit
    recent_records = get_recent_maintenance_records(3)
    assert len(recent_records) == 3

    # Should be ordered by service_date descending
    assert recent_records[0].service_type == "Service 1"
    assert recent_records[1].service_type == "Service 2"
    assert recent_records[2].service_type == "Service 3"


def test_maintenance_record_updates_car_odometer(sample_car):
    """Test that creating maintenance record updates car odometer."""
    # Car starts with default odometer of 0
    record_data = MaintenanceRecordCreate(
        car_id=sample_car.id,
        service_type="Oil Change",
        service_date=date.today(),
        odometer_reading=15000,
        cost=Decimal("45.99"),
    )

    create_maintenance_record(record_data)

    # Get updated car and check odometer
    from app.services.car_service import get_car_by_id

    updated_car = get_car_by_id(sample_car.id)
    assert updated_car.current_odometer == 15000
