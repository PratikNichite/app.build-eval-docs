import pytest
from nicegui.testing import User
from app.database import reset_db
from app.services.car_service import create_car
from app.services.maintenance_service import create_maintenance_record
from app.services.reminder_service import create_reminder
from app.models import CarCreate, MaintenanceRecordCreate, ServiceReminderCreate
from datetime import date, timedelta
from decimal import Decimal


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


@pytest.fixture()
def sample_data(new_db):
    """Create sample data for testing."""
    # Create a car
    car_data = CarCreate(
        make="Toyota",
        model="Camry",
        year=2023,
        vin="1HGBH41JXMN109186",
        license_plate="ABC123",
        color="Silver",
        current_odometer=15000,
    )
    car = create_car(car_data)

    # Create a maintenance record
    maintenance_data = MaintenanceRecordCreate(
        car_id=car.id,
        service_type="Oil Change",
        service_date=date.today(),
        odometer_reading=15000,
        cost=Decimal("45.99"),
    )
    create_maintenance_record(maintenance_data)

    # Create an overdue reminder
    overdue_reminder = ServiceReminderCreate(
        car_id=car.id, service_type="Brake Inspection", due_date=date.today() - timedelta(days=5)
    )
    create_reminder(overdue_reminder)

    # Create an upcoming reminder
    upcoming_reminder = ServiceReminderCreate(
        car_id=car.id, service_type="Tire Rotation", due_date=date.today() + timedelta(days=15)
    )
    create_reminder(upcoming_reminder)

    return car


async def test_dashboard_displays_metrics(user: User, sample_data) -> None:
    """Test that dashboard displays key metrics correctly."""
    await user.open("/")

    # Check that the dashboard title is present
    await user.should_see("Car Maintenance Dashboard")

    # Check that metric cards are displayed
    await user.should_see("Total Cars")
    await user.should_see("Recent Services")
    await user.should_see("Overdue Items")
    await user.should_see("Upcoming (30d)")


async def test_dashboard_navigation(user: User, sample_data) -> None:
    """Test navigation from dashboard."""
    await user.open("/")

    # Test navigation to cars page
    user.find("Add New Car").click()
    # Should navigate or open a form


async def test_car_list_displays_cars(user: User, sample_data) -> None:
    """Test that the car list displays cars correctly."""
    await user.open("/")

    # Should display the sample car
    await user.should_see("2023 Toyota Camry")
    await user.should_see("ABC123")
    await user.should_see("Silver")


async def test_cars_page_functionality(user: User, sample_data) -> None:
    """Test cars page basic functionality."""
    await user.open("/cars")

    # Check page elements
    await user.should_see("Vehicle Management")
    await user.should_see("Add New Car")
    await user.should_see("2023 Toyota Camry")


async def test_car_detail_page_loads(user: User, sample_data) -> None:
    """Test that car detail page loads correctly."""
    car_id = sample_data.id
    await user.open(f"/car/{car_id}")

    # Check that car details are displayed
    await user.should_see("2023 Toyota Camry")
    await user.should_see("ABC123")
    await user.should_see("Current Odometer")
    await user.should_see("15,000 miles")

    # Check that tabs are present
    await user.should_see("Maintenance History")
    await user.should_see("Service Reminders")


async def test_car_detail_nonexistent(user: User, new_db) -> None:
    """Test car detail page with non-existent car."""
    await user.open("/car/999")

    await user.should_see("Car not found")
    await user.should_see("Back to Dashboard")


async def test_maintenance_history_displays(user: User, sample_data) -> None:
    """Test that maintenance history is displayed."""
    car_id = sample_data.id
    await user.open(f"/car/{car_id}")

    # Should show maintenance record in table
    await user.should_see("Maintenance History")
    await user.should_see("Add Maintenance")


async def test_service_reminders_display(user: User, sample_data) -> None:
    """Test that service reminders are displayed."""
    car_id = sample_data.id
    await user.open(f"/car/{car_id}")

    # Click on reminders tab
    user.find("Service Reminders").click()

    # Should show reminders
    await user.should_see("Brake Inspection")
    await user.should_see("Tire Rotation")
