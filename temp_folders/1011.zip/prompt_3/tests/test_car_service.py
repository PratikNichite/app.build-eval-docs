import pytest
from app.database import reset_db
from app.services.car_service import (
    create_car,
    get_all_cars,
    get_car_by_id,
    update_car,
    delete_car,
    update_car_odometer,
)
from app.models import CarCreate, CarUpdate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_create_car(new_db):
    """Test creating a new car."""
    car_data = CarCreate(
        make="Toyota",
        model="Camry",
        year=2023,
        vin="1HGBH41JXMN109186",
        license_plate="ABC123",
        color="Silver",
        current_odometer=15000,
    )

    car = create_car(car_data)

    assert car.id is not None
    assert car.make == "Toyota"
    assert car.model == "Camry"
    assert car.year == 2023
    assert car.vin == "1HGBH41JXMN109186"
    assert car.license_plate == "ABC123"
    assert car.color == "Silver"
    assert car.current_odometer == 15000


def test_get_all_cars_empty(new_db):
    """Test getting all cars when none exist."""
    cars = get_all_cars()
    assert cars == []


def test_get_all_cars_with_data(new_db):
    """Test getting all cars when some exist."""
    car_data1 = CarCreate(
        make="Toyota", model="Camry", year=2023, vin="1HGBH41JXMN109186", license_plate="ABC123", color="Silver"
    )
    car_data2 = CarCreate(
        make="Honda", model="Civic", year=2022, vin="2HGFC2F59NH123456", license_plate="XYZ789", color="Blue"
    )

    create_car(car_data1)
    create_car(car_data2)

    cars = get_all_cars()
    assert len(cars) == 2


def test_get_car_by_id_existing(new_db):
    """Test getting a car by ID when it exists."""
    car_data = CarCreate(
        make="Toyota", model="Camry", year=2023, vin="1HGBH41JXMN109186", license_plate="ABC123", color="Silver"
    )

    created_car = create_car(car_data)
    retrieved_car = get_car_by_id(created_car.id)

    assert retrieved_car is not None
    assert retrieved_car.id == created_car.id
    assert retrieved_car.make == "Toyota"


def test_get_car_by_id_nonexistent(new_db):
    """Test getting a car by ID when it doesn't exist."""
    car = get_car_by_id(999)
    assert car is None


def test_update_car(new_db):
    """Test updating an existing car."""
    car_data = CarCreate(
        make="Toyota", model="Camry", year=2023, vin="1HGBH41JXMN109186", license_plate="ABC123", color="Silver"
    )

    created_car = create_car(car_data)

    update_data = CarUpdate(make="Honda", color="Red", current_odometer=20000)

    updated_car = update_car(created_car.id, update_data)

    assert updated_car is not None
    assert updated_car.make == "Honda"  # Changed
    assert updated_car.model == "Camry"  # Unchanged
    assert updated_car.color == "Red"  # Changed
    assert updated_car.current_odometer == 20000  # Changed


def test_update_car_nonexistent(new_db):
    """Test updating a car that doesn't exist."""
    update_data = CarUpdate(make="Honda")
    result = update_car(999, update_data)
    assert result is None


def test_delete_car_existing(new_db):
    """Test deleting an existing car."""
    car_data = CarCreate(
        make="Toyota", model="Camry", year=2023, vin="1HGBH41JXMN109186", license_plate="ABC123", color="Silver"
    )

    created_car = create_car(car_data)
    result = delete_car(created_car.id)

    assert result is True
    assert get_car_by_id(created_car.id) is None


def test_delete_car_nonexistent(new_db):
    """Test deleting a car that doesn't exist."""
    result = delete_car(999)
    assert result is False


def test_update_car_odometer(new_db):
    """Test updating car odometer reading."""
    car_data = CarCreate(
        make="Toyota",
        model="Camry",
        year=2023,
        vin="1HGBH41JXMN109186",
        license_plate="ABC123",
        color="Silver",
        current_odometer=10000,
    )

    created_car = create_car(car_data)

    # Update with higher odometer reading
    updated_car = update_car_odometer(created_car.id, 15000)
    assert updated_car is not None
    assert updated_car.current_odometer == 15000

    # Try to update with lower odometer reading (should not change)
    updated_car = update_car_odometer(created_car.id, 12000)
    assert updated_car is not None
    assert updated_car.current_odometer == 15000  # Should remain unchanged


def test_update_car_odometer_nonexistent(new_db):
    """Test updating odometer for non-existent car."""
    result = update_car_odometer(999, 15000)
    assert result is None
