import pytest
from datetime import date, timedelta
from decimal import Decimal
from app.database import reset_db
from app.services.car_service import create_car
from app.services.reminder_service import (
    create_reminder,
    get_reminders_by_car,
    get_reminder_by_id,
    update_reminder,
    delete_reminder,
    get_upcoming_reminders,
    get_overdue_reminders,
    complete_reminder,
    get_reminders_by_odometer,
)
from app.models import CarCreate, ServiceReminderCreate, ServiceReminderUpdate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


@pytest.fixture()
def sample_car(new_db):
    """Create a sample car for testing."""
    car_data = CarCreate(
        make="Toyota",
        model="Camry",
        year=2023,
        vin="1HGBH41JXMN109186",
        license_plate="ABC123",
        color="Silver",
        current_odometer=15000,
    )
    return create_car(car_data)


def test_create_reminder(sample_car):
    """Test creating a new service reminder."""
    reminder_data = ServiceReminderCreate(
        car_id=sample_car.id,
        service_type="Oil Change",
        description="Next oil change due",
        due_date=date.today() + timedelta(days=30),
        priority="medium",
        estimated_cost=Decimal("50.00"),
        notes="Use synthetic oil",
    )

    reminder = create_reminder(reminder_data)

    assert reminder.id is not None
    assert reminder.car_id == sample_car.id
    assert reminder.service_type == "Oil Change"
    assert reminder.description == "Next oil change due"
    assert reminder.due_date == date.today() + timedelta(days=30)
    assert reminder.priority == "medium"
    assert reminder.estimated_cost == Decimal("50.00")
    assert reminder.notes == "Use synthetic oil"
    assert not reminder.is_completed


def test_create_reminder_with_odometer(sample_car):
    """Test creating a reminder based on odometer reading."""
    reminder_data = ServiceReminderCreate(
        car_id=sample_car.id, service_type="Tire Rotation", due_odometer=20000, priority="low"
    )

    reminder = create_reminder(reminder_data)

    assert reminder.due_odometer == 20000
    assert reminder.due_date is None


def test_get_reminders_by_car_empty(sample_car):
    """Test getting reminders when none exist."""
    reminders = get_reminders_by_car(sample_car.id)
    assert reminders == []


def test_get_reminders_by_car_with_data(sample_car):
    """Test getting reminders when some exist."""
    reminder_data1 = ServiceReminderCreate(
        car_id=sample_car.id, service_type="Oil Change", due_date=date.today() + timedelta(days=30)
    )
    reminder_data2 = ServiceReminderCreate(
        car_id=sample_car.id, service_type="Tire Rotation", due_date=date.today() + timedelta(days=60)
    )

    create_reminder(reminder_data1)
    create_reminder(reminder_data2)

    reminders = get_reminders_by_car(sample_car.id)
    assert len(reminders) == 2


def test_get_reminder_by_id_existing(sample_car):
    """Test getting a reminder by ID when it exists."""
    reminder_data = ServiceReminderCreate(
        car_id=sample_car.id, service_type="Oil Change", due_date=date.today() + timedelta(days=30)
    )

    created_reminder = create_reminder(reminder_data)
    retrieved_reminder = get_reminder_by_id(created_reminder.id)

    assert retrieved_reminder is not None
    assert retrieved_reminder.id == created_reminder.id
    assert retrieved_reminder.service_type == "Oil Change"


def test_get_reminder_by_id_nonexistent(sample_car):
    """Test getting a reminder by ID when it doesn't exist."""
    reminder = get_reminder_by_id(999)
    assert reminder is None


def test_update_reminder(sample_car):
    """Test updating an existing reminder."""
    reminder_data = ServiceReminderCreate(
        car_id=sample_car.id, service_type="Oil Change", due_date=date.today() + timedelta(days=30), priority="medium"
    )

    created_reminder = create_reminder(reminder_data)

    update_data = ServiceReminderUpdate(
        service_type="Full Service Oil Change", priority="high", estimated_cost=Decimal("75.00")
    )

    updated_reminder = update_reminder(created_reminder.id, update_data)

    assert updated_reminder is not None
    assert updated_reminder.service_type == "Full Service Oil Change"
    assert updated_reminder.priority == "high"
    assert updated_reminder.estimated_cost == Decimal("75.00")
    assert updated_reminder.due_date == date.today() + timedelta(days=30)  # Unchanged


def test_update_reminder_nonexistent(sample_car):
    """Test updating a reminder that doesn't exist."""
    update_data = ServiceReminderUpdate(service_type="Oil Change")
    result = update_reminder(999, update_data)
    assert result is None


def test_delete_reminder_existing(sample_car):
    """Test deleting an existing reminder."""
    reminder_data = ServiceReminderCreate(
        car_id=sample_car.id, service_type="Oil Change", due_date=date.today() + timedelta(days=30)
    )

    created_reminder = create_reminder(reminder_data)
    result = delete_reminder(created_reminder.id)

    assert result is True
    assert get_reminder_by_id(created_reminder.id) is None


def test_delete_reminder_nonexistent(sample_car):
    """Test deleting a reminder that doesn't exist."""
    result = delete_reminder(999)
    assert result is False


def test_get_upcoming_reminders(sample_car):
    """Test getting upcoming reminders within specified days."""
    # Create reminders with different due dates
    reminder_data1 = ServiceReminderCreate(
        car_id=sample_car.id,
        service_type="Oil Change",
        due_date=date.today() + timedelta(days=10),  # Within 30 days
    )
    reminder_data2 = ServiceReminderCreate(
        car_id=sample_car.id,
        service_type="Tire Rotation",
        due_date=date.today() + timedelta(days=45),  # Beyond 30 days
    )
    reminder_data3 = ServiceReminderCreate(
        car_id=sample_car.id,
        service_type="Brake Check",
        due_date=date.today() + timedelta(days=5),  # Also within 30 days
    )
    reminder_data4 = ServiceReminderCreate(
        car_id=sample_car.id,
        service_type="Past Service",
        due_date=date.today() - timedelta(days=5),  # Past due, should not appear in upcoming
    )

    create_reminder(reminder_data1)
    create_reminder(reminder_data2)
    reminder3 = create_reminder(reminder_data3)
    # Mark reminder3 as completed after creation
    from app.services.reminder_service import update_reminder
    from app.models import ServiceReminderUpdate

    update_reminder(reminder3.id, ServiceReminderUpdate(is_completed=True))
    create_reminder(reminder_data4)

    upcoming = get_upcoming_reminders(30)
    # Should only include future dates within 30 days and not completed
    # Only 'Oil Change' should match (Brake Check is completed, others are outside range)
    assert len(upcoming) == 1
    assert upcoming[0].service_type == "Oil Change"


def test_get_overdue_reminders(sample_car):
    """Test getting overdue reminders."""
    # Create reminders with different due dates
    reminder_data1 = ServiceReminderCreate(
        car_id=sample_car.id,
        service_type="Oil Change",
        due_date=date.today() - timedelta(days=5),  # Overdue
    )
    reminder_data2 = ServiceReminderCreate(
        car_id=sample_car.id,
        service_type="Tire Rotation",
        due_date=date.today() + timedelta(days=10),  # Not overdue
    )
    reminder_data3 = ServiceReminderCreate(
        car_id=sample_car.id,
        service_type="Brake Check",
        due_date=date.today() - timedelta(days=10),  # Overdue
    )
    reminder_data4 = ServiceReminderCreate(
        car_id=sample_car.id,
        service_type="No Date Service",
        due_odometer=20000,  # Has no due_date, should not appear in overdue
    )

    create_reminder(reminder_data1)
    create_reminder(reminder_data2)
    reminder3 = create_reminder(reminder_data3)
    # Mark reminder3 as completed after creation
    from app.services.reminder_service import update_reminder
    from app.models import ServiceReminderUpdate

    update_reminder(reminder3.id, ServiceReminderUpdate(is_completed=True))
    create_reminder(reminder_data4)

    overdue = get_overdue_reminders()
    assert len(overdue) == 1
    assert overdue[0].service_type == "Oil Change"


def test_get_reminders_by_odometer(sample_car):
    """Test getting reminders due by odometer reading."""
    # Car has current_odometer = 15000
    reminder_data1 = ServiceReminderCreate(
        car_id=sample_car.id,
        service_type="Oil Change",
        due_odometer=14000,  # Already passed
    )
    reminder_data2 = ServiceReminderCreate(
        car_id=sample_car.id,
        service_type="Tire Rotation",
        due_odometer=16000,  # Not yet reached
    )
    reminder_data3 = ServiceReminderCreate(
        car_id=sample_car.id,
        service_type="Brake Check",
        due_odometer=15000,  # Exactly at current
    )

    create_reminder(reminder_data1)
    create_reminder(reminder_data2)
    reminder3 = create_reminder(reminder_data3)
    # Mark reminder3 as completed after creation
    from app.services.reminder_service import update_reminder
    from app.models import ServiceReminderUpdate

    update_reminder(reminder3.id, ServiceReminderUpdate(is_completed=True))

    due_reminders = get_reminders_by_odometer(sample_car.id)
    assert len(due_reminders) == 1
    assert due_reminders[0].service_type == "Oil Change"


def test_complete_reminder(sample_car):
    """Test marking a reminder as completed."""
    reminder_data = ServiceReminderCreate(
        car_id=sample_car.id, service_type="Oil Change", due_date=date.today() + timedelta(days=30)
    )

    created_reminder = create_reminder(reminder_data)
    assert not created_reminder.is_completed

    completed_reminder = complete_reminder(created_reminder.id)

    assert completed_reminder is not None
    assert completed_reminder.is_completed
