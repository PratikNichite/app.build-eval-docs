from nicegui import ui
from typing import Optional, Callable
from datetime import date, datetime
from decimal import Decimal
from app.models import MaintenanceRecord, MaintenanceRecordCreate, MaintenanceRecordUpdate, Car
from app.services.maintenance_service import (
    get_maintenance_records_by_car,
    create_maintenance_record,
    update_maintenance_record,
    delete_maintenance_record,
    get_maintenance_record_by_id,
    get_recent_maintenance_records,
)


def create_maintenance_form(car: Car, on_success: Optional[Callable] = None) -> None:
    """Create a form for adding a new maintenance record."""

    with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
        ui.label(f"Add Maintenance for {car.year} {car.make} {car.model}").classes("text-xl font-bold mb-4")

        service_type_input = ui.input("Service Type", placeholder="e.g., Oil Change").classes("w-full mb-2")
        description_input = (
            ui.textarea("Description", placeholder="Additional details").classes("w-full mb-2").props("rows=3")
        )
        service_date_input = ui.date(value=date.today()).classes("w-full mb-2")
        odometer_input = ui.number("Odometer Reading", value=car.current_odometer, min=0).classes("w-full mb-2")
        cost_input = ui.number("Cost ($)", value=0, min=0, step=0.01).classes("w-full mb-2")
        provider_input = ui.input("Service Provider", placeholder="e.g., Quick Lube").classes("w-full mb-2")
        notes_input = ui.textarea("Notes", placeholder="Additional notes").classes("w-full mb-4").props("rows=2")

        def save_maintenance():
            try:
                if not all([service_type_input.value, service_date_input.value, odometer_input.value is not None]):
                    ui.notify("Please fill in required fields", type="warning")
                    return

                # Parse the date string to date object
                service_date_value = service_date_input.value
                if isinstance(service_date_value, str):
                    service_date_obj = datetime.strptime(service_date_value, "%Y-%m-%d").date()
                else:
                    service_date_obj = service_date_value

                if car.id is None:
                    ui.notify("Car ID is missing", type="negative")
                    return

                record_data = MaintenanceRecordCreate(
                    car_id=car.id,
                    service_type=service_type_input.value,
                    description=description_input.value or "",
                    service_date=service_date_obj,
                    odometer_reading=int(odometer_input.value),
                    cost=Decimal(str(cost_input.value or 0)),
                    service_provider=provider_input.value or "",
                    notes=notes_input.value or "",
                )

                create_maintenance_record(record_data)
                ui.notify("Maintenance record added successfully! 🛠️✅", type="positive")
                dialog.close()
                if on_success:
                    on_success()

            except Exception as e:
                ui.notify(f"Error adding maintenance record: {str(e)}", type="negative")

        with ui.row().classes("gap-2 justify-end w-full"):
            ui.button("Cancel", on_click=dialog.close).props("outline")
            ui.button("Save", on_click=save_maintenance).classes("bg-primary text-white")

    dialog.open()


def create_maintenance_edit_form(record: MaintenanceRecord, on_success: Optional[Callable] = None) -> None:
    """Create a form for editing an existing maintenance record."""

    with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
        ui.label("Edit Maintenance Record").classes("text-xl font-bold mb-4")

        service_type_input = ui.input("Service Type", value=record.service_type).classes("w-full mb-2")
        description_input = ui.textarea("Description", value=record.description).classes("w-full mb-2").props("rows=3")
        service_date_input = ui.date(value=record.service_date).classes("w-full mb-2")
        odometer_input = ui.number("Odometer Reading", value=record.odometer_reading, min=0).classes("w-full mb-2")
        cost_input = ui.number("Cost ($)", value=float(record.cost), min=0, step=0.01).classes("w-full mb-2")
        provider_input = ui.input("Service Provider", value=record.service_provider).classes("w-full mb-2")
        notes_input = ui.textarea("Notes", value=record.notes).classes("w-full mb-4").props("rows=2")

        def update_maintenance():
            try:
                if not all([service_type_input.value, service_date_input.value, odometer_input.value is not None]):
                    ui.notify("Please fill in required fields", type="warning")
                    return

                # Parse the date string to date object
                service_date_value = service_date_input.value
                if isinstance(service_date_value, str):
                    service_date_obj = datetime.strptime(service_date_value, "%Y-%m-%d").date()
                else:
                    service_date_obj = service_date_value

                if record.id is None:
                    ui.notify("Record ID is missing", type="negative")
                    return

                record_data = MaintenanceRecordUpdate(
                    service_type=service_type_input.value,
                    description=description_input.value or "",
                    service_date=service_date_obj,
                    odometer_reading=int(odometer_input.value),
                    cost=Decimal(str(cost_input.value or 0)),
                    service_provider=provider_input.value or "",
                    notes=notes_input.value or "",
                )

                update_maintenance_record(record.id, record_data)
                ui.notify("Maintenance record updated successfully! 📝✅", type="positive")
                dialog.close()
                if on_success:
                    on_success()

            except Exception as e:
                ui.notify(f"Error updating maintenance record: {str(e)}", type="negative")

        with ui.row().classes("gap-2 justify-end w-full"):
            ui.button("Cancel", on_click=dialog.close).props("outline")
            ui.button("Update", on_click=update_maintenance).classes("bg-primary text-white")

    dialog.open()


def create_maintenance_history(car: Car) -> ui.column:
    """Create a maintenance history display for a specific car."""

    history_container = ui.column().classes("w-full")

    def refresh_history():
        history_container.clear()

        if car.id is None:
            with history_container:
                ui.label("Car ID is missing").classes("text-red-500")
            return

        records = get_maintenance_records_by_car(car.id)

        with history_container:
            with ui.row().classes("items-center justify-between mb-4"):
                ui.label(f"Maintenance History - {car.year} {car.make} {car.model}").classes("text-xl font-bold")
                ui.button("Add Maintenance", on_click=lambda: create_maintenance_form(car, refresh_history)).classes(
                    "bg-green-500 text-white"
                )

            if not records:
                ui.label("No maintenance records found").classes("text-gray-500 text-center p-4")
                return

            # Create table with maintenance records
            columns = [
                {"name": "date", "label": "Date", "field": "service_date", "sortable": True},
                {"name": "type", "label": "Service Type", "field": "service_type", "sortable": True},
                {"name": "odometer", "label": "Odometer", "field": "odometer_reading", "sortable": True},
                {"name": "cost", "label": "Cost", "field": "cost", "sortable": True},
                {"name": "provider", "label": "Provider", "field": "service_provider", "sortable": True},
                {"name": "actions", "label": "Actions", "field": "actions", "sortable": False},
            ]

            rows = []
            for record in records:
                rows.append(
                    {
                        "id": record.id,
                        "service_date": record.service_date.strftime("%Y-%m-%d"),
                        "service_type": record.service_type,
                        "odometer_reading": f"{record.odometer_reading:,}",
                        "cost": f"${record.cost:.2f}",
                        "service_provider": record.service_provider or "N/A",
                        "description": record.description,
                        "notes": record.notes,
                    }
                )

            def handle_row_click(event):
                if event.args and "id" in event.args:
                    record_id = event.args["id"]
                    record = get_maintenance_record_by_id(record_id)
                    if record:
                        show_maintenance_details(record, refresh_history)

            ui.table(columns=columns, rows=rows, on_select=handle_row_click).classes("w-full").props("dense")

    def show_maintenance_details(record: MaintenanceRecord, refresh_callback: Callable):
        with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
            ui.label("Maintenance Details").classes("text-xl font-bold mb-4")

            ui.label(f"Service Type: {record.service_type}").classes("mb-2")
            ui.label(f"Date: {record.service_date.strftime('%Y-%m-%d')}").classes("mb-2")
            ui.label(f"Odometer: {record.odometer_reading:,} miles").classes("mb-2")
            ui.label(f"Cost: ${record.cost:.2f}").classes("mb-2")
            if record.service_provider:
                ui.label(f"Provider: {record.service_provider}").classes("mb-2")
            if record.description:
                ui.label(f"Description: {record.description}").classes("mb-2")
            if record.notes:
                ui.label(f"Notes: {record.notes}").classes("mb-4")

            def delete_maintenance():
                if record.id is not None:
                    if delete_maintenance_record(record.id):
                        ui.notify("Maintenance record deleted! 🗑️🛠️", type="positive")
                        dialog.close()
                        refresh_callback()
                    else:
                        ui.notify("Failed to delete record", type="negative")
                else:
                    ui.notify("Record ID is missing", type="negative")

            with ui.row().classes("gap-2 justify-end w-full"):
                ui.button("Close", on_click=dialog.close).props("outline")
                ui.button(
                    "Edit", on_click=lambda: [dialog.close(), create_maintenance_edit_form(record, refresh_callback)]
                ).classes("bg-orange-500 text-white")
                ui.button("Delete", on_click=delete_maintenance).classes("bg-red-500 text-white")

        dialog.open()

    refresh_history()
    return history_container


def create_recent_maintenance_summary() -> ui.column:
    """Create a summary of recent maintenance across all cars."""

    summary_container = ui.column().classes("w-full")

    def refresh_summary():
        summary_container.clear()
        records = get_recent_maintenance_records(10)

        with summary_container:
            ui.label("Recent Maintenance").classes("text-xl font-bold mb-4")

            if not records:
                ui.label("No maintenance records found").classes("text-gray-500 text-center")
                return

            for record in records:
                with ui.card().classes("w-full p-4 mb-2"):
                    with ui.row().classes("items-center justify-between"):
                        with ui.column():
                            ui.label(f"{record.service_type}").classes("font-semibold")
                            ui.label(f"{record.service_date.strftime('%Y-%m-%d')} • ${record.cost:.2f}").classes(
                                "text-sm text-gray-600"
                            )
                        ui.label(f"{record.odometer_reading:,} mi").classes("text-sm text-gray-500")

    refresh_summary()
    return summary_container
