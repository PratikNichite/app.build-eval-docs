from nicegui import ui
from typing import Optional, Callable
from datetime import date, datetime
from decimal import Decimal
from app.models import ServiceReminder, ServiceReminderCreate, ServiceReminderUpdate, Car
from app.services.reminder_service import (
    get_reminders_by_car,
    create_reminder,
    update_reminder,
    delete_reminder,
    get_upcoming_reminders,
    get_overdue_reminders,
    complete_reminder,
    get_reminders_by_odometer,
)


def create_reminder_form(car: Car, on_success: Optional[Callable] = None) -> None:
    """Create a form for adding a new service reminder."""

    with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
        ui.label(f"Add Reminder for {car.year} {car.make} {car.model}").classes("text-xl font-bold mb-4")

        service_type_input = ui.input("Service Type", placeholder="e.g., Oil Change").classes("w-full mb-2")
        description_input = (
            ui.textarea("Description", placeholder="Additional details").classes("w-full mb-2").props("rows=3")
        )

        # Due date or odometer selection
        ui.label("Reminder Type:").classes("font-semibold mb-2")
        reminder_type = ui.radio(["Due Date", "Odometer Reading"], value="Due Date").classes("mb-2")

        due_date_input = ui.date(value=date.today()).classes("w-full mb-2")
        due_odometer_input = (
            ui.number("Due at Odometer", min=car.current_odometer)
            .classes("w-full mb-2")
            .bind_visibility_from(reminder_type, "value", value="Odometer Reading")
        )

        priority_input = ui.select(
            options={"low": "Low", "medium": "Medium", "high": "High", "urgent": "Urgent"},
            value="medium",
            label="Priority",
        ).classes("w-full mb-2")

        cost_input = ui.number("Estimated Cost ($)", value=0, min=0, step=0.01).classes("w-full mb-2")
        notes_input = ui.textarea("Notes", placeholder="Additional notes").classes("w-full mb-4").props("rows=2")

        def save_reminder():
            try:
                if not service_type_input.value:
                    ui.notify("Please enter a service type", type="warning")
                    return

                if car.id is None:
                    ui.notify("Car ID is missing", type="negative")
                    return

                # Handle due date/odometer based on selection
                due_date_value = None
                due_odometer_value = None

                if reminder_type.value == "Due Date":
                    due_date_str = due_date_input.value
                    if isinstance(due_date_str, str):
                        due_date_value = datetime.strptime(due_date_str, "%Y-%m-%d").date()
                    else:
                        due_date_value = due_date_str
                else:
                    if due_odometer_input.value is not None:
                        due_odometer_value = int(due_odometer_input.value)

                reminder_data = ServiceReminderCreate(
                    car_id=car.id,
                    service_type=service_type_input.value,
                    description=description_input.value or "",
                    due_date=due_date_value,
                    due_odometer=due_odometer_value,
                    priority=priority_input.value,
                    estimated_cost=Decimal(str(cost_input.value)) if cost_input.value else None,
                    notes=notes_input.value or "",
                )

                create_reminder(reminder_data)
                ui.notify("Service reminder added successfully! 🔔🚗", type="positive")
                dialog.close()
                if on_success:
                    on_success()

            except Exception as e:
                ui.notify(f"Error adding reminder: {str(e)}", type="negative")

        with ui.row().classes("gap-2 justify-end w-full"):
            ui.button("Cancel", on_click=dialog.close).props("outline")
            ui.button("Save", on_click=save_reminder).classes("bg-primary text-white")

    dialog.open()


def create_reminder_edit_form(reminder: ServiceReminder, on_success: Optional[Callable] = None) -> None:
    """Create a form for editing an existing service reminder."""

    with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
        ui.label("Edit Service Reminder").classes("text-xl font-bold mb-4")

        service_type_input = ui.input("Service Type", value=reminder.service_type).classes("w-full mb-2")
        description_input = (
            ui.textarea("Description", value=reminder.description).classes("w-full mb-2").props("rows=3")
        )

        # Due date
        due_date_input = None
        if reminder.due_date:
            due_date_input = ui.date(value=reminder.due_date).classes("w-full mb-2")
        else:
            due_date_input = ui.date().classes("w-full mb-2")

        # Due odometer
        due_odometer_input = ui.number("Due at Odometer", value=reminder.due_odometer, min=0).classes("w-full mb-2")

        priority_input = ui.select(
            options={"low": "Low", "medium": "Medium", "high": "High", "urgent": "Urgent"},
            value=reminder.priority,
            label="Priority",
        ).classes("w-full mb-2")

        cost_value = float(reminder.estimated_cost) if reminder.estimated_cost else 0
        cost_input = ui.number("Estimated Cost ($)", value=cost_value, min=0, step=0.01).classes("w-full mb-2")

        completed_input = ui.checkbox("Completed", value=reminder.is_completed).classes("mb-2")
        notes_input = ui.textarea("Notes", value=reminder.notes).classes("w-full mb-4").props("rows=2")

        def update_reminder_data():
            try:
                if not service_type_input.value:
                    ui.notify("Please enter a service type", type="warning")
                    return

                if reminder.id is None:
                    ui.notify("Reminder ID is missing", type="negative")
                    return

                # Handle due date
                due_date_value = None
                if due_date_input.value:
                    if isinstance(due_date_input.value, str):
                        due_date_value = datetime.strptime(due_date_input.value, "%Y-%m-%d").date()
                    else:
                        due_date_value = due_date_input.value

                reminder_data = ServiceReminderUpdate(
                    service_type=service_type_input.value,
                    description=description_input.value or "",
                    due_date=due_date_value,
                    due_odometer=int(due_odometer_input.value) if due_odometer_input.value else None,
                    priority=priority_input.value,
                    estimated_cost=Decimal(str(cost_input.value)) if cost_input.value else None,
                    is_completed=completed_input.value,
                    notes=notes_input.value or "",
                )

                update_reminder(reminder.id, reminder_data)
                ui.notify("Service reminder updated successfully! 🔔✅", type="positive")
                dialog.close()
                if on_success:
                    on_success()

            except Exception as e:
                ui.notify(f"Error updating reminder: {str(e)}", type="negative")

        with ui.row().classes("gap-2 justify-end w-full"):
            ui.button("Cancel", on_click=dialog.close).props("outline")
            ui.button("Update", on_click=update_reminder_data).classes("bg-primary text-white")

    dialog.open()


def create_reminder_list(car: Car) -> ui.column:
    """Create a list of service reminders for a specific car."""

    reminders_container = ui.column().classes("w-full")

    def refresh_reminders():
        reminders_container.clear()

        if car.id is None:
            with reminders_container:
                ui.label("Car ID is missing").classes("text-red-500")
            return

        reminders = get_reminders_by_car(car.id)
        odometer_reminders = get_reminders_by_odometer(car.id)

        with reminders_container:
            with ui.row().classes("items-center justify-between mb-4"):
                ui.label(f"Service Reminders - {car.year} {car.make} {car.model}").classes("text-xl font-bold")
                ui.button("Add Reminder", on_click=lambda: create_reminder_form(car, refresh_reminders)).classes(
                    "bg-green-500 text-white"
                )

            # Show odometer-based reminders that are due
            if odometer_reminders:
                ui.label("Due by Odometer:").classes("text-lg font-semibold text-orange-600 mb-2")
                for reminder in odometer_reminders:
                    if not reminder.is_completed:
                        create_reminder_card(reminder, refresh_reminders, is_due=True)

            if not reminders:
                ui.label("No service reminders found").classes("text-gray-500 text-center p-4")
                return

            # Group reminders by completion status
            pending_reminders = [r for r in reminders if not r.is_completed]
            completed_reminders = [r for r in reminders if r.is_completed]

            if pending_reminders:
                ui.label("Pending Reminders:").classes("text-lg font-semibold mb-2")
                for reminder in pending_reminders:
                    is_overdue = reminder.due_date and reminder.due_date < date.today()
                    create_reminder_card(reminder, refresh_reminders, is_overdue=is_overdue)

            if completed_reminders:
                ui.label("Completed Reminders:").classes("text-lg font-semibold mb-2 mt-4")
                for reminder in completed_reminders:
                    create_reminder_card(reminder, refresh_reminders, is_completed=True)

    def create_reminder_card(
        reminder: ServiceReminder,
        refresh_callback: Callable,
        is_due: bool = False,
        is_overdue: bool = False,
        is_completed: bool = False,
    ):
        """Create a card for displaying a single reminder."""

        card_classes = "w-full p-4 mb-2"
        if is_overdue:
            card_classes += " border-l-4 border-red-500 bg-red-50"
        elif is_due:
            card_classes += " border-l-4 border-orange-500 bg-orange-50"
        elif is_completed:
            card_classes += " border-l-4 border-green-500 bg-green-50"
        else:
            card_classes += " border-l-4 border-blue-500 bg-blue-50"

        with ui.card().classes(card_classes):
            with ui.row().classes("items-center justify-between w-full"):
                with ui.column().classes("flex-1"):
                    ui.label(reminder.service_type).classes("text-lg font-semibold")

                    details = []
                    if reminder.due_date:
                        details.append(f"Due: {reminder.due_date.strftime('%Y-%m-%d')}")
                    if reminder.due_odometer:
                        details.append(f"Due at: {reminder.due_odometer:,} miles")
                    if reminder.estimated_cost:
                        details.append(f"Est. Cost: ${reminder.estimated_cost:.2f}")

                    ui.label(" • ".join(details)).classes("text-sm text-gray-600")

                    if reminder.description:
                        ui.label(reminder.description).classes("text-sm text-gray-700 mt-1")

                    # Priority badge
                    priority_colors = {
                        "low": "bg-gray-200 text-gray-800",
                        "medium": "bg-blue-200 text-blue-800",
                        "high": "bg-orange-200 text-orange-800",
                        "urgent": "bg-red-200 text-red-800",
                    }
                    ui.label(reminder.priority.upper()).classes(
                        f"text-xs px-2 py-1 rounded {priority_colors.get(reminder.priority, 'bg-gray-200 text-gray-800')}"
                    )

                with ui.row().classes("gap-2"):
                    if not reminder.is_completed:
                        ui.button(
                            "Complete",
                            on_click=lambda r_id=reminder.id: mark_complete(r_id, refresh_callback)
                            if r_id is not None
                            else None,
                        ).classes("bg-green-500 text-white text-sm px-3 py-1")

                    ui.button(
                        "Edit", on_click=lambda r=reminder: create_reminder_edit_form(r, refresh_callback)
                    ).classes("bg-orange-500 text-white text-sm px-3 py-1")

                    ui.button(
                        "Delete",
                        on_click=lambda r_id=reminder.id: delete_reminder_with_confirmation(r_id, refresh_callback)
                        if r_id is not None
                        else None,
                    ).classes("bg-red-500 text-white text-sm px-3 py-1")

    def mark_complete(reminder_id: int, refresh_callback: Callable):
        try:
            complete_reminder(reminder_id)
            ui.notify("Reminder marked as completed! 🎉🔔", type="positive")
            refresh_callback()
        except Exception as e:
            ui.notify(f"Error completing reminder: {str(e)}", type="negative")

    def delete_reminder_with_confirmation(reminder_id: int, refresh_callback: Callable):
        with ui.dialog() as dialog, ui.card():
            ui.label("Are you sure you want to delete this reminder?").classes("mb-4")

            with ui.row().classes("gap-2 justify-end"):
                ui.button("Cancel", on_click=dialog.close).props("outline")
                ui.button("Delete", on_click=lambda: perform_delete()).classes("bg-red-500 text-white")

            def perform_delete():
                try:
                    if delete_reminder(reminder_id):
                        ui.notify("Reminder deleted successfully! 🗑️🔔", type="positive")
                        refresh_callback()
                    else:
                        ui.notify("Failed to delete reminder", type="negative")
                    dialog.close()
                except Exception as e:
                    ui.notify(f"Error deleting reminder: {str(e)}", type="negative")
                    dialog.close()

        dialog.open()

    refresh_reminders()
    return reminders_container


def create_dashboard_reminders() -> ui.column:
    """Create a dashboard widget showing upcoming and overdue reminders."""

    dashboard_container = ui.column().classes("w-full")

    def refresh_dashboard():
        dashboard_container.clear()

        overdue = get_overdue_reminders()
        upcoming = get_upcoming_reminders(30)

        with dashboard_container:
            ui.label("Service Reminders").classes("text-xl font-bold mb-4")

            # Overdue reminders
            if overdue:
                ui.label(f"Overdue ({len(overdue)})").classes("text-lg font-semibold text-red-600 mb-2")
                for reminder in overdue[:5]:  # Show max 5
                    with ui.card().classes("w-full p-3 mb-2 border-l-4 border-red-500 bg-red-50"):
                        ui.label(f"{reminder.service_type}").classes("font-semibold text-red-800")
                        ui.label(
                            f"Due: {reminder.due_date.strftime('%Y-%m-%d') if reminder.due_date else 'N/A'}"
                        ).classes("text-sm text-red-600")

            # Upcoming reminders
            if upcoming:
                ui.label("Upcoming (Next 30 days)").classes("text-lg font-semibold text-orange-600 mb-2 mt-4")
                for reminder in upcoming[:5]:  # Show max 5
                    with ui.card().classes("w-full p-3 mb-2 border-l-4 border-orange-500 bg-orange-50"):
                        ui.label(f"{reminder.service_type}").classes("font-semibold text-orange-800")
                        ui.label(
                            f"Due: {reminder.due_date.strftime('%Y-%m-%d') if reminder.due_date else 'N/A'}"
                        ).classes("text-sm text-orange-600")

            if not overdue and not upcoming:
                ui.label("No upcoming reminders").classes("text-gray-500 text-center p-4")

    refresh_dashboard()
    return dashboard_container
