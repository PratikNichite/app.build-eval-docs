from nicegui import ui
from typing import Optional, Callable
from app.models import Car, CarCreate, CarUpdate
from app.services.car_service import get_all_cars, create_car, update_car, delete_car, get_car_by_id


def create_car_form(on_success: Optional[Callable] = None) -> None:
    """Create a form for adding a new car."""

    with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
        ui.label("Add New Car").classes("text-xl font-bold mb-4")

        make_input = ui.input("Make", placeholder="e.g., Toyota").classes("w-full mb-2")
        model_input = ui.input("Model", placeholder="e.g., Camry").classes("w-full mb-2")
        year_input = ui.number("Year", value=2024, min=1900, max=2030).classes("w-full mb-2")
        vin_input = ui.input("VIN", placeholder="17-character VIN").classes("w-full mb-2")
        license_input = ui.input("License Plate").classes("w-full mb-2")
        color_input = ui.input("Color", placeholder="e.g., Silver").classes("w-full mb-2")
        odometer_input = ui.number("Current Odometer", value=0, min=0).classes("w-full mb-4")

        def save_car():
            try:
                if not all(
                    [
                        make_input.value,
                        model_input.value,
                        year_input.value,
                        vin_input.value,
                        license_input.value,
                        color_input.value,
                    ]
                ):
                    ui.notify("Please fill in all required fields", type="warning")
                    return

                car_data = CarCreate(
                    make=make_input.value,
                    model=model_input.value,
                    year=int(year_input.value),
                    vin=vin_input.value,
                    license_plate=license_input.value,
                    color=color_input.value,
                    current_odometer=int(odometer_input.value or 0),
                )

                create_car(car_data)
                ui.notify("Car added successfully! 🚗✨", type="positive")
                dialog.close()
                if on_success:
                    on_success()

            except Exception as e:
                ui.notify(f"Error adding car: {str(e)}", type="negative")

        with ui.row().classes("gap-2 justify-end w-full"):
            ui.button("Cancel", on_click=dialog.close).props("outline")
            ui.button("Save", on_click=save_car).classes("bg-primary text-white")

    dialog.open()


def create_car_edit_form(car: Car, on_success: Optional[Callable] = None) -> None:
    """Create a form for editing an existing car."""

    with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
        ui.label(f"Edit {car.make} {car.model}").classes("text-xl font-bold mb-4")

        make_input = ui.input("Make", value=car.make).classes("w-full mb-2")
        model_input = ui.input("Model", value=car.model).classes("w-full mb-2")
        year_input = ui.number("Year", value=car.year, min=1900, max=2030).classes("w-full mb-2")
        vin_input = ui.input("VIN", value=car.vin).classes("w-full mb-2")
        license_input = ui.input("License Plate", value=car.license_plate).classes("w-full mb-2")
        color_input = ui.input("Color", value=car.color).classes("w-full mb-2")
        odometer_input = ui.number("Current Odometer", value=car.current_odometer, min=0).classes("w-full mb-4")

        def update_car_data():
            try:
                if not all(
                    [
                        make_input.value,
                        model_input.value,
                        year_input.value,
                        vin_input.value,
                        license_input.value,
                        color_input.value,
                    ]
                ):
                    ui.notify("Please fill in all required fields", type="warning")
                    return

                car_data = CarUpdate(
                    make=make_input.value,
                    model=model_input.value,
                    year=int(year_input.value),
                    vin=vin_input.value,
                    license_plate=license_input.value,
                    color=color_input.value,
                    current_odometer=int(odometer_input.value or 0),
                )

                if car.id is not None:
                    update_car(car.id, car_data)
                    ui.notify("Car updated successfully! 🚗✅", type="positive")
                    dialog.close()
                    if on_success:
                        on_success()
                else:
                    ui.notify("Car ID is missing", type="negative")

            except Exception as e:
                ui.notify(f"Error updating car: {str(e)}", type="negative")

        with ui.row().classes("gap-2 justify-end w-full"):
            ui.button("Cancel", on_click=dialog.close).props("outline")
            ui.button("Update", on_click=update_car_data).classes("bg-primary text-white")

    dialog.open()


def create_car_list(on_car_select: Optional[Callable[[Car], None]] = None) -> ui.column:
    """Create a list of cars with management options."""

    cars_container = ui.column().classes("w-full")

    def refresh_cars():
        cars_container.clear()
        cars = get_all_cars()

        if not cars:
            with cars_container:
                ui.label("No cars added yet").classes("text-gray-500 text-center p-4")
                return

        for car in cars:
            with cars_container:
                with ui.card().classes("w-full p-4 mb-2 hover:shadow-md transition-shadow"):
                    with ui.row().classes("items-center justify-between w-full"):
                        with ui.column().classes("flex-1"):
                            ui.label(f"{car.year} {car.make} {car.model}").classes("text-lg font-semibold")
                            ui.label(f"License: {car.license_plate} • Color: {car.color}").classes(
                                "text-sm text-gray-600"
                            )
                            ui.label(f"Odometer: {car.current_odometer:,} miles").classes("text-sm text-gray-600")

                        with ui.row().classes("gap-2"):
                            if on_car_select:
                                ui.button(
                                    "View", on_click=lambda c=car: on_car_select(c) if c.id is not None else None
                                ).classes("bg-blue-500 text-white text-sm px-3 py-1")

                            ui.button("Edit", on_click=lambda c=car: create_car_edit_form(c, refresh_cars)).classes(
                                "bg-orange-500 text-white text-sm px-3 py-1"
                            )

                            ui.button(
                                "Delete",
                                on_click=lambda car_id=car.id: delete_car_with_confirmation(car_id, refresh_cars)
                                if car_id is not None
                                else None,
                            ).classes("bg-red-500 text-white text-sm px-3 py-1")

    def delete_car_with_confirmation(car_id: int, refresh_callback: Callable):
        async def confirm_delete():
            with ui.dialog() as dialog, ui.card():
                ui.label("Are you sure you want to delete this car?").classes("mb-4")
                ui.label("This will also delete all maintenance records and reminders.").classes(
                    "text-sm text-red-600 mb-4"
                )

                with ui.row().classes("gap-2 justify-end"):
                    ui.button("Cancel", on_click=dialog.close).props("outline")
                    ui.button("Delete", on_click=lambda: perform_delete()).classes("bg-red-500 text-white")

                def perform_delete():
                    try:
                        if delete_car(car_id):
                            ui.notify("Car deleted successfully! 🗑️🚗", type="positive")
                            refresh_callback()
                        else:
                            ui.notify("Failed to delete car", type="negative")
                        dialog.close()
                    except Exception as e:
                        ui.notify(f"Error deleting car: {str(e)}", type="negative")
                        dialog.close()

            dialog.open()

        ui.run_javascript("void(0)", callback=confirm_delete)

    refresh_cars()
    return cars_container


def create_car_selector(on_select: Callable[[Optional[Car]], None]) -> ui.select:
    """Create a dropdown selector for cars."""
    cars = get_all_cars()

    options = {}
    for car in cars:
        if car.id is not None:
            label = f"{car.year} {car.make} {car.model} ({car.license_plate})"
            options[car.id] = label

    def handle_selection(selection):
        if selection.value:
            car = get_car_by_id(selection.value)
            on_select(car)
        else:
            on_select(None)

    return ui.select(options=options, label="Select Car", on_change=handle_selection).classes("w-full")
