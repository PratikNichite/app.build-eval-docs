from sqlmodel import SQLModel, Field, Relationship
from datetime import datetime, date
from typing import Optional, List
from decimal import Decimal


# Persistent models (stored in database)
class Car(SQLModel, table=True):
    __tablename__ = "cars"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    make: str = Field(max_length=50)
    model: str = Field(max_length=50)
    year: int = Field(ge=1900, le=2030)
    vin: str = Field(max_length=17, unique=True)
    license_plate: str = Field(max_length=20)
    color: str = Field(max_length=30)
    current_odometer: int = Field(default=0, ge=0)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    maintenance_records: List["MaintenanceRecord"] = Relationship(back_populates="car")
    service_reminders: List["ServiceReminder"] = Relationship(back_populates="car")


class MaintenanceRecord(SQLModel, table=True):
    __tablename__ = "maintenance_records"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    car_id: int = Field(foreign_key="cars.id")
    service_type: str = Field(max_length=100)
    description: str = Field(default="", max_length=1000)
    service_date: date
    odometer_reading: int = Field(ge=0)
    cost: Decimal = Field(decimal_places=2, max_digits=10, default=Decimal("0"))
    service_provider: str = Field(default="", max_length=200)
    notes: str = Field(default="", max_length=500)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    car: Car = Relationship(back_populates="maintenance_records")


class ServiceReminder(SQLModel, table=True):
    __tablename__ = "service_reminders"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    car_id: int = Field(foreign_key="cars.id")
    service_type: str = Field(max_length=100)
    description: str = Field(default="", max_length=500)
    due_date: Optional[date] = Field(default=None)
    due_odometer: Optional[int] = Field(default=None, ge=0)
    is_completed: bool = Field(default=False)
    priority: str = Field(default="medium", max_length=20)  # low, medium, high, urgent
    estimated_cost: Optional[Decimal] = Field(default=None, decimal_places=2, max_digits=10)
    notes: str = Field(default="", max_length=500)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    car: Car = Relationship(back_populates="service_reminders")


# Non-persistent schemas (for validation, forms, API requests/responses)
class CarCreate(SQLModel, table=False):
    make: str = Field(max_length=50)
    model: str = Field(max_length=50)
    year: int = Field(ge=1900, le=2030)
    vin: str = Field(max_length=17)
    license_plate: str = Field(max_length=20)
    color: str = Field(max_length=30)
    current_odometer: int = Field(default=0, ge=0)


class CarUpdate(SQLModel, table=False):
    make: Optional[str] = Field(default=None, max_length=50)
    model: Optional[str] = Field(default=None, max_length=50)
    year: Optional[int] = Field(default=None, ge=1900, le=2030)
    vin: Optional[str] = Field(default=None, max_length=17)
    license_plate: Optional[str] = Field(default=None, max_length=20)
    color: Optional[str] = Field(default=None, max_length=30)
    current_odometer: Optional[int] = Field(default=None, ge=0)


class MaintenanceRecordCreate(SQLModel, table=False):
    car_id: int
    service_type: str = Field(max_length=100)
    description: str = Field(default="", max_length=1000)
    service_date: date
    odometer_reading: int = Field(ge=0)
    cost: Decimal = Field(decimal_places=2, max_digits=10, default=Decimal("0"))
    service_provider: str = Field(default="", max_length=200)
    notes: str = Field(default="", max_length=500)


class MaintenanceRecordUpdate(SQLModel, table=False):
    service_type: Optional[str] = Field(default=None, max_length=100)
    description: Optional[str] = Field(default=None, max_length=1000)
    service_date: Optional[date] = Field(default=None)
    odometer_reading: Optional[int] = Field(default=None, ge=0)
    cost: Optional[Decimal] = Field(default=None, decimal_places=2, max_digits=10)
    service_provider: Optional[str] = Field(default=None, max_length=200)
    notes: Optional[str] = Field(default=None, max_length=500)


class ServiceReminderCreate(SQLModel, table=False):
    car_id: int
    service_type: str = Field(max_length=100)
    description: str = Field(default="", max_length=500)
    due_date: Optional[date] = Field(default=None)
    due_odometer: Optional[int] = Field(default=None, ge=0)
    priority: str = Field(default="medium", max_length=20)
    estimated_cost: Optional[Decimal] = Field(default=None, decimal_places=2, max_digits=10)
    notes: str = Field(default="", max_length=500)


class ServiceReminderUpdate(SQLModel, table=False):
    service_type: Optional[str] = Field(default=None, max_length=100)
    description: Optional[str] = Field(default=None, max_length=500)
    due_date: Optional[date] = Field(default=None)
    due_odometer: Optional[int] = Field(default=None, ge=0)
    is_completed: Optional[bool] = Field(default=None)
    priority: Optional[str] = Field(default=None, max_length=20)
    estimated_cost: Optional[Decimal] = Field(default=None, decimal_places=2, max_digits=10)
    notes: Optional[str] = Field(default=None, max_length=500)
