from typing import List, Optional
from sqlmodel import select
from app.database import get_session
from app.models import MaintenanceRecord, MaintenanceRecordCreate, MaintenanceRecordUpdate
from app.services.car_service import update_car_odometer
from datetime import datetime


def get_maintenance_records_by_car(car_id: int) -> List[MaintenanceRecord]:
    """Retrieve all maintenance records for a specific car."""
    with get_session() as session:
        statement = (
            select(MaintenanceRecord)
            .where(MaintenanceRecord.car_id == car_id)
            .order_by(MaintenanceRecord.service_date.desc())
        )
        return list(session.exec(statement).all())


def get_maintenance_record_by_id(record_id: int) -> Optional[MaintenanceRecord]:
    """Retrieve a maintenance record by its ID."""
    with get_session() as session:
        return session.get(MaintenanceRecord, record_id)


def create_maintenance_record(record_data: MaintenanceRecordCreate) -> MaintenanceRecord:
    """Create a new maintenance record."""
    with get_session() as session:
        record = MaintenanceRecord(**record_data.model_dump())
        session.add(record)
        session.commit()
        session.refresh(record)

        # Update car's odometer if this reading is higher
        update_car_odometer(record.car_id, record.odometer_reading)

        return record


def update_maintenance_record(record_id: int, record_data: MaintenanceRecordUpdate) -> Optional[MaintenanceRecord]:
    """Update an existing maintenance record."""
    with get_session() as session:
        record = session.get(MaintenanceRecord, record_id)
        if record is None:
            return None

        update_data = record_data.model_dump(exclude_unset=True)
        old_odometer = record.odometer_reading

        for field, value in update_data.items():
            setattr(record, field, value)

        record.updated_at = datetime.utcnow()
        session.add(record)
        session.commit()
        session.refresh(record)

        # Update car's odometer if the new reading is higher
        if "odometer_reading" in update_data and record.odometer_reading > old_odometer:
            update_car_odometer(record.car_id, record.odometer_reading)

        return record


def delete_maintenance_record(record_id: int) -> bool:
    """Delete a maintenance record."""
    with get_session() as session:
        record = session.get(MaintenanceRecord, record_id)
        if record is None:
            return False

        session.delete(record)
        session.commit()
        return True


def get_recent_maintenance_records(limit: int = 10) -> List[MaintenanceRecord]:
    """Get the most recent maintenance records across all cars."""
    with get_session() as session:
        statement = select(MaintenanceRecord).order_by(MaintenanceRecord.service_date.desc()).limit(limit)
        return list(session.exec(statement).all())
