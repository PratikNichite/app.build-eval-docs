from typing import List, Optional
from sqlmodel import select
from app.database import get_session
from app.models import ServiceReminder, ServiceReminderCreate, ServiceReminderUpdate, Car
from datetime import datetime, date


def get_reminders_by_car(car_id: int) -> List[ServiceReminder]:
    """Retrieve all service reminders for a specific car."""
    with get_session() as session:
        statement = (
            select(ServiceReminder).where(ServiceReminder.car_id == car_id).order_by(ServiceReminder.due_date.asc())
        )
        return list(session.exec(statement).all())


def get_reminder_by_id(reminder_id: int) -> Optional[ServiceReminder]:
    """Retrieve a service reminder by its ID."""
    with get_session() as session:
        return session.get(ServiceReminder, reminder_id)


def create_reminder(reminder_data: ServiceReminderCreate) -> ServiceReminder:
    """Create a new service reminder."""
    with get_session() as session:
        reminder = ServiceReminder(**reminder_data.model_dump())
        session.add(reminder)
        session.commit()
        session.refresh(reminder)
        return reminder


def update_reminder(reminder_id: int, reminder_data: ServiceReminderUpdate) -> Optional[ServiceReminder]:
    """Update an existing service reminder."""
    with get_session() as session:
        reminder = session.get(ServiceReminder, reminder_id)
        if reminder is None:
            return None

        update_data = reminder_data.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(reminder, field, value)

        reminder.updated_at = datetime.utcnow()
        session.add(reminder)
        session.commit()
        session.refresh(reminder)
        return reminder


def delete_reminder(reminder_id: int) -> bool:
    """Delete a service reminder."""
    with get_session() as session:
        reminder = session.get(ServiceReminder, reminder_id)
        if reminder is None:
            return False

        session.delete(reminder)
        session.commit()
        return True


def get_upcoming_reminders(days_ahead: int = 30) -> List[ServiceReminder]:
    """Get upcoming service reminders within the specified number of days."""
    with get_session() as session:
        today = date.today()
        cutoff_date = date.fromordinal(today.toordinal() + days_ahead)

        statement = (
            select(ServiceReminder)
            .where(
                ServiceReminder.is_completed == False,  # noqa: E712
                ServiceReminder.due_date >= today,
                ServiceReminder.due_date <= cutoff_date,
            )
            .order_by(ServiceReminder.due_date.asc())
        )
        return list(session.exec(statement).all())


def get_overdue_reminders() -> List[ServiceReminder]:
    """Get overdue service reminders."""
    with get_session() as session:
        today = date.today()

        statement = (
            select(ServiceReminder)
            .where(
                ServiceReminder.is_completed == False,  # noqa: E712
                ServiceReminder.due_date.is_not(None),
                ServiceReminder.due_date < today,
            )
            .order_by(ServiceReminder.due_date.asc())
        )
        return list(session.exec(statement).all())


def get_reminders_by_odometer(car_id: int) -> List[ServiceReminder]:
    """Get reminders that are due based on odometer reading."""
    with get_session() as session:
        car = session.get(Car, car_id)
        if car is None:
            return []

        statement = (
            select(ServiceReminder)
            .where(
                ServiceReminder.car_id == car_id,
                ServiceReminder.is_completed == False,  # noqa: E712
                ServiceReminder.due_odometer.is_not(None),
                ServiceReminder.due_odometer <= car.current_odometer,
            )
            .order_by(ServiceReminder.due_odometer.asc())
        )
        return list(session.exec(statement).all())


def complete_reminder(reminder_id: int) -> Optional[ServiceReminder]:
    """Mark a service reminder as completed."""
    return update_reminder(reminder_id, ServiceReminderUpdate(is_completed=True))
