from typing import List, Optional
from sqlmodel import select
from app.database import get_session
from app.models import Car, CarCreate, CarUpdate
from datetime import datetime


def get_all_cars() -> List[Car]:
    """Retrieve all cars from the database."""
    with get_session() as session:
        return list(session.exec(select(Car)).all())


def get_car_by_id(car_id: int) -> Optional[Car]:
    """Retrieve a car by its ID."""
    with get_session() as session:
        return session.get(Car, car_id)


def create_car(car_data: CarCreate) -> Car:
    """Create a new car record."""
    with get_session() as session:
        car = Car(**car_data.model_dump())
        session.add(car)
        session.commit()
        session.refresh(car)
        return car


def update_car(car_id: int, car_data: CarUpdate) -> Optional[Car]:
    """Update an existing car record."""
    with get_session() as session:
        car = session.get(Car, car_id)
        if car is None:
            return None

        update_data = car_data.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(car, field, value)

        car.updated_at = datetime.utcnow()
        session.add(car)
        session.commit()
        session.refresh(car)
        return car


def delete_car(car_id: int) -> bool:
    """Delete a car record."""
    with get_session() as session:
        car = session.get(Car, car_id)
        if car is None:
            return False

        session.delete(car)
        session.commit()
        return True


def update_car_odometer(car_id: int, odometer_reading: int) -> Optional[Car]:
    """Update the current odometer reading for a car."""
    with get_session() as session:
        car = session.get(Car, car_id)
        if car is None:
            return None

        # Only update if the new reading is higher
        if odometer_reading > car.current_odometer:
            car.current_odometer = odometer_reading
            car.updated_at = datetime.utcnow()
            session.add(car)
            session.commit()
            session.refresh(car)

        return car
