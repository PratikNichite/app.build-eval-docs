from app.database import create_tables
import app.pages.dashboard
import app.pages.cars
import app.pages.car_detail


def startup() -> None:
    # this function is called before the first request
    create_tables()

    # Register all page modules
    app.pages.dashboard.create()
    app.pages.cars.create()
    app.pages.car_detail.create()
