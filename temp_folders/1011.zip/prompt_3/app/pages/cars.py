from nicegui import ui
from app.components.car_management import create_car_form, create_car_list


def create():
    @ui.page("/cars")
    def cars_page():
        # Apply modern color theme
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        with ui.column().classes("w-full max-w-6xl mx-auto p-6"):
            # Navigation breadcrumb
            with ui.row().classes("items-center gap-2 mb-4"):
                ui.link("Dashboard", "/").classes("text-blue-600 hover:text-blue-800")
                ui.label("/").classes("text-gray-400")
                ui.label("Cars").classes("text-gray-600")

            # Header with add button
            with ui.row().classes("items-center justify-between mb-6"):
                ui.label("Vehicle Management").classes("text-3xl font-bold text-gray-800")
                ui.button("Add New Car", on_click=lambda: create_car_form(refresh_page)).classes(
                    "bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg shadow-md"
                )

            # Cars list
            cars_container = ui.column().classes("w-full")

            def refresh_page():
                cars_container.clear()
                with cars_container:
                    create_car_list(on_car_select=lambda car: ui.navigate.to(f"/car/{car.id}" if car.id else "/"))

            refresh_page()
