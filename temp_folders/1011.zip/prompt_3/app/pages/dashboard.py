from nicegui import ui
from app.components.car_management import create_car_list
from app.components.maintenance_management import create_recent_maintenance_summary
from app.components.reminder_management import create_dashboard_reminders
from app.services.car_service import get_all_cars
from app.services.maintenance_service import get_recent_maintenance_records
from app.services.reminder_service import get_overdue_reminders, get_upcoming_reminders


def create():
    @ui.page("/")
    def dashboard():
        # Apply modern color theme
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        with ui.column().classes("w-full max-w-7xl mx-auto p-6"):
            # Header
            ui.label("Car Maintenance Dashboard 🚗🔧📊").classes("text-3xl font-bold text-gray-800 mb-6")

            # Key metrics cards
            with ui.row().classes("gap-6 w-full mb-8"):
                create_metric_card("Total Cars", len(get_all_cars()), "vehicles")
                create_metric_card("Recent Services", len(get_recent_maintenance_records(30)), "maintenance")
                create_metric_card("Overdue Items", len(get_overdue_reminders()), "overdue", is_warning=True)
                create_metric_card("Upcoming (30d)", len(get_upcoming_reminders(30)), "upcoming")

            # Main content area
            with ui.row().classes("gap-6 w-full"):
                # Left column - Cars and recent maintenance
                with ui.column().classes("flex-1"):
                    with ui.card().classes("p-6 shadow-lg rounded-xl bg-white"):
                        ui.label("Your Vehicles").classes("text-xl font-bold mb-4")
                        create_car_list(on_car_select=lambda car: ui.navigate.to(f"/car/{car.id}" if car.id else "/"))

                    with ui.card().classes("p-6 shadow-lg rounded-xl bg-white mt-6"):
                        create_recent_maintenance_summary()

                # Right column - Service reminders
                with ui.column().classes("w-80"):
                    with ui.card().classes("p-6 shadow-lg rounded-xl bg-white"):
                        create_dashboard_reminders()

            # Quick action buttons
            with ui.row().classes("gap-4 mt-8 justify-center"):
                ui.button("Add New Car", on_click=lambda: ui.navigate.to("/cars")).classes(
                    "bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg shadow-md"
                )
                ui.button("View All Cars", on_click=lambda: ui.navigate.to("/cars")).classes(
                    "bg-gray-500 hover:bg-gray-600 text-white px-6 py-3 rounded-lg shadow-md"
                )


def create_metric_card(title: str, value: int, metric_type: str, is_warning: bool = False):
    """Create a metric card for the dashboard."""

    # Define colors and icons based on metric type
    colors = {
        "vehicles": "bg-blue-500",
        "maintenance": "bg-green-500",
        "overdue": "bg-red-500",
        "upcoming": "bg-orange-500",
    }

    icons = {"vehicles": "🚗", "maintenance": "🔧", "overdue": "⚠️", "upcoming": "📅"}

    bg_color = colors.get(metric_type, "bg-gray-500")
    icon = icons.get(metric_type, "📊")

    if is_warning and value > 0:
        bg_color = "bg-red-500"

    with ui.card().classes("p-6 bg-white shadow-lg rounded-xl hover:shadow-xl transition-shadow min-w-48"):
        with ui.row().classes("items-center gap-4"):
            with ui.element("div").classes(f"{bg_color} p-3 rounded-full text-white text-2xl"):
                ui.label(icon)

            with ui.column():
                ui.label(str(value)).classes("text-3xl font-bold text-gray-800")
                ui.label(title).classes("text-sm text-gray-500 uppercase tracking-wider")
