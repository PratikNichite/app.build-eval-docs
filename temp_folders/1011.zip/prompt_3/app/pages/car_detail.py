from nicegui import ui
from app.services.car_service import get_car_by_id
from app.components.maintenance_management import create_maintenance_history
from app.components.reminder_management import create_reminder_list


def create():
    @ui.page("/car/{car_id}")
    def car_detail_page(car_id: int):
        # Apply modern color theme
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        car = get_car_by_id(car_id)

        if car is None:
            with ui.column().classes("w-full max-w-4xl mx-auto p-6"):
                ui.label("Car not found").classes("text-2xl font-bold text-red-600 text-center")
                ui.button("Back to Dashboard", on_click=lambda: ui.navigate.to("/")).classes(
                    "bg-blue-500 text-white px-4 py-2 rounded mx-auto mt-4"
                )
            return

        with ui.column().classes("w-full max-w-7xl mx-auto p-6"):
            # Navigation breadcrumb
            with ui.row().classes("items-center gap-2 mb-4"):
                ui.link("Dashboard", "/").classes("text-blue-600 hover:text-blue-800")
                ui.label("/").classes("text-gray-400")
                ui.link("Cars", "/cars").classes("text-blue-600 hover:text-blue-800")
                ui.label("/").classes("text-gray-400")
                ui.label(f"{car.year} {car.make} {car.model}").classes("text-gray-600")

            # Car header card
            with ui.card().classes("w-full p-6 mb-6 shadow-lg rounded-xl bg-white"):
                with ui.row().classes("items-center justify-between"):
                    with ui.column():
                        ui.label(f"{car.year} {car.make} {car.model}").classes("text-3xl font-bold text-gray-800")
                        ui.label(f"License Plate: {car.license_plate}").classes("text-lg text-gray-600")
                        ui.label(f"VIN: {car.vin}").classes("text-md text-gray-500")
                        ui.label(f"Color: {car.color}").classes("text-md text-gray-500")

                    with ui.column().classes("text-right"):
                        ui.label("Current Odometer").classes("text-sm text-gray-500 uppercase tracking-wider")
                        ui.label(f"{car.current_odometer:,} miles").classes("text-2xl font-bold text-blue-600")

            # Main content tabs
            with ui.tabs().classes("w-full") as tabs:
                maintenance_tab = ui.tab("Maintenance History")
                reminders_tab = ui.tab("Service Reminders")

            with ui.tab_panels(tabs, value=maintenance_tab).classes("w-full"):
                with ui.tab_panel(maintenance_tab):
                    create_maintenance_history(car)

                with ui.tab_panel(reminders_tab):
                    create_reminder_list(car)
