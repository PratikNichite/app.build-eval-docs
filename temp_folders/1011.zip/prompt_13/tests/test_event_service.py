import pytest
from datetime import date, datetime
from app.database import reset_db
from app.event_service import (
    create_event,
    get_all_events,
    get_event_by_id,
    update_event,
    delete_event,
    get_upcoming_events,
    get_events_count,
)
from app.models import EventCreate, EventUpdate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


def test_create_event(new_db):
    """Test creating a new event."""
    event_data = EventCreate(
        title="Team Meeting", event_date=date(2024, 12, 25), description="Monthly team sync meeting"
    )

    event = create_event(event_data)

    assert event.id is not None
    assert event.title == "Team Meeting"
    assert event.event_date == date(2024, 12, 25)
    assert event.description == "Monthly team sync meeting"
    assert isinstance(event.created_at, datetime)


def test_create_event_with_empty_description(new_db):
    """Test creating an event with empty description."""
    event_data = EventCreate(title="Quick Standup", event_date=date(2024, 12, 20))

    event = create_event(event_data)

    assert event.title == "Quick Standup"
    assert event.description == ""


def test_get_all_events_empty(new_db):
    """Test getting events when database is empty."""
    events = get_all_events()
    assert events == []


def test_get_all_events_with_data(new_db):
    """Test getting all events when database has data."""
    # Create test events
    create_event(EventCreate(title="Event 1", event_date=date(2024, 12, 25)))
    create_event(EventCreate(title="Event 2", event_date=date(2024, 12, 20)))
    create_event(EventCreate(title="Event 3", event_date=date(2024, 12, 30)))

    events = get_all_events()

    # Should return events ordered by date descending
    assert len(events) == 3
    assert events[0].event_date == date(2024, 12, 30)  # Latest first
    assert events[1].event_date == date(2024, 12, 25)
    assert events[2].event_date == date(2024, 12, 20)  # Earliest last


def test_get_event_by_id_exists(new_db):
    """Test getting an event that exists."""
    event_data = EventCreate(title="Test Event", event_date=date(2024, 12, 25))
    created_event = create_event(event_data)

    if created_event.id is not None:
        retrieved_event = get_event_by_id(created_event.id)

        assert retrieved_event is not None
        assert retrieved_event.id == created_event.id
        assert retrieved_event.title == "Test Event"


def test_get_event_by_id_not_exists(new_db):
    """Test getting an event that doesn't exist."""
    retrieved_event = get_event_by_id(999)
    assert retrieved_event is None


def test_update_event_success(new_db):
    """Test updating an existing event."""
    # Create initial event
    event_data = EventCreate(title="Original Title", event_date=date(2024, 12, 25))
    created_event = create_event(event_data)

    if created_event.id is not None:
        # Update the event
        update_data = EventUpdate(title="Updated Title", description="New description")

        updated_event = update_event(created_event.id, update_data)

        assert updated_event is not None
        assert updated_event.title == "Updated Title"
        assert updated_event.description == "New description"
        assert updated_event.event_date == date(2024, 12, 25)  # Unchanged


def test_update_event_partial(new_db):
    """Test partial update of an event."""
    # Create initial event
    event_data = EventCreate(title="Original Title", event_date=date(2024, 12, 25), description="Original description")
    created_event = create_event(event_data)

    if created_event.id is not None:
        # Update only the date
        update_data = EventUpdate(event_date=date(2024, 12, 30))

        updated_event = update_event(created_event.id, update_data)

        assert updated_event is not None
        assert updated_event.title == "Original Title"  # Unchanged
        assert updated_event.description == "Original description"  # Unchanged
        assert updated_event.event_date == date(2024, 12, 30)  # Updated


def test_update_event_not_exists(new_db):
    """Test updating an event that doesn't exist."""
    update_data = EventUpdate(title="New Title")
    updated_event = update_event(999, update_data)

    assert updated_event is None


def test_delete_event_success(new_db):
    """Test deleting an existing event."""
    # Create event
    event_data = EventCreate(title="To Delete", event_date=date(2024, 12, 25))
    created_event = create_event(event_data)

    if created_event.id is not None:
        # Delete the event
        success = delete_event(created_event.id)
        assert success

        # Verify it's gone
        retrieved_event = get_event_by_id(created_event.id)
        assert retrieved_event is None


def test_delete_event_not_exists(new_db):
    """Test deleting an event that doesn't exist."""
    success = delete_event(999)
    assert not success


def test_get_upcoming_events(new_db):
    """Test getting upcoming events."""
    today = date.today()

    # Create events - some past, some future
    from datetime import timedelta

    yesterday = today - timedelta(days=1)
    tomorrow = today + timedelta(days=1)
    next_week = today + timedelta(days=7)

    create_event(EventCreate(title="Past Event", event_date=yesterday))
    create_event(EventCreate(title="Tomorrow Event", event_date=tomorrow))
    create_event(EventCreate(title="Next Week Event", event_date=next_week))
    create_event(EventCreate(title="Today Event", event_date=today))

    upcoming = get_upcoming_events()

    # Should only get today and future events, ordered by date ascending
    assert len(upcoming) == 3
    assert all(event.event_date >= today for event in upcoming)

    # Check ordering (earliest first)
    dates = [event.event_date for event in upcoming]
    assert dates == sorted(dates)


def test_get_upcoming_events_limit(new_db):
    """Test getting upcoming events with limit."""
    today = date.today()
    from datetime import timedelta

    # Create many upcoming events
    for i in range(10):
        future_date = today + timedelta(days=i)
        create_event(EventCreate(title=f"Event {i}", event_date=future_date))

    upcoming = get_upcoming_events(limit=3)
    assert len(upcoming) == 3


def test_get_events_count(new_db):
    """Test getting total count of events."""
    assert get_events_count() == 0

    # Add some events
    create_event(EventCreate(title="Event 1", event_date=date(2024, 12, 25)))
    create_event(EventCreate(title="Event 2", event_date=date(2024, 12, 26)))

    assert get_events_count() == 2


def test_event_with_long_title(new_db):
    """Test creating event with maximum length title."""
    long_title = "A" * 200  # Max length
    event_data = EventCreate(title=long_title, event_date=date(2024, 12, 25))

    event = create_event(event_data)
    assert event.title == long_title


def test_event_with_long_description(new_db):
    """Test creating event with maximum length description."""
    long_description = "B" * 1000  # Max length
    event_data = EventCreate(title="Test Event", event_date=date(2024, 12, 25), description=long_description)

    event = create_event(event_data)
    assert event.description == long_description
