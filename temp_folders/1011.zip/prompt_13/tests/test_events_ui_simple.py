import pytest
from datetime import date
from app.database import reset_db
from app.event_service import create_event
from app.models import EventCreate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


# Focus on logic tests since UI context is problematic in testing
def test_event_creation_with_ui_data(new_db):
    """Test that event creation works with typical UI form data."""
    event_data = EventCreate(title="Team Meeting", event_date=date(2024, 12, 25), description="Weekly team sync")

    event = create_event(event_data)
    assert event.id is not None
    assert event.title == "Team Meeting"


def test_event_list_functionality(new_db):
    """Test the core functionality that powers the events list."""
    # Create events in different order
    create_event(EventCreate(title="First", event_date=date(2024, 12, 20)))
    create_event(EventCreate(title="Second", event_date=date(2024, 12, 25)))
    create_event(EventCreate(title="Third", event_date=date(2024, 12, 15)))

    from app.event_service import get_all_events

    events = get_all_events()

    # Should be ordered by date descending (latest first)
    assert len(events) == 3
    assert events[0].title == "Second"  # Dec 25
    assert events[1].title == "First"  # Dec 20
    assert events[2].title == "Third"  # Dec 15


def test_form_validation_logic(new_db):
    """Test form validation logic that would be used in UI."""
    # Test empty title - this would trigger UI validation
    title = ""
    assert len(title.strip()) == 0  # This is what UI validation checks

    # Test valid data
    title = "Valid Event"
    event_date = date(2024, 12, 25)
    assert len(title.strip()) > 0
    assert event_date is not None

    # Test successful creation with valid data
    event_data = EventCreate(title=title, event_date=event_date)
    event = create_event(event_data)
    assert event.title == "Valid Event"


def test_delete_confirmation_logic(new_db):
    """Test the logic that would be used in delete confirmation."""
    # Create event
    event = create_event(EventCreate(title="To Delete", event_date=date(2024, 12, 25)))
    assert event.id is not None

    # Test the delete logic that UI would call
    from app.event_service import delete_event, get_event_by_id

    # Simulate user confirming deletion
    success = delete_event(event.id)
    assert success

    # Verify event is gone
    deleted_event = get_event_by_id(event.id)
    assert deleted_event is None


def test_upcoming_events_logic(new_db):
    """Test the logic that powers upcoming events view."""
    from datetime import timedelta
    from app.event_service import get_upcoming_events

    today = date.today()
    yesterday = today - timedelta(days=1)
    tomorrow = today + timedelta(days=1)

    # Create mix of past and future events
    create_event(EventCreate(title="Past", event_date=yesterday))
    create_event(EventCreate(title="Future", event_date=tomorrow))
    create_event(EventCreate(title="Today", event_date=today))

    upcoming = get_upcoming_events()

    # Should only get today and future events
    assert len(upcoming) >= 2  # At least today and tomorrow
    assert all(event.event_date >= today for event in upcoming)

    # Check we don't get past events
    titles = [event.title for event in upcoming]
    assert "Past" not in titles
