from nicegui import ui


def create_navigation():
    """Create a modern navigation header for the application."""
    with ui.header().classes("bg-white shadow-sm border-b px-6 py-4"):
        with ui.row().classes("w-full justify-between items-center"):
            # Logo/Brand
            with ui.row().classes("items-center gap-2"):
                ui.label("📅").classes("text-2xl")
                ui.label("Event Tracker").classes("text-xl font-bold text-gray-800")

            # Navigation menu
            with ui.row().classes("gap-1"):
                ui.button("All Events", on_click=lambda: ui.navigate.to("/")).props("flat no-caps").classes(
                    "text-gray-600 hover:text-primary"
                )

                ui.button("Upcoming", on_click=lambda: ui.navigate.to("/upcoming")).props("flat no-caps").classes(
                    "text-gray-600 hover:text-primary"
                )

                ui.button("Add Event", on_click=lambda: ui.navigate.to("/add"), icon="add").classes(
                    "bg-primary text-white px-4 py-1 rounded-md"
                )


def create():
    """Create navigation component."""
    # Navigation is created per page, so we don't need a separate create function
    # The navigation will be added to each page individually
    pass
