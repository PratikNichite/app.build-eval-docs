from app.database import create_tables
import app.events_ui
import app.navigation


def startup() -> None:
    # this function is called before the first request
    create_tables()
    app.events_ui.create()
    app.navigation.create()
