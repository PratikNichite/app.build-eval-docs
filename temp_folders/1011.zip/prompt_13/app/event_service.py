from datetime import date
from typing import Optional
from sqlmodel import select
from app.database import get_session
from app.models import Event, EventCreate, EventUpdate


def create_event(event_data: EventCreate) -> Event:
    """Create a new event in the database."""
    with get_session() as session:
        event = Event(title=event_data.title, event_date=event_data.event_date, description=event_data.description)
        session.add(event)
        session.commit()
        session.refresh(event)
        return event


def get_all_events() -> list[Event]:
    """Retrieve all events from the database, ordered by event date."""
    with get_session() as session:
        statement = select(Event).order_by(Event.event_date.desc())
        return list(session.exec(statement))


def get_event_by_id(event_id: int) -> Optional[Event]:
    """Retrieve a specific event by ID."""
    with get_session() as session:
        return session.get(Event, event_id)


def update_event(event_id: int, event_data: EventUpdate) -> Optional[Event]:
    """Update an existing event."""
    with get_session() as session:
        event = session.get(Event, event_id)
        if event is None:
            return None

        if event_data.title is not None:
            event.title = event_data.title
        if event_data.event_date is not None:
            event.event_date = event_data.event_date
        if event_data.description is not None:
            event.description = event_data.description

        session.commit()
        session.refresh(event)
        return event


def delete_event(event_id: int) -> bool:
    """Delete an event by ID. Returns True if deleted, False if not found."""
    with get_session() as session:
        event = session.get(Event, event_id)
        if event is None:
            return False

        session.delete(event)
        session.commit()
        return True


def get_upcoming_events(limit: int = 5) -> list[Event]:
    """Get upcoming events from today onwards."""
    with get_session() as session:
        today = date.today()
        statement = select(Event).where(Event.event_date >= today).order_by(Event.event_date.asc()).limit(limit)
        return list(session.exec(statement))


def get_events_count() -> int:
    """Get total count of events."""
    with get_session() as session:
        statement = select(Event)
        return len(list(session.exec(statement)))
