from datetime import date
from nicegui import ui
from app.event_service import create_event, get_all_events, delete_event, get_upcoming_events, get_events_count
from app.models import EventCreate, Event


def apply_modern_theme():
    """Apply modern color scheme for professional appearance."""
    ui.colors(
        primary="#2563eb",  # Professional blue
        secondary="#64748b",  # Subtle gray
        accent="#10b981",  # Success green
        positive="#10b981",
        negative="#ef4444",  # Error red
        warning="#f59e0b",  # Warning amber
        info="#3b82f6",  # Info blue
    )


def create_metric_card(title: str, value: str, icon: str = "📊"):
    """Create a modern metric card component."""
    with ui.card().classes("p-6 bg-white shadow-lg rounded-xl hover:shadow-xl transition-shadow"):
        with ui.row().classes("items-center gap-4"):
            ui.label(icon).classes("text-3xl")
            with ui.column().classes("gap-1"):
                ui.label(title).classes("text-sm text-gray-500 uppercase tracking-wider")
                ui.label(value).classes("text-3xl font-bold text-gray-800")


def create_event_card(event: Event, refresh_callback):
    """Create an event card with delete functionality."""
    with ui.card().classes("p-6 bg-white shadow-md rounded-lg hover:shadow-lg transition-shadow"):
        with ui.row().classes("justify-between items-start w-full"):
            with ui.column().classes("flex-1"):
                ui.label(event.title).classes("text-xl font-bold text-gray-800 mb-2")
                ui.label(f"📅 {event.event_date.strftime('%B %d, %Y')}").classes("text-blue-600 font-medium mb-2")
                if event.description:
                    ui.label(event.description).classes("text-gray-600 leading-relaxed")
                ui.label(f"Created: {event.created_at.strftime('%m/%d/%Y')}").classes("text-xs text-gray-400 mt-2")

            # Delete button
            async def confirm_delete():
                with ui.dialog() as dialog, ui.card():
                    ui.label(f'🤔 Are you sure you want to delete "{event.title}"?').classes("text-lg mb-4")
                    with ui.row().classes("gap-2"):
                        ui.button("❌ Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
                        ui.button("🗑️ Delete", on_click=lambda: dialog.submit("delete")).props("color=negative")

                result = await dialog
                if result == "delete":
                    if event.id is not None:
                        success = delete_event(event.id)
                        if success:
                            ui.notify("🗑️ Event deleted successfully!", type="positive")
                            refresh_callback()
                        else:
                            ui.notify("⚠️ Failed to delete event.", type="negative")

            ui.button("🗑️", on_click=confirm_delete).props("flat round color=negative size=sm").classes("ml-4")


def create():
    """Create the events tracking application."""
    apply_modern_theme()

    @ui.page("/")
    def index():
        # Header
        with ui.row().classes("w-full justify-between items-center mb-8"):
            with ui.column():
                ui.label("🎯 Event Tracker").classes("text-3xl font-bold text-gray-800 mb-2")
                ui.label("✨ Manage your events and never miss an important date").classes("text-gray-600")

            ui.button("✨ Add New Event", on_click=lambda: ui.navigate.to("/add")).classes(
                "bg-primary text-white px-6 py-3 rounded-lg shadow-md hover:shadow-lg transition-all"
            )

        # Metrics row
        with ui.row().classes("gap-4 w-full mb-8"):
            events_count = get_events_count()
            upcoming_count = len(get_upcoming_events())

            create_metric_card("Total Events", str(events_count), "📊")
            create_metric_card("Upcoming", str(upcoming_count), "⏰")
            create_metric_card("This Month", "0", "🗓️")  # Could be enhanced with actual calculation

        # Events list
        events_container = ui.column().classes("w-full gap-4")

        def refresh_events():
            events_container.clear()
            events = get_all_events()

            if not events:
                with events_container:
                    with ui.card().classes("p-8 text-center bg-gray-50"):
                        ui.label("🌟 No events yet!").classes("text-2xl text-gray-400 mb-2")
                        ui.label('✨ Click "Add New Event" to get started.').classes("text-gray-500")
            else:
                with events_container:
                    ui.label(f"📋 All Events ({len(events)})").classes("text-xl font-bold text-gray-800 mb-4")
                    for event in events:
                        create_event_card(event, refresh_events)

        refresh_events()

    @ui.page("/add")
    def add_event():
        ui.label("✨ Add New Event").classes("text-3xl font-bold text-gray-800 mb-6")

        with ui.card().classes("max-w-2xl p-8 shadow-lg rounded-lg"):
            # Form fields
            ui.label("📝 Event Title *").classes("text-sm font-medium text-gray-700 mb-2")
            title_input = ui.input(placeholder="Enter event title...").classes("w-full mb-4")

            ui.label("📅 Event Date *").classes("text-sm font-medium text-gray-700 mb-2")
            date_input = ui.date(value=date.today()).classes("w-full mb-4")

            ui.label("📄 Description").classes("text-sm font-medium text-gray-700 mb-2")
            description_input = (
                ui.textarea(placeholder="Optional event description...").classes("w-full mb-6").props("rows=4")
            )

            # Action buttons
            with ui.row().classes("gap-4 justify-end w-full"):
                ui.button("❌ Cancel", on_click=lambda: ui.navigate.to("/")).props("outline").classes("px-6 py-2")

                def save_event():
                    title = title_input.value.strip()
                    event_date = date_input.value
                    description = description_input.value.strip()

                    if not title:
                        ui.notify("⚠️ Please enter an event title.", type="warning")
                        return

                    if not event_date:
                        ui.notify("⚠️ Please select an event date.", type="warning")
                        return

                    try:
                        # Parse date if it's a string
                        if isinstance(event_date, str):
                            event_date = date.fromisoformat(event_date)

                        event_data = EventCreate(title=title, event_date=event_date, description=description)

                        create_event(event_data)
                        ui.notify("🎉 Event created successfully!", type="positive")
                        ui.navigate.to("/")

                    except Exception as e:
                        ui.notify(f"❌ Error creating event: {str(e)}", type="negative")

                ui.button("💾 Save Event", on_click=save_event).classes("bg-primary text-white px-6 py-2")

    @ui.page("/upcoming")
    def upcoming_events():
        ui.label("🚀 Upcoming Events").classes("text-3xl font-bold text-gray-800 mb-6")

        events_container = ui.column().classes("w-full gap-4")

        def refresh_upcoming():
            events_container.clear()
            events = get_upcoming_events(10)  # Get next 10 events

            if not events:
                with events_container:
                    with ui.card().classes("p-8 text-center bg-gray-50"):
                        ui.label("🌅 No upcoming events").classes("text-2xl text-gray-400 mb-2")
                        ui.label("✅ All caught up!").classes("text-gray-500")
            else:
                with events_container:
                    for event in events:
                        create_event_card(event, refresh_upcoming)

        refresh_upcoming()

        # Navigation
        with ui.row().classes("gap-4 mt-8"):
            ui.button("⬅️ Back to All Events", on_click=lambda: ui.navigate.to("/")).props("outline")
            ui.button("✨ Add New Event", on_click=lambda: ui.navigate.to("/add")).classes("bg-primary text-white")
