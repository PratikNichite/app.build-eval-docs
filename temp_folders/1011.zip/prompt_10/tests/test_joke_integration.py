import pytest
from app.database import reset_db
from app.joke_service import save_joke, get_all_jokes, update_joke, delete_joke
from app.models import JokeCreate, JokeUpdate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


class TestJokeIntegration:
    """Integration tests for joke functionality without UI."""

    def test_complete_joke_workflow(self, new_db):
        """Test a complete workflow of creating, updating, and deleting jokes."""
        # Create multiple jokes
        joke1_data = JokeCreate(
            setup="Why don't scientists trust atoms?",
            punchline="Because they make up everything!",
            personal_comment="Classic chemistry joke",
        )

        joke2_data = JokeCreate(setup="What do you call a fake noodle?", punchline="An impasta!")

        # Save jokes
        saved_joke1 = save_joke(joke1_data)
        saved_joke2 = save_joke(joke2_data)

        assert saved_joke1 is not None
        assert saved_joke2 is not None

        # Verify they appear in list (newest first)
        all_jokes = get_all_jokes()
        assert len(all_jokes) == 2
        assert all_jokes[0].setup == "What do you call a fake noodle?"  # Newest first
        assert all_jokes[1].setup == "Why don't scientists trust atoms?"

        # Update first joke
        update_data = JokeUpdate(personal_comment="Updated comment")
        updated_joke = update_joke(saved_joke1.id, update_data)

        assert updated_joke is not None
        assert updated_joke.personal_comment == "Updated comment"
        assert updated_joke.setup == joke1_data.setup  # Unchanged

        # Delete second joke
        success = delete_joke(saved_joke2.id)
        assert success

        # Verify only one remains
        remaining_jokes = get_all_jokes()
        assert len(remaining_jokes) == 1
        assert remaining_jokes[0].id == saved_joke1.id

    def test_joke_data_validation(self, new_db):
        """Test that joke data is properly validated and stored."""
        # Test with all fields
        full_joke = JokeCreate(
            setup="Why did the scarecrow win an award?",
            punchline="He was outstanding in his field!",
            personal_comment="Dad joke level: expert",
        )

        saved_joke = save_joke(full_joke)
        assert saved_joke is not None
        assert saved_joke.setup == full_joke.setup
        assert saved_joke.punchline == full_joke.punchline
        assert saved_joke.personal_comment == full_joke.personal_comment

        # Test with minimal fields
        minimal_joke = JokeCreate(setup="Short setup", punchline="Quick punchline")

        saved_minimal = save_joke(minimal_joke)
        assert saved_minimal is not None
        assert saved_minimal.personal_comment == ""  # Default empty string

    def test_update_validation(self, new_db):
        """Test joke update functionality with various scenarios."""
        # Create initial joke
        joke_data = JokeCreate(
            setup="Original setup", punchline="Original punchline", personal_comment="Original comment"
        )

        saved_joke = save_joke(joke_data)
        assert saved_joke is not None

        # Test updating individual fields
        update_setup = JokeUpdate(setup="Updated setup")
        updated_joke = update_joke(saved_joke.id, update_setup)
        assert updated_joke is not None
        assert updated_joke.setup == "Updated setup"
        assert updated_joke.punchline == "Original punchline"  # Unchanged

        # Test updating multiple fields
        update_multiple = JokeUpdate(punchline="Updated punchline", personal_comment="Updated comment")
        updated_again = update_joke(saved_joke.id, update_multiple)
        assert updated_again is not None
        assert updated_again.setup == "Updated setup"  # From previous update
        assert updated_again.punchline == "Updated punchline"
        assert updated_again.personal_comment == "Updated comment"

    def test_error_handling(self, new_db):
        """Test error handling for invalid operations."""
        # Test updating non-existent joke
        update_data = JokeUpdate(setup="New setup")
        result = update_joke(999, update_data)
        assert result is None

        # Test deleting non-existent joke
        delete_result = delete_joke(999)
        assert not delete_result

        # Test valid operations don't interfere with error cases
        joke_data = JokeCreate(setup="Valid setup", punchline="Valid punchline")
        saved_joke = save_joke(joke_data)
        assert saved_joke is not None

        # Successful operations should still work
        success = delete_joke(saved_joke.id)
        assert success
