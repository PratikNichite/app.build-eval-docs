import pytest
from datetime import datetime
from app.database import reset_db
from app.joke_service import (
    fetch_random_joke_from_api,
    save_joke,
    get_all_jokes,
    get_joke_by_id,
    update_joke,
    delete_joke,
)
from app.models import JokeCreate, JokeUpdate


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


class TestJokeService:
    """Test joke service functionality."""

    def test_save_joke(self, new_db):
        """Test saving a new joke."""
        joke_data = JokeCreate(
            setup="Why don't scientists trust atoms?",
            punchline="Because they make up everything!",
            personal_comment="Classic chemistry joke",
        )

        saved_joke = save_joke(joke_data)

        assert saved_joke is not None
        assert saved_joke.id is not None
        assert saved_joke.setup == joke_data.setup
        assert saved_joke.punchline == joke_data.punchline
        assert saved_joke.personal_comment == joke_data.personal_comment
        assert isinstance(saved_joke.created_at, datetime)
        assert isinstance(saved_joke.updated_at, datetime)

    def test_save_joke_with_empty_comment(self, new_db):
        """Test saving a joke with no personal comment."""
        joke_data = JokeCreate(setup="What do you call a fake noodle?", punchline="An impasta!")

        saved_joke = save_joke(joke_data)

        assert saved_joke is not None
        assert saved_joke.personal_comment == ""

    def test_get_all_jokes_empty(self, new_db):
        """Test getting jokes when database is empty."""
        jokes = get_all_jokes()
        assert jokes == []

    def test_get_all_jokes_with_data(self, new_db):
        """Test getting all jokes with data."""
        # Create multiple jokes
        joke1_data = JokeCreate(setup="Setup 1", punchline="Punchline 1")
        joke2_data = JokeCreate(setup="Setup 2", punchline="Punchline 2")

        save_joke(joke1_data)
        save_joke(joke2_data)

        jokes = get_all_jokes()

        assert len(jokes) == 2
        # Should be ordered by created_at desc (newest first)
        assert jokes[0].setup == "Setup 2"
        assert jokes[1].setup == "Setup 1"

    def test_get_joke_by_id_existing(self, new_db):
        """Test getting a joke by existing ID."""
        joke_data = JokeCreate(
            setup="Why did the scarecrow win an award?", punchline="He was outstanding in his field!"
        )

        saved_joke = save_joke(joke_data)
        assert saved_joke is not None

        retrieved_joke = get_joke_by_id(saved_joke.id)

        assert retrieved_joke is not None
        assert retrieved_joke.id == saved_joke.id
        assert retrieved_joke.setup == joke_data.setup
        assert retrieved_joke.punchline == joke_data.punchline

    def test_get_joke_by_id_nonexistent(self, new_db):
        """Test getting a joke by non-existent ID."""
        joke = get_joke_by_id(999)
        assert joke is None

    def test_update_joke_existing(self, new_db):
        """Test updating an existing joke."""
        # Create initial joke
        joke_data = JokeCreate(
            setup="Original setup", punchline="Original punchline", personal_comment="Original comment"
        )

        saved_joke = save_joke(joke_data)
        assert saved_joke is not None

        # Update the joke
        update_data = JokeUpdate(setup="Updated setup", personal_comment="Updated comment")

        updated_joke = update_joke(saved_joke.id, update_data)

        assert updated_joke is not None
        assert updated_joke.id == saved_joke.id
        assert updated_joke.setup == "Updated setup"
        assert updated_joke.punchline == "Original punchline"  # Should remain unchanged
        assert updated_joke.personal_comment == "Updated comment"
        assert updated_joke.updated_at > saved_joke.updated_at

    def test_update_joke_partial(self, new_db):
        """Test partial update of a joke."""
        # Create initial joke
        joke_data = JokeCreate(
            setup="Original setup", punchline="Original punchline", personal_comment="Original comment"
        )

        saved_joke = save_joke(joke_data)
        assert saved_joke is not None

        # Update only the comment
        update_data = JokeUpdate(personal_comment="Only comment updated")

        updated_joke = update_joke(saved_joke.id, update_data)

        assert updated_joke is not None
        assert updated_joke.setup == "Original setup"  # Unchanged
        assert updated_joke.punchline == "Original punchline"  # Unchanged
        assert updated_joke.personal_comment == "Only comment updated"

    def test_update_joke_nonexistent(self, new_db):
        """Test updating a non-existent joke."""
        update_data = JokeUpdate(setup="New setup")

        result = update_joke(999, update_data)

        assert result is None

    def test_delete_joke_existing(self, new_db):
        """Test deleting an existing joke."""
        joke_data = JokeCreate(setup="To be deleted", punchline="This joke will be removed")

        saved_joke = save_joke(joke_data)
        assert saved_joke is not None

        # Delete the joke
        success = delete_joke(saved_joke.id)

        assert success

        # Verify it's gone
        retrieved_joke = get_joke_by_id(saved_joke.id)
        assert retrieved_joke is None

    def test_delete_joke_nonexistent(self, new_db):
        """Test deleting a non-existent joke."""
        success = delete_joke(999)
        assert not success

    async def test_fetch_random_joke_from_api(self):
        """Test fetching a random joke from the external API."""
        # This test fetches real data from the API
        joke = await fetch_random_joke_from_api()

        # The API might be down, so we handle both cases
        if joke is not None:
            assert hasattr(joke, "setup")
            assert hasattr(joke, "punchline")
            assert hasattr(joke, "type")
            assert hasattr(joke, "id")
            assert isinstance(joke.setup, str)
            assert isinstance(joke.punchline, str)
            assert len(joke.setup) > 0
            assert len(joke.punchline) > 0

    def test_save_joke_with_long_text(self, new_db):
        """Test saving joke with maximum allowed text length."""
        long_setup = "A" * 500  # Max length
        long_punchline = "B" * 500  # Max length
        long_comment = "C" * 1000  # Max length

        joke_data = JokeCreate(setup=long_setup, punchline=long_punchline, personal_comment=long_comment)

        saved_joke = save_joke(joke_data)

        assert saved_joke is not None
        assert saved_joke.setup == long_setup
        assert saved_joke.punchline == long_punchline
        assert saved_joke.personal_comment == long_comment

    def test_multiple_operations_integration(self, new_db):
        """Test a complete workflow of operations."""
        # Create a joke
        joke_data = JokeCreate(setup="Integration test setup", punchline="Integration test punchline")

        saved_joke = save_joke(joke_data)
        assert saved_joke is not None

        # Verify it appears in the list
        all_jokes = get_all_jokes()
        assert len(all_jokes) == 1
        assert all_jokes[0].id == saved_joke.id

        # Update it
        update_data = JokeUpdate(personal_comment="Added during integration test")
        updated_joke = update_joke(saved_joke.id, update_data)
        assert updated_joke is not None
        assert updated_joke.personal_comment == "Added during integration test"

        # Verify the update persisted
        retrieved_joke = get_joke_by_id(saved_joke.id)
        assert retrieved_joke is not None
        assert retrieved_joke.personal_comment == "Added during integration test"

        # Delete it
        success = delete_joke(saved_joke.id)
        assert success

        # Verify it's gone from the list
        all_jokes = get_all_jokes()
        assert len(all_jokes) == 0
