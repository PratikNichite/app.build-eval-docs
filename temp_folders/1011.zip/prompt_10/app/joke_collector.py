from nicegui import ui
from app.joke_service import (
    fetch_random_joke_from_api,
    save_joke,
    get_all_jokes,
    get_joke_by_id,
    update_joke,
    delete_joke,
)
from app.models import JokeCreate, JokeUpdate


def create():
    # Apply modern theme
    ui.colors(
        primary="#2563eb",  # Professional blue
        secondary="#64748b",  # Subtle gray
        accent="#10b981",  # Success green
        positive="#10b981",
        negative="#ef4444",  # Error red
        warning="#f59e0b",  # Warning amber
        info="#3b82f6",  # Info blue
    )

    @ui.page("/")
    def index():
        ui.add_head_html("<title>Joke Collector</title>")

        # Main page container
        with ui.column().classes("min-h-screen bg-gray-50 p-4"):
            # Main content container
            jokes_container = ui.column().classes("w-full max-w-4xl mx-auto")

            def refresh_jokes():
                """Refresh the jokes display."""
                jokes_container.clear()
                jokes = get_all_jokes()

                if not jokes:
                    with jokes_container:
                        ui.label('😅 No jokes saved yet. Click "Get Random Joke" to start!').classes(
                            "text-gray-500 text-center py-8 text-lg"
                        )
                    return

                with jokes_container:
                    for joke in jokes:
                        create_joke_card(joke, refresh_jokes)

            async def fetch_and_save_joke():
                """Fetch a random joke from API and save it."""
                try:
                    ui.notify("⏳ Fetching random joke...", type="info")

                    external_joke = await fetch_random_joke_from_api()
                    if external_joke is None:
                        ui.notify("❌ Failed to fetch joke from API", type="negative")
                        return

                    joke_data = JokeCreate(
                        setup=external_joke.setup, punchline=external_joke.punchline, personal_comment=""
                    )

                    saved_joke = save_joke(joke_data)
                    if saved_joke is None:
                        ui.notify("⚠️ Failed to save joke", type="negative")
                        return

                    ui.notify("✨ New joke added successfully!", type="positive")
                    refresh_jokes()

                except Exception as e:
                    ui.notify(f"🛑 Error: {str(e)}", type="negative")

            async def open_edit_dialog(joke_id: int | None, refresh_callback):
                """Open edit dialog for a joke."""
                if joke_id is None:
                    ui.notify("🚫 Invalid joke ID", type="negative")
                    return

                joke = get_joke_by_id(joke_id)
                if joke is None:
                    ui.notify("🔍 Joke not found", type="negative")
                    return

                with ui.dialog() as dialog, ui.card().classes("w-96"):
                    ui.label("Edit Joke").classes("text-xl font-bold mb-4")

                    setup_input = ui.input("Setup", value=joke.setup).classes("w-full mb-4")
                    punchline_input = ui.input("Punchline", value=joke.punchline).classes("w-full mb-4")
                    comment_input = (
                        ui.textarea("Personal Comment", value=joke.personal_comment)
                        .classes("w-full mb-4")
                        .props("rows=3")
                    )

                    with ui.row().classes("gap-2 justify-end"):
                        ui.button("Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
                        ui.button("Save", on_click=lambda: dialog.submit("save")).classes("bg-primary text-white")

                result = await dialog

                if result == "save":
                    try:
                        joke_data = JokeUpdate(
                            setup=setup_input.value.strip(),
                            punchline=punchline_input.value.strip(),
                            personal_comment=comment_input.value.strip(),
                        )

                        updated_joke = update_joke(joke_id, joke_data)
                        if updated_joke is None:
                            ui.notify("⚠️ Failed to update joke", type="negative")
                            return

                        ui.notify("✅ Joke updated successfully!", type="positive")
                        refresh_callback()

                    except Exception as e:
                        ui.notify(f"🛑 Error updating joke: {str(e)}", type="negative")

            async def confirm_delete(joke_id: int | None, refresh_callback):
                """Confirm and delete a joke."""
                if joke_id is None:
                    ui.notify("🚫 Invalid joke ID", type="negative")
                    return

                with ui.dialog() as dialog, ui.card():
                    ui.label("Are you sure you want to delete this joke?").classes("text-lg mb-4")

                    with ui.row().classes("gap-2 justify-end"):
                        ui.button("Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
                        ui.button("Delete", on_click=lambda: dialog.submit("delete")).classes("bg-negative text-white")

                result = await dialog

                if result == "delete":
                    try:
                        success = delete_joke(joke_id)
                        if not success:
                            ui.notify("⚠️ Failed to delete joke", type="negative")
                            return

                        ui.notify("🗑️ Joke deleted successfully!", type="positive")
                        refresh_callback()

                    except Exception as e:
                        ui.notify(f"🛑 Error deleting joke: {str(e)}", type="negative")

            def create_joke_card(joke, refresh_callback):
                """Create a card component for displaying a joke."""
                with ui.card().classes("w-full p-6 mb-4 shadow-lg rounded-xl hover:shadow-xl transition-shadow"):
                    # Joke content
                    ui.label(f"Setup: {joke.setup}").classes("text-lg font-semibold text-gray-800 mb-2")
                    ui.label(f"Punchline: {joke.punchline}").classes("text-lg text-gray-700 mb-4")

                    if joke.personal_comment:
                        ui.label(f"Personal Note: {joke.personal_comment}").classes(
                            "text-sm text-gray-600 italic bg-gray-50 p-2 rounded mb-4"
                        )

                    # Metadata
                    created_date = joke.created_at.strftime("%B %d, %Y at %I:%M %p")
                    ui.label(f"Added: {created_date}").classes("text-xs text-gray-400")

                    # Action buttons
                    with ui.row().classes("gap-2 mt-4"):
                        ui.button(
                            "Edit", on_click=lambda joke_id=joke.id: open_edit_dialog(joke_id, refresh_callback)
                        ).classes("bg-secondary text-white px-4 py-2 rounded")
                        ui.button(
                            "Delete", on_click=lambda joke_id=joke.id: confirm_delete(joke_id, refresh_callback)
                        ).classes("bg-negative text-white px-4 py-2 rounded")

            # Header
            with ui.row().classes("w-full items-center justify-between mb-8 bg-white shadow-md p-4 rounded-lg"):
                ui.label("🎭 Joke Collector").classes("text-2xl font-bold text-primary")
                ui.button("Get Random Joke", on_click=fetch_and_save_joke).classes(
                    "bg-primary text-white px-6 py-2 rounded-lg hover:shadow-lg transition-shadow"
                )

            # Initial load
            refresh_jokes()
