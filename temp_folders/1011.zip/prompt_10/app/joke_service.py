from datetime import datetime
from typing import Optional
import httpx
from sqlmodel import select
from app.database import get_session
from app.models import Joke, JokeCreate, JokeUpdate, ExternalJokeAPI


async def fetch_random_joke_from_api() -> Optional[ExternalJokeAPI]:
    """Fetch a random joke from the Official Joke API."""
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get("https://official-joke-api.appspot.com/random_joke")
            response.raise_for_status()
            data = response.json()
            return ExternalJokeAPI(**data)
    except Exception:
        return None


def save_joke(joke_data: JokeCreate) -> Optional[Joke]:
    """Save a new joke to the database."""
    try:
        with get_session() as session:
            joke = Joke(**joke_data.model_dump())
            session.add(joke)
            session.commit()
            session.refresh(joke)
            return joke
    except Exception:
        return None


def get_all_jokes() -> list[Joke]:
    """Retrieve all jokes from the database."""
    with get_session() as session:
        statement = select(Joke).order_by(Joke.created_at.desc())
        jokes = session.exec(statement).all()
        return list(jokes)


def get_joke_by_id(joke_id: int) -> Optional[Joke]:
    """Retrieve a specific joke by ID."""
    with get_session() as session:
        return session.get(Joke, joke_id)


def update_joke(joke_id: int, joke_data: JokeUpdate) -> Optional[Joke]:
    """Update an existing joke."""
    try:
        with get_session() as session:
            joke = session.get(Joke, joke_id)
            if joke is None:
                return None

            update_data = joke_data.model_dump(exclude_unset=True)
            for field, value in update_data.items():
                setattr(joke, field, value)

            joke.updated_at = datetime.utcnow()
            session.add(joke)
            session.commit()
            session.refresh(joke)
            return joke
    except Exception:
        return None


def delete_joke(joke_id: int) -> bool:
    """Delete a joke from the database."""
    try:
        with get_session() as session:
            joke = session.get(Joke, joke_id)
            if joke is None:
                return False

            session.delete(joke)
            session.commit()
            return True
    except Exception:
        return False
