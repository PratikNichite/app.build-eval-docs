from nicegui import ui
from app.services import AssignmentService, WeekService
from app.models import Assignment, ChoreStatus


def create():
    @ui.page("/")
    def dashboard():
        # Apply modern theme
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        ui.page_title("Roommate Chore Wheel")

        # Header
        with ui.row().classes("w-full justify-between items-center mb-6"):
            ui.label("🏠⚙️ Roommate Chore Wheel").classes("text-3xl font-bold text-gray-800")
            with ui.row().classes("gap-2"):
                ui.button("👥 Manage Roommates", on_click=lambda: ui.navigate.to("/roommates")).classes("px-4 py-2")
                ui.button("🧹 Manage Chores", on_click=lambda: ui.navigate.to("/chores")).classes("px-4 py-2")

        # Current week info
        current_week = WeekService.get_current_week()
        if current_week:
            ui.label(f"Current Week: {current_week.start_date} - {current_week.end_date}").classes(
                "text-lg text-gray-600 mb-4"
            )

        # Assignments container
        assignments_container = ui.column().classes("w-full")

        def assign_chores_handler():
            try:
                assignments = AssignmentService.assign_chores_for_current_week()
                if assignments:
                    ui.notify(f"✅ Successfully assigned {len(assignments)} chores!", type="positive")
                    refresh_assignments()
                else:
                    ui.notify("⚠️ No roommates or chores available to assign", type="warning")
            except Exception as e:
                ui.notify(f"❌ Error assigning chores: {str(e)}", type="negative")

        def refresh_assignments():
            assignments_container.clear()
            display_assignments(assignments_container)

        # Assignment controls
        with ui.row().classes("gap-4 mb-6"):
            ui.button("🪄 Assign Chores for This Week", on_click=assign_chores_handler, color="primary").classes(
                "px-6 py-3 text-white font-semibold"
            )
            ui.button("🔄 Refresh", on_click=refresh_assignments).classes("px-4 py-2")

        # Initial load
        refresh_assignments()


def display_assignments(container: ui.column):
    """Display current week's assignments in the given container"""
    assignments = AssignmentService.get_current_week_assignments()

    if not assignments:
        with container:
            with ui.card().classes("p-8 text-center bg-gray-50"):
                ui.label("📋 No chores assigned yet").classes("text-xl text-gray-500 mb-2")
                ui.label('Click "🪄 Assign Chores for This Week" to get started!').classes("text-gray-400")
        return

    with container:
        ui.label("📋 This Week's Assignments").classes("text-2xl font-bold text-gray-800 mb-4")

        # Group assignments by status
        pending_assignments = [a for a in assignments if a.status == ChoreStatus.PENDING]
        completed_assignments = [a for a in assignments if a.status == ChoreStatus.COMPLETED]

        # Statistics
        total_chores = len(assignments)
        completed_count = len(completed_assignments)
        completion_rate = (completed_count / total_chores * 100) if total_chores > 0 else 0

        with ui.card().classes("p-4 mb-6 bg-gradient-to-r from-blue-50 to-indigo-50"):
            with ui.row().classes("gap-8 items-center"):
                ui.label(f"📊 Progress: {completed_count}/{total_chores} completed").classes("text-lg font-semibold")
                ui.circular_progress(value=completion_rate / 100).classes("text-primary")
                ui.label(f"{completion_rate:.1f}%").classes("text-lg font-bold text-primary")

        # Pending assignments
        if pending_assignments:
            ui.label("⏳ Pending Chores").classes("text-xl font-semibold text-gray-700 mb-3")
            for assignment in pending_assignments:
                create_assignment_card(assignment, container)

        # Completed assignments
        if completed_assignments:
            ui.label("✅ Completed Chores").classes("text-xl font-semibold text-green-600 mb-3 mt-6")
            for assignment in completed_assignments:
                create_assignment_card(assignment, container)


def create_assignment_card(assignment: Assignment, container: ui.column):
    """Create a card for a single assignment"""
    is_completed = assignment.status == ChoreStatus.COMPLETED
    card_bg = "bg-green-50 border-green-200" if is_completed else "bg-white"

    with ui.card().classes(f"p-4 mb-3 {card_bg} shadow-md hover:shadow-lg transition-shadow"):
        with ui.row().classes("w-full justify-between items-start"):
            # Assignment info
            with ui.column().classes("flex-1"):
                with ui.row().classes("items-center gap-2 mb-2"):
                    status_icon = "✅" if is_completed else "⏳"
                    ui.label(f"{status_icon} {assignment.chore.name}").classes("text-lg font-semibold")

                ui.label(f"👤 Assigned to: {assignment.roommate.name}").classes("text-gray-600")

                if assignment.chore.description:
                    ui.label(f"📝 {assignment.chore.description}").classes("text-sm text-gray-500 mt-1")

                if assignment.chore.estimated_duration_minutes:
                    ui.label(f"⏱️ Est. {assignment.chore.estimated_duration_minutes} minutes").classes(
                        "text-sm text-gray-500"
                    )

                if assignment.completed_at:
                    completed_time = assignment.completed_at.strftime("%Y-%m-%d %H:%M")
                    ui.label(f"✅ Completed: {completed_time}").classes("text-sm text-green-600 font-medium")

                if assignment.notes:
                    ui.label(f"💭 Notes: {assignment.notes}").classes("text-sm text-gray-600 italic mt-1")

            # Action buttons
            with ui.column().classes("gap-2"):
                if is_completed:
                    ui.button(
                        "↩️ Mark Incomplete",
                        on_click=lambda aid=assignment.id: mark_incomplete_handler(aid, container),
                        color="warning",
                    ).classes("px-3 py-1").props("size=sm")
                else:
                    ui.button(
                        "✅ Complete",
                        on_click=lambda aid=assignment.id: show_complete_dialog(aid, container),
                        color="positive",
                    ).classes("px-3 py-1").props("size=sm")


def mark_incomplete_handler(assignment_id: int, container: ui.column):
    """Mark an assignment as incomplete"""
    try:
        success = AssignmentService.uncomplete_assignment(assignment_id)
        if success:
            ui.notify("✅ Chore marked as incomplete", type="positive")
            container.clear()
            display_assignments(container)
        else:
            ui.notify("❌ Failed to update chore status", type="negative")
    except Exception as e:
        ui.notify(f"❌ Error: {str(e)}", type="negative")


async def show_complete_dialog(assignment_id: int, container: ui.column):
    """Show dialog to complete an assignment with optional notes"""
    assignment = AssignmentService.get_assignment_by_id(assignment_id)
    if assignment is None:
        ui.notify("❌ Assignment not found", type="negative")
        return

    with ui.dialog() as dialog, ui.card().classes("w-96"):
        ui.label(f"Complete: {assignment.chore.name}").classes("text-lg font-bold mb-4")
        ui.label(f"Assigned to: {assignment.roommate.name}").classes("text-gray-600 mb-4")

        notes_input = (
            ui.textarea(label="Notes (optional)", placeholder="Add any notes about completing this chore...")
            .classes("w-full mb-4")
            .props("rows=3")
        )

        with ui.row().classes("gap-2 justify-end"):
            ui.button("❌ Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
            ui.button("✅ Complete Chore", on_click=lambda: dialog.submit("complete"), color="positive")

    result = await dialog

    if result == "complete":
        try:
            notes = notes_input.value.strip() if notes_input.value else None
            success = AssignmentService.complete_assignment(assignment_id, notes)
            if success:
                ui.notify("🎉 Chore completed!", type="positive")
                container.clear()
                display_assignments(container)
            else:
                ui.notify("❌ Failed to complete chore", type="negative")
        except Exception as e:
            ui.notify(f"❌ Error: {str(e)}", type="negative")
