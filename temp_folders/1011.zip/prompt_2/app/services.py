from datetime import datetime, date, timedelta
from typing import List, Optional
import random
from sqlmodel import select
from sqlalchemy.orm import selectinload
from app.database import get_session
from app.models import Roommate, Chore, Week, Assignment, ChoreStatus, RoommateCreate, ChoreCreate


class RoommateService:
    """Service for managing roommates"""

    @staticmethod
    def create_roommate(roommate_data: RoommateCreate) -> Roommate:
        with get_session() as session:
            roommate = Roommate(**roommate_data.model_dump())
            session.add(roommate)
            session.commit()
            session.refresh(roommate)
            return roommate

    @staticmethod
    def get_all_roommates() -> List[Roommate]:
        with get_session() as session:
            return list(session.exec(select(Roommate).where(Roommate.is_active == True)).all())  # noqa: E712

    @staticmethod
    def get_roommate_by_id(roommate_id: int) -> Optional[Roommate]:
        with get_session() as session:
            return session.get(Roommate, roommate_id)

    @staticmethod
    def delete_roommate(roommate_id: int) -> bool:
        with get_session() as session:
            roommate = session.get(Roommate, roommate_id)
            if roommate is None:
                return False
            roommate.is_active = False
            session.commit()
            return True


class ChoreService:
    """Service for managing chores"""

    @staticmethod
    def create_chore(chore_data: ChoreCreate) -> Chore:
        with get_session() as session:
            chore = Chore(**chore_data.model_dump())
            session.add(chore)
            session.commit()
            session.refresh(chore)
            return chore

    @staticmethod
    def get_all_chores() -> List[Chore]:
        with get_session() as session:
            return list(session.exec(select(Chore).where(Chore.is_active == True)).all())  # noqa: E712

    @staticmethod
    def get_chore_by_id(chore_id: int) -> Optional[Chore]:
        with get_session() as session:
            return session.get(Chore, chore_id)

    @staticmethod
    def delete_chore(chore_id: int) -> bool:
        with get_session() as session:
            chore = session.get(Chore, chore_id)
            if chore is None:
                return False
            chore.is_active = False
            session.commit()
            return True


class WeekService:
    """Service for managing weeks"""

    @staticmethod
    def get_current_week() -> Optional[Week]:
        with get_session() as session:
            return session.exec(select(Week).where(Week.is_current == True)).first()  # noqa: E712

    @staticmethod
    def create_current_week() -> Week:
        today = date.today()
        # Find the start of current week (Monday)
        days_since_monday = today.weekday()
        start_date = today - timedelta(days=days_since_monday)
        end_date = start_date + timedelta(days=6)

        with get_session() as session:
            # Mark any existing current week as not current
            existing_current = session.exec(select(Week).where(Week.is_current == True)).first()  # noqa: E712
            if existing_current:
                existing_current.is_current = False

            # Check if week already exists
            existing_week = session.exec(select(Week).where(Week.start_date == start_date)).first()
            if existing_week:
                existing_week.is_current = True
                session.commit()
                session.refresh(existing_week)
                return existing_week

            # Create new week
            new_week = Week(start_date=start_date, end_date=end_date, is_current=True)
            session.add(new_week)
            session.commit()
            session.refresh(new_week)
            return new_week

    @staticmethod
    def get_all_weeks() -> List[Week]:
        with get_session() as session:
            return list(session.exec(select(Week).order_by(Week.start_date.desc())).all())


class AssignmentService:
    """Service for managing chore assignments"""

    @staticmethod
    def get_current_week_assignments() -> List[Assignment]:
        current_week = WeekService.get_current_week()
        if current_week is None:
            return []

        with get_session() as session:
            return list(
                session.exec(
                    select(Assignment)
                    .options(selectinload(Assignment.roommate), selectinload(Assignment.chore))
                    .where(Assignment.week_id == current_week.id)
                    .order_by(Assignment.chore_id)
                ).all()
            )

    @staticmethod
    def assign_chores_for_current_week() -> List[Assignment]:
        """Randomly assign chores to roommates for the current week"""
        current_week = WeekService.get_current_week()
        if current_week is None:
            current_week = WeekService.create_current_week()

        # Get active roommates and chores
        roommates = RoommateService.get_all_roommates()
        chores = ChoreService.get_all_chores()

        if not roommates or not chores:
            return []

        with get_session() as session:
            # Clear existing assignments for this week
            existing_assignments = session.exec(select(Assignment).where(Assignment.week_id == current_week.id)).all()
            for assignment in existing_assignments:
                session.delete(assignment)

            # Create new random assignments
            assignments = []
            roommate_cycle = roommates.copy()
            random.shuffle(roommate_cycle)

            for i, chore in enumerate(chores):
                # Cycle through roommates to ensure fair distribution
                roommate = roommate_cycle[i % len(roommate_cycle)]

                assignment = Assignment(
                    roommate_id=roommate.id, chore_id=chore.id, week_id=current_week.id, status=ChoreStatus.PENDING
                )
                session.add(assignment)
                assignments.append(assignment)

            session.commit()

            # Refresh to get relationships
            for assignment in assignments:
                session.refresh(assignment)

            return assignments

    @staticmethod
    def complete_assignment(assignment_id: int, notes: Optional[str] = None) -> bool:
        with get_session() as session:
            assignment = session.get(Assignment, assignment_id)
            if assignment is None:
                return False

            assignment.status = ChoreStatus.COMPLETED
            assignment.completed_at = datetime.utcnow()
            if notes:
                assignment.notes = notes

            session.commit()
            return True

    @staticmethod
    def uncomplete_assignment(assignment_id: int) -> bool:
        with get_session() as session:
            assignment = session.get(Assignment, assignment_id)
            if assignment is None:
                return False

            assignment.status = ChoreStatus.PENDING
            assignment.completed_at = None

            session.commit()
            return True

    @staticmethod
    def get_assignment_by_id(assignment_id: int) -> Optional[Assignment]:
        with get_session() as session:
            result = session.exec(
                select(Assignment)
                .options(selectinload(Assignment.roommate), selectinload(Assignment.chore))
                .where(Assignment.id == assignment_id)
            ).first()
            return result
