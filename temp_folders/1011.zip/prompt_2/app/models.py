from sqlmodel import SQLModel, Field, Relationship
from datetime import datetime, date
from typing import Optional, List
from enum import Enum


class ChoreStatus(str, Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    OVERDUE = "overdue"


# Persistent models (stored in database)
class Roommate(SQLModel, table=True):
    __tablename__ = "roommates"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100)
    email: Optional[str] = Field(default=None, max_length=255)
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    assignments: List["Assignment"] = Relationship(back_populates="roommate")


class Chore(SQLModel, table=True):
    __tablename__ = "chores"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=200)
    description: Optional[str] = Field(default=None, max_length=1000)
    estimated_duration_minutes: Optional[int] = Field(default=None)
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    assignments: List["Assignment"] = Relationship(back_populates="chore")


class Week(SQLModel, table=True):
    __tablename__ = "weeks"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    start_date: date = Field(unique=True)
    end_date: date
    is_current: bool = Field(default=False)
    created_at: datetime = Field(default_factory=datetime.utcnow)

    # Relationships
    assignments: List["Assignment"] = Relationship(back_populates="week")


class Assignment(SQLModel, table=True):
    __tablename__ = "assignments"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    roommate_id: int = Field(foreign_key="roommates.id")
    chore_id: int = Field(foreign_key="chores.id")
    week_id: int = Field(foreign_key="weeks.id")
    status: ChoreStatus = Field(default=ChoreStatus.PENDING)
    assigned_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = Field(default=None)
    notes: Optional[str] = Field(default=None, max_length=500)

    # Relationships
    roommate: Roommate = Relationship(back_populates="assignments")
    chore: Chore = Relationship(back_populates="assignments")
    week: Week = Relationship(back_populates="assignments")


# Non-persistent schemas (for validation, forms, API requests/responses)
class RoommateCreate(SQLModel, table=False):
    name: str = Field(max_length=100)
    email: Optional[str] = Field(default=None, max_length=255)


class RoommateUpdate(SQLModel, table=False):
    name: Optional[str] = Field(default=None, max_length=100)
    email: Optional[str] = Field(default=None, max_length=255)
    is_active: Optional[bool] = Field(default=None)


class ChoreCreate(SQLModel, table=False):
    name: str = Field(max_length=200)
    description: Optional[str] = Field(default=None, max_length=1000)
    estimated_duration_minutes: Optional[int] = Field(default=None)


class ChoreUpdate(SQLModel, table=False):
    name: Optional[str] = Field(default=None, max_length=200)
    description: Optional[str] = Field(default=None, max_length=1000)
    estimated_duration_minutes: Optional[int] = Field(default=None)
    is_active: Optional[bool] = Field(default=None)


class WeekCreate(SQLModel, table=False):
    start_date: date
    end_date: date


class AssignmentCreate(SQLModel, table=False):
    roommate_id: int
    chore_id: int
    week_id: int


class AssignmentUpdate(SQLModel, table=False):
    status: Optional[ChoreStatus] = Field(default=None)
    completed_at: Optional[datetime] = Field(default=None)
    notes: Optional[str] = Field(default=None, max_length=500)


class AssignmentComplete(SQLModel, table=False):
    notes: Optional[str] = Field(default=None, max_length=500)
