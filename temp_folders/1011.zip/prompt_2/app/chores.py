from nicegui import ui
from app.services import ChoreService
from app.models import ChoreCreate


def create():
    @ui.page("/chores")
    def chores_page():
        ui.page_title("Manage Chores")

        # Header
        with ui.row().classes("w-full justify-between items-center mb-6"):
            ui.label("🧹 Manage Chores").classes("text-3xl font-bold text-gray-800")
            ui.button("← Back to Dashboard", on_click=lambda: ui.navigate.to("/")).classes("px-4 py-2")

        # Add chore form
        with ui.card().classes("p-6 mb-6 shadow-lg"):
            ui.label("⭐ Add New Chore").classes("text-xl font-semibold mb-4")

            with ui.column().classes("gap-4"):
                name_input = ui.input(label="Chore Name", placeholder="e.g., Take out trash, Clean bathroom").classes(
                    "w-full"
                )

                description_input = (
                    ui.textarea(
                        label="Description (optional)", placeholder="Add details about how to complete this chore..."
                    )
                    .classes("w-full")
                    .props("rows=3")
                )

                with ui.row().classes("gap-4 items-end"):
                    duration_input = ui.number(label="Estimated Duration (minutes)", placeholder="30").classes("flex-1")

                    ui.button(
                        "⭐ Add Chore",
                        on_click=lambda: add_chore_handler(name_input, description_input, duration_input),
                        color="primary",
                    ).classes("px-6 py-3")

        # Chores list container
        chores_container = ui.column().classes("w-full")

        def add_chore_handler(name_input: ui.input, description_input: ui.textarea, duration_input: ui.number):
            name = name_input.value.strip()
            description = description_input.value.strip() if description_input.value else None
            duration = int(duration_input.value) if duration_input.value else None

            if not name:
                ui.notify("❌ Chore name is required", type="negative")
                return

            try:
                chore_data = ChoreCreate(name=name, description=description, estimated_duration_minutes=duration)
                chore = ChoreService.create_chore(chore_data)
                ui.notify(f"✅ Added chore: {chore.name}", type="positive")
                name_input.set_value("")
                description_input.set_value("")
                duration_input.set_value(None)
                refresh_chores()
            except Exception as e:
                ui.notify(f"❌ Error adding chore: {str(e)}", type="negative")

        def refresh_chores():
            chores_container.clear()
            display_chores(chores_container)

        # Initial load
        refresh_chores()


def display_chores(container: ui.column):
    """Display all chores in the given container"""
    chores = ChoreService.get_all_chores()

    with container:
        ui.label("🧹 Current Chores").classes("text-2xl font-bold text-gray-800 mb-4")

        if not chores:
            with ui.card().classes("p-8 text-center bg-gray-50"):
                ui.label("📝 No chores defined yet").classes("text-xl text-gray-500 mb-2")
                ui.label("Add some chores to start assigning them to roommates!").classes("text-gray-400")
            return

        for chore in chores:
            create_chore_card(chore, container)


def create_chore_card(chore, container: ui.column):
    """Create a card for a single chore"""
    with ui.card().classes("p-4 mb-3 bg-white shadow-md hover:shadow-lg transition-shadow"):
        with ui.row().classes("w-full justify-between items-start"):
            # Chore info
            with ui.column().classes("flex-1"):
                ui.label(f"🧹 {chore.name}").classes("text-lg font-semibold")

                if chore.description:
                    ui.label(f"📝 {chore.description}").classes("text-gray-600 mt-1")

                info_items = []
                if chore.estimated_duration_minutes:
                    info_items.append(f"⏱️ {chore.estimated_duration_minutes} min")

                created_date = chore.created_at.strftime("%Y-%m-%d")
                info_items.append(f"📅 Added: {created_date}")

                ui.label(" • ".join(info_items)).classes("text-sm text-gray-500 mt-1")

            # Action buttons
            with ui.column().classes("gap-2"):
                ui.button(
                    "🗑️ Delete",
                    on_click=lambda cid=chore.id: show_delete_dialog(cid, chore.name, container),
                    color="negative",
                ).classes("px-3 py-1").props("size=sm outline")


async def show_delete_dialog(chore_id: int, chore_name: str, container: ui.column):
    """Show confirmation dialog before deleting a chore"""
    with ui.dialog() as dialog, ui.card().classes("w-96"):
        ui.label("⚠️ Delete Chore").classes("text-lg font-bold mb-4")
        ui.label(f'Are you sure you want to delete "{chore_name}"?').classes("text-gray-700 mb-2")
        ui.label("This will deactivate the chore but preserve its assignment history.").classes(
            "text-sm text-gray-500 mb-4"
        )

        with ui.row().classes("gap-2 justify-end"):
            ui.button("❌ Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
            ui.button("🗑️ Delete", on_click=lambda: dialog.submit("delete"), color="negative")

    result = await dialog

    if result == "delete":
        try:
            success = ChoreService.delete_chore(chore_id)
            if success:
                ui.notify(f"✅ Deleted chore: {chore_name}", type="positive")
                container.clear()
                display_chores(container)
            else:
                ui.notify("❌ Failed to delete chore", type="negative")
        except Exception as e:
            ui.notify(f"❌ Error: {str(e)}", type="negative")
