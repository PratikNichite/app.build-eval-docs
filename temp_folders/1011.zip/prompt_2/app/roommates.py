from nicegui import ui
from app.services import RoommateService
from app.models import RoommateCreate


def create():
    @ui.page("/roommates")
    def roommates_page():
        ui.page_title("Manage Roommates")

        # Header
        with ui.row().classes("w-full justify-between items-center mb-6"):
            ui.label("👥 Manage Roommates").classes("text-3xl font-bold text-gray-800")
            ui.button("← Back to Dashboard", on_click=lambda: ui.navigate.to("/")).classes("px-4 py-2")

        # Add roommate form
        with ui.card().classes("p-6 mb-6 shadow-lg"):
            ui.label("➕ Add New Roommate").classes("text-xl font-semibold mb-4")

            with ui.row().classes("gap-4 items-end"):
                name_input = ui.input(label="Name", placeholder="Enter roommate name").classes("flex-1")

                email_input = ui.input(label="Email (optional)", placeholder="Enter email address").classes("flex-1")

                ui.button(
                    "➕ Add Roommate", on_click=lambda: add_roommate_handler(name_input, email_input), color="primary"
                ).classes("px-6 py-3")

        # Roommates list container
        roommates_container = ui.column().classes("w-full")

        def add_roommate_handler(name_input: ui.input, email_input: ui.input):
            name = name_input.value.strip()
            email = email_input.value.strip() if email_input.value else None

            if not name:
                ui.notify("❌ Name is required", type="negative")
                return

            try:
                roommate_data = RoommateCreate(name=name, email=email)
                roommate = RoommateService.create_roommate(roommate_data)
                ui.notify(f"✅ Added roommate: {roommate.name}", type="positive")
                name_input.set_value("")
                email_input.set_value("")
                refresh_roommates()
            except Exception as e:
                ui.notify(f"❌ Error adding roommate: {str(e)}", type="negative")

        def refresh_roommates():
            roommates_container.clear()
            display_roommates(roommates_container)

        # Initial load
        refresh_roommates()


def display_roommates(container: ui.column):
    """Display all roommates in the given container"""
    roommates = RoommateService.get_all_roommates()

    with container:
        ui.label("👥 Current Roommates").classes("text-2xl font-bold text-gray-800 mb-4")

        if not roommates:
            with ui.card().classes("p-8 text-center bg-gray-50"):
                ui.label("👻 No roommates added yet").classes("text-xl text-gray-500 mb-2")
                ui.label("Add some roommates to get started with chore assignments!").classes("text-gray-400")
            return

        for roommate in roommates:
            create_roommate_card(roommate, container)


def create_roommate_card(roommate, container: ui.column):
    """Create a card for a single roommate"""
    with ui.card().classes("p-4 mb-3 bg-white shadow-md hover:shadow-lg transition-shadow"):
        with ui.row().classes("w-full justify-between items-center"):
            # Roommate info
            with ui.column().classes("flex-1"):
                ui.label(f"👤 {roommate.name}").classes("text-lg font-semibold")

                if roommate.email:
                    ui.label(f"📧 {roommate.email}").classes("text-gray-600")

                created_date = roommate.created_at.strftime("%Y-%m-%d")
                ui.label(f"📅 Added: {created_date}").classes("text-sm text-gray-500")

            # Action buttons
            with ui.row().classes("gap-2"):
                ui.button(
                    "🗑️ Delete",
                    on_click=lambda rid=roommate.id: show_delete_dialog(rid, roommate.name, container),
                    color="negative",
                ).classes("px-3 py-1").props("size=sm outline")


async def show_delete_dialog(roommate_id: int, roommate_name: str, container: ui.column):
    """Show confirmation dialog before deleting a roommate"""
    with ui.dialog() as dialog, ui.card().classes("w-96"):
        ui.label("⚠️ Delete Roommate").classes("text-lg font-bold mb-4")
        ui.label(f'Are you sure you want to delete "{roommate_name}"?').classes("text-gray-700 mb-2")
        ui.label("This will deactivate the roommate but preserve their assignment history.").classes(
            "text-sm text-gray-500 mb-4"
        )

        with ui.row().classes("gap-2 justify-end"):
            ui.button("❌ Cancel", on_click=lambda: dialog.submit("cancel")).props("outline")
            ui.button("🗑️ Delete", on_click=lambda: dialog.submit("delete"), color="negative")

    result = await dialog

    if result == "delete":
        try:
            success = RoommateService.delete_roommate(roommate_id)
            if success:
                ui.notify(f"✅ Deleted roommate: {roommate_name}", type="positive")
                container.clear()
                display_roommates(container)
            else:
                ui.notify("❌ Failed to delete roommate", type="negative")
        except Exception as e:
            ui.notify(f"❌ Error: {str(e)}", type="negative")
