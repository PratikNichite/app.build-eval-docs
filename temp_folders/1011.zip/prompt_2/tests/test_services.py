import pytest
from datetime import date, datetime, timedelta
from app.database import reset_db
from app.services import RoommateService, ChoreService, WeekService, AssignmentService
from app.models import RoommateCreate, ChoreCreate, ChoreStatus


@pytest.fixture()
def clean_db():
    reset_db()
    yield
    reset_db()


class TestRoommateService:
    def test_create_roommate(self, clean_db):
        roommate_data = RoommateCreate(name="Alice", email="alice@example.com")
        roommate = RoommateService.create_roommate(roommate_data)

        assert roommate.id is not None
        assert roommate.name == "Alice"
        assert roommate.email == "alice@example.com"
        assert roommate.is_active
        assert isinstance(roommate.created_at, datetime)

    def test_create_roommate_without_email(self, clean_db):
        roommate_data = RoommateCreate(name="Bob")
        roommate = RoommateService.create_roommate(roommate_data)

        assert roommate.name == "Bob"
        assert roommate.email is None

    def test_get_all_roommates(self, clean_db):
        # Create test roommates
        RoommateService.create_roommate(RoommateCreate(name="Alice"))
        RoommateService.create_roommate(RoommateCreate(name="Bob"))

        roommates = RoommateService.get_all_roommates()
        assert len(roommates) == 2
        names = [r.name for r in roommates]
        assert "Alice" in names
        assert "Bob" in names

    def test_get_roommate_by_id(self, clean_db):
        created = RoommateService.create_roommate(RoommateCreate(name="Alice"))

        roommate = RoommateService.get_roommate_by_id(created.id)
        assert roommate is not None
        assert roommate.name == "Alice"

        # Test non-existent ID
        non_existent = RoommateService.get_roommate_by_id(999)
        assert non_existent is None

    def test_delete_roommate(self, clean_db):
        created = RoommateService.create_roommate(RoommateCreate(name="Alice"))

        success = RoommateService.delete_roommate(created.id)
        assert success

        # Should not appear in active roommates
        active_roommates = RoommateService.get_all_roommates()
        assert len(active_roommates) == 0

        # But should still exist in database (soft delete)
        roommate = RoommateService.get_roommate_by_id(created.id)
        assert roommate is not None
        assert not roommate.is_active

    def test_delete_nonexistent_roommate(self, clean_db):
        success = RoommateService.delete_roommate(999)
        assert not success


class TestChoreService:
    def test_create_chore(self, clean_db):
        chore_data = ChoreCreate(
            name="Take out trash", description="Empty all wastebaskets", estimated_duration_minutes=15
        )
        chore = ChoreService.create_chore(chore_data)

        assert chore.id is not None
        assert chore.name == "Take out trash"
        assert chore.description == "Empty all wastebaskets"
        assert chore.estimated_duration_minutes == 15
        assert chore.is_active
        assert isinstance(chore.created_at, datetime)

    def test_create_minimal_chore(self, clean_db):
        chore_data = ChoreCreate(name="Clean bathroom")
        chore = ChoreService.create_chore(chore_data)

        assert chore.name == "Clean bathroom"
        assert chore.description is None
        assert chore.estimated_duration_minutes is None

    def test_get_all_chores(self, clean_db):
        ChoreService.create_chore(ChoreCreate(name="Dishes"))
        ChoreService.create_chore(ChoreCreate(name="Vacuuming"))

        chores = ChoreService.get_all_chores()
        assert len(chores) == 2
        names = [c.name for c in chores]
        assert "Dishes" in names
        assert "Vacuuming" in names

    def test_delete_chore(self, clean_db):
        created = ChoreService.create_chore(ChoreCreate(name="Dishes"))

        success = ChoreService.delete_chore(created.id)
        assert success

        # Should not appear in active chores
        active_chores = ChoreService.get_all_chores()
        assert len(active_chores) == 0

        # But should still exist in database (soft delete)
        chore = ChoreService.get_chore_by_id(created.id)
        assert chore is not None
        assert not chore.is_active


class TestWeekService:
    def test_create_current_week(self, clean_db):
        week = WeekService.create_current_week()

        assert week.id is not None
        assert week.is_current
        assert isinstance(week.start_date, date)
        assert isinstance(week.end_date, date)
        assert week.end_date == week.start_date + timedelta(days=6)

    def test_get_current_week(self, clean_db):
        # Initially no current week
        current = WeekService.get_current_week()
        assert current is None

        # Create current week
        created = WeekService.create_current_week()
        current = WeekService.get_current_week()
        assert current is not None
        assert current.id == created.id
        assert current.is_current

    def test_create_current_week_replaces_existing(self, clean_db):
        # Create first week
        first_week = WeekService.create_current_week()
        assert first_week.is_current

        # Create another current week should replace the first
        second_week = WeekService.create_current_week()
        assert second_week.is_current

        # First week should no longer be current
        updated_first = WeekService.get_current_week()
        assert updated_first.id == second_week.id


class TestAssignmentService:
    def test_assign_chores_for_current_week(self, clean_db):
        # Create test data
        roommate1 = RoommateService.create_roommate(RoommateCreate(name="Alice"))
        roommate2 = RoommateService.create_roommate(RoommateCreate(name="Bob"))
        chore1 = ChoreService.create_chore(ChoreCreate(name="Dishes"))
        chore2 = ChoreService.create_chore(ChoreCreate(name="Trash"))
        chore3 = ChoreService.create_chore(ChoreCreate(name="Bathroom"))

        assignments = AssignmentService.assign_chores_for_current_week()

        assert len(assignments) == 3
        for assignment in assignments:
            assert assignment.status == ChoreStatus.PENDING
            assert assignment.roommate_id in [roommate1.id, roommate2.id]
            assert assignment.chore_id in [chore1.id, chore2.id, chore3.id]
            assert assignment.week_id is not None

    def test_assign_chores_no_roommates(self, clean_db):
        ChoreService.create_chore(ChoreCreate(name="Dishes"))

        assignments = AssignmentService.assign_chores_for_current_week()
        assert len(assignments) == 0

    def test_assign_chores_no_chores(self, clean_db):
        RoommateService.create_roommate(RoommateCreate(name="Alice"))

        assignments = AssignmentService.assign_chores_for_current_week()
        assert len(assignments) == 0

    def test_reassign_clears_existing(self, clean_db):
        # Create test data
        RoommateService.create_roommate(RoommateCreate(name="Alice"))
        ChoreService.create_chore(ChoreCreate(name="Dishes"))

        # First assignment
        first_assignments = AssignmentService.assign_chores_for_current_week()
        assert len(first_assignments) == 1

        # Second assignment should clear first
        second_assignments = AssignmentService.assign_chores_for_current_week()
        assert len(second_assignments) == 1

        # Should only have current assignments
        current_assignments = AssignmentService.get_current_week_assignments()
        assert len(current_assignments) == 1

    def test_complete_assignment(self, clean_db):
        # Create test data and assignment
        RoommateService.create_roommate(RoommateCreate(name="Alice"))
        ChoreService.create_chore(ChoreCreate(name="Dishes"))
        assignments = AssignmentService.assign_chores_for_current_week()
        assignment_id = assignments[0].id

        # Complete assignment
        success = AssignmentService.complete_assignment(assignment_id, "All done!")
        assert success

        # Verify completion
        assignment = AssignmentService.get_assignment_by_id(assignment_id)
        assert assignment is not None
        assert assignment.status == ChoreStatus.COMPLETED
        assert assignment.completed_at is not None
        assert assignment.notes == "All done!"

    def test_complete_assignment_without_notes(self, clean_db):
        RoommateService.create_roommate(RoommateCreate(name="Alice"))
        ChoreService.create_chore(ChoreCreate(name="Dishes"))
        assignments = AssignmentService.assign_chores_for_current_week()
        assignment_id = assignments[0].id

        success = AssignmentService.complete_assignment(assignment_id)
        assert success

        assignment = AssignmentService.get_assignment_by_id(assignment_id)
        assert assignment.status == ChoreStatus.COMPLETED
        assert assignment.notes is None

    def test_complete_nonexistent_assignment(self, clean_db):
        success = AssignmentService.complete_assignment(999)
        assert not success

    def test_uncomplete_assignment(self, clean_db):
        # Create and complete assignment
        RoommateService.create_roommate(RoommateCreate(name="Alice"))
        ChoreService.create_chore(ChoreCreate(name="Dishes"))
        assignments = AssignmentService.assign_chores_for_current_week()
        assignment_id = assignments[0].id

        AssignmentService.complete_assignment(assignment_id, "Done")

        # Uncomplete it
        success = AssignmentService.uncomplete_assignment(assignment_id)
        assert success

        # Verify it's pending again
        assignment = AssignmentService.get_assignment_by_id(assignment_id)
        assert assignment.status == ChoreStatus.PENDING
        assert assignment.completed_at is None

    def test_get_current_week_assignments_empty(self, clean_db):
        assignments = AssignmentService.get_current_week_assignments()
        assert len(assignments) == 0

    def test_fair_distribution(self, clean_db):
        """Test that chores are distributed fairly among roommates"""
        # Create 2 roommates and 6 chores
        RoommateService.create_roommate(RoommateCreate(name="Alice"))
        RoommateService.create_roommate(RoommateCreate(name="Bob"))

        for i in range(6):
            ChoreService.create_chore(ChoreCreate(name=f"Chore {i + 1}"))

        assignments = AssignmentService.assign_chores_for_current_week()

        # Count assignments per roommate
        roommate_counts = {}
        for assignment in assignments:
            roommate_id = assignment.roommate_id
            roommate_counts[roommate_id] = roommate_counts.get(roommate_id, 0) + 1

        # Each roommate should get 3 chores
        assert len(roommate_counts) == 2
        for count in roommate_counts.values():
            assert count == 3
