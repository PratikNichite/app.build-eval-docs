import pytest
from nicegui.testing import User
from nicegui import ui
from app.database import reset_db
from app.services import ChoreService
from app.models import ChoreCreate


@pytest.fixture()
def clean_db():
    reset_db()
    yield
    reset_db()


async def test_chores_page_empty_state(user: User, clean_db) -> None:
    """Test chores page shows empty state when no chores exist"""
    await user.open("/chores")

    await user.should_see("Manage Chores")
    await user.should_see("No chores defined yet")
    await user.should_see("Add some chores to start assigning them")


async def test_add_chore_full_form(user: User, clean_db) -> None:
    """Test adding a chore with all fields filled"""
    await user.open("/chores")

    # Fill in the form
    user.find("Chore Name").type("Take out trash")
    description_input = list(user.find(ui.textarea).elements)[0]
    description_input.set_value("Empty all wastebaskets and take bags to curb")

    # Set duration - need to handle number input carefully
    number_elements = list(user.find(ui.number).elements)
    if number_elements:
        number_elements[0].set_value(15)

    # Submit the form
    user.find("⭐ Add Chore").click()

    # Should show success notification
    await user.should_see("Added chore: Take out trash")

    # Should display the new chore
    await user.should_see("Current Chores")
    await user.should_see("Take out trash")
    await user.should_see("Empty all wastebaskets and take bags to curb")
    await user.should_see("15 min")


async def test_add_chore_minimal(user: User, clean_db) -> None:
    """Test adding a chore with just the name"""
    await user.open("/chores")

    user.find("Chore Name").type("Clean bathroom")
    user.find("⭐ Add Chore").click()

    await user.should_see("Added chore: Clean bathroom")
    await user.should_see("Clean bathroom")


async def test_add_chore_empty_name(user: User, clean_db) -> None:
    """Test validation when chore name is empty"""
    await user.open("/chores")

    # Try to submit without name
    user.find("⭐ Add Chore").click()

    # Should show error notification
    await user.should_see("Chore name is required")

    # Should not create any chore
    await user.should_see("No chores defined yet")


async def test_display_existing_chores(user: User, clean_db) -> None:
    """Test displaying existing chores"""
    # Create test chores
    ChoreService.create_chore(
        ChoreCreate(name="Take out trash", description="Empty all bins", estimated_duration_minutes=15)
    )
    ChoreService.create_chore(ChoreCreate(name="Vacuum living room"))

    await user.open("/chores")

    # Should display both chores
    await user.should_see("Current Chores")
    await user.should_see("Take out trash")
    await user.should_see("Empty all bins")
    await user.should_see("15 min")
    await user.should_see("Vacuum living room")

    # Should show added dates
    await user.should_see("Added:")


async def test_delete_chore_confirmation(user: User, clean_db) -> None:
    """Test chore deletion with confirmation dialog"""
    # Create test chore
    ChoreService.create_chore(ChoreCreate(name="Take out trash"))

    await user.open("/chores")

    # Click delete button
    user.find("🗑️ Delete").click()

    # Should show confirmation dialog
    await user.should_see("Delete Chore")
    await user.should_see('Are you sure you want to delete "Take out trash"?')
    await user.should_see("This will deactivate the chore")

    # Cancel deletion
    user.find("❌ Cancel").click()

    # Chore should still be there
    await user.should_see("Take out trash")


async def test_delete_chore_confirm(user: User, clean_db) -> None:
    """Test actually deleting a chore"""
    # Create test chore
    ChoreService.create_chore(ChoreCreate(name="Take out trash"))

    await user.open("/chores")

    # Verify chore is initially there
    await user.should_see("Take out trash")

    # Delete the chore - first click opens dialog
    user.find("🗑️ Delete").click()

    # Should show confirmation dialog
    await user.should_see("Delete Chore")

    # Second click confirms deletion
    user.find("🗑️ Delete").click()

    # Wait a moment for the UI to update
    import asyncio

    await asyncio.sleep(0.1)

    # Should show empty state again
    await user.should_see("No chores defined yet")


async def test_navigation_back_to_dashboard(user: User, clean_db) -> None:
    """Test navigation back to dashboard"""
    await user.open("/chores")

    user.find("Back to Dashboard").click()

    # Should navigate to dashboard
    await user.should_see("🏠⚙️ Roommate Chore Wheel")


async def test_form_reset_after_submission(user: User, clean_db) -> None:
    """Test that form fields are cleared after successful submission"""
    await user.open("/chores")

    # Fill and submit form
    user.find("Chore Name").type("Test Chore")
    description_input = list(user.find(ui.textarea).elements)[0]
    description_input.set_value("Test description")

    user.find("⭐ Add Chore").click()

    # Form should be cleared
    name_input = list(user.find(ui.input).elements)[0]  # First input is chore name
    description_textarea = list(user.find(ui.textarea).elements)[0]

    assert name_input.value == ""
    assert description_textarea.value == ""


async def test_multiple_chores_display(user: User, clean_db) -> None:
    """Test displaying multiple chores with different configurations"""
    # Create chores with different data
    ChoreService.create_chore(
        ChoreCreate(name="Take out trash", description="Empty all wastebaskets", estimated_duration_minutes=15)
    )
    ChoreService.create_chore(ChoreCreate(name="Vacuum"))
    ChoreService.create_chore(ChoreCreate(name="Clean bathroom", estimated_duration_minutes=30))

    await user.open("/chores")

    # Should show all chores
    chore_names = ["Take out trash", "Vacuum", "Clean bathroom"]
    for name in chore_names:
        await user.should_see(name)

    # Should show descriptions and durations where present
    await user.should_see("Empty all wastebaskets")
    await user.should_see("15 min")
    await user.should_see("30 min")

    # Should have multiple delete buttons
    delete_buttons = list(user.find(ui.button).elements)
    delete_button_count = sum(1 for btn in delete_buttons if "🗑️ Delete" in str(btn.text))
    assert delete_button_count == 3


async def test_chore_card_layout(user: User, clean_db) -> None:
    """Test that chore cards display all information properly"""
    # Create a chore with all fields
    ChoreService.create_chore(
        ChoreCreate(
            name="Deep clean kitchen",
            description="Clean all surfaces, appliances, and floors thoroughly",
            estimated_duration_minutes=45,
        )
    )

    await user.open("/chores")

    # Should display all chore information
    await user.should_see("Deep clean kitchen")
    await user.should_see("Clean all surfaces, appliances, and floors thoroughly")
    await user.should_see("45 min")
    await user.should_see("Added:")

    # Should have delete button
    await user.should_see("🗑️ Delete")
