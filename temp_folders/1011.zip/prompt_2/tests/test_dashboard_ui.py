import pytest
from nicegui.testing import User
from nicegui import ui
from app.database import reset_db
from app.services import RoommateService, ChoreService, AssignmentService
from app.models import RoommateCreate, ChoreCreate


@pytest.fixture()
def clean_db():
    reset_db()
    yield
    reset_db()


async def test_dashboard_empty_state(user: User, clean_db) -> None:
    """Test dashboard shows empty state when no assignments exist"""
    await user.open("/")

    # Should show empty state message
    await user.should_see("No chores assigned yet")
    await user.should_see('Click "🪄 Assign Chores for This Week" to get started!')


async def test_dashboard_assign_chores_no_data(user: User, clean_db) -> None:
    """Test assigning chores when no roommates or chores exist"""
    await user.open("/")

    # Click assign button
    user.find("🪄 Assign Chores for This Week").click()

    # Should show warning notification
    await user.should_see("No roommates or chores available to assign")


async def test_dashboard_assign_chores_success(user: User, clean_db) -> None:
    """Test successful chore assignment workflow"""
    # Create test data
    RoommateService.create_roommate(RoommateCreate(name="Alice"))
    RoommateService.create_roommate(RoommateCreate(name="Bob"))
    ChoreService.create_chore(ChoreCreate(name="Take out trash"))
    ChoreService.create_chore(ChoreCreate(name="Clean bathroom"))

    await user.open("/")

    # Click assign button
    user.find("🪄 Assign Chores for This Week").click()

    # Wait a moment for assignments to load
    import asyncio

    await asyncio.sleep(0.1)

    # Should show assignments section
    await user.should_see("This Week's Assignments")
    await user.should_see("Take out trash")
    await user.should_see("Clean bathroom")
    await user.should_see("Alice")
    await user.should_see("Bob")


async def test_dashboard_complete_chore(user: User, clean_db) -> None:
    """Test completing a chore through the UI"""
    # Create test data and assignments
    RoommateService.create_roommate(RoommateCreate(name="Alice"))
    ChoreService.create_chore(ChoreCreate(name="Take out trash"))
    AssignmentService.assign_chores_for_current_week()

    await user.open("/")

    # Click complete button
    user.find("✅ Complete").click()

    # Should open completion dialog
    await user.should_see("Complete: Take out trash")
    await user.should_see("Assigned to: Alice")

    # Add notes and complete
    notes_input = list(user.find(ui.textarea).elements)[0]
    notes_input.set_value("All bins emptied")

    user.find("✅ Complete Chore").click()

    # Should show success notification
    await user.should_see("Chore completed!")

    # Should show in completed section
    await user.should_see("Completed Chores")
    await user.should_see("Notes: All bins emptied")


async def test_dashboard_mark_incomplete(user: User, clean_db) -> None:
    """Test marking a completed chore as incomplete"""
    # Create test data and complete a chore
    RoommateService.create_roommate(RoommateCreate(name="Alice"))
    ChoreService.create_chore(ChoreCreate(name="Take out trash"))
    assignments = AssignmentService.assign_chores_for_current_week()
    AssignmentService.complete_assignment(assignments[0].id, "Done")

    await user.open("/")

    # Should show completed chore
    await user.should_see("Completed Chores")

    # Click mark incomplete
    user.find("↩️ Mark Incomplete").click()

    # Should show success notification
    await user.should_see("Chore marked as incomplete")

    # Should be back in pending section
    await user.should_see("Pending Chores")


async def test_dashboard_navigation(user: User, clean_db) -> None:
    """Test navigation to other pages"""
    await user.open("/")

    # Test navigation to roommates page
    user.find("👥 Manage Roommates").click()
    await user.should_see("Manage Roommates")

    # Navigate back to dashboard
    await user.open("/")

    # Test navigation to chores page
    user.find("🧹 Manage Chores").click()
    await user.should_see("Manage Chores")


async def test_dashboard_progress_tracking(user: User, clean_db) -> None:
    """Test progress tracking display"""
    # Create test data with multiple chores
    RoommateService.create_roommate(RoommateCreate(name="Alice"))
    ChoreService.create_chore(ChoreCreate(name="Dishes"))
    ChoreService.create_chore(ChoreCreate(name="Trash"))
    ChoreService.create_chore(ChoreCreate(name="Bathroom"))

    assignments = AssignmentService.assign_chores_for_current_week()

    # Complete one chore
    AssignmentService.complete_assignment(assignments[0].id)

    await user.open("/")

    # Should show progress
    await user.should_see("Progress: 1/3 completed")
    await user.should_see("33.3%")

    # Should have circular progress indicator
    progress_elements = list(user.find(ui.circular_progress).elements)
    assert len(progress_elements) == 1
