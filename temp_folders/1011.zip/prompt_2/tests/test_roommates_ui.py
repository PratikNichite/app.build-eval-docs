import pytest
from nicegui.testing import User
from nicegui import ui
from app.database import reset_db
from app.services import RoommateService
from app.models import RoommateCreate


@pytest.fixture()
def clean_db():
    reset_db()
    yield
    reset_db()


async def test_roommates_page_empty_state(user: User, clean_db) -> None:
    """Test roommates page shows empty state when no roommates exist"""
    await user.open("/roommates")

    await user.should_see("Manage Roommates")
    await user.should_see("No roommates added yet")
    await user.should_see("Add some roommates to get started")


async def test_add_roommate_success(user: User, clean_db) -> None:
    """Test successfully adding a new roommate"""
    await user.open("/roommates")

    # Fill in the form
    user.find("Name").type("Alice Johnson")
    user.find("Email (optional)").type("alice@example.com")

    # Submit the form
    user.find("➕ Add Roommate").click()

    # Should show success notification
    await user.should_see("Added roommate: Alice Johnson")

    # Should display the new roommate
    await user.should_see("Current Roommates")
    await user.should_see("Alice Johnson")
    await user.should_see("alice@example.com")

    # Form should be cleared
    name_input = list(user.find(ui.input).elements)[0]
    email_input = list(user.find(ui.input).elements)[1]
    assert name_input.value == ""
    assert email_input.value == ""


async def test_add_roommate_without_email(user: User, clean_db) -> None:
    """Test adding a roommate without email"""
    await user.open("/roommates")

    user.find("Name").type("Bob Smith")
    user.find("➕ Add Roommate").click()

    await user.should_see("Added roommate: Bob Smith")
    await user.should_see("Bob Smith")
    # Should not show email section for this roommate
    await user.should_not_see("bob@")


async def test_add_roommate_empty_name(user: User, clean_db) -> None:
    """Test validation when name is empty"""
    await user.open("/roommates")

    # Try to submit without name
    user.find("➕ Add Roommate").click()

    # Should show error notification
    await user.should_see("Name is required")

    # Should not create any roommate
    await user.should_see("No roommates added yet")


async def test_display_existing_roommates(user: User, clean_db) -> None:
    """Test displaying existing roommates"""
    # Create test roommates
    RoommateService.create_roommate(RoommateCreate(name="Alice", email="alice@example.com"))
    RoommateService.create_roommate(RoommateCreate(name="Bob"))

    await user.open("/roommates")

    # Should display both roommates
    await user.should_see("Current Roommates")
    await user.should_see("Alice")
    await user.should_see("alice@example.com")
    await user.should_see("Bob")

    # Should show added dates
    await user.should_see("Added:")


async def test_delete_roommate_confirmation(user: User, clean_db) -> None:
    """Test roommate deletion with confirmation dialog"""
    # Create test roommate
    RoommateService.create_roommate(RoommateCreate(name="Alice"))

    await user.open("/roommates")

    # Click delete button
    user.find("🗑️ Delete").click()

    # Should show confirmation dialog
    await user.should_see("Delete Roommate")
    await user.should_see('Are you sure you want to delete "Alice"?')
    await user.should_see("This will deactivate the roommate")

    # Cancel deletion
    user.find("❌ Cancel").click()

    # Roommate should still be there
    await user.should_see("Alice")


async def test_delete_roommate_confirm(user: User, clean_db) -> None:
    """Test actually deleting a roommate"""
    # Create test roommate
    RoommateService.create_roommate(RoommateCreate(name="Alice"))

    await user.open("/roommates")

    # Verify roommate is initially there
    await user.should_see("Alice")

    # Delete the roommate - first click opens dialog
    user.find("🗑️ Delete").click()

    # Should show confirmation dialog
    await user.should_see("Delete Roommate")

    # Second click confirms deletion
    user.find("🗑️ Delete").click()

    # Wait a moment for the UI to update
    import asyncio

    await asyncio.sleep(0.1)

    # Should show empty state again
    await user.should_see("No roommates added yet")


async def test_navigation_back_to_dashboard(user: User, clean_db) -> None:
    """Test navigation back to dashboard"""
    await user.open("/roommates")

    user.find("Back to Dashboard").click()

    # Should navigate to dashboard
    await user.should_see("🏠⚙️ Roommate Chore Wheel")
    await user.should_see("No chores assigned yet")


async def test_multiple_roommates_display(user: User, clean_db) -> None:
    """Test displaying multiple roommates with different data"""

    # Create roommates with different data
    RoommateService.create_roommate(RoommateCreate(name="Alice Johnson", email="alice@example.com"))
    RoommateService.create_roommate(RoommateCreate(name="Bob Smith"))
    RoommateService.create_roommate(RoommateCreate(name="Carol Davis", email="carol@example.com"))

    await user.open("/roommates")

    # Should show all roommates
    roommate_names = ["Alice Johnson", "Bob Smith", "Carol Davis"]
    for name in roommate_names:
        await user.should_see(name)

    # Should show emails where present
    await user.should_see("alice@example.com")
    await user.should_see("carol@example.com")

    # Should have multiple delete buttons
    delete_buttons = list(user.find(ui.button).elements)
    delete_button_count = sum(1 for btn in delete_buttons if "🗑️ Delete" in str(btn.text))
    assert delete_button_count == 3
