from sqlmodel import SQLModel, Field, Relationship
from datetime import datetime, date
from typing import Optional, List
from decimal import Decimal


# Persistent models (stored in database)
class User(SQLModel, table=True):
    __tablename__ = "users"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=100)
    email: str = Field(unique=True, max_length=255)
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)

    wellness_records: List["WellnessRecord"] = Relationship(back_populates="user")


class WellnessRecord(SQLModel, table=True):
    __tablename__ = "wellness_records"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="users.id")
    record_date: date = Field(description="Date of the wellness record")

    # Sleep tracking
    sleep_hours: Decimal = Field(
        ge=Decimal("0"), le=Decimal("24"), decimal_places=1, description="Hours of sleep (0-24)"
    )

    # Stress level (1-10 scale)
    stress_level: int = Field(ge=1, le=10, description="Stress level on a scale of 1-10")

    # Caffeine intake
    caffeine_intake: int = Field(ge=0, description="Number of caffeinated drinks consumed")

    # Alcohol intake
    alcohol_intake: int = Field(ge=0, description="Number of alcoholic drinks consumed")

    # Calculated wellness score
    wellness_score: Optional[Decimal] = Field(
        default=None, decimal_places=1, description="Calculated daily wellness score (0-100)"
    )

    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    user: User = Relationship(back_populates="wellness_records")

    def __init__(self, **data):
        super().__init__(**data)
        if self.wellness_score is None:
            self.wellness_score = self.calculate_wellness_score()

    def calculate_wellness_score(self) -> Decimal:
        """
        Calculate wellness score based on inputs (0-100 scale).

        Scoring logic:
        - Sleep: Optimal 7-9 hours = 30 points, penalty for too little/much
        - Stress: Lower stress = higher score (inverse scale)
        - Caffeine: Moderate intake acceptable, penalty for excess
        - Alcohol: Lower intake = higher score
        """
        score = Decimal("0")

        # Sleep score (max 30 points)
        sleep_float = float(self.sleep_hours)
        if 7 <= sleep_float <= 9:
            sleep_score = 30
        elif 6 <= sleep_float < 7 or 9 < sleep_float <= 10:
            sleep_score = 25
        elif 5 <= sleep_float < 6 or 10 < sleep_float <= 11:
            sleep_score = 20
        elif 4 <= sleep_float < 5 or 11 < sleep_float <= 12:
            sleep_score = 10
        else:
            sleep_score = 5

        score += Decimal(str(sleep_score))

        # Stress score (max 30 points, inverse of stress level)
        stress_score = 30 - ((self.stress_level - 1) * 3)  # Scale 1-10 to 30-3
        score += Decimal(str(max(3, stress_score)))

        # Caffeine score (max 20 points)
        if self.caffeine_intake <= 2:
            caffeine_score = 20
        elif self.caffeine_intake <= 4:
            caffeine_score = 15
        elif self.caffeine_intake <= 6:
            caffeine_score = 10
        else:
            caffeine_score = 5

        score += Decimal(str(caffeine_score))

        # Alcohol score (max 20 points)
        if self.alcohol_intake == 0:
            alcohol_score = 20
        elif self.alcohol_intake <= 1:
            alcohol_score = 15
        elif self.alcohol_intake <= 2:
            alcohol_score = 10
        else:
            alcohol_score = 5

        score += Decimal(str(alcohol_score))

        return min(score, Decimal("100"))  # Cap at 100


# Non-persistent schemas (for validation, forms, API requests/responses)
class UserCreate(SQLModel, table=False):
    name: str = Field(max_length=100)
    email: str = Field(max_length=255)


class UserUpdate(SQLModel, table=False):
    name: Optional[str] = Field(default=None, max_length=100)
    email: Optional[str] = Field(default=None, max_length=255)
    is_active: Optional[bool] = Field(default=None)


class WellnessRecordCreate(SQLModel, table=False):
    user_id: int
    record_date: date
    sleep_hours: Decimal = Field(ge=Decimal("0"), le=Decimal("24"), decimal_places=1)
    stress_level: int = Field(ge=1, le=10)
    caffeine_intake: int = Field(ge=0)
    alcohol_intake: int = Field(ge=0)


class WellnessRecordUpdate(SQLModel, table=False):
    sleep_hours: Optional[Decimal] = Field(default=None, ge=Decimal("0"), le=Decimal("24"), decimal_places=1)
    stress_level: Optional[int] = Field(default=None, ge=1, le=10)
    caffeine_intake: Optional[int] = Field(default=None, ge=0)
    alcohol_intake: Optional[int] = Field(default=None, ge=0)


class WellnessRecordResponse(SQLModel, table=False):
    id: int
    user_id: int
    record_date: date
    sleep_hours: Decimal
    stress_level: int
    caffeine_intake: int
    alcohol_intake: int
    wellness_score: Decimal
    created_at: datetime
    updated_at: datetime

    @classmethod
    def from_record(cls, record: WellnessRecord) -> "WellnessRecordResponse":
        return cls(
            id=record.id or 0,
            user_id=record.user_id,
            record_date=record.record_date,
            sleep_hours=record.sleep_hours,
            stress_level=record.stress_level,
            caffeine_intake=record.caffeine_intake,
            alcohol_intake=record.alcohol_intake,
            wellness_score=record.wellness_score or Decimal("0"),
            created_at=record.created_at,
            updated_at=record.updated_at,
        )


class UserWithWellnessStats(SQLModel, table=False):
    id: int
    name: str
    email: str
    is_active: bool
    total_records: int
    avg_wellness_score: Optional[Decimal]
    latest_record_date: Optional[date]
    created_at: datetime
