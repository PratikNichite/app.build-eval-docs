from typing import Tuple
import random


class MotivationalMessages:
    """Service for generating motivational and encouraging messages based on wellness scores."""

    # Score-based messages (score, message, emoji)
    SCORE_MESSAGES = [
        # Excellent range (90-100)
        (90, "🌟 Outstanding! You're a wellness superstar!", "🚀"),
        (90, "💎 Absolutely brilliant! Keep shining bright!", "✨"),
        (90, "🏆 Perfect wellness warrior! You're crushing it!", "💪"),
        (90, "🎉 Phenomenal! Your dedication is paying off big time!", "🌈"),
        (90, "⭐ Incredible! You're setting the gold standard!", "👑"),
        # Great range (80-89)
        (80, "🔥 Amazing work! You're on fire with your wellness!", "💯"),
        (80, "🌸 Fantastic! Your healthy habits are blooming!", "🦋"),
        (80, "🎯 Excellent job! You're hitting all the right notes!", "🎵"),
        (80, "🌺 Beautiful consistency! Keep up the great work!", "☀️"),
        (80, "💫 Stellar performance! You're a wellness champion!", "🏅"),
        # Good range (70-79)
        (70, "🌱 Great progress! You're growing stronger every day!", "🌿"),
        (70, "🎈 Nice work! Your wellness journey is taking off!", "🚁"),
        (70, "🌊 Solid foundation! Ride the wave of good health!", "🏄‍♀️"),
        (70, "🎪 Well done! You're balancing life beautifully!", "⚖️"),
        (70, "🎨 Creative wellness approach! You're painting success!", "🖌️"),
        # Fair range (60-69)
        (60, "🌤️ Good start! Brighter days are ahead!", "🌅"),
        (60, "🌻 Nice effort! Small steps lead to big changes!", "👣"),
        (60, "🎵 You're finding your rhythm! Keep the beat going!", "🥁"),
        (60, "🌸 Blooming progress! Every day counts!", "📅"),
        (60, "🚂 All aboard the wellness train! Choo choo!", "🎫"),
        # Below average range (50-59)
        (50, "🌱 Every seed needs time to grow! You've got this!", "💚"),
        (50, "🌈 After every storm comes a rainbow! Keep going!", "⛅"),
        (50, "🎪 Life's a balancing act - you're learning the ropes!", "🎭"),
        (50, "🌊 Riding the waves of wellness! Surf's up!", "🏄‍♂️"),
        (50, "🎯 Practice makes progress! You're aiming true!", "🏹"),
        # Needs improvement range (0-49)
        (0, "🌱 New beginnings start today! You're planting seeds!", "🌰"),
        (0, "🌅 Every sunrise brings new possibilities! Rise up!", "🦅"),
        (0, "🎨 You're the artist of your wellness story! Paint it bright!", "🖼️"),
        (0, "🚀 Ready for launch? Your wellness journey starts now!", "🌌"),
        (0, "💎 Diamonds are made under pressure! You're precious!", "⚡"),
    ]

    # General encouraging messages for various UI elements
    GENERAL_MESSAGES = [
        ("🌟 Today is a new chance to shine!", "✨"),
        ("💪 You're stronger than you think!", "🦾"),
        ("🌸 Bloom where you are planted!", "🌺"),
        ("🚀 Progress, not perfection!", "📈"),
        ("💖 Self-care isn't selfish - it's essential!", "🫶"),
        ("🌊 Go with the flow of healthy habits!", "🌿"),
        ("🎯 Focus on the journey, not just the destination!", "🗺️"),
        ("⭐ You deserve to feel amazing!", "💫"),
        ("🌱 Growth happens one day at a time!", "🌳"),
        ("🎉 Celebrate every small victory!", "🏆"),
    ]

    # Sleep-specific messages
    SLEEP_MESSAGES = [
        ("😴 Sweet dreams lead to sweet days!", "🌙"),
        ("💤 Quality sleep = quality life!", "⭐"),
        ("🛌 Rest is not a reward - it's a requirement!", "💚"),
        ("🌟 Sleep is your superpower! Use it wisely!", "🦸‍♀️"),
        ("😴 Recharge your body, refresh your mind!", "🔋"),
    ]

    # Stress-related messages
    STRESS_MESSAGES = [
        ("🧘‍♀️ Breathe in calm, breathe out chaos!", "🌬️"),
        ("🌸 Stay calm and wellness on!", "☮️"),
        ("💆‍♀️ Stress less, live more!", "🌺"),
        ("🧘‍♂️ Find your inner peace, one breath at a time!", "🕯️"),
        ("🌊 Let stress flow away like water!", "🌊"),
    ]

    # Achievement messages for milestones
    MILESTONE_MESSAGES = [
        ("🎊 First entry! Welcome to your wellness journey!", "🚀"),
        ("🔥 7-day streak! You're on fire!", "📅"),
        ("💎 30 days strong! You're a wellness diamond!", "💪"),
        ("👑 Wellness royalty! 60+ days of dedication!", "🏰"),
        ("🌟 Legend status! 100+ days of amazing commitment!", "🏆"),
    ]

    @staticmethod
    def get_score_message(score: float) -> Tuple[str, str]:
        """Get a motivational message based on wellness score."""
        # Filter messages by score range
        applicable_messages = [
            (msg, emoji) for threshold, msg, emoji in MotivationalMessages.SCORE_MESSAGES if score >= threshold
        ]

        if not applicable_messages:
            # Fallback for very low scores
            return ("🌱 Every journey starts with a single step! You've got this!", "💚")

        return random.choice(applicable_messages)

    @staticmethod
    def get_general_message() -> Tuple[str, str]:
        """Get a random general motivational message."""
        return random.choice(MotivationalMessages.GENERAL_MESSAGES)

    @staticmethod
    def get_sleep_message() -> Tuple[str, str]:
        """Get a sleep-related motivational message."""
        return random.choice(MotivationalMessages.SLEEP_MESSAGES)

    @staticmethod
    def get_stress_message() -> Tuple[str, str]:
        """Get a stress-related motivational message."""
        return random.choice(MotivationalMessages.STRESS_MESSAGES)

    @staticmethod
    def get_milestone_message(total_records: int) -> Tuple[str, str] | None:
        """Get a milestone message based on the number of records."""
        if total_records == 1:
            return ("🎊 First entry! Welcome to your wellness journey!", "🚀")
        elif total_records == 7:
            return ("🔥 7-day streak! You're on fire!", "📅")
        elif total_records == 30:
            return ("💎 30 days strong! You're a wellness diamond!", "💪")
        elif total_records == 60:
            return ("👑 Wellness royalty! 60+ days of dedication!", "🏰")
        elif total_records == 100:
            return ("🌟 Legend status! 100+ days of amazing commitment!", "🏆")

        return None

    @staticmethod
    def get_category_feedback(category: str, value: float | int) -> Tuple[str, str]:
        """Get category-specific feedback based on the metric value."""
        if category == "sleep":
            if 7 <= value <= 9:
                return ("😴 Perfect sleep zone! You're a sleep champion!", "🏆")
            elif 6 <= value < 7 or 9 < value <= 10:
                return ("💤 Close to optimal! Fine-tune for even better rest!", "🎯")
            else:
                return ("🌙 Sleep is your foundation - let's build it stronger!", "🧱")

        elif category == "stress":
            if value <= 3:
                return ("🧘‍♀️ Zen master! Your calm energy is inspiring!", "☮️")
            elif 4 <= value <= 6:
                return ("🌸 Balanced vibes! You're managing stress like a pro!", "⚖️")
            else:
                return ("🌊 Rough waters make skilled sailors! You've got this!", "⛵")

        elif category == "caffeine":
            if value <= 2:
                return ("☕ Perfect balance! Energized without overdoing it!", "⚡")
            elif value <= 4:
                return ("🫖 Moderate approach! Keeping it reasonable!", "👍")
            else:
                return ("🌿 Maybe try some herbal tea? Your body will thank you!", "🍵")

        elif category == "alcohol":
            if value == 0:
                return ("✨ Crystal clear choices! Your liver is cheering!", "🎉")
            elif value <= 1:
                return ("🍃 Mindful moderation! Balanced and responsible!", "⚖️")
            else:
                return ("🌱 Your future self will thank you for mindful choices!", "💚")

        return ("🌟 Keep tracking, keep growing!", "📈")

    @staticmethod
    def get_trend_message(current_score: float, previous_score: float | None) -> Tuple[str, str] | None:
        """Get a message based on score trend comparison."""
        if previous_score is None:
            return None

        difference = current_score - previous_score

        if difference >= 10:
            return ("🚀 Massive improvement! You're soaring to new heights!", "📈")
        elif difference >= 5:
            return ("⬆️ Great progress! Your hard work is paying off!", "💪")
        elif difference >= 1:
            return ("📈 Steady improvement! Every step counts!", "👣")
        elif difference > -1:
            return ("🎯 Staying consistent! Stability is strength!", "⚖️")
        elif difference > -5:
            return ("🌊 Small dip, but you're still strong! Bounce back time!", "🏀")
        else:
            return ("🌱 Rough patch? That's just growth happening! Keep going!", "🌿")

    @staticmethod
    def get_time_based_greeting() -> Tuple[str, str]:
        """Get a time-appropriate greeting with emoji."""
        from datetime import datetime

        hour = datetime.now().hour

        if 5 <= hour < 12:
            greetings = [
                ("🌅 Good morning, sunshine! Ready to seize the day?", "☀️"),
                ("☀️ Morning energy activated! Let's make today amazing!", "⚡"),
                ("🌞 Rise and shine! Your wellness journey awaits!", "🚀"),
                ("🦅 Early bird gets the wellness worm! Soar high today!", "🌟"),
            ]
        elif 12 <= hour < 17:
            greetings = [
                ("🌞 Good afternoon, wellness warrior! Keeping strong!", "💪"),
                ("☀️ Midday motivation! You're halfway to wellness victory!", "🎯"),
                ("🌻 Afternoon sunshine! Your energy is contagious!", "✨"),
                ("🌸 Blooming beautifully through the day! Keep it up!", "🦋"),
            ]
        elif 17 <= hour < 21:
            greetings = [
                ("🌆 Evening excellence! Winding down with wellness!", "🧘‍♀️"),
                ("🌅 Golden hour goals! You're glowing with health!", "✨"),
                ("🌸 Evening reflection time! Celebrate today's wins!", "🎉"),
                ("🌙 Sunset serenity! What a wonderful day for wellness!", "🌺"),
            ]
        else:
            greetings = [
                ("🌙 Good evening, night owl! Even late hours can be wellness hours!", "🦉"),
                ("✨ Nighttime nurturing! Self-care has no schedule!", "💫"),
                ("🌟 Stars are shining, just like you! Rest well tonight!", "😴"),
                ("🌛 Moon-kissed moments! Sweet dreams and sweet wellness!", "💤"),
            ]

        return random.choice(greetings)
