from nicegui import ui, app
from datetime import date
from decimal import Decimal
from app.wellness_service import WellnessService
from app.models import WellnessRecord
from app.motivational_messages import MotivationalMessages


def create():
    @ui.page("/")
    async def dashboard():
        await ui.context.client.connected()

        # Get or create demo user
        user = WellnessService.get_or_create_demo_user()

        if user.id is None:
            ui.label("Error: Unable to create demo user").classes("text-red-500")
            return

        # Store user in tab storage
        app.storage.tab["user_id"] = user.id
        app.storage.tab["user_name"] = user.name

        # Apply modern theme
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        with ui.column().classes("w-full max-w-6xl mx-auto p-6 gap-6"):
            # Header with time-based greeting
            with ui.row().classes("items-center justify-between w-full mb-4"):
                with ui.column():
                    ui.label("🌟 Daily Wellness Tracker").classes("text-3xl font-bold text-gray-800")

                    # Dynamic greeting based on time of day
                    greeting_msg, greeting_emoji = MotivationalMessages.get_time_based_greeting()
                    ui.label(f"{greeting_emoji} Welcome back, {user.name}!").classes("text-lg text-gray-600")
                    ui.label(greeting_msg).classes("text-sm text-primary font-medium italic")

                # Date selector
                today = date.today()
                selected_date = ui.date(value=today.isoformat()).classes("w-48")
                selected_date.on("update:model-value", lambda: refresh_dashboard())

            # Daily motivation banner
            daily_msg, daily_emoji = MotivationalMessages.get_general_message()
            with ui.card().classes(
                "w-full p-4 mb-4 bg-gradient-to-r from-blue-50 to-purple-50 border-l-4 border-primary"
            ):
                with ui.row().classes("items-center gap-3"):
                    ui.label(daily_emoji).classes("text-2xl")
                    ui.label(daily_msg).classes("text-lg font-medium text-gray-700")
                    ui.label("💫").classes("text-lg ml-auto")

            # Main content container
            content_container = ui.column().classes("w-full gap-6")

            def refresh_dashboard():
                """Refresh dashboard content based on selected date."""
                content_container.clear()

                with content_container:
                    selected_date_value = date.fromisoformat(selected_date.value)

                    # Get wellness record for selected date
                    if user.id is None:
                        return
                    record = WellnessService.get_wellness_record_for_date(user.id, selected_date_value)

                    # Input form
                    create_input_form(user.id, selected_date_value, record)

                    # Wellness score display
                    if record:
                        create_wellness_score_card(record)

                    # Statistics and history
                    create_stats_section(user.id)
                    create_history_section(user.id)

            # Initial load
            refresh_dashboard()


def create_input_form(user_id: int, selected_date: date, existing_record: WellnessRecord | None):
    """Create the input form for wellness data."""
    with ui.card().classes("w-full p-6 shadow-lg rounded-xl bg-white"):
        with ui.row().classes("items-center gap-3 mb-4"):
            ui.label("📝").classes("text-2xl")
            ui.label(f"Wellness Data for {selected_date.strftime('%B %d, %Y')}").classes(
                "text-xl font-bold text-gray-800"
            )

        # Add encouraging message for data entry
        if existing_record is None:
            entry_msg, entry_emoji = MotivationalMessages.get_general_message()
            with ui.row().classes("items-center gap-2 mb-4 p-2 bg-blue-50 rounded-lg"):
                ui.label(entry_emoji).classes("text-lg")
                ui.label("Time to track your wellness! Every entry is a step forward.").classes(
                    "text-sm text-primary font-medium"
                )

        with ui.row().classes("gap-6 w-full"):
            # Sleep Hours with motivational tip
            with ui.column().classes("flex-1"):
                with ui.row().classes("items-center gap-2 mb-2"):
                    ui.label("💤 Sleep Hours").classes("text-sm font-medium text-gray-700")
                sleep_input = ui.number(
                    value=float(existing_record.sleep_hours) if existing_record else 8.0,
                    min=0,
                    max=24,
                    step=0.5,
                    precision=1,
                    placeholder="Hours of sleep",
                ).classes("w-full")

                # Sleep tip
                sleep_tip, sleep_emoji = MotivationalMessages.get_sleep_message()
                ui.label(f"{sleep_emoji} {sleep_tip}").classes("text-xs text-gray-600 italic mt-1")

            # Stress Level with motivational tip
            with ui.column().classes("flex-1"):
                with ui.row().classes("items-center gap-2 mb-2"):
                    ui.label("🧘‍♀️ Stress Level (1-10)").classes("text-sm font-medium text-gray-700")
                stress_input = ui.number(
                    value=existing_record.stress_level if existing_record else 5,
                    min=1,
                    max=10,
                    step=1,
                    placeholder="1 = Very calm, 10 = Very stressed",
                ).classes("w-full")

                # Stress management tip
                stress_tip, stress_emoji = MotivationalMessages.get_stress_message()
                ui.label(f"{stress_emoji} {stress_tip}").classes("text-xs text-gray-600 italic mt-1")

            # Caffeine Intake
            with ui.column().classes("flex-1"):
                with ui.row().classes("items-center gap-2 mb-2"):
                    ui.label("☕ Caffeine Drinks").classes("text-sm font-medium text-gray-700")
                caffeine_input = ui.number(
                    value=existing_record.caffeine_intake if existing_record else 0,
                    min=0,
                    step=1,
                    placeholder="Number of caffeinated drinks",
                ).classes("w-full")
                ui.label("⚡ Moderation is key for sustained energy!").classes("text-xs text-gray-600 italic mt-1")

            # Alcohol Intake
            with ui.column().classes("flex-1"):
                with ui.row().classes("items-center gap-2 mb-2"):
                    ui.label("🍷 Alcohol Drinks").classes("text-sm font-medium text-gray-700")
                alcohol_input = ui.number(
                    value=existing_record.alcohol_intake if existing_record else 0,
                    min=0,
                    step=1,
                    placeholder="Number of alcoholic drinks",
                ).classes("w-full")
                ui.label("✨ Your body loves mindful choices!").classes("text-xs text-gray-600 italic mt-1")

        # Save button with motivational text
        with ui.row().classes("justify-end mt-6"):
            save_text = "🎯 Save Wellness Data" if not existing_record else "✨ Update Wellness Data"
            ui.button(
                save_text,
                on_click=lambda: save_wellness_data(
                    user_id,
                    selected_date,
                    sleep_input.value,
                    stress_input.value,
                    caffeine_input.value,
                    alcohol_input.value,
                ),
            ).classes(
                "bg-primary text-white px-6 py-3 rounded-lg hover:shadow-lg transition-all duration-300 hover:scale-105"
            )


def save_wellness_data(
    user_id: int, record_date: date, sleep_hours: float, stress_level: int, caffeine_intake: int, alcohol_intake: int
):
    """Save wellness data to database."""
    try:
        # Convert sleep hours to Decimal
        sleep_decimal = Decimal(str(sleep_hours))

        record = WellnessService.upsert_wellness_record(
            user_id=user_id,
            record_date=record_date,
            sleep_hours=sleep_decimal,
            stress_level=int(stress_level),
            caffeine_intake=int(caffeine_intake),
            alcohol_intake=int(alcohol_intake),
        )

        # Get a motivational message for the saved data
        score_msg, score_emoji = MotivationalMessages.get_score_message(float(record.wellness_score or Decimal("0")))

        ui.notify(
            f"🎉 Wellness data saved! Score: {record.wellness_score}/100 {score_emoji}", type="positive", timeout=4000
        )

        # Show additional motivational message
        ui.notify(score_msg, type="info", timeout=3000)

        # Refresh the page to show updated data
        ui.navigate.reload()

    except ValueError as e:
        ui.notify(f"❌ Error: {str(e)}", type="negative")
    except Exception as e:
        ui.notify(f"⚠️ An error occurred: {str(e)}", type="negative")


def create_wellness_score_card(record: WellnessRecord):
    """Create wellness score display card."""
    with ui.card().classes("w-full p-6 shadow-lg rounded-xl bg-gradient-to-br from-white to-gray-50"):
        ui.label("✨ Today's Wellness Score").classes("text-xl font-bold mb-4 text-gray-800")

        score = record.wellness_score or Decimal("0")
        score_color = get_score_color(float(score))

        # Get motivational message based on score
        score_msg, score_emoji = MotivationalMessages.get_score_message(float(score))

        with ui.row().classes("items-center gap-6"):
            # Large score display with motivational message
            with ui.column().classes("items-center"):
                ui.label(f"{score}/100").classes(f"text-6xl font-bold {score_color}")
                ui.label(get_score_interpretation(float(score))).classes("text-lg text-gray-600")

                # Motivational message for the score
                with ui.card().classes("mt-4 p-3 bg-gradient-to-r from-green-50 to-blue-50 border-l-4 border-accent"):
                    with ui.row().classes("items-center gap-2"):
                        ui.label(score_emoji).classes("text-xl")
                        ui.label(score_msg).classes("text-sm font-medium text-gray-700 text-center")

            # Score breakdown with category feedback
            with ui.column().classes("flex-1"):
                ui.label("📊 Score Breakdown").classes("text-lg font-semibold mb-3 text-gray-700")

                # Enhanced breakdown items with motivational feedback
                create_enhanced_breakdown_item(
                    "💤 Sleep", record.sleep_hours, "7-9 hours optimal", "sleep", float(record.sleep_hours)
                )
                create_enhanced_breakdown_item(
                    "😰 Stress", 11 - record.stress_level, "Lower is better", "stress", record.stress_level
                )
                create_enhanced_breakdown_item(
                    "☕ Caffeine",
                    get_caffeine_score_text(record.caffeine_intake),
                    "≤2 drinks recommended",
                    "caffeine",
                    record.caffeine_intake,
                )
                create_enhanced_breakdown_item(
                    "🍷 Alcohol",
                    get_alcohol_score_text(record.alcohol_intake),
                    "0-1 drinks recommended",
                    "alcohol",
                    record.alcohol_intake,
                )


def create_score_breakdown_item(label: str, value, description: str):
    """Create individual score breakdown item."""
    with ui.row().classes("items-center gap-3 mb-2"):
        ui.label(label).classes("text-sm font-medium w-20")
        ui.label(str(value)).classes("text-sm font-bold text-primary w-16")
        ui.label(description).classes("text-xs text-gray-500")


def create_enhanced_breakdown_item(label: str, value, description: str, category: str, raw_value: float | int):
    """Create enhanced score breakdown item with motivational feedback."""
    with ui.column().classes("mb-3 p-2 rounded-lg bg-gray-50"):
        with ui.row().classes("items-center gap-3 mb-1"):
            ui.label(label).classes("text-sm font-medium w-20")
            ui.label(str(value)).classes("text-sm font-bold text-primary w-16")
            ui.label(description).classes("text-xs text-gray-500")

        # Add category-specific motivational feedback
        feedback_msg, feedback_emoji = MotivationalMessages.get_category_feedback(category, raw_value)
        with ui.row().classes("items-center gap-2 ml-2"):
            ui.label(feedback_emoji).classes("text-xs")
            ui.label(feedback_msg).classes("text-xs text-gray-600 italic")


def get_score_color(score: float) -> str:
    """Get color class based on wellness score."""
    if score >= 80:
        return "text-green-500"
    elif score >= 60:
        return "text-yellow-500"
    else:
        return "text-red-500"


def get_score_interpretation(score: float) -> str:
    """Get text interpretation of wellness score."""
    if score >= 90:
        return "Excellent wellness!"
    elif score >= 80:
        return "Great wellness"
    elif score >= 70:
        return "Good wellness"
    elif score >= 60:
        return "Fair wellness"
    elif score >= 50:
        return "Below average"
    else:
        return "Needs improvement"


def get_caffeine_score_text(intake: int) -> str:
    """Get caffeine score description."""
    if intake <= 2:
        return "Excellent"
    elif intake <= 4:
        return "Moderate"
    elif intake <= 6:
        return "High"
    else:
        return "Excessive"


def get_alcohol_score_text(intake: int) -> str:
    """Get alcohol score description."""
    if intake == 0:
        return "Excellent"
    elif intake <= 1:
        return "Moderate"
    elif intake <= 2:
        return "High"
    else:
        return "Excessive"


def create_stats_section(user_id: int):
    """Create statistics section."""
    stats = WellnessService.get_wellness_stats(user_id, 30)

    if stats["total_records"] == 0:
        with ui.card().classes("w-full p-6 shadow-lg rounded-xl"):
            ui.label("📊 30-Day Statistics").classes("text-xl font-bold mb-4 text-gray-800")
            with ui.column().classes("items-center p-4"):
                ui.label("🌱").classes("text-4xl mb-2")
                ui.label("No wellness data recorded yet. Start tracking to see your statistics!").classes(
                    "text-gray-600 text-center"
                )
                ui.label("Every wellness journey begins with a single entry! 🚀").classes(
                    "text-primary font-medium text-center mt-2"
                )
        return

    with ui.card().classes("w-full p-6 shadow-lg rounded-xl bg-gradient-to-br from-white to-gray-50"):
        with ui.row().classes("items-center gap-3 mb-6"):
            ui.label("📊 30-Day Statistics").classes("text-xl font-bold text-gray-800")
            # Check for milestone achievements
            milestone_msg = MotivationalMessages.get_milestone_message(stats["total_records"])
            if milestone_msg:
                msg, emoji = milestone_msg
                ui.label(f"{emoji} {msg}").classes("text-sm text-accent font-medium italic")

        with ui.row().classes("gap-6 w-full"):
            create_stat_card("Total Records", str(stats["total_records"]), "📅")
            create_stat_card("Avg Wellness", f"{stats['avg_wellness_score']}/100", "⭐")
            create_stat_card("Avg Sleep", f"{stats['avg_sleep_hours']}h", "💤")
            create_stat_card("Avg Stress", f"{stats['avg_stress_level']}/10", "🧘‍♀️")

        with ui.row().classes("gap-6 w-full mt-4"):
            create_stat_card("Best Score", f"{stats['best_score']}/100", "🏆")
            create_stat_card("Worst Score", f"{stats['worst_score']}/100", "📈")
            create_stat_card("Avg Caffeine", str(stats["avg_caffeine_intake"]), "☕")
            create_stat_card("Avg Alcohol", str(stats["avg_alcohol_intake"]), "🍷")

        # Add encouraging stats summary
        avg_score = float(stats["avg_wellness_score"])
        stats_msg, stats_emoji = MotivationalMessages.get_score_message(avg_score)
        with ui.card().classes("mt-4 p-3 bg-gradient-to-r from-purple-50 to-pink-50"):
            with ui.row().classes("items-center gap-2"):
                ui.label(stats_emoji).classes("text-lg")
                ui.label(f"Your 30-day average: {stats_msg}").classes("text-sm font-medium text-gray-700")


def create_stat_card(title: str, value: str, emoji: str):
    """Create individual statistics card."""
    with ui.card().classes("flex-1 p-4 bg-gray-50 rounded-lg"):
        with ui.column().classes("items-center"):
            ui.label(emoji).classes("text-2xl mb-1")
            ui.label(value).classes("text-lg font-bold text-gray-800")
            ui.label(title).classes("text-sm text-gray-600")


def create_history_section(user_id: int):
    """Create wellness history table."""
    records = WellnessService.get_user_wellness_history(user_id, 14)  # Last 14 days

    if not records:
        return

    with ui.card().classes("w-full p-6 shadow-lg rounded-xl"):
        with ui.row().classes("items-center gap-3 mb-4"):
            ui.label("📈 Recent Wellness History").classes("text-xl font-bold text-gray-800")
            ui.label("🔍 Track your progress over time!").classes("text-sm text-primary italic")

        # Show trend message if we have enough data
        if len(records) >= 2:
            current_score = float(records[0].wellness_score or Decimal("0"))
            previous_score = float(records[1].wellness_score or Decimal("0"))
            trend_msg = MotivationalMessages.get_trend_message(current_score, previous_score)
            if trend_msg:
                msg, emoji = trend_msg
                with ui.card().classes("mb-4 p-3 bg-gradient-to-r from-yellow-50 to-orange-50"):
                    with ui.row().classes("items-center gap-2"):
                        ui.label(emoji).classes("text-lg")
                        ui.label(f"Trend Alert: {msg}").classes("text-sm font-medium text-gray-700")

        # Table headers and data
        columns = [
            {"name": "date", "label": "Date", "field": "date", "align": "left"},
            {"name": "score", "label": "Score", "field": "score", "align": "center"},
            {"name": "sleep", "label": "Sleep (h)", "field": "sleep", "align": "center"},
            {"name": "stress", "label": "Stress", "field": "stress", "align": "center"},
            {"name": "caffeine", "label": "Caffeine", "field": "caffeine", "align": "center"},
            {"name": "alcohol", "label": "Alcohol", "field": "alcohol", "align": "center"},
        ]

        rows = []
        for record in records:
            rows.append(
                {
                    "date": record.record_date.strftime("%m/%d"),
                    "score": f"{record.wellness_score}/100",
                    "sleep": str(record.sleep_hours),
                    "stress": f"{record.stress_level}/10",
                    "caffeine": str(record.caffeine_intake),
                    "alcohol": str(record.alcohol_intake),
                }
            )

        ui.table(columns=columns, rows=rows).classes("w-full")
