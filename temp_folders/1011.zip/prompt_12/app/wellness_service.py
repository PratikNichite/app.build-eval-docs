from sqlmodel import select
from app.database import get_session
from app.models import User, WellnessRecord, WellnessRecordCreate, WellnessRecordUpdate, UserCreate
from datetime import date, datetime, timedelta
from typing import Optional, List
from decimal import Decimal


class WellnessService:
    @staticmethod
    def create_user(user_data: UserCreate) -> User:
        """Create a new user."""
        with get_session() as session:
            user = User(**user_data.model_dump())
            session.add(user)
            session.commit()
            session.refresh(user)
            return user

    @staticmethod
    def get_user_by_email(email: str) -> Optional[User]:
        """Get user by email address."""
        with get_session() as session:
            user = session.exec(select(User).where(User.email == email)).first()
            return user

    @staticmethod
    def get_or_create_demo_user() -> User:
        """Get or create a demo user for the application."""
        demo_email = "demo@wellness.app"
        user = WellnessService.get_user_by_email(demo_email)

        if user is None:
            user_data = UserCreate(name="Demo User", email=demo_email)
            user = WellnessService.create_user(user_data)

        return user

    @staticmethod
    def get_wellness_record_for_date(user_id: int, record_date: date) -> Optional[WellnessRecord]:
        """Get wellness record for a specific user and date."""
        with get_session() as session:
            record = session.exec(
                select(WellnessRecord).where(
                    WellnessRecord.user_id == user_id, WellnessRecord.record_date == record_date
                )
            ).first()
            return record

    @staticmethod
    def create_wellness_record(record_data: WellnessRecordCreate) -> WellnessRecord:
        """Create a new wellness record."""
        with get_session() as session:
            # Check if record for this date already exists
            existing = session.exec(
                select(WellnessRecord).where(
                    WellnessRecord.user_id == record_data.user_id, WellnessRecord.record_date == record_data.record_date
                )
            ).first()

            if existing:
                raise ValueError("Wellness record for this date already exists")

            record = WellnessRecord(**record_data.model_dump())
            session.add(record)
            session.commit()
            session.refresh(record)
            return record

    @staticmethod
    def update_wellness_record(record_id: int, update_data: WellnessRecordUpdate) -> Optional[WellnessRecord]:
        """Update an existing wellness record."""
        with get_session() as session:
            record = session.get(WellnessRecord, record_id)
            if record is None:
                return None

            update_dict = update_data.model_dump(exclude_unset=True)
            for field, value in update_dict.items():
                setattr(record, field, value)

            # Recalculate wellness score
            record.wellness_score = record.calculate_wellness_score()
            record.updated_at = datetime.utcnow()

            session.add(record)
            session.commit()
            session.refresh(record)
            return record

    @staticmethod
    def upsert_wellness_record(user_id: int, record_date: date, **kwargs) -> WellnessRecord:
        """Create or update wellness record for a specific date."""
        existing_record = WellnessService.get_wellness_record_for_date(user_id, record_date)

        if existing_record:
            # Update existing record
            update_data = WellnessRecordUpdate(**kwargs)
            record = WellnessService.update_wellness_record(existing_record.id, update_data)
            if record is None:
                raise ValueError("Failed to update wellness record")
            return record
        else:
            # Create new record
            record_data = WellnessRecordCreate(user_id=user_id, record_date=record_date, **kwargs)
            return WellnessService.create_wellness_record(record_data)

    @staticmethod
    def get_user_wellness_history(user_id: int, days: int = 30) -> List[WellnessRecord]:
        """Get user's wellness history for the last N days."""
        with get_session() as session:
            start_date = date.today() - timedelta(days=days)
            records = session.exec(
                select(WellnessRecord)
                .where(WellnessRecord.user_id == user_id, WellnessRecord.record_date >= start_date)
                .order_by(WellnessRecord.record_date.desc())
            ).all()
            return list(records)

    @staticmethod
    def get_wellness_stats(user_id: int, days: int = 30) -> dict:
        """Get wellness statistics for a user."""
        records = WellnessService.get_user_wellness_history(user_id, days)

        if not records:
            return {
                "total_records": 0,
                "avg_wellness_score": Decimal("0"),
                "avg_sleep_hours": Decimal("0"),
                "avg_stress_level": Decimal("0"),
                "avg_caffeine_intake": Decimal("0"),
                "avg_alcohol_intake": Decimal("0"),
                "best_score": Decimal("0"),
                "worst_score": Decimal("0"),
            }

        total_records = len(records)
        avg_wellness_score = sum(r.wellness_score or Decimal("0") for r in records) / total_records
        avg_sleep_hours = sum(r.sleep_hours for r in records) / total_records
        avg_stress_level = sum(r.stress_level for r in records) / total_records
        avg_caffeine_intake = sum(r.caffeine_intake for r in records) / total_records
        avg_alcohol_intake = sum(r.alcohol_intake for r in records) / total_records

        wellness_scores = [r.wellness_score or Decimal("0") for r in records]
        best_score = max(wellness_scores) if wellness_scores else Decimal("0")
        worst_score = min(wellness_scores) if wellness_scores else Decimal("0")

        return {
            "total_records": total_records,
            "avg_wellness_score": round(avg_wellness_score, 1),
            "avg_sleep_hours": round(avg_sleep_hours, 1),
            "avg_stress_level": round(Decimal(str(avg_stress_level)), 1),
            "avg_caffeine_intake": round(Decimal(str(avg_caffeine_intake)), 1),
            "avg_alcohol_intake": round(Decimal(str(avg_alcohol_intake)), 1),
            "best_score": best_score,
            "worst_score": worst_score,
        }
