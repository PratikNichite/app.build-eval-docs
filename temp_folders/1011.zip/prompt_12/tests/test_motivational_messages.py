"""Tests for motivational messages functionality."""

from app.motivational_messages import MotivationalMessages


def test_get_score_message_excellent_range():
    """Test score messages for excellent wellness scores."""
    message, emoji = MotivationalMessages.get_score_message(95.0)
    assert isinstance(message, str)
    assert isinstance(emoji, str)
    assert len(message) > 0
    assert len(emoji) > 0
    # Should be positive and encouraging (not testing specific words due to randomness)
    assert len(message) > 10  # Should be a substantial message


def test_get_score_message_good_range():
    """Test score messages for good wellness scores."""
    message, emoji = MotivationalMessages.get_score_message(75.0)
    assert isinstance(message, str)
    assert isinstance(emoji, str)
    assert len(message) > 0
    assert len(emoji) > 0


def test_get_score_message_low_range():
    """Test score messages for low wellness scores."""
    message, emoji = MotivationalMessages.get_score_message(25.0)
    assert isinstance(message, str)
    assert isinstance(emoji, str)
    assert len(message) > 0
    assert len(emoji) > 0
    # Should be encouraging even for low scores
    assert any(word in message.lower() for word in ["seed", "beginning", "start", "journey", "possibilities"])


def test_get_general_message():
    """Test general motivational messages."""
    message, emoji = MotivationalMessages.get_general_message()
    assert isinstance(message, str)
    assert isinstance(emoji, str)
    assert len(message) > 0
    assert len(emoji) > 0


def test_get_sleep_message():
    """Test sleep-specific messages."""
    message, emoji = MotivationalMessages.get_sleep_message()
    assert isinstance(message, str)
    assert isinstance(emoji, str)
    assert len(message) > 0
    assert len(emoji) > 0
    # Should mention sleep-related concepts
    assert any(word in message.lower() for word in ["sleep", "dream", "rest", "recharge", "refresh"])


def test_get_stress_message():
    """Test stress-related messages."""
    message, emoji = MotivationalMessages.get_stress_message()
    assert isinstance(message, str)
    assert isinstance(emoji, str)
    assert len(message) > 0
    assert len(emoji) > 0
    # Should mention stress/calm concepts
    assert any(word in message.lower() for word in ["calm", "stress", "peace", "breathe", "flow"])


def test_get_milestone_message():
    """Test milestone messages for different record counts."""
    # First entry milestone
    message = MotivationalMessages.get_milestone_message(1)
    assert message is not None
    msg, emoji = message
    assert "first" in msg.lower() or "welcome" in msg.lower()

    # 7-day milestone
    message = MotivationalMessages.get_milestone_message(7)
    assert message is not None
    msg, emoji = message
    assert "7" in msg

    # 30-day milestone
    message = MotivationalMessages.get_milestone_message(30)
    assert message is not None
    msg, emoji = message
    assert "30" in msg

    # No milestone
    message = MotivationalMessages.get_milestone_message(15)
    assert message is None


def test_get_category_feedback_sleep():
    """Test category feedback for sleep."""
    # Optimal sleep
    message, emoji = MotivationalMessages.get_category_feedback("sleep", 8.0)
    assert "perfect" in message.lower() or "champion" in message.lower()

    # Poor sleep
    message, emoji = MotivationalMessages.get_category_feedback("sleep", 4.0)
    assert "foundation" in message.lower() or "stronger" in message.lower()


def test_get_category_feedback_stress():
    """Test category feedback for stress."""
    # Low stress (good)
    message, emoji = MotivationalMessages.get_category_feedback("stress", 2)
    assert any(word in message.lower() for word in ["zen", "master", "calm", "inspiring"])

    # High stress
    message, emoji = MotivationalMessages.get_category_feedback("stress", 8)
    assert any(word in message.lower() for word in ["rough", "waters", "skilled", "sailors"])


def test_get_category_feedback_caffeine():
    """Test category feedback for caffeine."""
    # Low caffeine (good)
    message, emoji = MotivationalMessages.get_category_feedback("caffeine", 1)
    assert "perfect" in message.lower() or "balance" in message.lower()

    # High caffeine
    message, emoji = MotivationalMessages.get_category_feedback("caffeine", 6)
    assert "herbal" in message.lower() or "tea" in message.lower()


def test_get_category_feedback_alcohol():
    """Test category feedback for alcohol."""
    # No alcohol (excellent)
    message, emoji = MotivationalMessages.get_category_feedback("alcohol", 0)
    assert "crystal" in message.lower() or "clear" in message.lower()

    # High alcohol
    message, emoji = MotivationalMessages.get_category_feedback("alcohol", 4)
    assert "future" in message.lower() and "mindful" in message.lower()


def test_get_trend_message():
    """Test trend-based messages."""
    # Large improvement
    message = MotivationalMessages.get_trend_message(85.0, 70.0)
    assert message is not None
    msg, emoji = message
    assert isinstance(msg, str) and len(msg) > 10
    assert isinstance(emoji, str) and len(emoji) > 0

    # Small improvement
    message = MotivationalMessages.get_trend_message(75.0, 72.0)
    assert message is not None
    msg, emoji = message
    assert isinstance(msg, str) and len(msg) > 10
    assert isinstance(emoji, str) and len(emoji) > 0

    # Stable
    message = MotivationalMessages.get_trend_message(75.0, 75.5)
    assert message is not None
    msg, emoji = message
    assert isinstance(msg, str) and len(msg) > 10
    assert isinstance(emoji, str) and len(emoji) > 0

    # Decline
    message = MotivationalMessages.get_trend_message(65.0, 75.0)
    assert message is not None
    msg, emoji = message
    assert isinstance(msg, str) and len(msg) > 10
    assert isinstance(emoji, str) and len(emoji) > 0

    # No previous score
    message = MotivationalMessages.get_trend_message(75.0, None)
    assert message is None


def test_get_time_based_greeting():
    """Test time-based greetings."""
    greeting, emoji = MotivationalMessages.get_time_based_greeting()
    assert isinstance(greeting, str)
    assert isinstance(emoji, str)
    assert len(greeting) > 0
    assert len(emoji) > 0
    # Should contain time-appropriate words
    assert any(word in greeting.lower() for word in ["morning", "afternoon", "evening", "night", "good"])


def test_score_messages_coverage():
    """Test that we have appropriate messages for all score ranges."""
    # Test various score ranges
    test_scores = [5, 25, 45, 65, 75, 85, 95]

    for score in test_scores:
        message, emoji = MotivationalMessages.get_score_message(score)
        assert isinstance(message, str)
        assert isinstance(emoji, str)
        assert len(message) > 10  # Reasonable message length
        assert len(emoji) > 0


def test_messages_are_encouraging():
    """Test that messages are positive and encouraging."""
    # Test low score - should still be encouraging
    message, emoji = MotivationalMessages.get_score_message(10.0)

    # Should not contain negative words
    negative_words = ["bad", "terrible", "awful", "horrible", "failure", "give up"]
    assert not any(word in message.lower() for word in negative_words)

    # Should contain positive/encouraging words
    positive_words = ["seed", "beginning", "journey", "possibilities", "start", "grow", "can"]
    assert any(word in message.lower() for word in positive_words)


def test_emoji_presence():
    """Test that all messages include appropriate emojis."""
    # Test different message types
    score_msg, score_emoji = MotivationalMessages.get_score_message(80.0)
    general_msg, general_emoji = MotivationalMessages.get_general_message()
    sleep_msg, sleep_emoji = MotivationalMessages.get_sleep_message()
    stress_msg, stress_emoji = MotivationalMessages.get_stress_message()

    # All should have emojis
    for emoji in [score_emoji, general_emoji, sleep_emoji, stress_emoji]:
        assert len(emoji) > 0
        # Basic emoji detection (unicode characters)
        assert any(ord(char) > 1000 for char in emoji)
