import pytest
from datetime import date, timedelta
from decimal import Decimal
from app.wellness_service import WellnessService
from app.models import UserCreate, WellnessRecordCreate, WellnessRecordUpdate
from app.database import reset_db


@pytest.fixture()
def fresh_db():
    """Reset database before each test."""
    reset_db()
    yield
    reset_db()


def test_create_user(fresh_db):
    """Test user creation."""
    user_data = UserCreate(name="Test User", email="test@example.com")
    user = WellnessService.create_user(user_data)

    assert user.id is not None
    assert user.name == "Test User"
    assert user.email == "test@example.com"
    assert user.is_active is True
    assert user.created_at is not None


def test_get_user_by_email(fresh_db):
    """Test getting user by email."""
    # Test non-existent user
    user = WellnessService.get_user_by_email("nonexistent@example.com")
    assert user is None

    # Create user and test retrieval
    user_data = UserCreate(name="Test User", email="test@example.com")
    created_user = WellnessService.create_user(user_data)

    retrieved_user = WellnessService.get_user_by_email("test@example.com")
    assert retrieved_user is not None
    assert retrieved_user.id == created_user.id
    assert retrieved_user.email == "test@example.com"


def test_get_or_create_demo_user(fresh_db):
    """Test demo user creation and retrieval."""
    # First call should create user
    user1 = WellnessService.get_or_create_demo_user()
    assert user1.id is not None
    assert user1.name == "Demo User"
    assert user1.email == "demo@wellness.app"

    # Second call should return same user
    user2 = WellnessService.get_or_create_demo_user()
    assert user2.id == user1.id
    assert user2.email == user1.email


def test_create_wellness_record(fresh_db):
    """Test wellness record creation."""
    user = WellnessService.get_or_create_demo_user()
    today = date.today()

    if user.id is None:
        pytest.skip("User creation failed")

    record_data = WellnessRecordCreate(
        user_id=user.id,
        record_date=today,
        sleep_hours=Decimal("8.0"),
        stress_level=3,
        caffeine_intake=2,
        alcohol_intake=0,
    )

    record = WellnessService.create_wellness_record(record_data)

    assert record.id is not None
    assert record.user_id == user.id
    assert record.record_date == today
    assert record.sleep_hours == Decimal("8.0")
    assert record.stress_level == 3
    assert record.caffeine_intake == 2
    assert record.alcohol_intake == 0
    assert record.wellness_score is not None
    assert record.wellness_score > Decimal("0")


def test_duplicate_wellness_record_raises_error(fresh_db):
    """Test that creating duplicate wellness record for same date raises error."""
    user = WellnessService.get_or_create_demo_user()
    today = date.today()

    if user.id is None:
        pytest.skip("User creation failed")

    record_data = WellnessRecordCreate(
        user_id=user.id,
        record_date=today,
        sleep_hours=Decimal("8.0"),
        stress_level=3,
        caffeine_intake=2,
        alcohol_intake=0,
    )

    # First creation should succeed
    WellnessService.create_wellness_record(record_data)

    # Second creation should raise error
    with pytest.raises(ValueError, match="Wellness record for this date already exists"):
        WellnessService.create_wellness_record(record_data)


def test_get_wellness_record_for_date(fresh_db):
    """Test getting wellness record for specific date."""
    user = WellnessService.get_or_create_demo_user()
    today = date.today()
    yesterday = today - timedelta(days=1)

    if user.id is None:
        pytest.skip("User creation failed")

    # Test non-existent record
    record = WellnessService.get_wellness_record_for_date(user.id, today)
    assert record is None

    # Create record and test retrieval
    record_data = WellnessRecordCreate(
        user_id=user.id,
        record_date=today,
        sleep_hours=Decimal("7.5"),
        stress_level=4,
        caffeine_intake=1,
        alcohol_intake=0,
    )
    created_record = WellnessService.create_wellness_record(record_data)

    retrieved_record = WellnessService.get_wellness_record_for_date(user.id, today)
    assert retrieved_record is not None
    assert retrieved_record.id == created_record.id

    # Test different date
    different_date_record = WellnessService.get_wellness_record_for_date(user.id, yesterday)
    assert different_date_record is None


def test_update_wellness_record(fresh_db):
    """Test updating wellness record."""
    user = WellnessService.get_or_create_demo_user()
    today = date.today()

    if user.id is None:
        pytest.skip("User creation failed")

    # Create initial record
    record_data = WellnessRecordCreate(
        user_id=user.id,
        record_date=today,
        sleep_hours=Decimal("6.0"),
        stress_level=7,
        caffeine_intake=4,
        alcohol_intake=2,
    )
    original_record = WellnessService.create_wellness_record(record_data)
    original_score = original_record.wellness_score

    # Update record
    update_data = WellnessRecordUpdate(sleep_hours=Decimal("8.0"), stress_level=3, caffeine_intake=1, alcohol_intake=0)
    updated_record = WellnessService.update_wellness_record(original_record.id, update_data)

    assert updated_record is not None
    assert updated_record.id == original_record.id
    assert updated_record.sleep_hours == Decimal("8.0")
    assert updated_record.stress_level == 3
    assert updated_record.caffeine_intake == 1
    assert updated_record.alcohol_intake == 0
    assert updated_record.wellness_score != original_score
    assert updated_record.wellness_score > original_score  # Should be better score


def test_update_nonexistent_record_returns_none(fresh_db):
    """Test updating non-existent record returns None."""
    update_data = WellnessRecordUpdate(sleep_hours=Decimal("8.0"))
    result = WellnessService.update_wellness_record(999, update_data)
    assert result is None


def test_upsert_wellness_record_create(fresh_db):
    """Test upsert creates new record when none exists."""
    user = WellnessService.get_or_create_demo_user()
    today = date.today()

    if user.id is None:
        pytest.skip("User creation failed")

    record = WellnessService.upsert_wellness_record(
        user_id=user.id,
        record_date=today,
        sleep_hours=Decimal("7.0"),
        stress_level=5,
        caffeine_intake=2,
        alcohol_intake=1,
    )

    assert record.id is not None
    assert record.sleep_hours == Decimal("7.0")
    assert record.stress_level == 5
    assert record.caffeine_intake == 2
    assert record.alcohol_intake == 1


def test_upsert_wellness_record_update(fresh_db):
    """Test upsert updates existing record."""
    user = WellnessService.get_or_create_demo_user()
    today = date.today()

    if user.id is None:
        pytest.skip("User creation failed")

    # Create initial record
    record_data = WellnessRecordCreate(
        user_id=user.id,
        record_date=today,
        sleep_hours=Decimal("6.0"),
        stress_level=8,
        caffeine_intake=5,
        alcohol_intake=3,
    )
    original_record = WellnessService.create_wellness_record(record_data)

    # Upsert should update existing record
    updated_record = WellnessService.upsert_wellness_record(
        user_id=user.id,
        record_date=today,
        sleep_hours=Decimal("8.5"),
        stress_level=2,
        caffeine_intake=1,
        alcohol_intake=0,
    )

    assert updated_record.id == original_record.id  # Same record
    assert updated_record.sleep_hours == Decimal("8.5")
    assert updated_record.stress_level == 2
    assert updated_record.caffeine_intake == 1
    assert updated_record.alcohol_intake == 0


def test_get_user_wellness_history(fresh_db):
    """Test getting user wellness history."""
    user = WellnessService.get_or_create_demo_user()
    today = date.today()

    if user.id is None:
        pytest.skip("User creation failed")

    # Test empty history
    history = WellnessService.get_user_wellness_history(user.id, 30)
    assert history == []

    # Create multiple records
    dates_and_scores = []
    for i in range(5):
        record_date = today - timedelta(days=i)
        record_data = WellnessRecordCreate(
            user_id=user.id,
            record_date=record_date,
            sleep_hours=Decimal("7.0") + Decimal(str(i * 0.5)),
            stress_level=3 + i,
            caffeine_intake=i,
            alcohol_intake=0,
        )
        record = WellnessService.create_wellness_record(record_data)
        dates_and_scores.append((record_date, record.wellness_score))

    # Get history (should be in descending date order)
    history = WellnessService.get_user_wellness_history(user.id, 30)
    assert len(history) == 5

    # Verify order (most recent first)
    for i, record in enumerate(history):
        expected_date = today - timedelta(days=i)
        assert record.record_date == expected_date

    # Test limited days
    recent_history = WellnessService.get_user_wellness_history(user.id, 2)
    assert len(recent_history) == 3  # Today + 2 days back


def test_get_wellness_stats_empty(fresh_db):
    """Test wellness stats with no records."""
    user = WellnessService.get_or_create_demo_user()

    if user.id is None:
        pytest.skip("User creation failed")

    stats = WellnessService.get_wellness_stats(user.id, 30)

    assert stats["total_records"] == 0
    assert stats["avg_wellness_score"] == Decimal("0")
    assert stats["avg_sleep_hours"] == Decimal("0")
    assert stats["avg_stress_level"] == Decimal("0")
    assert stats["avg_caffeine_intake"] == Decimal("0")
    assert stats["avg_alcohol_intake"] == Decimal("0")
    assert stats["best_score"] == Decimal("0")
    assert stats["worst_score"] == Decimal("0")


def test_get_wellness_stats_with_data(fresh_db):
    """Test wellness stats calculation with data."""
    user = WellnessService.get_or_create_demo_user()
    today = date.today()

    if user.id is None:
        pytest.skip("User creation failed")

    # Create test records with known values
    test_data = [
        (Decimal("8.0"), 2, 1, 0),  # Good day
        (Decimal("6.0"), 6, 3, 1),  # Average day
        (Decimal("9.0"), 1, 0, 0),  # Excellent day
    ]

    records = []
    for i, (sleep, stress, caffeine, alcohol) in enumerate(test_data):
        record_data = WellnessRecordCreate(
            user_id=user.id,
            record_date=today - timedelta(days=i),
            sleep_hours=sleep,
            stress_level=stress,
            caffeine_intake=caffeine,
            alcohol_intake=alcohol,
        )
        records.append(WellnessService.create_wellness_record(record_data))

    stats = WellnessService.get_wellness_stats(user.id, 30)

    assert stats["total_records"] == 3

    # Check averages (should be calculated correctly)
    expected_avg_sleep = (Decimal("8.0") + Decimal("6.0") + Decimal("9.0")) / 3
    assert stats["avg_sleep_hours"] == round(expected_avg_sleep, 1)

    expected_avg_stress = (2 + 6 + 1) / 3
    assert stats["avg_stress_level"] == round(Decimal(str(expected_avg_stress)), 1)

    expected_avg_caffeine = (1 + 3 + 0) / 3
    assert stats["avg_caffeine_intake"] == round(Decimal(str(expected_avg_caffeine)), 1)

    expected_avg_alcohol = (0 + 1 + 0) / 3
    assert stats["avg_alcohol_intake"] == round(Decimal(str(expected_avg_alcohol)), 1)

    # Best and worst scores should be from the actual records
    wellness_scores = [r.wellness_score for r in records]
    assert stats["best_score"] == max(wellness_scores)
    assert stats["worst_score"] == min(wellness_scores)

    # Average wellness score should be reasonable
    assert stats["avg_wellness_score"] > Decimal("0")
    assert stats["avg_wellness_score"] <= Decimal("100")


def test_wellness_score_calculation_edge_cases(fresh_db):
    """Test wellness score calculation with edge case values."""
    user = WellnessService.get_or_create_demo_user()
    today = date.today()

    if user.id is None:
        pytest.skip("User creation failed")

    # Test minimum values (worst possible score)
    worst_case = WellnessRecordCreate(
        user_id=user.id,
        record_date=today,
        sleep_hours=Decimal("2.0"),  # Very little sleep
        stress_level=10,  # Maximum stress
        caffeine_intake=10,  # Excessive caffeine
        alcohol_intake=5,  # Excessive alcohol
    )
    worst_record = WellnessService.create_wellness_record(worst_case)
    assert worst_record.wellness_score is not None
    assert worst_record.wellness_score >= Decimal("0")

    # Test optimal values (best possible score)
    tomorrow = today + timedelta(days=1)
    best_case = WellnessRecordCreate(
        user_id=user.id,
        record_date=tomorrow,
        sleep_hours=Decimal("8.0"),  # Optimal sleep
        stress_level=1,  # Minimal stress
        caffeine_intake=0,  # No caffeine
        alcohol_intake=0,  # No alcohol
    )
    best_record = WellnessService.create_wellness_record(best_case)
    assert best_record.wellness_score is not None
    assert best_record.wellness_score <= Decimal("100")
    assert best_record.wellness_score > worst_record.wellness_score
