from datetime import date
from decimal import Decimal
from app.models import WellnessRecord


def test_wellness_score_calculation_optimal():
    """Test wellness score calculation with optimal values."""
    record = WellnessRecord(
        user_id=1,
        record_date=date.today(),
        sleep_hours=Decimal("8.0"),  # Optimal sleep (30 points)
        stress_level=1,  # Minimal stress (30 points)
        caffeine_intake=1,  # Low caffeine (20 points)
        alcohol_intake=0,  # No alcohol (20 points)
    )

    # Total should be 100 points
    assert record.wellness_score == Decimal("100")


def test_wellness_score_calculation_poor():
    """Test wellness score calculation with poor values."""
    record = WellnessRecord(
        user_id=1,
        record_date=date.today(),
        sleep_hours=Decimal("3.0"),  # Very poor sleep (5 points)
        stress_level=10,  # Maximum stress (3 points)
        caffeine_intake=10,  # Excessive caffeine (5 points)
        alcohol_intake=5,  # Excessive alcohol (5 points)
    )

    # Total should be low
    expected_score = Decimal("18")  # 5 + 3 + 5 + 5
    assert record.wellness_score == expected_score


def test_wellness_score_sleep_ranges():
    """Test sleep score calculation across different ranges."""
    base_record_data = {
        "user_id": 1,
        "record_date": date.today(),
        "stress_level": 5,  # Neutral
        "caffeine_intake": 0,
        "alcohol_intake": 0,
    }

    # Test optimal sleep (7-9 hours) = 30 points
    record = WellnessRecord(sleep_hours=Decimal("7.5"), **base_record_data)
    sleep_component = 30  # Optimal
    stress_component = 30 - ((5 - 1) * 3)  # 18 points
    caffeine_component = 20  # No caffeine
    alcohol_component = 20  # No alcohol
    expected = sleep_component + stress_component + caffeine_component + alcohol_component
    assert record.wellness_score == Decimal(str(expected))

    # Test good sleep (6-7 or 9-10 hours) = 25 points
    record = WellnessRecord(sleep_hours=Decimal("6.5"), **base_record_data)
    expected = 25 + 18 + 20 + 20
    assert record.wellness_score == Decimal(str(expected))

    # Test fair sleep (5-6 or 10-11 hours) = 20 points
    record = WellnessRecord(sleep_hours=Decimal("5.5"), **base_record_data)
    expected = 20 + 18 + 20 + 20
    assert record.wellness_score == Decimal(str(expected))

    # Test poor sleep (4-5 or 11-12 hours) = 10 points
    record = WellnessRecord(sleep_hours=Decimal("4.5"), **base_record_data)
    expected = 10 + 18 + 20 + 20
    assert record.wellness_score == Decimal(str(expected))

    # Test very poor sleep (outside ranges) = 5 points
    record = WellnessRecord(sleep_hours=Decimal("2.0"), **base_record_data)
    expected = 5 + 18 + 20 + 20
    assert record.wellness_score == Decimal(str(expected))


def test_wellness_score_stress_levels():
    """Test stress score calculation across different levels."""
    base_record_data = {
        "user_id": 1,
        "record_date": date.today(),
        "sleep_hours": Decimal("8.0"),  # Optimal
        "caffeine_intake": 0,
        "alcohol_intake": 0,
    }

    # Stress level 1 (minimal) = 30 points
    record = WellnessRecord(stress_level=1, **base_record_data)
    stress_component = 30 - ((1 - 1) * 3)  # 30 points
    expected = 30 + stress_component + 20 + 20
    assert record.wellness_score == Decimal(str(expected))

    # Stress level 5 (moderate) = 18 points
    record = WellnessRecord(stress_level=5, **base_record_data)
    stress_component = 30 - ((5 - 1) * 3)  # 18 points
    expected = 30 + stress_component + 20 + 20
    assert record.wellness_score == Decimal(str(expected))

    # Stress level 10 (maximum) = 3 points (minimum)
    record = WellnessRecord(stress_level=10, **base_record_data)
    stress_component = max(3, 30 - ((10 - 1) * 3))  # 3 points (capped)
    expected = 30 + stress_component + 20 + 20
    assert record.wellness_score == Decimal(str(expected))


def test_wellness_score_caffeine_intake():
    """Test caffeine score calculation."""
    base_record_data = {
        "user_id": 1,
        "record_date": date.today(),
        "sleep_hours": Decimal("8.0"),
        "stress_level": 1,
        "alcohol_intake": 0,
    }

    # 0-2 drinks = 20 points
    record = WellnessRecord(caffeine_intake=2, **base_record_data)
    expected = 30 + 30 + 20 + 20
    assert record.wellness_score == Decimal(str(expected))

    # 3-4 drinks = 15 points
    record = WellnessRecord(caffeine_intake=4, **base_record_data)
    expected = 30 + 30 + 15 + 20
    assert record.wellness_score == Decimal(str(expected))

    # 5-6 drinks = 10 points
    record = WellnessRecord(caffeine_intake=6, **base_record_data)
    expected = 30 + 30 + 10 + 20
    assert record.wellness_score == Decimal(str(expected))

    # 7+ drinks = 5 points
    record = WellnessRecord(caffeine_intake=10, **base_record_data)
    expected = 30 + 30 + 5 + 20
    assert record.wellness_score == Decimal(str(expected))


def test_wellness_score_alcohol_intake():
    """Test alcohol score calculation."""
    base_record_data = {
        "user_id": 1,
        "record_date": date.today(),
        "sleep_hours": Decimal("8.0"),
        "stress_level": 1,
        "caffeine_intake": 0,
    }

    # 0 drinks = 20 points
    record = WellnessRecord(alcohol_intake=0, **base_record_data)
    expected = 30 + 30 + 20 + 20
    assert record.wellness_score == Decimal(str(expected))

    # 1 drink = 15 points
    record = WellnessRecord(alcohol_intake=1, **base_record_data)
    expected = 30 + 30 + 20 + 15
    assert record.wellness_score == Decimal(str(expected))

    # 2 drinks = 10 points
    record = WellnessRecord(alcohol_intake=2, **base_record_data)
    expected = 30 + 30 + 20 + 10
    assert record.wellness_score == Decimal(str(expected))

    # 3+ drinks = 5 points
    record = WellnessRecord(alcohol_intake=5, **base_record_data)
    expected = 30 + 30 + 20 + 5
    assert record.wellness_score == Decimal(str(expected))


def test_wellness_score_capped_at_100():
    """Test that wellness score is capped at 100."""
    record = WellnessRecord(
        user_id=1,
        record_date=date.today(),
        sleep_hours=Decimal("8.0"),  # 30 points
        stress_level=1,  # 30 points
        caffeine_intake=0,  # 20 points
        alcohol_intake=0,  # 20 points
    )

    # Even if calculation would exceed 100, it should be capped
    assert record.wellness_score == Decimal("100")
    assert record.wellness_score <= Decimal("100")


def test_wellness_record_auto_calculation():
    """Test that wellness score is automatically calculated on record creation."""
    record = WellnessRecord(
        user_id=1,
        record_date=date.today(),
        sleep_hours=Decimal("7.0"),
        stress_level=4,
        caffeine_intake=2,
        alcohol_intake=1,
    )

    # Score should be automatically calculated
    assert record.wellness_score is not None
    assert record.wellness_score > Decimal("0")

    # Manual calculation to verify
    expected = (
        30  # Sleep: 7 hours is optimal
        + (30 - ((4 - 1) * 3))  # Stress: 4 -> 21 points
        + 20  # Caffeine: 2 drinks -> 20 points
        + 15  # Alcohol: 1 drink -> 15 points
    )
    assert record.wellness_score == Decimal(str(expected))


def test_wellness_record_recalculation():
    """Test that wellness score is recalculated when values change."""
    record = WellnessRecord(
        user_id=1,
        record_date=date.today(),
        sleep_hours=Decimal("6.0"),
        stress_level=8,
        caffeine_intake=5,
        alcohol_intake=3,
    )

    original_score = record.wellness_score

    # Change values
    record.sleep_hours = Decimal("8.0")
    record.stress_level = 2
    record.caffeine_intake = 1
    record.alcohol_intake = 0

    # Recalculate score
    new_score = record.calculate_wellness_score()

    # New score should be higher
    assert new_score > original_score
    assert new_score == Decimal("97")  # 30 + 27 + 20 + 20
