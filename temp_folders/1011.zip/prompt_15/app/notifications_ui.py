from nicegui import ui
from app.pantry_service import get_active_notifications, dismiss_notification, create_expiry_notifications


def get_notification_icon_and_emoji(notification_type: str) -> tuple[str, str]:
    """Get icon and emoji for notification type."""
    mapping = {
        "expired": ("error", "💀"),
        "expiring_soon": ("warning", "🔥"),
        "low_stock": ("inventory_2", "📦"),
        "recipe_suggestion": ("restaurant", "🍽️"),
    }
    return mapping.get(notification_type, ("notifications", "🔔"))


def get_notification_color(priority: str) -> str:
    """Get color class for notification priority."""
    colors = {
        "high": "bg-red-100 border-red-500 text-red-800",
        "medium": "bg-yellow-100 border-yellow-500 text-yellow-800",
        "low": "bg-blue-100 border-blue-500 text-blue-800",
    }
    return colors.get(priority, "bg-gray-100 border-gray-500 text-gray-800")


def create_notification_card(notification, refresh_callback):
    """Create a card for displaying a notification."""
    color_class = get_notification_color(notification.priority)
    icon, emoji = get_notification_icon_and_emoji(notification.notification_type)

    with ui.card().classes(f"w-full p-4 {color_class} border-l-4 mb-3"):
        with ui.row().classes("items-start justify-between w-full"):
            # Notification content
            with ui.column().classes("flex-1"):
                with ui.row().classes("items-center gap-2 mb-2"):
                    ui.icon(icon).classes("text-lg")
                    ui.label(f"{emoji} {notification.title}").classes("text-lg font-semibold")

                    # Priority badge with emoji
                    priority_emojis = {"high": "🚨", "medium": "⚠️", "low": "ℹ️"}
                    priority_colors = {"high": "bg-red-500", "medium": "bg-yellow-500", "low": "bg-blue-500"}
                    ui.chip(
                        f"{priority_emojis.get(notification.priority, '')} {notification.priority.upper()}",
                        color="white",
                    ).classes(f"{priority_colors.get(notification.priority, 'bg-gray-500')} text-white").props(
                        "size=sm"
                    )

                ui.label(notification.message).classes("text-base mb-2")

                # Timestamp
                created_time = notification.created_at.strftime("%Y-%m-%d %H:%M")
                ui.label(f"🕐 Created: {created_time}").classes("text-sm opacity-75")

            # Dismiss button
            async def dismiss_notification_handler():
                if notification.id is not None:
                    if dismiss_notification(notification.id):
                        ui.notify("✅ Notification dismissed", type="positive")
                        refresh_callback()
                    else:
                        ui.notify("❌ Error dismissing notification", type="negative")

            ui.button("❌", on_click=dismiss_notification_handler).props("flat round size=sm")


def create_notifications_panel():
    """Create a floating notifications panel."""

    def show_notifications():
        # Create/update notifications first
        create_expiry_notifications()

        # Get active notifications
        _ = get_active_notifications()

        async def show_panel():
            with ui.dialog() as dialog, ui.card().classes("w-full max-w-2xl p-6"):
                ui.label("🔔 Notifications Center").classes("text-2xl font-bold text-gray-800 mb-4")

                notifications_container = ui.column().classes("w-full")

                def refresh_notifications():
                    notifications_container.clear()

                    # Get fresh notifications
                    fresh_notifications = get_active_notifications()

                    with notifications_container:
                        if not fresh_notifications:
                            with ui.card().classes("w-full p-8 text-center bg-gray-50"):
                                ui.label("🎉 No active notifications").classes("text-lg text-gray-600 mb-2")
                                ui.label("You're all caught up! Great job! ✨").classes("text-gray-500")
                        else:
                            ui.label(f"📬 {len(fresh_notifications)} active notifications:").classes(
                                "text-lg font-semibold text-gray-700 mb-4"
                            )

                            # Group notifications by type
                            expired_notifications = [n for n in fresh_notifications if n.notification_type == "expired"]
                            expiring_notifications = [
                                n for n in fresh_notifications if n.notification_type == "expiring_soon"
                            ]
                            other_notifications = [
                                n
                                for n in fresh_notifications
                                if n.notification_type not in ["expired", "expiring_soon"]
                            ]

                            # Show expired items first
                            for notification in expired_notifications:
                                create_notification_card(notification, refresh_notifications)

                            # Then expiring soon
                            for notification in expiring_notifications:
                                create_notification_card(notification, refresh_notifications)

                            # Then other notifications
                            for notification in other_notifications:
                                create_notification_card(notification, refresh_notifications)

                # Initial load
                refresh_notifications()

                # Action buttons
                with ui.row().classes("gap-2 justify-end mt-4"):
                    ui.button("🔄 Refresh", on_click=refresh_notifications, icon="refresh").props("outline")
                    ui.button("✖️ Close", on_click=lambda: dialog.close()).classes("bg-gray-500 text-white")

            await dialog

        return show_panel

    return show_notifications


def create_notification_badge():
    """Create a notification badge that shows count of active notifications."""

    # Get notification count
    notification_count = len(get_active_notifications())

    if notification_count == 0:
        return ui.button("🔔", on_click=create_notifications_panel()()).props("flat round")

    # Create button with badge
    button_container = ui.element("div").classes("relative")

    with button_container:
        ui.button("🔔", on_click=create_notifications_panel()()).props("flat round")

        # Badge with count
        if notification_count > 0:
            badge = ui.element("span").classes(
                "absolute -top-1 -right-1 bg-red-500 text-white rounded-full text-xs px-1.5 py-0.5 min-w-5 text-center"
            )
            badge.text = str(min(notification_count, 99))  # Cap at 99

    return button_container


def create():
    """Create the notifications UI module."""

    @ui.page("/notifications")
    def notifications_page():
        # Navigation header
        with ui.row().classes("w-full items-center justify-between mb-6 p-4 bg-white shadow-sm rounded-lg"):
            with ui.row().classes("items-center gap-4"):
                ui.button("🏠 Home", on_click=lambda: ui.navigate.to("/")).props("flat")
                ui.label("🔔 Notifications Center").classes("text-3xl font-bold text-gray-800")
            with ui.row().classes("gap-2"):
                ui.button("🥫 Pantry", on_click=lambda: ui.navigate.to("/pantry")).classes(
                    "bg-primary text-white px-4 py-2"
                )
                ui.button("🍽️ Recipes", on_click=lambda: ui.navigate.to("/recipes")).classes(
                    "bg-accent text-white px-4 py-2"
                )

        # Auto-create notifications on page load
        create_expiry_notifications()

        # Container for dynamic content
        content_container = ui.column().classes("w-full")

        def refresh_content():
            content_container.clear()

            # Get active notifications
            notifications = get_active_notifications()

            with content_container:
                if not notifications:
                    with ui.card().classes("w-full p-8 text-center bg-gray-50"):
                        ui.label("🎉 No active notifications").classes("text-xl text-gray-600 mb-4")
                        ui.label("You're all caught up! Great job! ✨").classes("text-gray-500 mb-4")
                        ui.button("🔄 Check for Updates", on_click=refresh_content).classes(
                            "bg-primary text-white px-4 py-2"
                        )
                else:
                    ui.label(f"📬 {len(notifications)} active notifications:").classes(
                        "text-xl font-semibold text-gray-700 mb-6"
                    )

                    # Group notifications by priority
                    high_priority = [n for n in notifications if n.priority == "high"]
                    medium_priority = [n for n in notifications if n.priority == "medium"]
                    low_priority = [n for n in notifications if n.priority == "low"]

                    # Show high priority first
                    if high_priority:
                        ui.label(f"🚨 High Priority ({len(high_priority)})").classes(
                            "text-lg font-semibold text-red-700 mb-3"
                        )
                        for notification in high_priority:
                            create_notification_card(notification, refresh_content)

                        ui.separator().classes("my-4")

                    # Then medium priority
                    if medium_priority:
                        ui.label(f"⚠️ Medium Priority ({len(medium_priority)})").classes(
                            "text-lg font-semibold text-yellow-700 mb-3"
                        )
                        for notification in medium_priority:
                            create_notification_card(notification, refresh_content)

                        if low_priority:
                            ui.separator().classes("my-4")

                    # Finally low priority
                    if low_priority:
                        ui.label(f"ℹ️ Low Priority ({len(low_priority)})").classes(
                            "text-lg font-semibold text-blue-700 mb-3"
                        )
                        for notification in low_priority:
                            create_notification_card(notification, refresh_content)

                    # Action buttons
                    with ui.row().classes("gap-2 justify-center mt-6"):
                        ui.button("🔄 Refresh Notifications", on_click=refresh_content, icon="refresh").classes(
                            "bg-primary text-white px-4 py-2"
                        )

                        async def dismiss_all():
                            result = await ui.dialog("🗑️ Dismiss All Notifications", ["Yes, dismiss all", "Cancel"])
                            if result == "Yes, dismiss all":
                                dismissed_count = 0
                                for notification in notifications:
                                    if notification.id is not None and dismiss_notification(notification.id):
                                        dismissed_count += 1

                                ui.notify(f"✅ Dismissed {dismissed_count} notifications", type="positive")
                                refresh_content()

                        if notifications:
                            ui.button("🗑️ Dismiss All", on_click=dismiss_all, color="warning").props("outline")

        # Initial content load
        refresh_content()

        # Auto-refresh every 30 seconds with loading indicator
        def auto_refresh():
            ui.notify("🔄 Auto-refreshing notifications...", type="info")
            refresh_content()

        ui.timer(30.0, lambda: auto_refresh())
