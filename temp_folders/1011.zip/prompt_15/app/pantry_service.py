from datetime import date
from decimal import Decimal
from typing import List, Optional
from sqlmodel import select
from app.database import get_session
from app.models import PantryItem, PantryItemCreate, PantryItemUpdate, Notification, ExpiryAlert


def calculate_expiry_status(expiry_date: date) -> tuple[bool, int]:
    """Calculate if item is expired and days until expiry."""
    today = date.today()
    days_until_expiry = (expiry_date - today).days
    is_expired = days_until_expiry < 0
    return is_expired, days_until_expiry


def get_all_pantry_items() -> List[PantryItem]:
    """Retrieve all pantry items with updated expiry status."""
    with get_session() as session:
        statement = select(PantryItem).order_by(PantryItem.expiry_date)
        items = list(session.exec(statement).all())

        # Update expiry status for each item
        for item in items:
            is_expired, days_until_expiry = calculate_expiry_status(item.expiry_date)
            item.is_expired = is_expired
            item.days_until_expiry = days_until_expiry

        session.commit()

        # Return fresh copies to avoid detached instance issues
        fresh_items = []
        for item in items:
            session.refresh(item)
            fresh_items.append(item)

        return fresh_items


def add_pantry_item(item_data: PantryItemCreate) -> PantryItem:
    """Add a new pantry item to the database."""
    with get_session() as session:
        is_expired, days_until_expiry = calculate_expiry_status(item_data.expiry_date)

        item = PantryItem(
            name=item_data.name,
            quantity=item_data.quantity,
            unit=item_data.unit,
            expiry_date=item_data.expiry_date,
            category=item_data.category,
            location=item_data.location,
            notes=item_data.notes,
            is_expired=is_expired,
            days_until_expiry=days_until_expiry,
        )

        session.add(item)
        session.commit()
        session.refresh(item)
        return item


def update_pantry_item(item_id: int, item_data: PantryItemUpdate) -> Optional[PantryItem]:
    """Update an existing pantry item."""
    with get_session() as session:
        item = session.get(PantryItem, item_id)
        if item is None:
            return None

        # Update only provided fields
        for field, value in item_data.model_dump(exclude_unset=True).items():
            setattr(item, field, value)

        # Recalculate expiry status if expiry date was updated
        if item_data.expiry_date is not None:
            is_expired, days_until_expiry = calculate_expiry_status(item.expiry_date)
            item.is_expired = is_expired
            item.days_until_expiry = days_until_expiry

        session.commit()
        session.refresh(item)
        return item


def delete_pantry_item(item_id: int) -> bool:
    """Delete a pantry item."""
    with get_session() as session:
        item = session.get(PantryItem, item_id)
        if item is None:
            return False

        session.delete(item)
        session.commit()
        return True


def get_expiry_alerts() -> List[ExpiryAlert]:
    """Get items that are expired or expiring soon."""
    items = get_all_pantry_items()
    alerts = []

    for item in items:
        if item.days_until_expiry is None:
            continue

        alert_level = None
        if item.days_until_expiry < 0:
            alert_level = "expired"
        elif item.days_until_expiry <= 3:
            alert_level = "critical"
        elif item.days_until_expiry <= 7:
            alert_level = "warning"

        if alert_level:
            alerts.append(
                ExpiryAlert(
                    item_id=item.id or 0,
                    item_name=item.name,
                    expiry_date=item.expiry_date.isoformat(),
                    days_until_expiry=item.days_until_expiry,
                    alert_level=alert_level,
                )
            )

    return alerts


def create_expiry_notifications() -> List[Notification]:
    """Create notifications for expired or soon-to-expire items."""
    alerts = get_expiry_alerts()
    notifications = []

    with get_session() as session:
        for alert in alerts:
            # Check if notification already exists for this item
            existing = session.exec(
                select(Notification).where(
                    Notification.related_item_id == alert.item_id,
                    Notification.notification_type.in_(["expired", "expiring_soon"]),
                    not Notification.is_dismissed,
                )
            ).first()

            if existing:
                continue

            if alert.alert_level == "expired":
                title = f"Item Expired: {alert.item_name}"
                message = f"{alert.item_name} expired {abs(alert.days_until_expiry)} days ago"
                notification_type = "expired"
                priority = "high"
            else:
                title = f"Item Expiring Soon: {alert.item_name}"
                message = f"{alert.item_name} expires in {alert.days_until_expiry} days"
                notification_type = "expiring_soon"
                priority = "medium" if alert.alert_level == "warning" else "high"

            notification = Notification(
                title=title,
                message=message,
                notification_type=notification_type,
                priority=priority,
                related_item_id=alert.item_id,
            )

            session.add(notification)
            session.commit()
            session.refresh(notification)
            notifications.append(notification)

        return notifications


def get_active_notifications() -> List[Notification]:
    """Get all active (non-dismissed) notifications."""
    with get_session() as session:
        statement = select(Notification).where(not Notification.is_dismissed).order_by(Notification.created_at.desc())

        return list(session.exec(statement).all())


def dismiss_notification(notification_id: int) -> bool:
    """Mark a notification as dismissed."""
    with get_session() as session:
        notification = session.get(Notification, notification_id)
        if notification is None:
            return False

        notification.is_dismissed = True
        session.commit()
        return True


def get_low_stock_items(threshold: Decimal = Decimal("1")) -> List[PantryItem]:
    """Get items with low stock based on quantity threshold."""
    with get_session() as session:
        statement = select(PantryItem).where(PantryItem.quantity <= threshold).order_by(PantryItem.quantity)

        return list(session.exec(statement).all())
