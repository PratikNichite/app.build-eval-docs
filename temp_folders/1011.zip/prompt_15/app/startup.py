from app.database import create_tables
import app.pantry_ui
import app.recipe_ui
import app.notifications_ui


def startup() -> None:
    # this function is called before the first request
    create_tables()

    # Register all UI modules
    app.pantry_ui.create()
    app.recipe_ui.create()
    app.notifications_ui.create()
