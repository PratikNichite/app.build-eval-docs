from sqlmodel import SQLModel, Field, Relationship, JSON, Column
from datetime import datetime, date
from typing import Optional, List
from decimal import Decimal


# Persistent models (stored in database)
class PantryItem(SQLModel, table=True):
    __tablename__ = "pantry_items"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=200)
    quantity: Decimal = Field(default=Decimal("0"), decimal_places=2, max_digits=10)
    unit: str = Field(max_length=50, default="piece")  # e.g., "kg", "lbs", "piece", "cup"
    expiry_date: date
    added_date: date = Field(default_factory=lambda: datetime.now().date())
    category: Optional[str] = Field(default=None, max_length=100)  # e.g., "dairy", "meat", "vegetables"
    location: Optional[str] = Field(default=None, max_length=100)  # e.g., "fridge", "pantry", "freezer"
    notes: Optional[str] = Field(default=None, max_length=500)
    is_expired: bool = Field(default=False)  # Computed field for quick filtering
    days_until_expiry: Optional[int] = Field(default=None)  # Computed field for sorting/filtering


class Recipe(SQLModel, table=True):
    __tablename__ = "recipes"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(max_length=200)
    description: Optional[str] = Field(default=None, max_length=1000)
    instructions: str = Field(max_length=5000)
    prep_time_minutes: Optional[int] = Field(default=None)
    cook_time_minutes: Optional[int] = Field(default=None)
    servings: Optional[int] = Field(default=None)
    difficulty_level: Optional[str] = Field(default=None, max_length=20)  # "easy", "medium", "hard"
    cuisine_type: Optional[str] = Field(default=None, max_length=100)
    tags: List[str] = Field(default=[], sa_column=Column(JSON))  # e.g., ["vegetarian", "quick", "healthy"]
    created_at: datetime = Field(default_factory=datetime.utcnow)

    ingredients: List["RecipeIngredient"] = Relationship(back_populates="recipe")


class RecipeIngredient(SQLModel, table=True):
    __tablename__ = "recipe_ingredients"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    recipe_id: int = Field(foreign_key="recipes.id")
    ingredient_name: str = Field(max_length=200)
    quantity: Decimal = Field(decimal_places=2, max_digits=10)
    unit: str = Field(max_length=50)
    is_optional: bool = Field(default=False)

    recipe: Recipe = Relationship(back_populates="ingredients")


class Notification(SQLModel, table=True):
    __tablename__ = "notifications"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    title: str = Field(max_length=200)
    message: str = Field(max_length=500)
    notification_type: str = Field(max_length=50)  # "expired", "expiring_soon", "low_stock", "recipe_suggestion"
    priority: str = Field(max_length=20, default="medium")  # "low", "medium", "high"
    is_read: bool = Field(default=False)
    is_dismissed: bool = Field(default=False)
    related_item_id: Optional[int] = Field(default=None, foreign_key="pantry_items.id")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: Optional[datetime] = Field(default=None)  # When notification should auto-expire


class RecipeSuggestion(SQLModel, table=True):
    __tablename__ = "recipe_suggestions"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    recipe_id: int = Field(foreign_key="recipes.id")
    suggested_at: datetime = Field(default_factory=datetime.utcnow)
    match_percentage: Decimal = Field(decimal_places=2, max_digits=5)  # 0.00 to 100.00
    available_ingredients: List[str] = Field(default=[], sa_column=Column(JSON))
    missing_ingredients: List[str] = Field(default=[], sa_column=Column(JSON))
    is_favorited: bool = Field(default=False)
    is_dismissed: bool = Field(default=False)


# Non-persistent schemas (for validation, forms, API requests/responses)
class PantryItemCreate(SQLModel, table=False):
    name: str = Field(max_length=200)
    quantity: Decimal = Field(decimal_places=2, max_digits=10)
    unit: str = Field(max_length=50, default="piece")
    expiry_date: date
    category: Optional[str] = Field(default=None, max_length=100)
    location: Optional[str] = Field(default=None, max_length=100)
    notes: Optional[str] = Field(default=None, max_length=500)


class PantryItemUpdate(SQLModel, table=False):
    name: Optional[str] = Field(default=None, max_length=200)
    quantity: Optional[Decimal] = Field(default=None, decimal_places=2, max_digits=10)
    unit: Optional[str] = Field(default=None, max_length=50)
    expiry_date: Optional[date] = Field(default=None)
    category: Optional[str] = Field(default=None, max_length=100)
    location: Optional[str] = Field(default=None, max_length=100)
    notes: Optional[str] = Field(default=None, max_length=500)


class RecipeCreate(SQLModel, table=False):
    name: str = Field(max_length=200)
    description: Optional[str] = Field(default=None, max_length=1000)
    instructions: str = Field(max_length=5000)
    prep_time_minutes: Optional[int] = Field(default=None)
    cook_time_minutes: Optional[int] = Field(default=None)
    servings: Optional[int] = Field(default=None)
    difficulty_level: Optional[str] = Field(default=None, max_length=20)
    cuisine_type: Optional[str] = Field(default=None, max_length=100)
    tags: List[str] = Field(default=[])


class RecipeIngredientCreate(SQLModel, table=False):
    ingredient_name: str = Field(max_length=200)
    quantity: Decimal = Field(decimal_places=2, max_digits=10)
    unit: str = Field(max_length=50)
    is_optional: bool = Field(default=False)


class NotificationCreate(SQLModel, table=False):
    title: str = Field(max_length=200)
    message: str = Field(max_length=500)
    notification_type: str = Field(max_length=50)
    priority: str = Field(max_length=20, default="medium")
    related_item_id: Optional[int] = Field(default=None)
    expires_at: Optional[datetime] = Field(default=None)


class PantryItemResponse(SQLModel, table=False):
    id: int
    name: str
    quantity: Decimal
    unit: str
    expiry_date: str  # Will be serialized as ISO format string
    added_date: str  # Will be serialized as ISO format string
    category: Optional[str]
    location: Optional[str]
    notes: Optional[str]
    is_expired: bool
    days_until_expiry: Optional[int]


class RecipeMatch(SQLModel, table=False):
    """Schema for recipe matching results"""

    recipe_id: int
    recipe_name: str
    match_percentage: Decimal
    available_ingredients: List[str]
    missing_ingredients: List[str]
    total_ingredients: int


class ExpiryAlert(SQLModel, table=False):
    """Schema for expiry alerts"""

    item_id: int
    item_name: str
    expiry_date: str
    days_until_expiry: int
    alert_level: str  # "expired", "critical", "warning"
