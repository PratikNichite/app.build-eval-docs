from nicegui import ui
from decimal import Decimal
from app.recipe_service import get_recipe_suggestions, get_recipe_by_id, create_sample_recipes


def create_recipe_match_card(recipe_match):
    """Create a card displaying a recipe match."""

    # Determine match color and emoji
    match_percentage = float(recipe_match.match_percentage)
    if match_percentage >= 80:
        match_color = "bg-green-100 border-green-500"
        match_text_color = "text-green-700"
        match_emoji = "🎯"
    elif match_percentage >= 60:
        match_color = "bg-blue-100 border-blue-500"
        match_text_color = "text-blue-700"
        match_emoji = "👍"
    elif match_percentage >= 40:
        match_color = "bg-yellow-100 border-yellow-500"
        match_text_color = "text-yellow-700"
        match_emoji = "🤔"
    else:
        match_color = "bg-orange-100 border-orange-500"
        match_text_color = "text-orange-700"
        match_emoji = "💡"

    with ui.card().classes(f"w-96 p-6 {match_color} border-l-4"):
        # Recipe header
        with ui.row().classes("items-center justify-between w-full mb-3"):
            ui.label(f"🍽️ {recipe_match.recipe_name}").classes("text-xl font-bold text-gray-800")
            ui.label(f"{match_emoji} {match_percentage:.0f}% match").classes(
                f"text-lg font-semibold {match_text_color}"
            )

        # Match details
        ui.label(f"📋 Total ingredients: {recipe_match.total_ingredients}").classes("text-sm text-gray-600 mb-2")

        # Available ingredients
        if recipe_match.available_ingredients:
            ui.label("✅ You have:").classes("text-sm font-semibold text-green-700 mb-1")
            for ingredient in recipe_match.available_ingredients[:3]:  # Show first 3
                ui.label(f"• {ingredient}").classes("text-sm text-green-600 ml-2")

            if len(recipe_match.available_ingredients) > 3:
                ui.label(f"... and {len(recipe_match.available_ingredients) - 3} more! 🎉").classes(
                    "text-sm text-green-600 ml-2 italic"
                )

        # Missing ingredients
        if recipe_match.missing_ingredients:
            ui.label("🛒 You need:").classes("text-sm font-semibold text-red-700 mb-1 mt-2")
            for ingredient in recipe_match.missing_ingredients[:3]:  # Show first 3
                ui.label(f"• {ingredient}").classes("text-sm text-red-600 ml-2")

            if len(recipe_match.missing_ingredients) > 3:
                ui.label(f"... and {len(recipe_match.missing_ingredients) - 3} more").classes(
                    "text-sm text-red-600 ml-2 italic"
                )

        # View recipe button
        ui.button(
            "👀 View Full Recipe", on_click=lambda recipe_id=recipe_match.recipe_id: show_full_recipe(recipe_id)
        ).classes("mt-4 bg-primary text-white")


async def show_full_recipe(recipe_id: int):
    """Show full recipe details in a dialog."""
    recipe = get_recipe_by_id(recipe_id)
    if recipe is None:
        ui.notify("❌ Recipe not found", type="negative")
        return

    with ui.dialog() as dialog, ui.card().classes("w-full max-w-2xl p-6"):
        # Recipe header
        ui.label(f"🍽️ {recipe.name}").classes("text-2xl font-bold text-gray-800 mb-2")

        if recipe.description:
            ui.label(f"📖 {recipe.description}").classes("text-gray-600 mb-4")

        # Recipe info
        with ui.row().classes("gap-4 mb-6"):
            if recipe.prep_time_minutes:
                with ui.chip("⏳ Prep", color="info").props("size=sm"):
                    ui.label(f"{recipe.prep_time_minutes} min")
            if recipe.cook_time_minutes:
                with ui.chip("🔥 Cook", color="warning").props("size=sm"):
                    ui.label(f"{recipe.cook_time_minutes} min")
            if recipe.servings:
                with ui.chip("👥 Servings", color="secondary").props("size=sm"):
                    ui.label(str(recipe.servings))
            if recipe.difficulty_level:
                difficulty_emoji = {"easy": "😊", "medium": "🤔", "hard": "💪"}.get(
                    recipe.difficulty_level.lower(), "⭐"
                )
                with ui.chip(f"{difficulty_emoji} Difficulty", color="accent").props("size=sm"):
                    ui.label(recipe.difficulty_level.capitalize())

        # Ingredients
        if recipe.ingredients:
            ui.label("🛒 Ingredients:").classes("text-lg font-semibold text-gray-700 mb-2")
            with ui.column().classes("mb-4"):
                for ingredient in recipe.ingredients:
                    optional_text = " (optional)" if ingredient.is_optional else ""
                    ui.label(
                        f"• {ingredient.quantity} {ingredient.unit} {ingredient.ingredient_name}{optional_text}"
                    ).classes("text-gray-700 ml-2")

        # Instructions
        ui.label("👨‍🍳 Instructions:").classes("text-lg font-semibold text-gray-700 mb-2")

        # Split instructions by newlines and number them
        instructions = recipe.instructions.split("\n")
        with ui.column().classes("mb-6"):
            for i, instruction in enumerate(instructions, 1):
                if instruction.strip():
                    ui.label(f"{i}. {instruction.strip()}").classes("text-gray-700 mb-1")

        # Close button
        ui.button("✖️ Close", on_click=lambda: dialog.close()).classes("bg-gray-500 text-white")

    await dialog


def create():
    """Create the recipe suggestions UI module."""

    @ui.page("/recipes")
    def recipes_page():
        # Navigation header
        with ui.row().classes("w-full items-center justify-between mb-6 p-4 bg-white shadow-sm rounded-lg"):
            with ui.row().classes("items-center gap-4"):
                ui.button("🏠 Home", on_click=lambda: ui.navigate.to("/")).props("flat")
                ui.label("🍽️ Recipe Suggestions").classes("text-3xl font-bold text-gray-800")
            with ui.row().classes("gap-2"):
                ui.button("🥫 Pantry", on_click=lambda: ui.navigate.to("/pantry")).classes(
                    "bg-primary text-white px-4 py-2"
                )
                ui.button("🔔 Notifications", on_click=lambda: ui.navigate.to("/notifications")).classes(
                    "bg-info text-white px-4 py-2"
                )

        # Container for dynamic content
        content_container = ui.column().classes("w-full")

        def load_recipes():
            content_container.clear()

            with content_container:
                ui.label("🧑‍🍳 Based on ingredients in your pantry:").classes("text-lg text-gray-600 mb-6")

                try:
                    # Show loading state
                    with ui.card().classes("w-full p-4 text-center bg-blue-50 mb-4"):
                        ui.spinner(size="lg")
                        ui.label("🔍 Finding delicious recipes for you...").classes("mt-2 text-blue-600")

                    # Ensure sample recipes exist
                    create_sample_recipes()

                    # Clear loading state
                    content_container.clear()

                    with content_container:
                        ui.label("🧑‍🍳 Based on ingredients in your pantry:").classes("text-lg text-gray-600 mb-6")

                        # Get recipe suggestions
                        suggestions = get_recipe_suggestions(min_match_percentage=Decimal("20"))

                        if not suggestions:
                            with ui.card().classes("w-full p-8 text-center bg-gray-50"):
                                ui.label("😔 No recipe suggestions available").classes("text-xl text-gray-600 mb-4")
                                ui.label("🥫 Add more items to your pantry to get recipe suggestions!").classes(
                                    "text-gray-500 mb-4"
                                )
                                ui.button("➕ Go to Pantry", on_click=lambda: ui.navigate.to("/pantry")).classes(
                                    "bg-primary text-white px-6 py-3"
                                )
                        else:
                            ui.label(f"🎉 Found {len(suggestions)} recipes you can make:").classes(
                                "text-lg font-semibold text-gray-700 mb-4"
                            )

                            # Filter buttons
                            with ui.row().classes("gap-2 mb-6"):
                                ui.button("📋 All Recipes", on_click=lambda: show_filtered_recipes(suggestions)).props(
                                    "outline size=sm"
                                )

                                high_match = [r for r in suggestions if r.match_percentage >= 80]
                                if high_match:
                                    ui.button(
                                        f"🎯 High Match ({len(high_match)})",
                                        on_click=lambda: show_filtered_recipes(high_match),
                                        color="positive",
                                    ).props("size=sm")

                                medium_match = [r for r in suggestions if 50 <= r.match_percentage < 80]
                                if medium_match:
                                    ui.button(
                                        f"👍 Medium Match ({len(medium_match)})",
                                        on_click=lambda: show_filtered_recipes(medium_match),
                                        color="info",
                                    ).props("size=sm")

                                low_match = [r for r in suggestions if r.match_percentage < 50]
                                if low_match:
                                    ui.button(
                                        f"💡 Low Match ({len(low_match)})",
                                        on_click=lambda: show_filtered_recipes(low_match),
                                        color="warning",
                                    ).props("size=sm")

                            # Recipes container
                            recipes_container = ui.row().classes("gap-6 flex-wrap")

                            def show_filtered_recipes(filtered_suggestions):
                                recipes_container.clear()
                                with recipes_container:
                                    for suggestion in filtered_suggestions:
                                        create_recipe_match_card(suggestion)

                            # Show all recipes initially
                            show_filtered_recipes(suggestions)

                            # Helpful tips
                            with ui.card().classes("w-full p-6 bg-blue-50 mt-8"):
                                ui.label("💡 Pro Tips:").classes("text-lg font-semibold text-blue-800 mb-3")
                                with ui.column().classes("gap-2"):
                                    ui.label("🎯 Recipes with 80%+ match use mostly ingredients you have").classes(
                                        "text-blue-700"
                                    )
                                    ui.label(
                                        '🔍 Check your pantry for similar ingredients (e.g., "tomatoes" vs "tomato")'
                                    ).classes("text-blue-700")
                                    ui.label("⭐ Optional ingredients don't affect the match percentage").classes(
                                        "text-blue-700"
                                    )
                                    ui.label("🥫 Add more items to your pantry to get better recipe matches").classes(
                                        "text-blue-700"
                                    )

                except Exception as e:
                    content_container.clear()
                    with content_container:
                        ui.notify(f"❌ Error loading recipes: {str(e)}", type="negative")
                        with ui.card().classes("w-full p-8 text-center bg-red-50"):
                            ui.label("😞 Error loading recipe suggestions").classes("text-xl text-red-600 mb-4")
                            ui.label("🔧 Please try again later or contact support if the problem persists.").classes(
                                "text-red-500"
                            )

        # Load initial content
        load_recipes()

        # Refresh button
        ui.button("🔄 Refresh Suggestions", on_click=load_recipes, icon="refresh").classes(
            "mt-6 bg-accent text-white px-4 py-2"
        )
