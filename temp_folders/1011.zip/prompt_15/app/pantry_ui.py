from nicegui import ui
from datetime import date, timedelta
from decimal import Decimal
from typing import Optional
from app.pantry_service import (
    get_all_pantry_items,
    add_pantry_item,
    update_pantry_item,
    delete_pantry_item,
    get_expiry_alerts,
)
from app.models import PantryItemCreate, PantryItemUpdate


# Modern color theme
def apply_modern_theme():
    ui.colors(
        primary="#2563eb",
        secondary="#64748b",
        accent="#10b981",
        positive="#10b981",
        negative="#ef4444",
        warning="#f59e0b",
        info="#3b82f6",
    )


class TextStyles:
    HEADING = "text-2xl font-bold text-gray-800 mb-4"
    SUBHEADING = "text-lg font-semibold text-gray-700 mb-2"
    BODY = "text-base text-gray-600 leading-relaxed"
    CAPTION = "text-sm text-gray-500"


def create_add_item_form(refresh_callback):
    """Create a form for adding new pantry items."""

    async def show_add_form():
        with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
            ui.label("➕ Add New Pantry Item").classes("text-xl font-bold mb-4")

            # Form inputs
            name_input = ui.input("🏷️ Item Name", placeholder="e.g., Tomatoes").classes("w-full mb-2")
            quantity_input = ui.number("📊 Quantity", value=1, precision=2).classes("w-full mb-2")
            unit_input = ui.select(
                ["piece", "kg", "g", "lbs", "cup", "tbsp", "tsp", "liter", "ml", "bottle", "can", "package"],
                value="piece",
                label="📏 Unit",
            ).classes("w-full mb-2")
            expiry_input = ui.date("📅 Expiry Date", value=(date.today() + timedelta(days=7)).isoformat()).classes(
                "w-full mb-2"
            )
            category_input = ui.select(
                ["vegetables", "fruits", "dairy", "meat", "pantry", "freezer", "beverages", "snacks", "other"],
                value="other",
                label="🏷️ Category",
            ).classes("w-full mb-2")
            location_input = ui.select(
                ["fridge", "pantry", "freezer", "countertop", "other"], value="pantry", label="📍 Location"
            ).classes("w-full mb-2")
            notes_input = ui.textarea("📝 Notes (optional)").classes("w-full mb-4").props("rows=2")

            async def submit_form():
                try:
                    if not name_input.value or not name_input.value.strip():
                        ui.notify("❌ Please enter an item name", type="negative")
                        return

                    if quantity_input.value is None or quantity_input.value <= 0:
                        ui.notify("❌ Please enter a valid quantity", type="negative")
                        return

                    # Parse expiry date
                    try:
                        expiry_date = date.fromisoformat(expiry_input.value) if expiry_input.value else date.today()
                    except ValueError:
                        ui.notify("❌ Please enter a valid expiry date", type="negative")
                        return

                    item_data = PantryItemCreate(
                        name=name_input.value.strip(),
                        quantity=Decimal(str(quantity_input.value)),
                        unit=unit_input.value or "piece",
                        expiry_date=expiry_date,
                        category=category_input.value if category_input.value != "other" else None,
                        location=location_input.value if location_input.value != "other" else None,
                        notes=notes_input.value.strip() if notes_input.value else None,
                    )

                    add_pantry_item(item_data)
                    ui.notify("✅ Item added successfully!", type="positive")
                    dialog.close()
                    refresh_callback()

                except Exception as e:
                    ui.notify(f"❌ Error adding item: {str(e)}", type="negative")

            # Form buttons
            with ui.row().classes("gap-2 justify-end w-full"):
                ui.button("❌ Cancel", on_click=lambda: dialog.close()).props("outline")
                ui.button("✅ Add Item", on_click=submit_form).classes("bg-primary text-white")

        await dialog

    ui.button("➕ Add New Item", on_click=show_add_form, icon="add").classes("bg-primary text-white px-4 py-2 mb-4")


def create_edit_item_form(item, refresh_callback):
    """Create a form for editing pantry items."""

    async def show_edit_form():
        with ui.dialog() as dialog, ui.card().classes("w-96 p-6"):
            ui.label(f"✏️ Edit {item.name}").classes("text-xl font-bold mb-4")

            # Form inputs with current values
            name_input = ui.input("🏷️ Item Name", value=item.name).classes("w-full mb-2")
            quantity_input = ui.number("📊 Quantity", value=float(item.quantity), precision=2).classes("w-full mb-2")
            unit_input = ui.select(
                ["piece", "kg", "g", "lbs", "cup", "tbsp", "tsp", "liter", "ml", "bottle", "can", "package"],
                value=item.unit,
                label="📏 Unit",
            ).classes("w-full mb-2")
            expiry_input = ui.date("📅 Expiry Date", value=item.expiry_date.isoformat()).classes("w-full mb-2")
            category_input = ui.select(
                ["vegetables", "fruits", "dairy", "meat", "pantry", "freezer", "beverages", "snacks", "other"],
                value=item.category or "other",
                label="🏷️ Category",
            ).classes("w-full mb-2")
            location_input = ui.select(
                ["fridge", "pantry", "freezer", "countertop", "other"],
                value=item.location or "other",
                label="📍 Location",
            ).classes("w-full mb-2")
            notes_input = ui.textarea("📝 Notes", value=item.notes or "").classes("w-full mb-4").props("rows=2")

            async def submit_form():
                try:
                    if not name_input.value or not name_input.value.strip():
                        ui.notify("❌ Please enter an item name", type="negative")
                        return

                    if quantity_input.value is None or quantity_input.value <= 0:
                        ui.notify("❌ Please enter a valid quantity", type="negative")
                        return

                    # Parse expiry date
                    try:
                        expiry_date = date.fromisoformat(expiry_input.value) if expiry_input.value else date.today()
                    except ValueError:
                        ui.notify("❌ Please enter a valid expiry date", type="negative")
                        return

                    item_data = PantryItemUpdate(
                        name=name_input.value.strip(),
                        quantity=Decimal(str(quantity_input.value)),
                        unit=unit_input.value,
                        expiry_date=expiry_date,
                        category=category_input.value if category_input.value != "other" else None,
                        location=location_input.value if location_input.value != "other" else None,
                        notes=notes_input.value.strip() if notes_input.value else None,
                    )

                    if item.id is not None:
                        update_pantry_item(item.id, item_data)
                        ui.notify("✅ Item updated successfully!", type="positive")
                        dialog.close()
                        refresh_callback()

                except Exception as e:
                    ui.notify(f"❌ Error updating item: {str(e)}", type="negative")

            # Form buttons
            with ui.row().classes("gap-2 justify-end w-full"):
                ui.button("❌ Cancel", on_click=lambda: dialog.close()).props("outline")
                ui.button("✅ Update Item", on_click=submit_form).classes("bg-primary text-white")

        await dialog

    return show_edit_form


def get_alert_color(days_until_expiry: Optional[int]) -> str:
    """Get color class based on expiry status."""
    if days_until_expiry is None:
        return "bg-gray-100"

    if days_until_expiry < 0:
        return "bg-red-100 border-l-4 border-red-500"
    elif days_until_expiry <= 3:
        return "bg-orange-100 border-l-4 border-orange-500"
    elif days_until_expiry <= 7:
        return "bg-yellow-100 border-l-4 border-yellow-500"
    else:
        return "bg-green-50"


def get_expiry_text(days_until_expiry: Optional[int]) -> tuple[str, str]:
    """Get expiry text and color."""
    if days_until_expiry is None:
        return "❓ Unknown", "text-gray-500"

    if days_until_expiry < 0:
        return f"💀 Expired {abs(days_until_expiry)} days ago", "text-red-600 font-semibold"
    elif days_until_expiry == 0:
        return "⚡ Expires today!", "text-red-600 font-semibold"
    elif days_until_expiry <= 3:
        return f"🔥 Expires in {days_until_expiry} days", "text-orange-600 font-semibold"
    elif days_until_expiry <= 7:
        return f"⚠️ Expires in {days_until_expiry} days", "text-yellow-600"
    else:
        return f"✅ Expires in {days_until_expiry} days", "text-green-600"


def create_pantry_item_card(item, refresh_callback):
    """Create a card displaying a pantry item."""
    alert_color = get_alert_color(item.days_until_expiry)
    expiry_text, expiry_color = get_expiry_text(item.days_until_expiry)

    with ui.card().classes(f"w-80 p-4 {alert_color}"):
        # Item header
        with ui.row().classes("items-center justify-between w-full mb-2"):
            ui.label(item.name).classes("text-lg font-semibold text-gray-800")
            with ui.row().classes("gap-1"):
                ui.button(icon="edit", on_click=create_edit_item_form(item, refresh_callback)).props(
                    "size=sm flat round"
                )

                async def confirm_delete():
                    result = await ui.dialog("🗑️ Delete Item", ["Yes, delete it", "Cancel"])
                    if result == "Yes, delete it" and item.id is not None:
                        if delete_pantry_item(item.id):
                            ui.notify(f"🗑️ {item.name} deleted", type="warning")
                            refresh_callback()
                        else:
                            ui.notify("❌ Error deleting item", type="negative")

                ui.button(icon="delete", on_click=confirm_delete, color="negative").props("size=sm flat round")

        # Item details
        ui.label(f"📊 {item.quantity} {item.unit}").classes("text-base text-gray-600 mb-1")
        ui.label(expiry_text).classes(f"text-sm {expiry_color} mb-2")

        # Category and location
        with ui.row().classes("gap-2 mb-2"):
            if item.category:
                category_emoji = {
                    "vegetables": "🥕",
                    "fruits": "🍎",
                    "dairy": "🥛",
                    "meat": "🥩",
                    "freezer": "🧊",
                    "beverages": "🥤",
                    "snacks": "🍿",
                }.get(item.category, "🏷️")
                ui.chip(f"{category_emoji} {item.category}", color="secondary").props("size=sm")
            if item.location:
                location_emoji = {"fridge": "❄️", "pantry": "🏠", "freezer": "🧊", "countertop": "🧑‍🍳"}.get(
                    item.location, "📍"
                )
                ui.chip(f"{location_emoji} {item.location}", color="info").props("size=sm")

        # Notes
        if item.notes:
            ui.label(f"📝 {item.notes}").classes("text-sm text-gray-600 italic")


def create_expiry_alerts_section():
    """Create a section showing expiry alerts."""
    alerts = get_expiry_alerts()

    if not alerts:
        return

    ui.label("⚠️ Expiry Alerts").classes("text-xl font-bold text-orange-600 mb-4")

    expired_items = [a for a in alerts if a.alert_level == "expired"]
    critical_items = [a for a in alerts if a.alert_level == "critical"]
    warning_items = [a for a in alerts if a.alert_level == "warning"]

    if expired_items:
        with ui.card().classes("w-full p-4 bg-red-100 border-l-4 border-red-500 mb-4"):
            ui.label(f"🚨 {len(expired_items)} Expired Items").classes("text-lg font-semibold text-red-800 mb-2")
            for alert in expired_items:
                ui.label(f"💀 {alert.item_name} (expired {abs(alert.days_until_expiry)} days ago)").classes(
                    "text-red-700"
                )

    if critical_items:
        with ui.card().classes("w-full p-4 bg-orange-100 border-l-4 border-orange-500 mb-4"):
            ui.label(f"⚡ {len(critical_items)} Items Expiring Soon").classes(
                "text-lg font-semibold text-orange-800 mb-2"
            )
            for alert in critical_items:
                ui.label(f"🔥 {alert.item_name} (expires in {alert.days_until_expiry} days)").classes("text-orange-700")

    if warning_items:
        with ui.card().classes("w-full p-4 bg-yellow-100 border-l-4 border-yellow-500 mb-4"):
            ui.label(f"⏰ {len(warning_items)} Items to Watch").classes("text-lg font-semibold text-yellow-800 mb-2")
            for alert in warning_items:
                ui.label(f"⚠️ {alert.item_name} (expires in {alert.days_until_expiry} days)").classes("text-yellow-700")


def create():
    """Create the pantry management UI module."""

    apply_modern_theme()

    @ui.page("/pantry")
    def pantry_page():
        # Navigation header
        with ui.row().classes("w-full items-center justify-between mb-6 p-4 bg-white shadow-sm rounded-lg"):
            with ui.row().classes("items-center gap-4"):
                ui.button("🏠 Home", on_click=lambda: ui.navigate.to("/")).props("flat")
                ui.label("🥫 My Pantry").classes("text-3xl font-bold text-gray-800")
            with ui.row().classes("gap-2"):
                ui.button("🍽️ Recipe Suggestions", on_click=lambda: ui.navigate.to("/recipes")).classes(
                    "bg-accent text-white px-4 py-2"
                )
                ui.button("🔔 Notifications", on_click=lambda: ui.navigate.to("/notifications")).classes(
                    "bg-info text-white px-4 py-2"
                )

        # Container for dynamic content
        content_container = ui.column().classes("w-full")

        def refresh_content():
            content_container.clear()
            with content_container:
                # Expiry alerts
                create_expiry_alerts_section()

                # Add new item form
                create_add_item_form(refresh_content)

                # Items grid
                items = get_all_pantry_items()

                if not items:
                    with ui.card().classes("w-full p-8 text-center bg-gray-50"):
                        ui.label("📦 No items in your pantry yet").classes("text-xl text-gray-600 mb-4")
                        ui.label("🎯 Add your first item to get started!").classes("text-gray-500")
                else:
                    ui.label(f"📋 All Items ({len(items)})").classes("text-xl font-semibold text-gray-700 mb-4")

                    # Filter buttons
                    with ui.row().classes("gap-2 mb-4"):
                        ui.button("📋 All", on_click=lambda: show_filtered_items(items)).props("outline size=sm")
                        expired_count = sum(
                            1 for item in items if item.days_until_expiry is not None and item.days_until_expiry < 0
                        )
                        if expired_count > 0:
                            ui.button(
                                f"💀 Expired ({expired_count})",
                                on_click=lambda: show_filtered_items(
                                    [
                                        item
                                        for item in items
                                        if item.days_until_expiry is not None and item.days_until_expiry < 0
                                    ]
                                ),
                                color="negative",
                            ).props("size=sm")

                        expiring_count = sum(
                            1
                            for item in items
                            if item.days_until_expiry is not None and 0 <= item.days_until_expiry <= 7
                        )
                        if expiring_count > 0:
                            ui.button(
                                f"🔥 Expiring Soon ({expiring_count})",
                                on_click=lambda: show_filtered_items(
                                    [
                                        item
                                        for item in items
                                        if item.days_until_expiry is not None and 0 <= item.days_until_expiry <= 7
                                    ]
                                ),
                                color="warning",
                            ).props("size=sm")

                    # Items container
                    items_container = ui.row().classes("gap-4 flex-wrap")

                    def show_filtered_items(filtered_items):
                        items_container.clear()
                        with items_container:
                            for item in filtered_items:
                                create_pantry_item_card(item, refresh_content)

                    # Show all items initially
                    show_filtered_items(items)

        # Initial content load
        refresh_content()

    # Navigation from home page
    @ui.page("/")
    def index():
        # Modern landing page
        with ui.column().classes("w-full max-w-4xl mx-auto p-8"):
            # Header
            with ui.row().classes("w-full items-center justify-center mb-8"):
                ui.label("🥫").classes("text-6xl mr-4")
                ui.label("Pantry Manager").classes("text-4xl font-bold text-gray-800")

            ui.label(
                "✨ Keep track of your pantry items, get expiry alerts, and discover recipes based on what you have!"
            ).classes("text-xl text-gray-600 text-center mb-8")

            # Feature cards
            with ui.row().classes("gap-6 justify-center mb-8"):
                with ui.card().classes("w-64 p-6 text-center bg-blue-50 hover:bg-blue-100 transition-colors"):
                    ui.icon("inventory", size="3em").classes("text-blue-600 mb-4")
                    ui.label("📦 Manage Items").classes("text-lg font-semibold text-gray-800 mb-2")
                    ui.label("Add, edit, and organize your pantry items with expiry tracking").classes("text-gray-600")

                with ui.card().classes("w-64 p-6 text-center bg-orange-50 hover:bg-orange-100 transition-colors"):
                    ui.icon("notifications", size="3em").classes("text-orange-600 mb-4")
                    ui.label("🔔 Expiry Alerts").classes("text-lg font-semibold text-gray-800 mb-2")
                    ui.label("Get notified about items that are expired or expiring soon").classes("text-gray-600")

                with ui.card().classes("w-64 p-6 text-center bg-green-50 hover:bg-green-100 transition-colors"):
                    ui.icon("restaurant", size="3em").classes("text-green-600 mb-4")
                    ui.label("🍽️ Recipe Ideas").classes("text-lg font-semibold text-gray-800 mb-2")
                    ui.label("Discover recipes based on ingredients you already have").classes("text-gray-600")

            # Action buttons
            with ui.row().classes("gap-4 justify-center"):
                ui.button("🥫 Manage My Pantry", on_click=lambda: ui.navigate.to("/pantry")).classes(
                    "bg-primary text-white px-8 py-3 text-lg"
                )
                ui.button("🍽️ View Recipe Suggestions", on_click=lambda: ui.navigate.to("/recipes")).classes(
                    "bg-accent text-white px-8 py-3 text-lg"
                )
