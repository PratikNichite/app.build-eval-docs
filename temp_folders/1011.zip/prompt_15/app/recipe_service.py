from typing import List
from decimal import Decimal
from sqlmodel import select
from app.database import get_session
from app.models import Recipe, RecipeIngredient, PantryItem, RecipeMatch
import re


def normalize_ingredient_name(name: str) -> str:
    """Normalize ingredient names for better matching."""
    # Convert to lowercase and remove extra spaces
    name = name.lower().strip()

    # Remove common words that don't affect matching
    words_to_remove = ["fresh", "dried", "chopped", "sliced", "diced", "minced", "organic"]
    for word in words_to_remove:
        name = re.sub(rf"\b{word}\b", "", name).strip()

    # Remove extra spaces
    name = re.sub(r"\s+", " ", name)

    return name


def find_ingredient_matches(pantry_items: List[PantryItem], recipe_ingredient: str) -> List[PantryItem]:
    """Find pantry items that match a recipe ingredient."""
    recipe_ingredient_norm = normalize_ingredient_name(recipe_ingredient)
    matches = []

    for item in pantry_items:
        item_name_norm = normalize_ingredient_name(item.name)

        # Check for exact match first
        if item_name_norm == recipe_ingredient_norm:
            matches.append(item)
            continue

        # Check if one contains the other
        if recipe_ingredient_norm in item_name_norm or item_name_norm in recipe_ingredient_norm:
            matches.append(item)
            continue

        # Check for common synonyms or variations
        synonyms = {
            "tomato": ["tomatoes", "tomato"],
            "onion": ["onions", "onion"],
            "potato": ["potatoes", "potato"],
            "bell pepper": ["pepper", "capsicum"],
            "chicken breast": ["chicken", "chicken fillet"],
            "ground beef": ["beef", "mince", "ground meat"],
        }

        for key, variants in synonyms.items():
            if (recipe_ingredient_norm in variants and any(v in item_name_norm for v in variants)) or (
                item_name_norm in variants and any(v in recipe_ingredient_norm for v in variants)
            ):
                matches.append(item)
                break

    return matches


def calculate_recipe_match(recipe: Recipe, pantry_items: List[PantryItem]) -> RecipeMatch:
    """Calculate how well a recipe matches available pantry items."""
    # Always get fresh ingredients from database to avoid detached instance issues
    with get_session() as session:
        fresh_recipe = session.get(Recipe, recipe.id)
        if not fresh_recipe or not fresh_recipe.ingredients:
            return RecipeMatch(
                recipe_id=recipe.id or 0,
                recipe_name=recipe.name,
                match_percentage=Decimal("0"),
                available_ingredients=[],
                missing_ingredients=[],
                total_ingredients=0,
            )

        ingredients = list(fresh_recipe.ingredients)

    available_ingredients = []
    missing_ingredients = []

    for ingredient in ingredients:
        matches = find_ingredient_matches(pantry_items, ingredient.ingredient_name)

        if matches:
            # Check if we have enough quantity (simplified check)
            has_sufficient = any(item.quantity >= ingredient.quantity for item in matches)
            if has_sufficient:
                available_ingredients.append(ingredient.ingredient_name)
            else:
                missing_ingredients.append(f"{ingredient.ingredient_name} (insufficient quantity)")
        else:
            if not ingredient.is_optional:
                missing_ingredients.append(ingredient.ingredient_name)

    total_ingredients = len(ingredients)
    match_percentage = Decimal("0")

    if total_ingredients > 0:
        available_count = len(available_ingredients)
        match_percentage = (Decimal(str(available_count)) / Decimal(str(total_ingredients))) * Decimal("100")

    return RecipeMatch(
        recipe_id=recipe.id or 0,
        recipe_name=recipe.name,
        match_percentage=match_percentage,
        available_ingredients=available_ingredients,
        missing_ingredients=missing_ingredients,
        total_ingredients=total_ingredients,
    )


def get_recipe_suggestions(min_match_percentage: Decimal = Decimal("30")) -> List[RecipeMatch]:
    """Get recipe suggestions based on available pantry items."""
    with get_session() as session:
        # Get all pantry items that are not expired
        pantry_statement = select(PantryItem).where(not PantryItem.is_expired, PantryItem.quantity > Decimal("0"))
        pantry_items = list(session.exec(pantry_statement).all())

        if not pantry_items:
            return []

        # Get all recipes with their ingredients
        recipe_statement = select(Recipe)
        recipes = list(session.exec(recipe_statement).all())

        suggestions = []
        for recipe in recipes:
            # Trigger loading of ingredients while session is active
            _ = recipe.ingredients
            match = calculate_recipe_match(recipe, pantry_items)
            if match.match_percentage >= min_match_percentage:
                suggestions.append(match)

        # Sort by match percentage (highest first)
        suggestions.sort(key=lambda x: x.match_percentage, reverse=True)

        return suggestions


def create_sample_recipes() -> None:
    """Create some sample recipes for demonstration."""
    with get_session() as session:
        # Check if recipes already exist
        existing = session.exec(select(Recipe)).first()
        if existing:
            return

        sample_recipes = [
            {
                "name": "Simple Tomato Pasta",
                "description": "Quick and easy pasta with tomatoes",
                "instructions": "1. Cook pasta according to package instructions\n2. Heat olive oil in a pan\n3. Add diced tomatoes and cook for 5 minutes\n4. Toss with cooked pasta\n5. Season with salt, pepper, and herbs",
                "prep_time_minutes": 10,
                "cook_time_minutes": 15,
                "servings": 4,
                "difficulty_level": "easy",
                "ingredients": [
                    {"ingredient_name": "pasta", "quantity": Decimal("400"), "unit": "g"},
                    {"ingredient_name": "tomatoes", "quantity": Decimal("3"), "unit": "piece"},
                    {"ingredient_name": "olive oil", "quantity": Decimal("2"), "unit": "tbsp"},
                    {"ingredient_name": "garlic", "quantity": Decimal("2"), "unit": "clove", "is_optional": True},
                ],
            },
            {
                "name": "Chicken Stir Fry",
                "description": "Healthy chicken and vegetable stir fry",
                "instructions": "1. Cut chicken into strips\n2. Heat oil in wok or large pan\n3. Stir fry chicken until cooked\n4. Add vegetables and cook until tender\n5. Season and serve with rice",
                "prep_time_minutes": 15,
                "cook_time_minutes": 10,
                "servings": 3,
                "difficulty_level": "easy",
                "ingredients": [
                    {"ingredient_name": "chicken breast", "quantity": Decimal("500"), "unit": "g"},
                    {"ingredient_name": "bell pepper", "quantity": Decimal("1"), "unit": "piece"},
                    {"ingredient_name": "onion", "quantity": Decimal("1"), "unit": "piece"},
                    {"ingredient_name": "soy sauce", "quantity": Decimal("3"), "unit": "tbsp"},
                    {"ingredient_name": "rice", "quantity": Decimal("200"), "unit": "g"},
                ],
            },
            {
                "name": "Vegetable Soup",
                "description": "Hearty and nutritious vegetable soup",
                "instructions": "1. Chop all vegetables\n2. Heat oil in large pot\n3. Sauté onions until soft\n4. Add other vegetables and stock\n5. Simmer for 30 minutes\n6. Season to taste",
                "prep_time_minutes": 20,
                "cook_time_minutes": 35,
                "servings": 6,
                "difficulty_level": "easy",
                "ingredients": [
                    {"ingredient_name": "carrots", "quantity": Decimal("2"), "unit": "piece"},
                    {"ingredient_name": "potatoes", "quantity": Decimal("3"), "unit": "piece"},
                    {"ingredient_name": "onion", "quantity": Decimal("1"), "unit": "piece"},
                    {"ingredient_name": "vegetable stock", "quantity": Decimal("1"), "unit": "liter"},
                    {"ingredient_name": "celery", "quantity": Decimal("2"), "unit": "stalk", "is_optional": True},
                ],
            },
        ]

        for recipe_data in sample_recipes:
            recipe = Recipe(
                name=recipe_data["name"],
                description=recipe_data["description"],
                instructions=recipe_data["instructions"],
                prep_time_minutes=recipe_data["prep_time_minutes"],
                cook_time_minutes=recipe_data["cook_time_minutes"],
                servings=recipe_data["servings"],
                difficulty_level=recipe_data["difficulty_level"],
            )

            session.add(recipe)
            session.commit()
            session.refresh(recipe)

            for ingredient_data in recipe_data["ingredients"]:
                ingredient = RecipeIngredient(
                    recipe_id=recipe.id or 0,
                    ingredient_name=ingredient_data["ingredient_name"],
                    quantity=ingredient_data["quantity"],
                    unit=ingredient_data["unit"],
                    is_optional=ingredient_data.get("is_optional", False),
                )
                session.add(ingredient)

            session.commit()


def get_all_recipes() -> List[Recipe]:
    """Get all recipes with their ingredients."""
    with get_session() as session:
        statement = select(Recipe).order_by(Recipe.name)
        recipes = list(session.exec(statement).all())
        # Trigger loading of ingredients while session is active
        for recipe in recipes:
            _ = recipe.ingredients
        return recipes


def get_recipe_by_id(recipe_id: int) -> Recipe | None:
    """Get a recipe by ID with its ingredients."""
    with get_session() as session:
        recipe = session.get(Recipe, recipe_id)
        if recipe:
            # Trigger loading of ingredients while session is active
            _ = recipe.ingredients
        return recipe
