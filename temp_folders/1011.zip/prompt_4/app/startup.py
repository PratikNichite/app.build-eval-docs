from app.database import create_tables
import app.trip_advisor


def startup() -> None:
    # this function is called before the first request
    create_tables()
    app.trip_advisor.create()
