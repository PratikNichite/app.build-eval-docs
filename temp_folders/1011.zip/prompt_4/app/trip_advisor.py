from nicegui import ui, app
from datetime import datetime, timedelta
from sqlmodel import Session
from app.database import ENGINE
from app.models import WeatherForecast, TripSuggestion
from app.weather_service import WeatherService, evaluate_trip_conditions


def create():
    @ui.page("/")
    async def index():
        # Apply modern theme
        ui.colors(
            primary="#2563eb",
            secondary="#64748b",
            accent="#10b981",
            positive="#10b981",
            negative="#ef4444",
            warning="#f59e0b",
            info="#3b82f6",
        )

        # Page layout
        with ui.column().classes("w-full max-w-4xl mx-auto p-6 gap-6"):
            # Header
            ui.label("🌤️ Trip Weather Advisor").classes("text-4xl font-bold text-center text-primary mb-2")
            ui.label("Get weather-based recommendations for your next trip").classes(
                "text-lg text-center text-gray-600 mb-8"
            )

            # Input form
            await create_weather_form()

            # Results container
            result_container = ui.column().classes("w-full")

            # Store reference for updates
            app.storage.client["result_container"] = result_container


async def create_weather_form():
    """Create the weather query form"""
    with ui.card().classes("w-full max-w-md mx-auto p-6 shadow-lg rounded-xl"):
        ui.label("Enter Destination").classes("text-xl font-semibold mb-4")

        city_input = ui.input(label="City Name", placeholder="e.g., London, Paris, Tokyo").classes("w-full mb-4")

        search_button = ui.button(
            "Check Weather & Get Suggestion", on_click=lambda: handle_weather_search(city_input.value, search_button)
        ).classes("w-full bg-primary text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-600 transition-colors")

        # Add enter key support
        city_input.on("keydown.enter", lambda: handle_weather_search(city_input.value, search_button))


async def handle_weather_search(city_name: str, button):
    """Handle weather search and display results"""
    if not city_name or not city_name.strip():
        ui.notify("Please enter a city name", type="warning")
        return

    city_name = city_name.strip()

    # Show loading state
    button.set_text("Searching...")
    button.disable()

    # Clear previous results
    result_container = app.storage.client.get("result_container")
    if result_container:
        result_container.clear()

    try:
        # Fetch weather data
        weather_data = await WeatherService.get_weather_forecast(city_name)

        if weather_data is None:
            show_error_result("City not found or weather data unavailable. Please check the city name and try again.")
            return

        # Evaluate trip conditions
        is_good_trip, suggestion_text, reasoning = evaluate_trip_conditions(weather_data)

        # Save to database
        with Session(ENGINE) as session:
            # Save weather forecast
            weather_forecast = WeatherForecast(
                city_name=weather_data.city_name,
                forecast_date=weather_data.forecast_date,
                max_temperature_celsius=weather_data.max_temperature_celsius,
                min_temperature_celsius=weather_data.min_temperature_celsius,
                precipitation_probability=weather_data.precipitation_probability,
                precipitation_sum_mm=weather_data.precipitation_sum_mm,
                weather_description=weather_data.weather_description,
                updated_at=datetime.utcnow(),
            )
            session.add(weather_forecast)
            session.commit()
            session.refresh(weather_forecast)

            # Save trip suggestion
            trip_suggestion = TripSuggestion(
                city_name=weather_data.city_name,
                forecast_date=weather_data.forecast_date,
                is_good_trip=is_good_trip,
                suggestion_text=suggestion_text,
                reasoning=reasoning,
                weather_forecast_id=weather_forecast.id,
            )
            session.add(trip_suggestion)
            session.commit()

        # Display results
        show_weather_result(weather_data, is_good_trip, suggestion_text, reasoning)

        ui.notify("Weather forecast retrieved successfully!", type="positive")

    except Exception as e:
        show_error_result(f"An error occurred while fetching weather data: {str(e)}")
        ui.notify("Failed to retrieve weather data", type="negative")

    finally:
        # Reset button
        button.set_text("Check Weather & Get Suggestion")
        button.enable()


def show_weather_result(weather_data, is_good_trip: bool, suggestion_text: str, reasoning: str):
    """Display weather results and trip suggestion"""
    result_container = app.storage.client.get("result_container")
    if not result_container:
        return

    with result_container:
        # Main suggestion card
        suggestion_color = "bg-green-50 border-green-200" if is_good_trip else "bg-red-50 border-red-200"
        with ui.card().classes(f"w-full p-6 {suggestion_color} border-2 rounded-xl mb-4"):
            ui.label(suggestion_text).classes("text-xl font-bold mb-2")
            ui.label(reasoning).classes("text-base text-gray-700")

        # Weather details card
        with ui.card().classes("w-full p-6 bg-white shadow-md rounded-xl"):
            ui.label(f"Weather Details for {weather_data.city_name}").classes("text-lg font-semibold mb-4")

            tomorrow = datetime.now() + timedelta(days=1)
            ui.label(f"📅 Date: {tomorrow.strftime('%A, %B %d, %Y')}").classes("text-base mb-2")

            with ui.row().classes("gap-8 mb-4"):
                with ui.column().classes("gap-2"):
                    ui.label("🌡️ Temperature").classes("font-medium text-gray-700")
                    ui.label(f"Max: {weather_data.max_temperature_celsius}°C").classes("text-base")
                    ui.label(f"Min: {weather_data.min_temperature_celsius}°C").classes("text-base")

                with ui.column().classes("gap-2"):
                    ui.label("🌧️ Precipitation").classes("font-medium text-gray-700")
                    ui.label(f"Probability: {weather_data.precipitation_probability}%").classes("text-base")
                    ui.label(f"Expected: {weather_data.precipitation_sum_mm}mm").classes("text-base")

            ui.label(f"📝 Conditions: {weather_data.weather_description}").classes("text-base text-gray-600 italic")

            # Trip criteria explanation
            with ui.expansion("Trip Evaluation Criteria", icon="info").classes("mt-4"):
                ui.markdown("""
                **A trip is considered "good" when:**
                - Maximum temperature is between 15°C and 25°C (comfortable range)
                - Precipitation probability is less than 30% (low chance of rain/snow)
                
                **Otherwise, the trip is considered less ideal due to:**
                - Too cold (< 15°C) or too hot (> 25°C) temperatures
                - High chance of precipitation (≥ 30%)
                """).classes("text-sm text-gray-600")


def show_error_result(error_message: str):
    """Display error message to user"""
    result_container = app.storage.client.get("result_container")
    if not result_container:
        return

    with result_container:
        with ui.card().classes("w-full p-6 bg-red-50 border-2 border-red-200 rounded-xl"):
            ui.label("❌ Unable to Get Weather Data").classes("text-xl font-bold text-red-700 mb-2")
            ui.label(error_message).classes("text-base text-red-600")

            ui.label("💡 Suggestions:").classes("font-medium text-red-700 mt-4 mb-2")
            with ui.column().classes("gap-1"):
                ui.label("• Check the spelling of the city name").classes("text-sm text-red-600")
                ui.label('• Try including the country (e.g., "London, UK")').classes("text-sm text-red-600")
                ui.label("• Ensure you have an internet connection").classes("text-sm text-red-600")
