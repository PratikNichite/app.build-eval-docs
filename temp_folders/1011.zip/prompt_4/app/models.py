from sqlmodel import SQLModel, Field
from datetime import datetime
from typing import Optional
from decimal import Decimal


# Persistent models (stored in database)
class WeatherForecast(SQLModel, table=True):
    """Weather forecast data for a specific city and date"""

    __tablename__ = "weather_forecasts"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    city_name: str = Field(max_length=100, index=True)
    forecast_date: datetime = Field(index=True)
    max_temperature_celsius: Decimal = Field(decimal_places=1)
    min_temperature_celsius: Decimal = Field(decimal_places=1)
    precipitation_probability: int = Field(ge=0, le=100)  # Percentage 0-100
    precipitation_sum_mm: Decimal = Field(decimal_places=2, default=Decimal("0"))
    weather_description: str = Field(max_length=200, default="")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class TripSuggestion(SQLModel, table=True):
    """Trip suggestion based on weather forecast"""

    __tablename__ = "trip_suggestions"  # type: ignore[assignment]

    id: Optional[int] = Field(default=None, primary_key=True)
    city_name: str = Field(max_length=100, index=True)
    forecast_date: datetime = Field(index=True)
    is_good_trip: bool = Field(index=True)
    suggestion_text: str = Field(max_length=500)
    reasoning: str = Field(max_length=1000, default="")
    weather_forecast_id: Optional[int] = Field(foreign_key="weather_forecasts.id")
    created_at: datetime = Field(default_factory=datetime.utcnow)


# Non-persistent schemas (for validation, forms, API requests/responses)
class WeatherQuery(SQLModel, table=False):
    """Input schema for weather query"""

    city_name: str = Field(min_length=1, max_length=100)


class WeatherForecastResponse(SQLModel, table=False):
    """Response schema for weather forecast data"""

    city_name: str
    forecast_date: str  # ISO format date string
    max_temperature_celsius: Decimal
    min_temperature_celsius: Decimal
    precipitation_probability: int
    precipitation_sum_mm: Decimal
    weather_description: str


class TripSuggestionResponse(SQLModel, table=False):
    """Response schema for trip suggestion"""

    city_name: str
    forecast_date: str  # ISO format date string
    is_good_trip: bool
    suggestion_text: str
    reasoning: str
    weather_details: WeatherForecastResponse


class WeatherForecastCreate(SQLModel, table=False):
    """Schema for creating weather forecast records"""

    city_name: str = Field(max_length=100)
    forecast_date: datetime
    max_temperature_celsius: Decimal
    min_temperature_celsius: Decimal
    precipitation_probability: int = Field(ge=0, le=100)
    precipitation_sum_mm: Decimal = Field(default=Decimal("0"))
    weather_description: str = Field(default="", max_length=200)


class TripSuggestionCreate(SQLModel, table=False):
    """Schema for creating trip suggestion records"""

    city_name: str = Field(max_length=100)
    forecast_date: datetime
    is_good_trip: bool
    suggestion_text: str = Field(max_length=500)
    reasoning: str = Field(default="", max_length=1000)
    weather_forecast_id: Optional[int] = None
