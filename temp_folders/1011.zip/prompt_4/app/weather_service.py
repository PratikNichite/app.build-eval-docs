import httpx
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Optional, Tuple
from app.models import WeatherForecastCreate


class WeatherService:
    """Service for fetching weather data from Open-Meteo API"""

    GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
    FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

    @classmethod
    async def get_coordinates(cls, city_name: str) -> Optional[Tuple[float, float]]:
        """Get latitude and longitude for a city name"""
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    cls.GEOCODING_URL, params={"name": city_name, "count": 1, "language": "en", "format": "json"}
                )
                response.raise_for_status()
                data = response.json()

                if data.get("results") and len(data["results"]) > 0:
                    result = data["results"][0]
                    return float(result["latitude"]), float(result["longitude"])
                return None

            except Exception:
                return None

    @classmethod
    async def get_weather_forecast(cls, city_name: str) -> Optional[WeatherForecastCreate]:
        """Fetch weather forecast for tomorrow for a given city"""
        coordinates = await cls.get_coordinates(city_name)
        if coordinates is None:
            return None

        latitude, longitude = coordinates
        tomorrow = datetime.now() + timedelta(days=1)
        tomorrow_date = tomorrow.strftime("%Y-%m-%d")

        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    cls.FORECAST_URL,
                    params={
                        "latitude": latitude,
                        "longitude": longitude,
                        "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum",
                        "start_date": tomorrow_date,
                        "end_date": tomorrow_date,
                        "timezone": "auto",
                    },
                )
                response.raise_for_status()
                data = response.json()

                daily = data.get("daily", {})
                if not daily or not daily.get("time"):
                    return None

                # Extract tomorrow's forecast data
                max_temp = daily.get("temperature_2m_max", [None])[0]
                min_temp = daily.get("temperature_2m_min", [None])[0]
                precip_prob = daily.get("precipitation_probability_max", [None])[0]
                precip_sum = daily.get("precipitation_sum", [None])[0]

                if max_temp is None or min_temp is None:
                    return None

                # Generate weather description based on data
                weather_desc = cls._generate_weather_description(max_temp, min_temp, precip_prob or 0, precip_sum or 0)

                return WeatherForecastCreate(
                    city_name=city_name,
                    forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
                    max_temperature_celsius=Decimal(str(max_temp)),
                    min_temperature_celsius=Decimal(str(min_temp)),
                    precipitation_probability=int(precip_prob or 0),
                    precipitation_sum_mm=Decimal(str(precip_sum or 0)),
                    weather_description=weather_desc,
                )

            except Exception:
                return None

    @classmethod
    def _generate_weather_description(
        cls, max_temp: float, min_temp: float, precip_prob: int, precip_sum: float
    ) -> str:
        """Generate a human-readable weather description"""
        temp_desc = ""
        if max_temp >= 25:
            temp_desc = "warm"
        elif max_temp >= 15:
            temp_desc = "mild"
        elif max_temp >= 5:
            temp_desc = "cool"
        else:
            temp_desc = "cold"

        precip_desc = ""
        if precip_prob >= 70:
            precip_desc = " with high chance of precipitation"
        elif precip_prob >= 40:
            precip_desc = " with some chance of precipitation"
        elif precip_prob >= 20:
            precip_desc = " with slight chance of precipitation"
        else:
            precip_desc = " with clear skies expected"

        return f"Expected to be {temp_desc} ({min_temp:.1f}°C - {max_temp:.1f}°C){precip_desc}"


def evaluate_trip_conditions(weather: WeatherForecastCreate) -> Tuple[bool, str, str]:
    """
    Evaluate if weather conditions are good for a trip.

    Returns:
        Tuple of (is_good_trip, suggestion_text, reasoning)
    """
    max_temp = float(weather.max_temperature_celsius)
    precip_prob = weather.precipitation_probability

    # Trip is good if temp is 15-25°C and precipitation probability is low (< 30%)
    temp_good = 15 <= max_temp <= 25
    precip_good = precip_prob < 30

    is_good_trip = temp_good and precip_good

    # Generate suggestion text
    if is_good_trip:
        suggestion_text = f"🎉 Great weather for your trip to {weather.city_name}! Perfect conditions expected."
    else:
        suggestion_text = (
            f"😢 Consider postponing your trip to {weather.city_name}. Weather conditions may not be ideal."
        )

    # Generate reasoning
    reasoning_parts = []

    if temp_good:
        reasoning_parts.append(f"🌡️ Temperature is comfortable ({max_temp:.1f}°C)")
    else:
        if max_temp < 15:
            reasoning_parts.append(f"❄️ Temperature is too cold ({max_temp:.1f}°C, below 15°C)")
        else:
            reasoning_parts.append(f"🔥 Temperature is too hot ({max_temp:.1f}°C, above 25°C)")

    if precip_good:
        reasoning_parts.append(f"☀️ Low precipitation risk ({precip_prob}%)")
    else:
        reasoning_parts.append(f"🌧️ High precipitation risk ({precip_prob}%)")

    reasoning = ". ".join(reasoning_parts) + "."

    return is_good_trip, suggestion_text, reasoning
