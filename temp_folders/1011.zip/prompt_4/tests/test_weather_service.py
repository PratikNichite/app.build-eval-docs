import pytest
from decimal import Decimal
from datetime import datetime, timedelta
from app.weather_service import WeatherService, evaluate_trip_conditions
from app.models import WeatherForecastCreate


class TestWeatherService:
    """Test weather service functionality"""

    @pytest.mark.asyncio
    async def test_get_coordinates_valid_city(self):
        """Test getting coordinates for a well-known city"""
        coordinates = await WeatherService.get_coordinates("London")
        assert coordinates is not None
        lat, lon = coordinates
        assert isinstance(lat, float)
        assert isinstance(lon, float)
        # London coordinates should be roughly around these values
        assert 51.0 < lat < 52.0
        assert -1.0 < lon < 1.0

    @pytest.mark.asyncio
    async def test_get_coordinates_invalid_city(self):
        """Test getting coordinates for invalid city"""
        coordinates = await WeatherService.get_coordinates("NonExistentCityXYZ123")
        assert coordinates is None

    @pytest.mark.asyncio
    async def test_get_coordinates_empty_string(self):
        """Test getting coordinates for empty string"""
        coordinates = await WeatherService.get_coordinates("")
        assert coordinates is None

    @pytest.mark.asyncio
    async def test_get_weather_forecast_valid_city(self):
        """Test getting weather forecast for a valid city"""
        forecast = await WeatherService.get_weather_forecast("London")
        assert forecast is not None
        assert isinstance(forecast, WeatherForecastCreate)
        assert forecast.city_name == "London"
        assert isinstance(forecast.max_temperature_celsius, Decimal)
        assert isinstance(forecast.min_temperature_celsius, Decimal)
        assert 0 <= forecast.precipitation_probability <= 100
        assert forecast.precipitation_sum_mm >= Decimal("0")
        assert forecast.weather_description != ""

        # Check that forecast is for tomorrow
        tomorrow = datetime.now() + timedelta(days=1)
        expected_date = tomorrow.replace(hour=0, minute=0, second=0, microsecond=0)
        assert forecast.forecast_date.date() == expected_date.date()

    @pytest.mark.asyncio
    async def test_get_weather_forecast_invalid_city(self):
        """Test getting weather forecast for invalid city"""
        forecast = await WeatherService.get_weather_forecast("NonExistentCityXYZ123")
        assert forecast is None

    def test_generate_weather_description_warm(self):
        """Test weather description generation for warm weather"""
        desc = WeatherService._generate_weather_description(28.0, 18.0, 10, 0.1)
        assert "warm" in desc.lower()
        assert "clear skies" in desc.lower()

    def test_generate_weather_description_cold(self):
        """Test weather description generation for cold weather"""
        desc = WeatherService._generate_weather_description(2.0, -3.0, 80, 5.0)
        assert "cold" in desc.lower()
        assert "high chance" in desc.lower()

    def test_generate_weather_description_mild(self):
        """Test weather description generation for mild weather"""
        desc = WeatherService._generate_weather_description(20.0, 12.0, 5, 0.0)
        assert "mild" in desc.lower()
        assert "clear skies" in desc.lower()


class TestTripEvaluation:
    """Test trip condition evaluation logic"""

    def test_evaluate_trip_conditions_good_weather(self):
        """Test evaluation for good trip conditions"""
        tomorrow = datetime.now() + timedelta(days=1)
        weather = WeatherForecastCreate(
            city_name="TestCity",
            forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
            max_temperature_celsius=Decimal("20.0"),
            min_temperature_celsius=Decimal("12.0"),
            precipitation_probability=15,
            precipitation_sum_mm=Decimal("0.1"),
            weather_description="Mild weather with clear skies",
        )

        is_good, suggestion, reasoning = evaluate_trip_conditions(weather)

        assert is_good
        assert "Great weather" in suggestion
        assert "TestCity" in suggestion
        assert "comfortable" in reasoning.lower()
        assert "low precipitation risk" in reasoning.lower()

    def test_evaluate_trip_conditions_too_cold(self):
        """Test evaluation for too cold conditions"""
        tomorrow = datetime.now() + timedelta(days=1)
        weather = WeatherForecastCreate(
            city_name="ColdCity",
            forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
            max_temperature_celsius=Decimal("10.0"),
            min_temperature_celsius=Decimal("3.0"),
            precipitation_probability=20,
            precipitation_sum_mm=Decimal("0.0"),
        )

        is_good, suggestion, reasoning = evaluate_trip_conditions(weather)

        assert not is_good
        assert "Consider postponing" in suggestion
        assert "ColdCity" in suggestion
        assert "too cold" in reasoning.lower()
        assert "below 15°c" in reasoning.lower()

    def test_evaluate_trip_conditions_too_hot(self):
        """Test evaluation for too hot conditions"""
        tomorrow = datetime.now() + timedelta(days=1)
        weather = WeatherForecastCreate(
            city_name="HotCity",
            forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
            max_temperature_celsius=Decimal("35.0"),
            min_temperature_celsius=Decimal("22.0"),
            precipitation_probability=10,
        )

        is_good, suggestion, reasoning = evaluate_trip_conditions(weather)

        assert not is_good
        assert "Consider postponing" in suggestion
        assert "too hot" in reasoning.lower()
        assert "above 25°c" in reasoning.lower()

    def test_evaluate_trip_conditions_high_precipitation(self):
        """Test evaluation for high precipitation risk"""
        tomorrow = datetime.now() + timedelta(days=1)
        weather = WeatherForecastCreate(
            city_name="RainyCity",
            forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
            max_temperature_celsius=Decimal("18.0"),
            min_temperature_celsius=Decimal("12.0"),
            precipitation_probability=60,
            precipitation_sum_mm=Decimal("8.5"),
        )

        is_good, suggestion, reasoning = evaluate_trip_conditions(weather)

        assert not is_good
        assert "Consider postponing" in suggestion
        assert "comfortable" in reasoning.lower()  # Temperature is good
        assert "high precipitation risk" in reasoning.lower()
        assert "60%" in reasoning

    def test_evaluate_trip_conditions_boundary_temp_good(self):
        """Test evaluation at temperature boundaries (good case)"""
        tomorrow = datetime.now() + timedelta(days=1)
        weather = WeatherForecastCreate(
            city_name="BoundaryCity",
            forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
            max_temperature_celsius=Decimal("15.0"),  # Exactly at lower boundary
            min_temperature_celsius=Decimal("8.0"),
            precipitation_probability=29,  # Just below 30%
        )

        is_good, suggestion, reasoning = evaluate_trip_conditions(weather)

        assert is_good
        assert "Great weather" in suggestion

    def test_evaluate_trip_conditions_boundary_temp_bad(self):
        """Test evaluation at temperature boundaries (bad case)"""
        tomorrow = datetime.now() + timedelta(days=1)
        weather = WeatherForecastCreate(
            city_name="BoundaryCity",
            forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
            max_temperature_celsius=Decimal("25.1"),  # Just above upper boundary
            min_temperature_celsius=Decimal("18.0"),
            precipitation_probability=25,
        )

        is_good, suggestion, reasoning = evaluate_trip_conditions(weather)

        assert not is_good
        assert "too hot" in reasoning.lower()

    def test_evaluate_trip_conditions_boundary_precipitation(self):
        """Test evaluation at precipitation boundary"""
        tomorrow = datetime.now() + timedelta(days=1)
        weather = WeatherForecastCreate(
            city_name="BoundaryCity",
            forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
            max_temperature_celsius=Decimal("20.0"),
            min_temperature_celsius=Decimal("12.0"),
            precipitation_probability=30,  # Exactly at boundary
        )

        is_good, suggestion, reasoning = evaluate_trip_conditions(weather)

        assert not is_good  # 30% is not < 30%
        assert "high precipitation risk" in reasoning.lower()
