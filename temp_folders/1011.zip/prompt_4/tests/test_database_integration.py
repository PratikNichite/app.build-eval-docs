import pytest
from decimal import Decimal
from datetime import datetime, timedelta
from sqlmodel import Session, select
from app.database import ENGINE, reset_db
from app.models import WeatherForecast, TripSuggestion


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


class TestDatabaseIntegration:
    """Test database operations for weather and trip data"""

    def test_create_weather_forecast(self, new_db):
        """Test creating and retrieving weather forecast"""
        tomorrow = datetime.now() + timedelta(days=1)

        with Session(ENGINE) as session:
            weather_forecast = WeatherForecast(
                city_name="London",
                forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
                max_temperature_celsius=Decimal("20.5"),
                min_temperature_celsius=Decimal("12.3"),
                precipitation_probability=25,
                precipitation_sum_mm=Decimal("2.1"),
                weather_description="Mild weather with some clouds",
                updated_at=datetime.utcnow(),
            )
            session.add(weather_forecast)
            session.commit()
            session.refresh(weather_forecast)

            # Verify forecast was created
            assert weather_forecast.id is not None
            assert weather_forecast.city_name == "London"
            assert weather_forecast.max_temperature_celsius == Decimal("20.5")
            assert weather_forecast.min_temperature_celsius == Decimal("12.3")
            assert weather_forecast.precipitation_probability == 25
            assert weather_forecast.precipitation_sum_mm == Decimal("2.1")

    def test_create_trip_suggestion(self, new_db):
        """Test creating and retrieving trip suggestion"""
        tomorrow = datetime.now() + timedelta(days=1)

        with Session(ENGINE) as session:
            # First create a weather forecast
            weather_forecast = WeatherForecast(
                city_name="Paris",
                forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
                max_temperature_celsius=Decimal("18.0"),
                min_temperature_celsius=Decimal("10.0"),
                precipitation_probability=15,
                precipitation_sum_mm=Decimal("0.5"),
                weather_description="Pleasant weather",
            )
            session.add(weather_forecast)
            session.commit()
            session.refresh(weather_forecast)

            # Create trip suggestion linked to weather forecast
            trip_suggestion = TripSuggestion(
                city_name="Paris",
                forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
                is_good_trip=True,
                suggestion_text="Great weather for your trip to Paris!",
                reasoning="Temperature is comfortable (18.0°C). Low precipitation risk (15%).",
                weather_forecast_id=weather_forecast.id,
            )
            session.add(trip_suggestion)
            session.commit()
            session.refresh(trip_suggestion)

            # Verify suggestion was created
            assert trip_suggestion.id is not None
            assert trip_suggestion.city_name == "Paris"
            assert trip_suggestion.is_good_trip is True
            assert "Great weather" in trip_suggestion.suggestion_text
            assert trip_suggestion.weather_forecast_id == weather_forecast.id

    def test_query_weather_by_city_and_date(self, new_db):
        """Test querying weather forecast by city and date"""
        tomorrow = datetime.now() + timedelta(days=1)
        forecast_date = tomorrow.replace(hour=0, minute=0, second=0, microsecond=0)

        with Session(ENGINE) as session:
            # Create multiple forecasts
            cities = ["London", "Paris", "Tokyo"]
            for city in cities:
                weather_forecast = WeatherForecast(
                    city_name=city,
                    forecast_date=forecast_date,
                    max_temperature_celsius=Decimal("20.0"),
                    min_temperature_celsius=Decimal("15.0"),
                    precipitation_probability=20,
                    precipitation_sum_mm=Decimal("1.0"),
                    weather_description=f"Weather for {city}",
                )
                session.add(weather_forecast)
            session.commit()

            # Query for specific city and date
            statement = select(WeatherForecast).where(
                WeatherForecast.city_name == "London", WeatherForecast.forecast_date == forecast_date
            )
            london_forecast = session.exec(statement).first()

            assert london_forecast is not None
            assert london_forecast.city_name == "London"
            assert london_forecast.forecast_date == forecast_date

    def test_query_trip_suggestions_by_city(self, new_db):
        """Test querying trip suggestions by city"""
        tomorrow = datetime.now() + timedelta(days=1)
        forecast_date = tomorrow.replace(hour=0, minute=0, second=0, microsecond=0)

        with Session(ENGINE) as session:
            # Create trip suggestions for different cities
            suggestions_data = [
                ("London", True, "Good trip to London"),
                ("Berlin", False, "Not ideal for Berlin"),
                ("Rome", True, "Perfect for Rome"),
            ]

            for city, is_good, text in suggestions_data:
                suggestion = TripSuggestion(
                    city_name=city,
                    forecast_date=forecast_date,
                    is_good_trip=is_good,
                    suggestion_text=text,
                    reasoning=f"Reasoning for {city}",
                )
                session.add(suggestion)
            session.commit()

            # Query good trips only
            statement = select(TripSuggestion).where(TripSuggestion.is_good_trip)
            good_trips = session.exec(statement).all()

            assert len(good_trips) == 2
            good_cities = {trip.city_name for trip in good_trips}
            assert good_cities == {"London", "Rome"}

    def test_weather_forecast_update_timestamp(self, new_db):
        """Test that updated_at timestamp works correctly"""
        tomorrow = datetime.now() + timedelta(days=1)

        with Session(ENGINE) as session:
            weather_forecast = WeatherForecast(
                city_name="Amsterdam",
                forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
                max_temperature_celsius=Decimal("17.0"),
                min_temperature_celsius=Decimal("9.0"),
                precipitation_probability=40,
                precipitation_sum_mm=Decimal("3.2"),
                weather_description="Cloudy with light rain",
            )
            session.add(weather_forecast)
            session.commit()
            session.refresh(weather_forecast)

            # Check timestamps were set
            assert weather_forecast.created_at is not None
            assert weather_forecast.updated_at is not None

            # Update the record
            original_updated_at = weather_forecast.updated_at
            weather_forecast.max_temperature_celsius = Decimal("19.0")
            weather_forecast.updated_at = datetime.utcnow()
            session.commit()
            session.refresh(weather_forecast)

            # Verify updated_at changed
            assert weather_forecast.updated_at > original_updated_at

    def test_decimal_precision_handling(self, new_db):
        """Test that decimal values are handled with correct precision"""
        tomorrow = datetime.now() + timedelta(days=1)

        with Session(ENGINE) as session:
            weather_forecast = WeatherForecast(
                city_name="TestCity",
                forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
                max_temperature_celsius=Decimal("23.7"),  # 1 decimal place
                min_temperature_celsius=Decimal("14.2"),
                precipitation_probability=33,
                precipitation_sum_mm=Decimal("5.75"),  # 2 decimal places
                weather_description="Test weather",
            )
            session.add(weather_forecast)
            session.commit()
            session.refresh(weather_forecast)

            # Verify decimal precision is maintained
            assert weather_forecast.max_temperature_celsius == Decimal("23.7")
            assert weather_forecast.min_temperature_celsius == Decimal("14.2")
            assert weather_forecast.precipitation_sum_mm == Decimal("5.75")

    def test_foreign_key_relationship(self, new_db):
        """Test foreign key relationship between weather forecast and trip suggestion"""
        tomorrow = datetime.now() + timedelta(days=1)

        with Session(ENGINE) as session:
            # Create weather forecast
            weather_forecast = WeatherForecast(
                city_name="Vienna",
                forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
                max_temperature_celsius=Decimal("22.0"),
                min_temperature_celsius=Decimal("13.0"),
                precipitation_probability=10,
                precipitation_sum_mm=Decimal("0.1"),
                weather_description="Sunny and pleasant",
            )
            session.add(weather_forecast)
            session.commit()
            session.refresh(weather_forecast)

            # Create trip suggestion with reference to weather forecast
            trip_suggestion = TripSuggestion(
                city_name="Vienna",
                forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
                is_good_trip=True,
                suggestion_text="Excellent weather for Vienna trip!",
                reasoning="Perfect temperature and no precipitation",
                weather_forecast_id=weather_forecast.id,
            )
            session.add(trip_suggestion)
            session.commit()
            session.refresh(trip_suggestion)

            # Verify foreign key relationship
            assert trip_suggestion.weather_forecast_id == weather_forecast.id

            # Query to verify relationship works
            statement = select(TripSuggestion).where(TripSuggestion.weather_forecast_id == weather_forecast.id)
            linked_suggestion = session.exec(statement).first()

            assert linked_suggestion is not None
            assert linked_suggestion.city_name == "Vienna"

    def test_multiple_forecasts_same_city_different_dates(self, new_db):
        """Test handling multiple forecasts for same city on different dates"""
        base_date = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)

        with Session(ENGINE) as session:
            # Create forecasts for same city on different dates
            for i in range(3):
                forecast_date = base_date + timedelta(days=i + 1)
                weather_forecast = WeatherForecast(
                    city_name="Munich",
                    forecast_date=forecast_date,
                    max_temperature_celsius=Decimal(str(20.0 + i)),
                    min_temperature_celsius=Decimal(str(12.0 + i)),
                    precipitation_probability=20 + (i * 10),
                    precipitation_sum_mm=Decimal(str(1.0 + i)),
                    weather_description=f"Day {i + 1} weather",
                )
                session.add(weather_forecast)
            session.commit()

            # Query all forecasts for Munich
            statement = (
                select(WeatherForecast)
                .where(WeatherForecast.city_name == "Munich")
                .order_by(WeatherForecast.forecast_date)
            )

            munich_forecasts = session.exec(statement).all()

            assert len(munich_forecasts) == 3
            # Verify they are in chronological order
            for i, forecast in enumerate(munich_forecasts):
                expected_date = base_date + timedelta(days=i + 1)
                assert forecast.forecast_date == expected_date
                assert forecast.max_temperature_celsius == Decimal(str(20.0 + i))
