import pytest
from decimal import Decimal
from datetime import datetime, timedelta
from nicegui import ui
from nicegui.testing import User
from app.models import WeatherForecastCreate
from app.database import reset_db
from app.weather_service import evaluate_trip_conditions


@pytest.fixture()
def new_db():
    reset_db()
    yield
    reset_db()


class TestTripAdvisorUI:
    """Test trip advisor user interface"""

    async def test_page_loads_correctly(self, user: User) -> None:
        """Test that the main page loads with correct elements"""
        await user.open("/")

        # Check header elements
        await user.should_see("Trip Weather Advisor")
        await user.should_see("Get weather-based recommendations")

        # Check form elements
        await user.should_see("Enter Destination")
        await user.should_see(ui.input)
        await user.should_see(ui.button)

    async def test_empty_city_input_validation(self, user: User) -> None:
        """Test validation for empty city input"""
        await user.open("/")

        # Try to search with empty input
        user.find("Check Weather & Get Suggestion").click()

        # Should show warning notification
        await user.should_see("Please enter a city name")

    async def test_whitespace_city_input_validation(self, user: User) -> None:
        """Test validation for whitespace-only city input"""
        await user.open("/")

        # Enter whitespace and search
        user.find(ui.input).type("   ")
        user.find("Check Weather & Get Suggestion").click()

        # Should show warning notification
        await user.should_see("Please enter a city name")

    async def test_invalid_city_search(self, user: User, new_db) -> None:
        """Test handling of invalid city search"""
        await user.open("/")

        # Enter invalid city and search
        user.find(ui.input).type("NonExistentCityXYZ123456")
        user.find("Check Weather & Get Suggestion").click()

        # Should show error message
        await user.should_see("City not found or weather data unavailable")
        await user.should_see("Check the spelling of the city name")

    async def test_successful_weather_search_real_api(self, user: User, new_db) -> None:
        """Test successful weather search with real API call"""
        await user.open("/")

        # Enter a well-known city and search
        user.find(ui.input).type("London")
        user.find("Check Weather & Get Suggestion").click()

        # Should eventually show success or results
        # This test verifies the API integration works
        # Results will vary based on actual weather, so we just check for key elements
        await user.should_see("Weather Details for London")

    async def test_enter_key_triggers_search(self, user: User) -> None:
        """Test that pressing Enter in input field triggers search"""
        await user.open("/")

        # Enter city name and press Enter
        input_element = user.find(ui.input)
        input_element.type("Paris")
        input_element.trigger("keydown.enter")

        # Should trigger search functionality
        # This is a smoke test to ensure the enter key functionality works
        pass

    async def test_ui_elements_present(self, user: User) -> None:
        """Test that all expected UI elements are present"""
        await user.open("/")

        # Check main structure elements
        await user.should_see("🌤️ Trip Weather Advisor")
        await user.should_see("Enter Destination")

        # Check input field
        input_elements = list(user.find(ui.input).elements)
        assert len(input_elements) == 1

        # Check button
        button_elements = list(user.find(ui.button).elements)
        assert len(button_elements) == 1


class TestTripAdvisorLogic:
    """Test business logic without UI interactions"""

    def test_temperature_evaluation_boundaries(self):
        """Test temperature evaluation at exact boundaries"""
        tomorrow = datetime.now() + timedelta(days=1)
        base_weather = WeatherForecastCreate(
            city_name="TestCity",
            forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
            max_temperature_celsius=Decimal("20.0"),
            min_temperature_celsius=Decimal("12.0"),
            precipitation_probability=20,
            precipitation_sum_mm=Decimal("0.1"),
        )

        # Test boundary conditions
        test_cases = [
            (Decimal("14.9"), False, "too cold"),  # Just below 15°C
            (Decimal("15.0"), True, "comfortable"),  # Exactly 15°C
            (Decimal("25.0"), True, "comfortable"),  # Exactly 25°C
            (Decimal("25.1"), False, "too hot"),  # Just above 25°C
        ]

        for temp, expected_temp_good, expected_text in test_cases:
            base_weather.max_temperature_celsius = temp
            is_good, suggestion, reasoning = evaluate_trip_conditions(base_weather)

            # Check if temperature evaluation matches expected
            if expected_temp_good and base_weather.precipitation_probability < 30:
                assert is_good, f"Should be good trip for temp {temp}"
                assert "comfortable" in reasoning.lower()
            elif not expected_temp_good:
                assert expected_text in reasoning.lower()

    def test_precipitation_evaluation_boundaries(self):
        """Test precipitation evaluation at exact boundaries"""
        tomorrow = datetime.now() + timedelta(days=1)
        base_weather = WeatherForecastCreate(
            city_name="TestCity",
            forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
            max_temperature_celsius=Decimal("20.0"),  # Good temperature
            min_temperature_celsius=Decimal("12.0"),
            precipitation_probability=25,
            precipitation_sum_mm=Decimal("0.1"),
        )

        # Test boundary conditions
        test_cases = [
            (29, True, "low precipitation risk"),  # Just below 30%
            (30, False, "high precipitation risk"),  # Exactly 30%
            (31, False, "high precipitation risk"),  # Just above 30%
        ]

        for precip_prob, expected_precip_good, expected_text in test_cases:
            base_weather.precipitation_probability = precip_prob
            is_good, suggestion, reasoning = evaluate_trip_conditions(base_weather)

            # Check precipitation evaluation
            assert expected_text in reasoning.lower()

            # Overall trip should be good only if both conditions are met
            temp_good = True  # Temperature is 20°C which is good
            expected_overall_good = temp_good and expected_precip_good
            assert is_good == expected_overall_good

    def test_combined_conditions_matrix(self):
        """Test evaluation with various combinations of conditions"""
        tomorrow = datetime.now() + timedelta(days=1)

        test_cases = [
            # (temp, precip_prob, expected_good, description)
            (20, 15, True, "Perfect conditions"),
            (10, 15, False, "Too cold despite low precipitation"),
            (30, 15, False, "Too hot despite low precipitation"),
            (20, 50, False, "Good temperature but high precipitation"),
            (10, 50, False, "Both temperature and precipitation are bad"),
            (15, 29, True, "Boundary case - both conditions just met"),
            (25, 29, True, "Upper temp boundary with low precipitation"),
        ]

        for temp, precip_prob, expected_good, description in test_cases:
            weather = WeatherForecastCreate(
                city_name="TestCity",
                forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
                max_temperature_celsius=Decimal(str(temp)),
                min_temperature_celsius=Decimal("10.0"),
                precipitation_probability=precip_prob,
                precipitation_sum_mm=Decimal("1.0"),
            )

            is_good, suggestion, reasoning = evaluate_trip_conditions(weather)
            assert is_good == expected_good, (
                f"Failed for {description}: temp={temp}, precip={precip_prob}, got={is_good}, reasoning={reasoning}"
            )

    def test_suggestion_text_format(self):
        """Test that suggestion text follows expected format"""
        tomorrow = datetime.now() + timedelta(days=1)

        # Test good conditions
        good_weather = WeatherForecastCreate(
            city_name="Paris",
            forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
            max_temperature_celsius=Decimal("20.0"),
            min_temperature_celsius=Decimal("12.0"),
            precipitation_probability=15,
            precipitation_sum_mm=Decimal("0.1"),
        )

        is_good, suggestion, reasoning = evaluate_trip_conditions(good_weather)

        assert is_good
        assert "🎉 Great weather for your trip to Paris" in suggestion
        assert "Perfect conditions expected" in suggestion

        # Test bad conditions
        bad_weather = WeatherForecastCreate(
            city_name="Berlin",
            forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
            max_temperature_celsius=Decimal("5.0"),
            min_temperature_celsius=Decimal("-2.0"),
            precipitation_probability=70,
            precipitation_sum_mm=Decimal("10.0"),
        )

        is_good, suggestion, reasoning = evaluate_trip_conditions(bad_weather)

        assert not is_good
        assert "😢 Consider postponing your trip to Berlin" in suggestion
        assert "Weather conditions may not be ideal" in suggestion

    def test_reasoning_includes_both_factors(self):
        """Test that reasoning mentions both temperature and precipitation"""
        tomorrow = datetime.now() + timedelta(days=1)

        weather = WeatherForecastCreate(
            city_name="TestCity",
            forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
            max_temperature_celsius=Decimal("18.0"),
            min_temperature_celsius=Decimal("10.0"),
            precipitation_probability=25,
            precipitation_sum_mm=Decimal("1.0"),
        )

        is_good, suggestion, reasoning = evaluate_trip_conditions(weather)

        # Reasoning should mention both temperature and precipitation
        assert "temperature" in reasoning.lower() or "18.0°c" in reasoning.lower()
        assert "precipitation" in reasoning.lower() or "25%" in reasoning

        # Should end with period
        assert reasoning.endswith(".")

    def test_decimal_temperature_handling(self):
        """Test that decimal temperatures are handled correctly"""
        tomorrow = datetime.now() + timedelta(days=1)

        weather = WeatherForecastCreate(
            city_name="TestCity",
            forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
            max_temperature_celsius=Decimal("24.7"),  # Decimal with fraction
            min_temperature_celsius=Decimal("15.3"),
            precipitation_probability=20,
            precipitation_sum_mm=Decimal("0.5"),
        )

        is_good, suggestion, reasoning = evaluate_trip_conditions(weather)

        # Should handle decimal temperatures correctly
        assert is_good  # 24.7°C is within 15-25°C range
        assert "24.7°c" in reasoning.lower()

    def test_weather_forecast_create_validation(self):
        """Test WeatherForecastCreate model validation"""
        tomorrow = datetime.now() + timedelta(days=1)

        # Valid weather forecast
        valid_weather = WeatherForecastCreate(
            city_name="London",
            forecast_date=tomorrow.replace(hour=0, minute=0, second=0, microsecond=0),
            max_temperature_celsius=Decimal("20.0"),
            min_temperature_celsius=Decimal("12.0"),
            precipitation_probability=25,
            precipitation_sum_mm=Decimal("1.5"),
            weather_description="Pleasant weather",
        )

        # Should be valid
        assert valid_weather.city_name == "London"
        assert valid_weather.max_temperature_celsius == Decimal("20.0")
        assert 0 <= valid_weather.precipitation_probability <= 100
